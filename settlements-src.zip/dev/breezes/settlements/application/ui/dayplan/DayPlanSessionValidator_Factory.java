package dev.breezes.settlements.application.ui.dayplan;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class DayPlanSessionValidator_Factory implements Factory<DayPlanSessionValidator> {
   public DayPlanSessionValidator get() {
      return newInstance();
   }

   public static DayPlanSessionValidator_Factory create() {
      return DayPlanSessionValidator_Factory.InstanceHolder.INSTANCE;
   }

   public static DayPlanSessionValidator newInstance() {
      return new DayPlanSessionValidator();
   }

   private static final class InstanceHolder {
      static final DayPlanSessionValidator_Factory INSTANCE = new DayPlanSessionValidator_Factory();
   }
}
