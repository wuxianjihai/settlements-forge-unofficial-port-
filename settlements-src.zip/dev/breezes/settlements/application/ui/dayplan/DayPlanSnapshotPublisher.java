package dev.breezes.settlements.application.ui.dayplan;

import dev.breezes.settlements.application.ui.dayplan.model.DayPlanSnapshot;
import dev.breezes.settlements.application.ui.sync.UiSnapshotPublisher;
import dev.breezes.settlements.application.ui.sync.session.UiSession;
import dev.breezes.settlements.domain.ai.planning.DayPlan;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.compat.NetworkHelper;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.infrastructure.network.features.ui.dayplan.packet.ClientBoundDayPlanSnapshotPacket;
import jakarta.inject.Inject;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.server.level.ServerPlayer;

public final class DayPlanSnapshotPublisher implements UiSnapshotPublisher {
   private static final int PUBLISH_INTERVAL_TICKS = ClockTicks.seconds((double)2.0F).getTicksAsInt();
   private final DayPlanSnapshotAssembler assembler;

   public void onSessionOpened(@Nonnull UiSession session, @Nonnull ServerPlayer player, @Nonnull BaseVillager villager, long gameTime, long dayTime) {
      this.publish(session, player, villager, gameTime, dayTime);
   }

   public void tick(@Nonnull UiSession session, @Nonnull ServerPlayer player, @Nonnull BaseVillager villager, long gameTime, long dayTime) {
      if (gameTime - session.getLastSentGameTime() >= (long)PUBLISH_INTERVAL_TICKS) {
         this.publish(session, player, villager, gameTime, dayTime);
      }
   }

   private void publish(@Nonnull UiSession session, @Nonnull ServerPlayer player, @Nonnull BaseVillager villager, long gameTime, long dayTime) {
      DayPlan dayPlan = villager.getDayPlan();
      if (dayPlan != null) {
         DayPlanSnapshot snapshot = this.assembler.assemble(dayPlan, villager, dayTime);
         NetworkHelper.sendToPlayer(player, new ClientBoundDayPlanSnapshotPacket(session.getSessionId(), snapshot));
         session.markSnapshotSent(gameTime);
      }
   }

   @Inject
   @Generated
   DayPlanSnapshotPublisher(DayPlanSnapshotAssembler assembler) {
      this.assembler = assembler;
   }
}
