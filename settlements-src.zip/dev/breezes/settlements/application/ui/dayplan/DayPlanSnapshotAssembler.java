package dev.breezes.settlements.application.ui.dayplan;

import dev.breezes.settlements.application.ui.dayplan.model.DayPlanSlotSnapshot;
import dev.breezes.settlements.application.ui.dayplan.model.DayPlanSlotVisualStatus;
import dev.breezes.settlements.application.ui.dayplan.model.DayPlanSnapshot;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.catalog.BehaviorDisplayMetadata;
import dev.breezes.settlements.domain.ai.catalog.BehaviorPlanningMetadata;
import dev.breezes.settlements.domain.ai.catalog.IBehaviorCatalog;
import dev.breezes.settlements.domain.ai.planning.DayPlan;
import dev.breezes.settlements.domain.ai.planning.PlanSlot;
import dev.breezes.settlements.domain.ai.planning.PlanSlotStatus;
import dev.breezes.settlements.domain.time.CivilTime;
import dev.breezes.settlements.domain.world.WorldCalendar;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Locale;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.resources.ResourceLocation;

@ServerScope
public final class DayPlanSnapshotAssembler {
   private static final ResourceLocation DEFAULT_ICON_ITEM_ID = new ResourceLocation("minecraft:clock");
   private final IBehaviorCatalog behaviorCatalog;

   public DayPlanSnapshot assemble(@Nonnull DayPlan dayPlan, @Nonnull BaseVillager villager, long dayTime) {
      int nowCivil = WorldCalendar.civilOffsetWithin(dayPlan.getCalendarDay(), dayTime);
      List<DayPlanSlotSnapshot> slots = dayPlan.getSlots().stream().map((slot) -> this.assembleSlot(slot, nowCivil)).toList();
      return DayPlanSnapshot.builder().dayNumber(dayPlan.getCalendarDay()).dayType(dayPlan.getDayType()).currentTime(formatTime(CivilTime.civilFromDayTime(dayTime))).planStatus(dayPlan.getStatus()).villagerEntityId(villager.m_19879_()).villagerName(villager.m_7755_().getString()).slots(slots).build();
   }

   private DayPlanSlotSnapshot assembleSlot(@Nonnull PlanSlot slot, int nowCivil) {
      BehaviorDisplayMetadata displayInfo = this.resolveDisplayInfo(slot);
      return DayPlanSlotSnapshot.builder().behaviorKey(slot.getBehaviorKey().id()).displayNameKey(displayInfo.displayNameKey()).formattedTime(formatTime(slot.getStartTick())).iconItemId(displayInfo.iconItemId()).status(resolveVisualStatus(slot, nowCivil)).description(this.resolveDescription(slot)).flexible(slot.isFlexible()).build();
   }

   private BehaviorDisplayMetadata resolveDisplayInfo(@Nonnull PlanSlot slot) {
      return (BehaviorDisplayMetadata)this.behaviorCatalog.getDisplayInfo(slot.getBehaviorKey()).orElseGet(() -> BehaviorDisplayMetadata.builder().displayNameKey("ui.settlements.dayplan.behavior.unknown").iconItemId(DEFAULT_ICON_ITEM_ID).build());
   }

   @Nullable
   private String resolveDescription(@Nonnull PlanSlot slot) {
      BehaviorPlanningMetadata metadata = (BehaviorPlanningMetadata)this.behaviorCatalog.getDescriptor(slot.getBehaviorKey()).orElse((Object)null);
      return metadata != null && metadata.getDescription() != null && !metadata.getDescription().isBlank() ? metadata.getDescription() : null;
   }

   private static DayPlanSlotVisualStatus resolveVisualStatus(@Nonnull PlanSlot slot, int nowCivil) {
      if (slot.getStatus() == PlanSlotStatus.ACTIVE) {
         return DayPlanSlotVisualStatus.ACTIVE;
      } else if (slot.getStatus() == PlanSlotStatus.COMPLETED) {
         return DayPlanSlotVisualStatus.COMPLETED;
      } else if (slot.getStatus() == PlanSlotStatus.SKIPPED) {
         return DayPlanSlotVisualStatus.SKIPPED;
      } else if (slot.getStatus() == PlanSlotStatus.INTERRUPTED) {
         return DayPlanSlotVisualStatus.INTERRUPTED;
      } else {
         return slot.getStartTick() < nowCivil ? DayPlanSlotVisualStatus.COMPLETED : DayPlanSlotVisualStatus.UPCOMING;
      }
   }

   private static String formatTime(int civilTick) {
      int hour = civilTick / 1000;
      int minute = civilTick % 1000 * 60 / 1000;
      return String.format(Locale.ROOT, "%02d:%02d", hour, minute);
   }

   @Inject
   @Generated
   DayPlanSnapshotAssembler(IBehaviorCatalog behaviorCatalog) {
      this.behaviorCatalog = behaviorCatalog;
   }
}
