package dev.breezes.settlements.application.ui.dayplan;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.domain.ai.catalog.IBehaviorCatalog;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class DayPlanSnapshotAssembler_Factory implements Factory<DayPlanSnapshotAssembler> {
   private final Provider<IBehaviorCatalog> behaviorCatalogProvider;

   private DayPlanSnapshotAssembler_Factory(Provider<IBehaviorCatalog> behaviorCatalogProvider) {
      this.behaviorCatalogProvider = behaviorCatalogProvider;
   }

   public DayPlanSnapshotAssembler get() {
      return newInstance((IBehaviorCatalog)this.behaviorCatalogProvider.get());
   }

   public static DayPlanSnapshotAssembler_Factory create(Provider<IBehaviorCatalog> behaviorCatalogProvider) {
      return new DayPlanSnapshotAssembler_Factory(behaviorCatalogProvider);
   }

   public static DayPlanSnapshotAssembler newInstance(IBehaviorCatalog behaviorCatalog) {
      return new DayPlanSnapshotAssembler(behaviorCatalog);
   }
}
