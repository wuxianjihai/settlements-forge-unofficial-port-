package dev.breezes.settlements.application.ui.dayplan.model;

import dev.breezes.settlements.domain.ai.planning.PlanStatus;
import dev.breezes.settlements.domain.ai.schedule.PlanDayType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nonnull;
import lombok.Generated;

public record DayPlanSnapshot(long dayNumber, @Nonnull PlanDayType dayType, @Nonnull String currentTime, @Nonnull PlanStatus planStatus, int villagerEntityId, @Nonnull String villagerName, @Nonnull List<DayPlanSlotSnapshot> slots) {
   @Generated
   public static DayPlanSnapshotBuilder builder() {
      return new DayPlanSnapshotBuilder();
   }

   @Generated
   public static class DayPlanSnapshotBuilder {
      @Generated
      private long dayNumber;
      @Generated
      private PlanDayType dayType;
      @Generated
      private String currentTime;
      @Generated
      private PlanStatus planStatus;
      @Generated
      private int villagerEntityId;
      @Generated
      private String villagerName;
      @Generated
      private ArrayList<DayPlanSlotSnapshot> slots;

      @Generated
      DayPlanSnapshotBuilder() {
      }

      @Generated
      public DayPlanSnapshotBuilder dayNumber(long dayNumber) {
         this.dayNumber = dayNumber;
         return this;
      }

      @Generated
      public DayPlanSnapshotBuilder dayType(@Nonnull PlanDayType dayType) {
         if (dayType == null) {
            throw new NullPointerException("dayType is marked non-null but is null");
         } else {
            this.dayType = dayType;
            return this;
         }
      }

      @Generated
      public DayPlanSnapshotBuilder currentTime(@Nonnull String currentTime) {
         if (currentTime == null) {
            throw new NullPointerException("currentTime is marked non-null but is null");
         } else {
            this.currentTime = currentTime;
            return this;
         }
      }

      @Generated
      public DayPlanSnapshotBuilder planStatus(@Nonnull PlanStatus planStatus) {
         if (planStatus == null) {
            throw new NullPointerException("planStatus is marked non-null but is null");
         } else {
            this.planStatus = planStatus;
            return this;
         }
      }

      @Generated
      public DayPlanSnapshotBuilder villagerEntityId(int villagerEntityId) {
         this.villagerEntityId = villagerEntityId;
         return this;
      }

      @Generated
      public DayPlanSnapshotBuilder villagerName(@Nonnull String villagerName) {
         if (villagerName == null) {
            throw new NullPointerException("villagerName is marked non-null but is null");
         } else {
            this.villagerName = villagerName;
            return this;
         }
      }

      @Generated
      public DayPlanSnapshotBuilder slot(DayPlanSlotSnapshot slot) {
         if (this.slots == null) {
            this.slots = new ArrayList();
         }

         this.slots.add(slot);
         return this;
      }

      @Generated
      public DayPlanSnapshotBuilder slots(Collection<? extends DayPlanSlotSnapshot> slots) {
         if (slots == null) {
            throw new NullPointerException("slots cannot be null");
         } else {
            if (this.slots == null) {
               this.slots = new ArrayList();
            }

            this.slots.addAll(slots);
            return this;
         }
      }

      @Generated
      public DayPlanSnapshotBuilder clearSlots() {
         if (this.slots != null) {
            this.slots.clear();
         }

         return this;
      }

      @Generated
      public DayPlanSnapshot build() {
         List<DayPlanSlotSnapshot> slots;
         switch (this.slots == null ? 0 : this.slots.size()) {
            case 0 -> slots = Collections.emptyList();
            case 1 -> slots = Collections.singletonList((DayPlanSlotSnapshot)this.slots.get(0));
            default -> slots = Collections.unmodifiableList(new ArrayList(this.slots));
         }

         return new DayPlanSnapshot(this.dayNumber, this.dayType, this.currentTime, this.planStatus, this.villagerEntityId, this.villagerName, slots);
      }

      @Generated
      public String toString() {
         long var10000 = this.dayNumber;
         return "DayPlanSnapshot.DayPlanSnapshotBuilder(dayNumber=" + var10000 + ", dayType=" + String.valueOf(this.dayType) + ", currentTime=" + this.currentTime + ", planStatus=" + String.valueOf(this.planStatus) + ", villagerEntityId=" + this.villagerEntityId + ", villagerName=" + this.villagerName + ", slots=" + String.valueOf(this.slots) + ")";
      }
   }
}
