package dev.breezes.settlements.application.ui.dayplan.model;

public enum DayPlanSlotVisualStatus {
   COMPLETED,
   ACTIVE,
   UPCOMING,
   SKIPPED,
   INTERRUPTED;

   // $FF: synthetic method
   private static DayPlanSlotVisualStatus[] $values() {
      return new DayPlanSlotVisualStatus[]{COMPLETED, ACTIVE, UPCOMING, SKIPPED, INTERRUPTED};
   }
}
