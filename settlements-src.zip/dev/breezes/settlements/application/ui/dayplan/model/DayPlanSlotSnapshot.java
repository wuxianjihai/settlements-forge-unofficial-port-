package dev.breezes.settlements.application.ui.dayplan.model;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.resources.ResourceLocation;

public record DayPlanSlotSnapshot(@Nonnull String behaviorKey, @Nonnull String displayNameKey, @Nonnull String formattedTime, @Nonnull ResourceLocation iconItemId, @Nonnull DayPlanSlotVisualStatus status, @Nullable String description, boolean flexible) {
   @Generated
   public static DayPlanSlotSnapshotBuilder builder() {
      return new DayPlanSlotSnapshotBuilder();
   }

   @Generated
   public static class DayPlanSlotSnapshotBuilder {
      @Generated
      private String behaviorKey;
      @Generated
      private String displayNameKey;
      @Generated
      private String formattedTime;
      @Generated
      private ResourceLocation iconItemId;
      @Generated
      private DayPlanSlotVisualStatus status;
      @Generated
      private String description;
      @Generated
      private boolean flexible;

      @Generated
      DayPlanSlotSnapshotBuilder() {
      }

      @Generated
      public DayPlanSlotSnapshotBuilder behaviorKey(@Nonnull String behaviorKey) {
         if (behaviorKey == null) {
            throw new NullPointerException("behaviorKey is marked non-null but is null");
         } else {
            this.behaviorKey = behaviorKey;
            return this;
         }
      }

      @Generated
      public DayPlanSlotSnapshotBuilder displayNameKey(@Nonnull String displayNameKey) {
         if (displayNameKey == null) {
            throw new NullPointerException("displayNameKey is marked non-null but is null");
         } else {
            this.displayNameKey = displayNameKey;
            return this;
         }
      }

      @Generated
      public DayPlanSlotSnapshotBuilder formattedTime(@Nonnull String formattedTime) {
         if (formattedTime == null) {
            throw new NullPointerException("formattedTime is marked non-null but is null");
         } else {
            this.formattedTime = formattedTime;
            return this;
         }
      }

      @Generated
      public DayPlanSlotSnapshotBuilder iconItemId(@Nonnull ResourceLocation iconItemId) {
         if (iconItemId == null) {
            throw new NullPointerException("iconItemId is marked non-null but is null");
         } else {
            this.iconItemId = iconItemId;
            return this;
         }
      }

      @Generated
      public DayPlanSlotSnapshotBuilder status(@Nonnull DayPlanSlotVisualStatus status) {
         if (status == null) {
            throw new NullPointerException("status is marked non-null but is null");
         } else {
            this.status = status;
            return this;
         }
      }

      @Generated
      public DayPlanSlotSnapshotBuilder description(@Nullable String description) {
         this.description = description;
         return this;
      }

      @Generated
      public DayPlanSlotSnapshotBuilder flexible(boolean flexible) {
         this.flexible = flexible;
         return this;
      }

      @Generated
      public DayPlanSlotSnapshot build() {
         return new DayPlanSlotSnapshot(this.behaviorKey, this.displayNameKey, this.formattedTime, this.iconItemId, this.status, this.description, this.flexible);
      }

      @Generated
      public String toString() {
         String var10000 = this.behaviorKey;
         return "DayPlanSlotSnapshot.DayPlanSlotSnapshotBuilder(behaviorKey=" + var10000 + ", displayNameKey=" + this.displayNameKey + ", formattedTime=" + this.formattedTime + ", iconItemId=" + String.valueOf(this.iconItemId) + ", status=" + String.valueOf(this.status) + ", description=" + this.description + ", flexible=" + this.flexible + ")";
      }
   }
}
