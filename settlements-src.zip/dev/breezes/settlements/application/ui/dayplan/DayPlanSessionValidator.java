package dev.breezes.settlements.application.ui.dayplan;

import dev.breezes.settlements.application.ui.sync.UiSessionValidator;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class DayPlanSessionValidator implements UiSessionValidator {
   public Optional<String> validate(@Nonnull BaseVillager villager) {
      return villager.getDayPlan() == null ? Optional.of("ui.settlements.dayplan.no_plan") : Optional.empty();
   }
}
