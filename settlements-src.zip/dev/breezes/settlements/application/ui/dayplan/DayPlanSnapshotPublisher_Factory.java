package dev.breezes.settlements.application.ui.dayplan;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class DayPlanSnapshotPublisher_Factory implements Factory<DayPlanSnapshotPublisher> {
   private final Provider<DayPlanSnapshotAssembler> assemblerProvider;

   private DayPlanSnapshotPublisher_Factory(Provider<DayPlanSnapshotAssembler> assemblerProvider) {
      this.assemblerProvider = assemblerProvider;
   }

   public DayPlanSnapshotPublisher get() {
      return newInstance((DayPlanSnapshotAssembler)this.assemblerProvider.get());
   }

   public static DayPlanSnapshotPublisher_Factory create(Provider<DayPlanSnapshotAssembler> assemblerProvider) {
      return new DayPlanSnapshotPublisher_Factory(assemblerProvider);
   }

   public static DayPlanSnapshotPublisher newInstance(DayPlanSnapshotAssembler assembler) {
      return new DayPlanSnapshotPublisher(assembler);
   }
}
