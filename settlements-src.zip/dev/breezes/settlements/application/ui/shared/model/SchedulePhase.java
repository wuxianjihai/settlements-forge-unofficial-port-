package dev.breezes.settlements.application.ui.shared.model;

public enum SchedulePhase {
   REST,
   WORK,
   MEET,
   IDLE,
   UNKNOWN;

   // $FF: synthetic method
   private static SchedulePhase[] $values() {
      return new SchedulePhase[]{REST, WORK, MEET, IDLE, UNKNOWN};
   }
}
