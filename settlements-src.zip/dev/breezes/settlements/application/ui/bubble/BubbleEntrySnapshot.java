package dev.breezes.settlements.application.ui.bubble;

import java.util.List;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public record BubbleEntrySnapshot(@Nonnull UUID bubbleId, @Nonnull BubbleChannel channel, @Nullable String ownerKey, int priority, long expireGameTime, long createdGameTime, long sequenceNumber, int contentVersion, @Nonnull String sourceType, @Nonnull List<BubbleSegment> segments) {
   public BubbleEntrySnapshot(@Nonnull UUID bubbleId, @Nonnull BubbleChannel channel, @Nullable String ownerKey, int priority, long expireGameTime, long createdGameTime, long sequenceNumber, int contentVersion, @Nonnull String sourceType, @Nonnull List<BubbleSegment> segments) {
      segments = List.copyOf(segments);
      if (createdGameTime < 0L) {
         throw new IllegalArgumentException("createdGameTime must be >= 0");
      } else if (expireGameTime <= createdGameTime) {
         throw new IllegalArgumentException("expireGameTime must be > createdGameTime");
      } else if (sequenceNumber < 0L) {
         throw new IllegalArgumentException("sequenceNumber must be >= 0");
      } else if (ownerKey != null && ownerKey.isBlank()) {
         throw new IllegalArgumentException("ownerKey must not be blank");
      } else if (sourceType.isBlank()) {
         throw new IllegalArgumentException("sourceType must not be blank");
      } else if (segments.isEmpty()) {
         throw new IllegalArgumentException("segments must not be empty");
      } else {
         this.bubbleId = bubbleId;
         this.channel = channel;
         this.ownerKey = ownerKey;
         this.priority = priority;
         this.expireGameTime = expireGameTime;
         this.createdGameTime = createdGameTime;
         this.sequenceNumber = sequenceNumber;
         this.contentVersion = contentVersion;
         this.sourceType = sourceType;
         this.segments = segments;
      }
   }

   public static BubbleEntrySnapshot fromEntry(@Nonnull BubbleEntry entry) {
      return builder().bubbleId(entry.bubbleId()).channel(entry.channel()).ownerKey(entry.ownerKey()).priority(entry.message().getPriority()).expireGameTime(entry.expireGameTime()).createdGameTime(entry.createdGameTime()).sequenceNumber(entry.sequenceNumber()).contentVersion(entry.contentVersion()).sourceType(entry.message().getSourceType()).segments(entry.message().getSegments()).build();
   }

   @Generated
   public static BubbleEntrySnapshotBuilder builder() {
      return new BubbleEntrySnapshotBuilder();
   }

   @Generated
   public static class BubbleEntrySnapshotBuilder {
      @Generated
      private UUID bubbleId;
      @Generated
      private BubbleChannel channel;
      @Generated
      private String ownerKey;
      @Generated
      private int priority;
      @Generated
      private long expireGameTime;
      @Generated
      private long createdGameTime;
      @Generated
      private long sequenceNumber;
      @Generated
      private int contentVersion;
      @Generated
      private String sourceType;
      @Generated
      private List<BubbleSegment> segments;

      @Generated
      BubbleEntrySnapshotBuilder() {
      }

      @Generated
      public BubbleEntrySnapshotBuilder bubbleId(@Nonnull UUID bubbleId) {
         if (bubbleId == null) {
            throw new NullPointerException("bubbleId is marked non-null but is null");
         } else {
            this.bubbleId = bubbleId;
            return this;
         }
      }

      @Generated
      public BubbleEntrySnapshotBuilder channel(@Nonnull BubbleChannel channel) {
         if (channel == null) {
            throw new NullPointerException("channel is marked non-null but is null");
         } else {
            this.channel = channel;
            return this;
         }
      }

      @Generated
      public BubbleEntrySnapshotBuilder ownerKey(@Nullable String ownerKey) {
         this.ownerKey = ownerKey;
         return this;
      }

      @Generated
      public BubbleEntrySnapshotBuilder priority(int priority) {
         this.priority = priority;
         return this;
      }

      @Generated
      public BubbleEntrySnapshotBuilder expireGameTime(long expireGameTime) {
         this.expireGameTime = expireGameTime;
         return this;
      }

      @Generated
      public BubbleEntrySnapshotBuilder createdGameTime(long createdGameTime) {
         this.createdGameTime = createdGameTime;
         return this;
      }

      @Generated
      public BubbleEntrySnapshotBuilder sequenceNumber(long sequenceNumber) {
         this.sequenceNumber = sequenceNumber;
         return this;
      }

      @Generated
      public BubbleEntrySnapshotBuilder contentVersion(int contentVersion) {
         this.contentVersion = contentVersion;
         return this;
      }

      @Generated
      public BubbleEntrySnapshotBuilder sourceType(@Nonnull String sourceType) {
         if (sourceType == null) {
            throw new NullPointerException("sourceType is marked non-null but is null");
         } else {
            this.sourceType = sourceType;
            return this;
         }
      }

      @Generated
      public BubbleEntrySnapshotBuilder segments(@Nonnull List<BubbleSegment> segments) {
         if (segments == null) {
            throw new NullPointerException("segments is marked non-null but is null");
         } else {
            this.segments = segments;
            return this;
         }
      }

      @Generated
      public BubbleEntrySnapshot build() {
         return new BubbleEntrySnapshot(this.bubbleId, this.channel, this.ownerKey, this.priority, this.expireGameTime, this.createdGameTime, this.sequenceNumber, this.contentVersion, this.sourceType, this.segments);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.bubbleId);
         return "BubbleEntrySnapshot.BubbleEntrySnapshotBuilder(bubbleId=" + var10000 + ", channel=" + String.valueOf(this.channel) + ", ownerKey=" + this.ownerKey + ", priority=" + this.priority + ", expireGameTime=" + this.expireGameTime + ", createdGameTime=" + this.createdGameTime + ", sequenceNumber=" + this.sequenceNumber + ", contentVersion=" + this.contentVersion + ", sourceType=" + this.sourceType + ", segments=" + String.valueOf(this.segments) + ")";
      }
   }
}
