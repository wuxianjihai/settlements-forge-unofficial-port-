package dev.breezes.settlements.application.ui.bubble;

import dev.breezes.settlements.domain.time.ClockTicks;
import java.util.List;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.ChatFormatting;
import net.minecraft.resources.ResourceLocation;

public sealed interface BubbleSegment {
   public static record Item(@Nonnull ResourceLocation itemId, int count) implements BubbleSegment {
      public Item {
         if (count < 0) {
            throw new IllegalArgumentException("count must be >= 0");
         }
      }

      public static Item iconOnly(@Nonnull ResourceLocation itemId) {
         return builder().itemId(itemId).count(0).build();
      }

      @Generated
      public static ItemBuilder builder() {
         return new ItemBuilder();
      }

      @Generated
      public static class ItemBuilder {
         @Generated
         private ResourceLocation itemId;
         @Generated
         private int count;

         @Generated
         ItemBuilder() {
         }

         @Generated
         public ItemBuilder itemId(@Nonnull ResourceLocation itemId) {
            if (itemId == null) {
               throw new NullPointerException("itemId is marked non-null but is null");
            } else {
               this.itemId = itemId;
               return this;
            }
         }

         @Generated
         public ItemBuilder count(int count) {
            this.count = count;
            return this;
         }

         @Generated
         public Item build() {
            return new Item(this.itemId, this.count);
         }

         @Generated
         public String toString() {
            String var10000 = String.valueOf(this.itemId);
            return "BubbleSegment.Item.ItemBuilder(itemId=" + var10000 + ", count=" + this.count + ")";
         }
      }
   }

   public static record Text(@Nonnull String literal, @Nonnull ChatFormatting color, boolean bold, float scale) implements BubbleSegment {
      public Text {
         if (literal.isBlank()) {
            throw new IllegalArgumentException("literal must not be blank");
         } else if (scale <= 0.0F) {
            throw new IllegalArgumentException("scale must be > 0");
         }
      }

      @Generated
      public static TextBuilder builder() {
         return new TextBuilder();
      }

      @Generated
      public static class TextBuilder {
         @Generated
         private String literal;
         @Generated
         private ChatFormatting color;
         @Generated
         private boolean bold;
         @Generated
         private float scale;

         @Generated
         TextBuilder() {
         }

         @Generated
         public TextBuilder literal(@Nonnull String literal) {
            if (literal == null) {
               throw new NullPointerException("literal is marked non-null but is null");
            } else {
               this.literal = literal;
               return this;
            }
         }

         @Generated
         public TextBuilder color(@Nonnull ChatFormatting color) {
            if (color == null) {
               throw new NullPointerException("color is marked non-null but is null");
            } else {
               this.color = color;
               return this;
            }
         }

         @Generated
         public TextBuilder bold(boolean bold) {
            this.bold = bold;
            return this;
         }

         @Generated
         public TextBuilder scale(float scale) {
            this.scale = scale;
            return this;
         }

         @Generated
         public Text build() {
            return new Text(this.literal, this.color, this.bold, this.scale);
         }

         @Generated
         public String toString() {
            String var10000 = this.literal;
            return "BubbleSegment.Text.TextBuilder(literal=" + var10000 + ", color=" + String.valueOf(this.color) + ", bold=" + this.bold + ", scale=" + this.scale + ")";
         }
      }
   }

   public static record Translatable(@Nonnull String key, @Nonnull List<String> args, @Nonnull ChatFormatting color, boolean bold, float scale) implements BubbleSegment {
      public Translatable {
         if (key.isBlank()) {
            throw new IllegalArgumentException("key must not be blank");
         } else if (scale <= 0.0F) {
            throw new IllegalArgumentException("scale must be > 0");
         }
      }

      @Generated
      public static TranslatableBuilder builder() {
         return new TranslatableBuilder();
      }

      @Generated
      public static class TranslatableBuilder {
         @Generated
         private String key;
         @Generated
         private List<String> args;
         @Generated
         private ChatFormatting color;
         @Generated
         private boolean bold;
         @Generated
         private float scale;

         @Generated
         TranslatableBuilder() {
         }

         @Generated
         public TranslatableBuilder key(@Nonnull String key) {
            if (key == null) {
               throw new NullPointerException("key is marked non-null but is null");
            } else {
               this.key = key;
               return this;
            }
         }

         @Generated
         public TranslatableBuilder args(@Nonnull List<String> args) {
            if (args == null) {
               throw new NullPointerException("args is marked non-null but is null");
            } else {
               this.args = args;
               return this;
            }
         }

         @Generated
         public TranslatableBuilder color(@Nonnull ChatFormatting color) {
            if (color == null) {
               throw new NullPointerException("color is marked non-null but is null");
            } else {
               this.color = color;
               return this;
            }
         }

         @Generated
         public TranslatableBuilder bold(boolean bold) {
            this.bold = bold;
            return this;
         }

         @Generated
         public TranslatableBuilder scale(float scale) {
            this.scale = scale;
            return this;
         }

         @Generated
         public Translatable build() {
            return new Translatable(this.key, this.args, this.color, this.bold, this.scale);
         }

         @Generated
         public String toString() {
            String var10000 = this.key;
            return "BubbleSegment.Translatable.TranslatableBuilder(key=" + var10000 + ", args=" + String.valueOf(this.args) + ", color=" + String.valueOf(this.color) + ", bold=" + this.bold + ", scale=" + this.scale + ")";
         }
      }
   }

   public static record Sprite(@Nonnull SpriteRef sprite, @Nonnull ClockTicks frameDuration) implements BubbleSegment {
      @Generated
      public static SpriteBuilder builder() {
         return new SpriteBuilder();
      }

      @Generated
      public static class SpriteBuilder {
         @Generated
         private SpriteRef sprite;
         @Generated
         private ClockTicks frameDuration;

         @Generated
         SpriteBuilder() {
         }

         @Generated
         public SpriteBuilder sprite(@Nonnull SpriteRef sprite) {
            if (sprite == null) {
               throw new NullPointerException("sprite is marked non-null but is null");
            } else {
               this.sprite = sprite;
               return this;
            }
         }

         @Generated
         public SpriteBuilder frameDuration(@Nonnull ClockTicks frameDuration) {
            if (frameDuration == null) {
               throw new NullPointerException("frameDuration is marked non-null but is null");
            } else {
               this.frameDuration = frameDuration;
               return this;
            }
         }

         @Generated
         public Sprite build() {
            return new Sprite(this.sprite, this.frameDuration);
         }

         @Generated
         public String toString() {
            String var10000 = String.valueOf(this.sprite);
            return "BubbleSegment.Sprite.SpriteBuilder(sprite=" + var10000 + ", frameDuration=" + String.valueOf(this.frameDuration) + ")";
         }
      }
   }
}
