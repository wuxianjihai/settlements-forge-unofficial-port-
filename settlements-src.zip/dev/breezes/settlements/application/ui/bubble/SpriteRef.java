package dev.breezes.settlements.application.ui.bubble;

public enum SpriteRef {
   SHEARS,
   SHEEP;

   // $FF: synthetic method
   private static SpriteRef[] $values() {
      return new SpriteRef[]{SHEARS, SHEEP};
   }
}
