package dev.breezes.settlements.application.ui.bubble;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class VillagerBubbleService_Factory implements Factory<VillagerBubbleService> {
   public VillagerBubbleService get() {
      return newInstance();
   }

   public static VillagerBubbleService_Factory create() {
      return VillagerBubbleService_Factory.InstanceHolder.INSTANCE;
   }

   public static VillagerBubbleService newInstance() {
      return new VillagerBubbleService();
   }

   private static final class InstanceHolder {
      static final VillagerBubbleService_Factory INSTANCE = new VillagerBubbleService_Factory();
   }
}
