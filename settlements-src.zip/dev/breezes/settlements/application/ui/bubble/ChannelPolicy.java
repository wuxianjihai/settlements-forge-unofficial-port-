package dev.breezes.settlements.application.ui.bubble;

import dev.breezes.settlements.domain.time.ClockTicks;
import javax.annotation.Nonnull;
import lombok.Generated;

public record ChannelPolicy(int maxActive, @Nonnull OverflowPolicy overflowPolicy, int renderOrder, @Nonnull ClockTicks defaultTtlCap) {
   public ChannelPolicy {
      if (maxActive <= 0) {
         throw new IllegalArgumentException("maxActive must be > 0");
      }
   }

   public ClockTicks clampTtl(@Nonnull ClockTicks requestedTtl) {
      return ClockTicks.of(Math.min(requestedTtl.getTicks(), this.defaultTtlCap.getTicks()));
   }

   @Generated
   public static ChannelPolicyBuilder builder() {
      return new ChannelPolicyBuilder();
   }

   @Generated
   public static class ChannelPolicyBuilder {
      @Generated
      private int maxActive;
      @Generated
      private OverflowPolicy overflowPolicy;
      @Generated
      private int renderOrder;
      @Generated
      private ClockTicks defaultTtlCap;

      @Generated
      ChannelPolicyBuilder() {
      }

      @Generated
      public ChannelPolicyBuilder maxActive(int maxActive) {
         this.maxActive = maxActive;
         return this;
      }

      @Generated
      public ChannelPolicyBuilder overflowPolicy(@Nonnull OverflowPolicy overflowPolicy) {
         if (overflowPolicy == null) {
            throw new NullPointerException("overflowPolicy is marked non-null but is null");
         } else {
            this.overflowPolicy = overflowPolicy;
            return this;
         }
      }

      @Generated
      public ChannelPolicyBuilder renderOrder(int renderOrder) {
         this.renderOrder = renderOrder;
         return this;
      }

      @Generated
      public ChannelPolicyBuilder defaultTtlCap(@Nonnull ClockTicks defaultTtlCap) {
         if (defaultTtlCap == null) {
            throw new NullPointerException("defaultTtlCap is marked non-null but is null");
         } else {
            this.defaultTtlCap = defaultTtlCap;
            return this;
         }
      }

      @Generated
      public ChannelPolicy build() {
         return new ChannelPolicy(this.maxActive, this.overflowPolicy, this.renderOrder, this.defaultTtlCap);
      }

      @Generated
      public String toString() {
         int var10000 = this.maxActive;
         return "ChannelPolicy.ChannelPolicyBuilder(maxActive=" + var10000 + ", overflowPolicy=" + String.valueOf(this.overflowPolicy) + ", renderOrder=" + this.renderOrder + ", defaultTtlCap=" + String.valueOf(this.defaultTtlCap) + ")";
      }
   }

   public static enum OverflowPolicy {
      REPLACE_EXISTING,
      DROP_OLDEST,
      DROP_LOWEST_PRIORITY,
      REJECT_NEW;

      // $FF: synthetic method
      private static OverflowPolicy[] $values() {
         return new OverflowPolicy[]{REPLACE_EXISTING, DROP_OLDEST, DROP_LOWEST_PRIORITY, REJECT_NEW};
      }
   }
}
