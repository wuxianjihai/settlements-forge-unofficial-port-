package dev.breezes.settlements.application.ui.bubble;

import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public record BubbleEntry(@Nonnull UUID bubbleId, @Nonnull BubbleChannel channel, @Nullable String ownerKey, @Nonnull BubbleMessage message, long createdGameTime, long expireGameTime, long sequenceNumber, int contentVersion) {
   public BubbleEntry {
      if (createdGameTime < 0L) {
         throw new IllegalArgumentException("createdGameTime must be >= 0");
      } else if (expireGameTime <= createdGameTime) {
         throw new IllegalArgumentException("expireGameTime must be > createdGameTime");
      } else if (sequenceNumber < 0L) {
         throw new IllegalArgumentException("sequenceNumber must be >= 0");
      } else if (ownerKey != null && ownerKey.isBlank()) {
         throw new IllegalArgumentException("ownerKey must not be blank");
      }
   }

   public boolean isExpiredAt(long gameTime) {
      return gameTime >= this.expireGameTime;
   }

   public BubbleEntry withMessage(@Nonnull BubbleMessage newMessage, long newCreatedGameTime, long newExpireGameTime) {
      return builder().bubbleId(this.bubbleId).channel(this.channel).ownerKey(this.ownerKey).message(newMessage).createdGameTime(newCreatedGameTime).expireGameTime(newExpireGameTime).sequenceNumber(this.sequenceNumber).contentVersion(this.contentVersion + 1).build();
   }

   @Generated
   public static BubbleEntryBuilder builder() {
      return new BubbleEntryBuilder();
   }

   @Generated
   public static class BubbleEntryBuilder {
      @Generated
      private UUID bubbleId;
      @Generated
      private BubbleChannel channel;
      @Generated
      private String ownerKey;
      @Generated
      private BubbleMessage message;
      @Generated
      private long createdGameTime;
      @Generated
      private long expireGameTime;
      @Generated
      private long sequenceNumber;
      @Generated
      private int contentVersion;

      @Generated
      BubbleEntryBuilder() {
      }

      @Generated
      public BubbleEntryBuilder bubbleId(@Nonnull UUID bubbleId) {
         if (bubbleId == null) {
            throw new NullPointerException("bubbleId is marked non-null but is null");
         } else {
            this.bubbleId = bubbleId;
            return this;
         }
      }

      @Generated
      public BubbleEntryBuilder channel(@Nonnull BubbleChannel channel) {
         if (channel == null) {
            throw new NullPointerException("channel is marked non-null but is null");
         } else {
            this.channel = channel;
            return this;
         }
      }

      @Generated
      public BubbleEntryBuilder ownerKey(@Nullable String ownerKey) {
         this.ownerKey = ownerKey;
         return this;
      }

      @Generated
      public BubbleEntryBuilder message(@Nonnull BubbleMessage message) {
         if (message == null) {
            throw new NullPointerException("message is marked non-null but is null");
         } else {
            this.message = message;
            return this;
         }
      }

      @Generated
      public BubbleEntryBuilder createdGameTime(long createdGameTime) {
         this.createdGameTime = createdGameTime;
         return this;
      }

      @Generated
      public BubbleEntryBuilder expireGameTime(long expireGameTime) {
         this.expireGameTime = expireGameTime;
         return this;
      }

      @Generated
      public BubbleEntryBuilder sequenceNumber(long sequenceNumber) {
         this.sequenceNumber = sequenceNumber;
         return this;
      }

      @Generated
      public BubbleEntryBuilder contentVersion(int contentVersion) {
         this.contentVersion = contentVersion;
         return this;
      }

      @Generated
      public BubbleEntry build() {
         return new BubbleEntry(this.bubbleId, this.channel, this.ownerKey, this.message, this.createdGameTime, this.expireGameTime, this.sequenceNumber, this.contentVersion);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.bubbleId);
         return "BubbleEntry.BubbleEntryBuilder(bubbleId=" + var10000 + ", channel=" + String.valueOf(this.channel) + ", ownerKey=" + this.ownerKey + ", message=" + String.valueOf(this.message) + ", createdGameTime=" + this.createdGameTime + ", expireGameTime=" + this.expireGameTime + ", sequenceNumber=" + this.sequenceNumber + ", contentVersion=" + this.contentVersion + ")";
      }
   }
}
