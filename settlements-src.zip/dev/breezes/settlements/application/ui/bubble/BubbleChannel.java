package dev.breezes.settlements.application.ui.bubble;

public enum BubbleChannel {
   BEHAVIOR,
   CHAT,
   SYSTEM,
   FLAVOR;

   // $FF: synthetic method
   private static BubbleChannel[] $values() {
      return new BubbleChannel[]{BEHAVIOR, CHAT, SYSTEM, FLAVOR};
   }
}
