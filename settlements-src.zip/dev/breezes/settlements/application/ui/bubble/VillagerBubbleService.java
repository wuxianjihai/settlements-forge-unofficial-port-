package dev.breezes.settlements.application.ui.bubble;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.entities.BubbleHost;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.compat.NetworkHelper;
import dev.breezes.settlements.infrastructure.network.features.ui.bubble.packet.ClientBoundBubbleSnapshotPacket;
import dev.breezes.settlements.shared.annotations.functional.ServerSide;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.Generated;

@ServerSide
@ServerScope
public final class VillagerBubbleService {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(VillagerBubbleService.class.getName());
   private static final ClockTicks DEFAULT_BEHAVIOR_TTL_CAP = ClockTicks.seconds((double)30.0F);
   private static final ClockTicks DEFAULT_CHAT_TTL_CAP = ClockTicks.seconds((double)20.0F);
   private static final ClockTicks DEFAULT_SYSTEM_TTL_CAP = ClockTicks.seconds((double)10.0F);
   private static final ClockTicks DEFAULT_FLAVOR_TTL_CAP = ClockTicks.seconds((double)10.0F);
   private final EnumMap<BubbleChannel, ChannelPolicy> policies = new EnumMap(BubbleChannel.class);
   private final Comparator<BubbleEntry> renderComparator;

   @Inject
   public VillagerBubbleService() {
      this.policies.put(BubbleChannel.BEHAVIOR, ChannelPolicy.builder().maxActive(1).overflowPolicy(ChannelPolicy.OverflowPolicy.REPLACE_EXISTING).renderOrder(0).defaultTtlCap(DEFAULT_BEHAVIOR_TTL_CAP).build());
      this.policies.put(BubbleChannel.CHAT, ChannelPolicy.builder().maxActive(3).overflowPolicy(ChannelPolicy.OverflowPolicy.DROP_OLDEST).renderOrder(1).defaultTtlCap(DEFAULT_CHAT_TTL_CAP).build());
      this.policies.put(BubbleChannel.SYSTEM, ChannelPolicy.builder().maxActive(2).overflowPolicy(ChannelPolicy.OverflowPolicy.DROP_OLDEST).renderOrder(2).defaultTtlCap(DEFAULT_SYSTEM_TTL_CAP).build());
      this.policies.put(BubbleChannel.FLAVOR, ChannelPolicy.builder().maxActive(1).overflowPolicy(ChannelPolicy.OverflowPolicy.REPLACE_EXISTING).renderOrder(3).defaultTtlCap(DEFAULT_FLAVOR_TTL_CAP).build());
      this.renderComparator = buildRenderComparator(this.policies);
   }

   public ChannelPolicy getPolicy(BubbleChannel channel) {
      return (ChannelPolicy)this.policies.get(channel);
   }

   public boolean applyCommand(BubbleHost host, BubbleCommand command, long gameTime) {
      VillagerBubbleState state = host.getBubbleState();
      boolean expiredRemoved = !state.pruneExpired(gameTime).isEmpty();
      boolean changed;
      if (command instanceof BubbleCommand.Upsert upsert) {
         changed = this.handleUpsert(state, upsert.channel(), upsert.ownerKey(), upsert.message(), gameTime);
      } else if (command instanceof BubbleCommand.Push push) {
         changed = this.handlePush(state, push.channel(), push.message(), gameTime);
      } else if (command instanceof BubbleCommand.RemoveById remove) {
         changed = state.removeById(remove.bubbleId()).isPresent();
      } else if (command instanceof BubbleCommand.RemoveByOwner remove) {
         changed = state.removeByOwner(remove.channel(), remove.ownerKey()).isPresent();
      } else {
         if (!(command instanceof BubbleCommand.ClearChannel)) {
            throw new IllegalArgumentException("Unknown BubbleCommand: " + String.valueOf(command));
         }

         BubbleCommand.ClearChannel clear = (BubbleCommand.ClearChannel)command;
         changed = !state.clearChannel(clear.channel()).isEmpty();
      }

      if (changed || expiredRemoved) {
         this.publishSnapshot(host);
      }

      return changed || expiredRemoved;
   }

   public List<BubbleEntry> getOrderedEntries(BubbleHost host) {
      List<BubbleEntry> entries = new ArrayList(host.getBubbleState().getAllEntries());
      entries.sort(this.renderComparator);
      return List.copyOf(entries);
   }

   public boolean tick(BubbleHost host, long gameTime) {
      List<BubbleEntry> removedEntries = host.getBubbleState().pruneExpired(gameTime);
      if (removedEntries.isEmpty()) {
         return false;
      } else {
         this.publishSnapshot(host);
         return true;
      }
   }

   private boolean handleUpsert(VillagerBubbleState state, BubbleChannel channel, String ownerKey, BubbleMessage message, long gameTime) {
      Optional<BubbleEntry> existing = state.getByOwner(channel, ownerKey);
      if (existing.isPresent()) {
         ClockTicks ttl = this.clampTtl(channel, message.getTtl());
         BubbleEntry updated = ((BubbleEntry)existing.get()).withMessage(message, gameTime, gameTime + ttl.getTicks());
         state.put(updated);
         return true;
      } else {
         BubbleEntry entry = this.buildEntry(state, channel, ownerKey, message, gameTime);
         return this.insertWithPolicy(state, entry, channel);
      }
   }

   private boolean handlePush(VillagerBubbleState state, BubbleChannel channel, BubbleMessage message, long gameTime) {
      BubbleEntry entry = this.buildEntry(state, channel, (String)null, message, gameTime);
      return this.insertWithPolicy(state, entry, channel);
   }

   private BubbleEntry buildEntry(VillagerBubbleState state, BubbleChannel channel, String ownerKey, BubbleMessage message, long gameTime) {
      ClockTicks ttlTicks = this.clampTtl(channel, message.getTtl());
      return BubbleEntry.builder().bubbleId(UUID.randomUUID()).channel(channel).ownerKey(ownerKey).message(message).createdGameTime(gameTime).expireGameTime(gameTime + ttlTicks.getTicks()).sequenceNumber(state.nextSequenceNumber()).build();
   }

   private ClockTicks clampTtl(BubbleChannel channel, ClockTicks requestedTtl) {
      ChannelPolicy policy = (ChannelPolicy)this.policies.get(channel);
      return policy.clampTtl(requestedTtl);
   }

   private boolean insertWithPolicy(VillagerBubbleState state, BubbleEntry entry, BubbleChannel channel) {
      ChannelPolicy policy = (ChannelPolicy)this.policies.get(channel);
      if (state.getChannelSize(channel) >= policy.maxActive()) {
         boolean removed = this.handleOverflow(state, channel, policy);
         if (!removed && policy.overflowPolicy() == ChannelPolicy.OverflowPolicy.REJECT_NEW) {
            return false;
         }
      }

      state.put(entry);
      return true;
   }

   private boolean handleOverflow(VillagerBubbleState state, BubbleChannel channel, ChannelPolicy policy) {
      List<BubbleEntry> entries = state.getEntries(channel);
      if (entries.isEmpty()) {
         return false;
      } else {
         Optional<BubbleEntry> candidate = this.selectEvictionCandidate(entries, policy.overflowPolicy());
         return candidate.flatMap((entry) -> state.removeById(entry.bubbleId())).isPresent();
      }
   }

   private Optional<BubbleEntry> selectEvictionCandidate(List<BubbleEntry> entries, ChannelPolicy.OverflowPolicy policy) {
      Comparator var10000;
      switch (policy) {
         case REPLACE_EXISTING:
         case DROP_OLDEST:
            var10000 = Comparator.comparingLong(BubbleEntry::createdGameTime).thenComparingLong(BubbleEntry::sequenceNumber);
            break;
         case DROP_LOWEST_PRIORITY:
            var10000 = Comparator.comparingInt((entry) -> entry.message().getPriority()).thenComparingLong(BubbleEntry::createdGameTime).thenComparingLong(BubbleEntry::sequenceNumber);
            break;
         case REJECT_NEW:
            var10000 = null;
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      Comparator<BubbleEntry> comparator = var10000;
      return comparator == null ? Optional.empty() : entries.stream().min(comparator);
   }

   private static Comparator<BubbleEntry> buildRenderComparator(EnumMap<BubbleChannel, ChannelPolicy> policies) {
      return Comparator.comparingInt((entry) -> ((ChannelPolicy)policies.get(entry.channel())).renderOrder()).thenComparing((left, right) -> Integer.compare(right.message().getPriority(), left.message().getPriority())).thenComparingLong(BubbleEntry::createdGameTime).thenComparingLong(BubbleEntry::sequenceNumber);
   }

   private void publishSnapshot(BubbleHost host) {
      List<BubbleEntrySnapshot> snapshots = this.getOrderedEntries(host).stream().map(BubbleEntrySnapshot::fromEntry).toList();
      NetworkHelper.sendToTrackingEntity(host.getMinecraftEntity(), new ClientBoundBubbleSnapshotPacket(host.getNetworkingId(), snapshots));
   }
}
