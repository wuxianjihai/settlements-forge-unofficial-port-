package dev.breezes.settlements.application.ui.bubble;

import java.util.UUID;
import javax.annotation.Nonnull;

public sealed interface BubbleCommand {
   public static record Upsert(@Nonnull BubbleChannel channel, @Nonnull String ownerKey, @Nonnull BubbleMessage message) implements BubbleCommand {
      public Upsert {
         if (ownerKey.isBlank()) {
            throw new IllegalArgumentException("ownerKey must not be blank");
         }
      }
   }

   public static record Push(@Nonnull BubbleChannel channel, @Nonnull BubbleMessage message) implements BubbleCommand {
   }

   public static record RemoveById(@Nonnull UUID bubbleId) implements BubbleCommand {
   }

   public static record RemoveByOwner(@Nonnull BubbleChannel channel, @Nonnull String ownerKey) implements BubbleCommand {
      public RemoveByOwner {
         if (ownerKey.isBlank()) {
            throw new IllegalArgumentException("ownerKey must not be blank");
         }
      }
   }

   public static record ClearChannel(@Nonnull BubbleChannel channel) implements BubbleCommand {
   }
}
