package dev.breezes.settlements.application.ui.bubble;

import dev.breezes.settlements.domain.time.ClockTicks;
import java.util.List;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class BubbleMessage {
   private final int priority;
   private final ClockTicks ttl;
   private final String sourceType;
   private final List<BubbleSegment> segments;

   public BubbleMessage(int priority, @Nonnull ClockTicks ttl, @Nonnull String sourceType, @Nonnull List<BubbleSegment> segments) {
      this.priority = priority;
      this.ttl = ttl;
      if (sourceType.isBlank()) {
         throw new IllegalArgumentException("sourceType must not be blank");
      } else {
         this.sourceType = sourceType;
         if (segments.isEmpty()) {
            throw new IllegalArgumentException("segments must not be empty");
         } else {
            this.segments = List.copyOf(segments);
         }
      }
   }

   @Generated
   private static int $default$priority() {
      return 0;
   }

   @Generated
   public static BubbleMessageBuilder builder() {
      return new BubbleMessageBuilder();
   }

   @Generated
   public int getPriority() {
      return this.priority;
   }

   @Generated
   public ClockTicks getTtl() {
      return this.ttl;
   }

   @Generated
   public String getSourceType() {
      return this.sourceType;
   }

   @Generated
   public List<BubbleSegment> getSegments() {
      return this.segments;
   }

   @Generated
   public static class BubbleMessageBuilder {
      @Generated
      private boolean priority$set;
      @Generated
      private int priority$value;
      @Generated
      private ClockTicks ttl;
      @Generated
      private String sourceType;
      @Generated
      private List<BubbleSegment> segments;

      @Generated
      BubbleMessageBuilder() {
      }

      @Generated
      public BubbleMessageBuilder priority(int priority) {
         this.priority$value = priority;
         this.priority$set = true;
         return this;
      }

      @Generated
      public BubbleMessageBuilder ttl(ClockTicks ttl) {
         this.ttl = ttl;
         return this;
      }

      @Generated
      public BubbleMessageBuilder sourceType(String sourceType) {
         this.sourceType = sourceType;
         return this;
      }

      @Generated
      public BubbleMessageBuilder segments(List<BubbleSegment> segments) {
         this.segments = segments;
         return this;
      }

      @Generated
      public BubbleMessage build() {
         int priority$value = this.priority$value;
         if (!this.priority$set) {
            priority$value = BubbleMessage.$default$priority();
         }

         return new BubbleMessage(priority$value, this.ttl, this.sourceType, this.segments);
      }

      @Generated
      public String toString() {
         int var10000 = this.priority$value;
         return "BubbleMessage.BubbleMessageBuilder(priority$value=" + var10000 + ", ttl=" + String.valueOf(this.ttl) + ", sourceType=" + this.sourceType + ", segments=" + String.valueOf(this.segments) + ")";
      }
   }
}
