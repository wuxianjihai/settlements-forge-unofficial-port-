package dev.breezes.settlements.application.ui.stats.model;

import java.util.List;
import javax.annotation.Nonnull;

public record VillagerDemandDisplaySnapshot(@Nonnull List<DemandDisplayEntry> entries) {
   public VillagerDemandDisplaySnapshot(@Nonnull List<DemandDisplayEntry> entries) {
      entries = List.copyOf(entries);
      this.entries = entries;
   }
}
