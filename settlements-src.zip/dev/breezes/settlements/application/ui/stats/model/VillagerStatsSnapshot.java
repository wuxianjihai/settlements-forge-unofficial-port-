package dev.breezes.settlements.application.ui.stats.model;

import dev.breezes.settlements.application.ui.shared.model.SchedulePhase;
import dev.breezes.settlements.domain.genetics.GeneType;
import dev.breezes.settlements.domain.personality.OriginType;
import java.util.Arrays;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;

public record VillagerStatsSnapshot(long gameTime, int villagerEntityId, @Nullable String villagerName, @Nonnull String professionKey, int expertiseLevel, float currentHealth, float maxHealth, @Nonnull double[] geneValues, @Nullable BlockPos homePos, @Nullable BlockPos workstationPos, @Nullable String activeBehaviorNameKey, @Nullable String activeBehaviorIconId, @Nonnull SchedulePhase schedulePhase, int reputation, float hunger, int walletBalance, @Nonnull List<String> adjectives, @Nullable String characterSketch, @Nullable OriginType origin) {
   public VillagerStatsSnapshot(long gameTime, int villagerEntityId, @Nullable String villagerName, @Nonnull String professionKey, int expertiseLevel, float currentHealth, float maxHealth, @Nonnull double[] geneValues, @Nullable BlockPos homePos, @Nullable BlockPos workstationPos, @Nullable String activeBehaviorNameKey, @Nullable String activeBehaviorIconId, @Nonnull SchedulePhase schedulePhase, int reputation, float hunger, int walletBalance, @Nonnull List<String> adjectives, @Nullable String characterSketch, @Nullable OriginType origin) {
      if (geneValues.length != GeneType.VALUES.length) {
         throw new IllegalArgumentException("geneValues must have exactly " + GeneType.VALUES.length + " entries");
      } else {
         geneValues = (double[])(([D)geneValues).clone();
         adjectives = adjectives == null ? List.of() : List.copyOf(adjectives);
         this.gameTime = gameTime;
         this.villagerEntityId = villagerEntityId;
         this.villagerName = villagerName;
         this.professionKey = professionKey;
         this.expertiseLevel = expertiseLevel;
         this.currentHealth = currentHealth;
         this.maxHealth = maxHealth;
         this.geneValues = geneValues;
         this.homePos = homePos;
         this.workstationPos = workstationPos;
         this.activeBehaviorNameKey = activeBehaviorNameKey;
         this.activeBehaviorIconId = activeBehaviorIconId;
         this.schedulePhase = schedulePhase;
         this.reputation = reputation;
         this.hunger = hunger;
         this.walletBalance = walletBalance;
         this.adjectives = adjectives;
         this.characterSketch = characterSketch;
         this.origin = origin;
      }
   }

   public double[] geneValues() {
      return (double[])this.geneValues.clone();
   }

   @Generated
   public static VillagerStatsSnapshotBuilder builder() {
      return new VillagerStatsSnapshotBuilder();
   }

   @Generated
   public static class VillagerStatsSnapshotBuilder {
      @Generated
      private long gameTime;
      @Generated
      private int villagerEntityId;
      @Generated
      private String villagerName;
      @Generated
      private String professionKey;
      @Generated
      private int expertiseLevel;
      @Generated
      private float currentHealth;
      @Generated
      private float maxHealth;
      @Generated
      private double[] geneValues;
      @Generated
      private BlockPos homePos;
      @Generated
      private BlockPos workstationPos;
      @Generated
      private String activeBehaviorNameKey;
      @Generated
      private String activeBehaviorIconId;
      @Generated
      private SchedulePhase schedulePhase;
      @Generated
      private int reputation;
      @Generated
      private float hunger;
      @Generated
      private int walletBalance;
      @Generated
      private List<String> adjectives;
      @Generated
      private String characterSketch;
      @Generated
      private OriginType origin;

      @Generated
      VillagerStatsSnapshotBuilder() {
      }

      @Generated
      public VillagerStatsSnapshotBuilder gameTime(long gameTime) {
         this.gameTime = gameTime;
         return this;
      }

      @Generated
      public VillagerStatsSnapshotBuilder villagerEntityId(int villagerEntityId) {
         this.villagerEntityId = villagerEntityId;
         return this;
      }

      @Generated
      public VillagerStatsSnapshotBuilder villagerName(@Nullable String villagerName) {
         this.villagerName = villagerName;
         return this;
      }

      @Generated
      public VillagerStatsSnapshotBuilder professionKey(@Nonnull String professionKey) {
         if (professionKey == null) {
            throw new NullPointerException("professionKey is marked non-null but is null");
         } else {
            this.professionKey = professionKey;
            return this;
         }
      }

      @Generated
      public VillagerStatsSnapshotBuilder expertiseLevel(int expertiseLevel) {
         this.expertiseLevel = expertiseLevel;
         return this;
      }

      @Generated
      public VillagerStatsSnapshotBuilder currentHealth(float currentHealth) {
         this.currentHealth = currentHealth;
         return this;
      }

      @Generated
      public VillagerStatsSnapshotBuilder maxHealth(float maxHealth) {
         this.maxHealth = maxHealth;
         return this;
      }

      @Generated
      public VillagerStatsSnapshotBuilder geneValues(@Nonnull double[] geneValues) {
         if (geneValues == null) {
            throw new NullPointerException("geneValues is marked non-null but is null");
         } else {
            this.geneValues = geneValues;
            return this;
         }
      }

      @Generated
      public VillagerStatsSnapshotBuilder homePos(@Nullable BlockPos homePos) {
         this.homePos = homePos;
         return this;
      }

      @Generated
      public VillagerStatsSnapshotBuilder workstationPos(@Nullable BlockPos workstationPos) {
         this.workstationPos = workstationPos;
         return this;
      }

      @Generated
      public VillagerStatsSnapshotBuilder activeBehaviorNameKey(@Nullable String activeBehaviorNameKey) {
         this.activeBehaviorNameKey = activeBehaviorNameKey;
         return this;
      }

      @Generated
      public VillagerStatsSnapshotBuilder activeBehaviorIconId(@Nullable String activeBehaviorIconId) {
         this.activeBehaviorIconId = activeBehaviorIconId;
         return this;
      }

      @Generated
      public VillagerStatsSnapshotBuilder schedulePhase(@Nonnull SchedulePhase schedulePhase) {
         if (schedulePhase == null) {
            throw new NullPointerException("schedulePhase is marked non-null but is null");
         } else {
            this.schedulePhase = schedulePhase;
            return this;
         }
      }

      @Generated
      public VillagerStatsSnapshotBuilder reputation(int reputation) {
         this.reputation = reputation;
         return this;
      }

      @Generated
      public VillagerStatsSnapshotBuilder hunger(float hunger) {
         this.hunger = hunger;
         return this;
      }

      @Generated
      public VillagerStatsSnapshotBuilder walletBalance(int walletBalance) {
         this.walletBalance = walletBalance;
         return this;
      }

      @Generated
      public VillagerStatsSnapshotBuilder adjectives(@Nonnull List<String> adjectives) {
         if (adjectives == null) {
            throw new NullPointerException("adjectives is marked non-null but is null");
         } else {
            this.adjectives = adjectives;
            return this;
         }
      }

      @Generated
      public VillagerStatsSnapshotBuilder characterSketch(@Nullable String characterSketch) {
         this.characterSketch = characterSketch;
         return this;
      }

      @Generated
      public VillagerStatsSnapshotBuilder origin(@Nullable OriginType origin) {
         this.origin = origin;
         return this;
      }

      @Generated
      public VillagerStatsSnapshot build() {
         return new VillagerStatsSnapshot(this.gameTime, this.villagerEntityId, this.villagerName, this.professionKey, this.expertiseLevel, this.currentHealth, this.maxHealth, this.geneValues, this.homePos, this.workstationPos, this.activeBehaviorNameKey, this.activeBehaviorIconId, this.schedulePhase, this.reputation, this.hunger, this.walletBalance, this.adjectives, this.characterSketch, this.origin);
      }

      @Generated
      public String toString() {
         long var10000 = this.gameTime;
         return "VillagerStatsSnapshot.VillagerStatsSnapshotBuilder(gameTime=" + var10000 + ", villagerEntityId=" + this.villagerEntityId + ", villagerName=" + this.villagerName + ", professionKey=" + this.professionKey + ", expertiseLevel=" + this.expertiseLevel + ", currentHealth=" + this.currentHealth + ", maxHealth=" + this.maxHealth + ", geneValues=" + Arrays.toString(this.geneValues) + ", homePos=" + String.valueOf(this.homePos) + ", workstationPos=" + String.valueOf(this.workstationPos) + ", activeBehaviorNameKey=" + this.activeBehaviorNameKey + ", activeBehaviorIconId=" + this.activeBehaviorIconId + ", schedulePhase=" + String.valueOf(this.schedulePhase) + ", reputation=" + this.reputation + ", hunger=" + this.hunger + ", walletBalance=" + this.walletBalance + ", adjectives=" + String.valueOf(this.adjectives) + ", characterSketch=" + this.characterSketch + ", origin=" + String.valueOf(this.origin) + ")";
      }
   }
}
