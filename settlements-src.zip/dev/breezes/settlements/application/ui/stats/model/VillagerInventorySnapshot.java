package dev.breezes.settlements.application.ui.stats.model;

import dev.breezes.settlements.domain.inventory.BackpackEntry;
import java.util.List;
import javax.annotation.Nonnull;
import lombok.Generated;

public record VillagerInventorySnapshot(@Nonnull List<BackpackEntry> entries) {
   public VillagerInventorySnapshot(@Nonnull List<BackpackEntry> entries) {
      entries = List.copyOf(entries);
      this.entries = entries;
   }

   public int distinctKinds() {
      return this.entries.size();
   }

   public int totalItemCount() {
      return this.entries.stream().mapToInt(BackpackEntry::count).sum();
   }

   @Generated
   public static VillagerInventorySnapshotBuilder builder() {
      return new VillagerInventorySnapshotBuilder();
   }

   @Generated
   public static class VillagerInventorySnapshotBuilder {
      @Generated
      private List<BackpackEntry> entries;

      @Generated
      VillagerInventorySnapshotBuilder() {
      }

      @Generated
      public VillagerInventorySnapshotBuilder entries(@Nonnull List<BackpackEntry> entries) {
         if (entries == null) {
            throw new NullPointerException("entries is marked non-null but is null");
         } else {
            this.entries = entries;
            return this;
         }
      }

      @Generated
      public VillagerInventorySnapshot build() {
         return new VillagerInventorySnapshot(this.entries);
      }

      @Generated
      public String toString() {
         return "VillagerInventorySnapshot.VillagerInventorySnapshotBuilder(entries=" + String.valueOf(this.entries) + ")";
      }
   }
}
