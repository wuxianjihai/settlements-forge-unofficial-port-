package dev.breezes.settlements.application.ui.stats.model;

import dev.breezes.settlements.application.economy.demand.ActiveDemand;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public record DemandDisplayEntry(@Nonnull String id, @Nonnull ItemMatch match, int desiredMinCount, int basePricePerUnit, int basePriority, @Nullable ActiveDemand activeDemand) {
   public DemandDisplayEntry {
      if (id.isBlank()) {
         throw new IllegalArgumentException("DemandDisplayEntry id must not be blank");
      } else if (desiredMinCount <= 0) {
         throw new IllegalArgumentException("DemandDisplayEntry desiredMinCount must be positive");
      } else if (basePricePerUnit <= 0) {
         throw new IllegalArgumentException("DemandDisplayEntry basePricePerUnit must be positive");
      } else if (basePriority < 0) {
         throw new IllegalArgumentException("DemandDisplayEntry basePriority must be non-negative");
      }
   }

   public boolean active() {
      return this.activeDemand != null;
   }

   @Generated
   public static DemandDisplayEntryBuilder builder() {
      return new DemandDisplayEntryBuilder();
   }

   @Generated
   public static class DemandDisplayEntryBuilder {
      @Generated
      private String id;
      @Generated
      private ItemMatch match;
      @Generated
      private int desiredMinCount;
      @Generated
      private int basePricePerUnit;
      @Generated
      private int basePriority;
      @Generated
      private ActiveDemand activeDemand;

      @Generated
      DemandDisplayEntryBuilder() {
      }

      @Generated
      public DemandDisplayEntryBuilder id(@Nonnull String id) {
         if (id == null) {
            throw new NullPointerException("id is marked non-null but is null");
         } else {
            this.id = id;
            return this;
         }
      }

      @Generated
      public DemandDisplayEntryBuilder match(@Nonnull ItemMatch match) {
         if (match == null) {
            throw new NullPointerException("match is marked non-null but is null");
         } else {
            this.match = match;
            return this;
         }
      }

      @Generated
      public DemandDisplayEntryBuilder desiredMinCount(int desiredMinCount) {
         this.desiredMinCount = desiredMinCount;
         return this;
      }

      @Generated
      public DemandDisplayEntryBuilder basePricePerUnit(int basePricePerUnit) {
         this.basePricePerUnit = basePricePerUnit;
         return this;
      }

      @Generated
      public DemandDisplayEntryBuilder basePriority(int basePriority) {
         this.basePriority = basePriority;
         return this;
      }

      @Generated
      public DemandDisplayEntryBuilder activeDemand(@Nullable ActiveDemand activeDemand) {
         this.activeDemand = activeDemand;
         return this;
      }

      @Generated
      public DemandDisplayEntry build() {
         return new DemandDisplayEntry(this.id, this.match, this.desiredMinCount, this.basePricePerUnit, this.basePriority, this.activeDemand);
      }

      @Generated
      public String toString() {
         String var10000 = this.id;
         return "DemandDisplayEntry.DemandDisplayEntryBuilder(id=" + var10000 + ", match=" + String.valueOf(this.match) + ", desiredMinCount=" + this.desiredMinCount + ", basePricePerUnit=" + this.basePricePerUnit + ", basePriority=" + this.basePriority + ", activeDemand=" + String.valueOf(this.activeDemand) + ")";
      }
   }
}
