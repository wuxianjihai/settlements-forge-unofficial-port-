package dev.breezes.settlements.application.reputation;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.domain.reputation.ReputationStore;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class ReputationService_Factory implements Factory<ReputationService> {
   private final Provider<ReputationStore> storeProvider;
   private final Provider<ReputationConfig> configProvider;

   private ReputationService_Factory(Provider<ReputationStore> storeProvider, Provider<ReputationConfig> configProvider) {
      this.storeProvider = storeProvider;
      this.configProvider = configProvider;
   }

   public ReputationService get() {
      return newInstance((ReputationStore)this.storeProvider.get(), (ReputationConfig)this.configProvider.get());
   }

   public static ReputationService_Factory create(Provider<ReputationStore> storeProvider, Provider<ReputationConfig> configProvider) {
      return new ReputationService_Factory(storeProvider, configProvider);
   }

   public static ReputationService newInstance(ReputationStore store, ReputationConfig config) {
      return new ReputationService(store, config);
   }
}
