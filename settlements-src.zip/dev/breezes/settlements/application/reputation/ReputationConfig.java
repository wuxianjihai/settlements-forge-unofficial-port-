package dev.breezes.settlements.application.reputation;

import dev.breezes.settlements.infrastructure.config.annotations.BehaviorConfig;
import dev.breezes.settlements.infrastructure.config.annotations.ConfigurationType;
import dev.breezes.settlements.infrastructure.config.annotations.integers.IntegerConfig;

@BehaviorConfig(
   name = "reputation",
   type = ConfigurationType.GENERAL
)
public record ReputationConfig(@IntegerConfig(type = ConfigurationType.GENERAL,identifier = "reputation_cure_gain",description = "Reputation gained per zombie villager cured",defaultValue = 20,min = 0,max = 1000) int cureGain, @IntegerConfig(type = ConfigurationType.GENERAL,identifier = "reputation_minor_positive_gain",description = "Minor positive reputation gained alongside a cure",defaultValue = 25,min = 0,max = 1000) int minorPositiveGain, @IntegerConfig(type = ConfigurationType.GENERAL,identifier = "reputation_hurt_loss",description = "Reputation lost per hit on a villager",defaultValue = 20,min = 0,max = 1000) int hurtLoss, @IntegerConfig(type = ConfigurationType.GENERAL,identifier = "reputation_kill_loss",description = "Reputation lost per kill of a villager",defaultValue = 25,min = 0,max = 1000) int killLoss, @IntegerConfig(type = ConfigurationType.GENERAL,identifier = "reputation_trade_gain",description = "Reputation gained per trade with a villager",defaultValue = 15,min = 0,max = 1000) int tradeGain, @IntegerConfig(type = ConfigurationType.GENERAL,identifier = "reputation_kill_spread_radius",description = "Radius (in blocks) within which other villagers learn about a kill",defaultValue = 16,min = 1,max = 128) int killSpreadRadius, @IntegerConfig(type = ConfigurationType.GENERAL,identifier = "reputation_trade_heal_amount",description = "HURT reputation reduced per successful trade (trade-heals-reputation mechanic)",defaultValue = 5,min = 0,max = 200) int tradeHealAmount) {
}
