package dev.breezes.settlements.application.reputation;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.reputation.PlayerReputation;
import dev.breezes.settlements.domain.reputation.ReputationLevel;
import dev.breezes.settlements.domain.reputation.ReputationStore;
import dev.breezes.settlements.domain.reputation.ReputationType;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import lombok.Generated;

@ServerScope
public final class ReputationService {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ReputationService.class.getName());
   private final ReputationStore store;
   private final ReputationConfig config;
   private final List<ReputationChangeListener> listeners = new CopyOnWriteArrayList();

   public void addListener(ReputationChangeListener listener) {
      this.listeners.add(listener);
   }

   public ReputationChangeEvent addReputation(UUID villagerId, UUID playerId, ReputationType type) {
      int var10000;
      switch (type) {
         case CURE -> var10000 = this.config.cureGain();
         case MINOR_POSITIVE -> var10000 = this.config.minorPositiveGain();
         case HURT -> var10000 = this.config.hurtLoss();
         case KILL -> var10000 = this.config.killLoss();
         case TRADE -> var10000 = this.config.tradeGain();
         default -> throw new IncompatibleClassChangeError();
      }

      int amount = var10000;
      return this.addReputation(villagerId, playerId, type, amount);
   }

   public ReputationChangeEvent addReputation(UUID villagerId, UUID playerId, ReputationType type, int amount) {
      PlayerReputation rep = this.store.getOrCreate(villagerId, playerId);
      int oldScore = rep.getScore(type);
      int oldComposite = rep.getCompositeScore();
      ReputationLevel oldLevel = ReputationLevel.fromScore(oldComposite);
      int delta = rep.add(type, amount);
      int newScore = rep.getScore(type);
      int newComposite = rep.getCompositeScore();
      ReputationLevel newLevel = ReputationLevel.fromScore(newComposite);
      ReputationChangeEvent event = ReputationChangeEvent.builder().villagerId(villagerId).playerId(playerId).type(type).delta(delta).oldScore(oldScore).newScore(newScore).oldCompositeScore(oldComposite).newCompositeScore(newComposite).oldLevel(oldLevel).newLevel(newLevel).build();
      log.debug("Reputation change: villager={} player={} type={} delta={} score={}→{} composite={}→{} level={}→{}", villagerId, playerId, type, delta, oldScore, newScore, oldComposite, newComposite, oldLevel, newLevel);
      this.fireEvent(event);
      return event;
   }

   public void onTrade(UUID villagerId, UUID playerId) {
      this.addReputation(villagerId, playerId, ReputationType.TRADE);
      int healAmount = this.config.tradeHealAmount();
      if (healAmount > 0) {
         PlayerReputation rep = this.store.getOrCreate(villagerId, playerId);
         int reduced = rep.reduceHurt(healAmount);
         if (reduced > 0) {
            log.debug("Trade healed HURT reputation: villager={} player={} reduced={}", villagerId, playerId, reduced);
         }
      }

   }

   public void removeVillager(UUID villagerId) {
      this.store.removeVillager(villagerId);
      log.debug("Cleared reputation data for villager {}", villagerId);
   }

   public int getCompositeScore(UUID villagerId, UUID playerId) {
      PlayerReputation rep = this.store.getOrNull(villagerId, playerId);
      return rep == null ? 0 : rep.getCompositeScore();
   }

   public ReputationLevel getLevel(UUID villagerId, UUID playerId) {
      return ReputationLevel.fromScore(this.getCompositeScore(villagerId, playerId));
   }

   public Optional<PlayerReputation> getReputation(UUID villagerId, UUID playerId) {
      return Optional.ofNullable(this.store.getOrNull(villagerId, playerId));
   }

   public Map<UUID, PlayerReputation> getVillagerReputations(UUID villagerId) {
      return this.store.getVillagerReputations(villagerId);
   }

   public ReputationStore getStore() {
      return this.store;
   }

   private void fireEvent(ReputationChangeEvent event) {
      for(ReputationChangeListener listener : this.listeners) {
         try {
            listener.onReputationChanged(event);
         } catch (Exception e) {
            log.error("Reputation listener {} threw on event {}", listener, event, e);
         }
      }

   }

   @Inject
   @Generated
   ReputationService(ReputationStore store, ReputationConfig config) {
      this.store = store;
      this.config = config;
   }

   @FunctionalInterface
   public interface ReputationChangeListener {
      void onReputationChanged(ReputationChangeEvent var1);
   }
}
