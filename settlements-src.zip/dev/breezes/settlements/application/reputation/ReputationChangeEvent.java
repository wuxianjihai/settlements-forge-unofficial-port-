package dev.breezes.settlements.application.reputation;

import dev.breezes.settlements.domain.reputation.ReputationLevel;
import dev.breezes.settlements.domain.reputation.ReputationType;
import java.util.UUID;
import lombok.Generated;

public final class ReputationChangeEvent {
   private final UUID villagerId;
   private final UUID playerId;
   private final ReputationType type;
   private final int delta;
   private final int oldScore;
   private final int newScore;
   private final int oldCompositeScore;
   private final int newCompositeScore;
   private final ReputationLevel oldLevel;
   private final ReputationLevel newLevel;

   public boolean isLevelChange() {
      return this.oldLevel != this.newLevel;
   }

   @Generated
   ReputationChangeEvent(UUID villagerId, UUID playerId, ReputationType type, int delta, int oldScore, int newScore, int oldCompositeScore, int newCompositeScore, ReputationLevel oldLevel, ReputationLevel newLevel) {
      this.villagerId = villagerId;
      this.playerId = playerId;
      this.type = type;
      this.delta = delta;
      this.oldScore = oldScore;
      this.newScore = newScore;
      this.oldCompositeScore = oldCompositeScore;
      this.newCompositeScore = newCompositeScore;
      this.oldLevel = oldLevel;
      this.newLevel = newLevel;
   }

   @Generated
   public static ReputationChangeEventBuilder builder() {
      return new ReputationChangeEventBuilder();
   }

   @Generated
   public UUID getVillagerId() {
      return this.villagerId;
   }

   @Generated
   public UUID getPlayerId() {
      return this.playerId;
   }

   @Generated
   public ReputationType getType() {
      return this.type;
   }

   @Generated
   public int getDelta() {
      return this.delta;
   }

   @Generated
   public int getOldScore() {
      return this.oldScore;
   }

   @Generated
   public int getNewScore() {
      return this.newScore;
   }

   @Generated
   public int getOldCompositeScore() {
      return this.oldCompositeScore;
   }

   @Generated
   public int getNewCompositeScore() {
      return this.newCompositeScore;
   }

   @Generated
   public ReputationLevel getOldLevel() {
      return this.oldLevel;
   }

   @Generated
   public ReputationLevel getNewLevel() {
      return this.newLevel;
   }

   @Generated
   public static class ReputationChangeEventBuilder {
      @Generated
      private UUID villagerId;
      @Generated
      private UUID playerId;
      @Generated
      private ReputationType type;
      @Generated
      private int delta;
      @Generated
      private int oldScore;
      @Generated
      private int newScore;
      @Generated
      private int oldCompositeScore;
      @Generated
      private int newCompositeScore;
      @Generated
      private ReputationLevel oldLevel;
      @Generated
      private ReputationLevel newLevel;

      @Generated
      ReputationChangeEventBuilder() {
      }

      @Generated
      public ReputationChangeEventBuilder villagerId(UUID villagerId) {
         this.villagerId = villagerId;
         return this;
      }

      @Generated
      public ReputationChangeEventBuilder playerId(UUID playerId) {
         this.playerId = playerId;
         return this;
      }

      @Generated
      public ReputationChangeEventBuilder type(ReputationType type) {
         this.type = type;
         return this;
      }

      @Generated
      public ReputationChangeEventBuilder delta(int delta) {
         this.delta = delta;
         return this;
      }

      @Generated
      public ReputationChangeEventBuilder oldScore(int oldScore) {
         this.oldScore = oldScore;
         return this;
      }

      @Generated
      public ReputationChangeEventBuilder newScore(int newScore) {
         this.newScore = newScore;
         return this;
      }

      @Generated
      public ReputationChangeEventBuilder oldCompositeScore(int oldCompositeScore) {
         this.oldCompositeScore = oldCompositeScore;
         return this;
      }

      @Generated
      public ReputationChangeEventBuilder newCompositeScore(int newCompositeScore) {
         this.newCompositeScore = newCompositeScore;
         return this;
      }

      @Generated
      public ReputationChangeEventBuilder oldLevel(ReputationLevel oldLevel) {
         this.oldLevel = oldLevel;
         return this;
      }

      @Generated
      public ReputationChangeEventBuilder newLevel(ReputationLevel newLevel) {
         this.newLevel = newLevel;
         return this;
      }

      @Generated
      public ReputationChangeEvent build() {
         return new ReputationChangeEvent(this.villagerId, this.playerId, this.type, this.delta, this.oldScore, this.newScore, this.oldCompositeScore, this.newCompositeScore, this.oldLevel, this.newLevel);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.villagerId);
         return "ReputationChangeEvent.ReputationChangeEventBuilder(villagerId=" + var10000 + ", playerId=" + String.valueOf(this.playerId) + ", type=" + String.valueOf(this.type) + ", delta=" + this.delta + ", oldScore=" + this.oldScore + ", newScore=" + this.newScore + ", oldCompositeScore=" + this.oldCompositeScore + ", newCompositeScore=" + this.newCompositeScore + ", oldLevel=" + String.valueOf(this.oldLevel) + ", newLevel=" + String.valueOf(this.newLevel) + ")";
      }
   }
}
