package dev.breezes.settlements.application.ai.socialcue;

import dev.breezes.settlements.domain.ai.observation.ObservationBuffer;
import dev.breezes.settlements.domain.world.location.Location;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public final class SocialCueRuntimeState {
   @Nullable
   private SocialCue activeCue;
   @Nullable
   private SocialCueCatalogEntry activeCueEntry;
   private int nextStepIndex;
   private long cueStartGameTime;
   @Nullable
   private Location gazeLookTarget;
   private final Map<String, Long> cueCooldowns;
   private final Map<UUID, Long> targetCooldowns;
   private long nextAdmissionScanTick;
   private long laneQuietUntil;
   private long lastSeenSeq;
   private boolean admissionScanInitialized;
   private final ObservationBuffer observationBuffer;

   public SocialCueRuntimeState() {
      this(50);
   }

   public SocialCueRuntimeState(int observationBufferCapacity) {
      this.cueCooldowns = new HashMap();
      this.targetCooldowns = new HashMap();
      this.observationBuffer = new ObservationBuffer(observationBufferCapacity);
      this.reset();
   }

   public boolean isCueActive() {
      return this.activeCue != null;
   }

   public void start(@Nonnull SocialCue cue, @Nullable SocialCueCatalogEntry entry, long gameTime) {
      this.activeCue = cue;
      this.activeCueEntry = entry;
      this.nextStepIndex = 0;
      this.cueStartGameTime = gameTime;
      this.gazeLookTarget = null;
   }

   public void advance() {
      ++this.nextStepIndex;
   }

   public void setGazeLookTarget(@Nullable Location location) {
      this.gazeLookTarget = location;
   }

   @Nullable
   public SocialCueCatalogEntry getActiveCueEntry() {
      return this.activeCueEntry;
   }

   public void markAdmissionScanInitialized() {
      this.admissionScanInitialized = true;
   }

   public void cancelActiveCue() {
      this.activeCue = null;
      this.activeCueEntry = null;
      this.nextStepIndex = 0;
      this.gazeLookTarget = null;
   }

   public void finish(long gameTime) {
      long baseCooldownTicks = this.activeCue != null ? this.activeCue.getCooldown().getTicks() : 0L;
      this.finish(gameTime, baseCooldownTicks);
   }

   public void finish(long gameTime, long cooldownTicks) {
      if (this.activeCue != null) {
         this.cueCooldowns.put(this.activeCue.getKey(), gameTime + cooldownTicks);
      }

      this.activeCue = null;
      this.activeCueEntry = null;
      this.nextStepIndex = 0;
      this.gazeLookTarget = null;
      this.targetCooldowns.entrySet().removeIf((e) -> (Long)e.getValue() <= gameTime);
   }

   public boolean isCueOnCooldown(String cueKey, long gameTime) {
      Long expiry = (Long)this.cueCooldowns.get(cueKey);
      return expiry != null && gameTime < expiry;
   }

   public boolean isTargetOnCooldown(UUID targetId, long gameTime) {
      Long expiry = (Long)this.targetCooldowns.get(targetId);
      return expiry != null && gameTime < expiry;
   }

   public void recordTargetGreeted(UUID targetId, long gameTime, long cooldownTicks) {
      this.targetCooldowns.put(targetId, gameTime + cooldownTicks);
   }

   public void markLaneQuietUntil(long tick) {
      this.laneQuietUntil = tick;
   }

   public boolean isLaneQuiet(long gameTime) {
      return gameTime < this.laneQuietUntil;
   }

   public void recordCueDeclined(String cueKey, long gameTime, long cooldownTicks) {
      this.cueCooldowns.put(cueKey, gameTime + cooldownTicks);
   }

   public void scheduleNextAdmissionScan(long gameTick) {
      this.nextAdmissionScanTick = gameTick;
   }

   public void seedCursor(long currentBusSeq) {
      this.lastSeenSeq = currentBusSeq;
   }

   public void advanceCursor(long newSeq) {
      this.lastSeenSeq = newSeq;
   }

   public void reset() {
      this.activeCue = null;
      this.activeCueEntry = null;
      this.nextStepIndex = 0;
      this.cueStartGameTime = 0L;
      this.gazeLookTarget = null;
      this.cueCooldowns.clear();
      this.targetCooldowns.clear();
      this.nextAdmissionScanTick = 0L;
      this.laneQuietUntil = 0L;
      this.lastSeenSeq = 0L;
      this.admissionScanInitialized = false;
   }

   @Nullable
   @Generated
   public SocialCue getActiveCue() {
      return this.activeCue;
   }

   @Generated
   public int getNextStepIndex() {
      return this.nextStepIndex;
   }

   @Generated
   public long getCueStartGameTime() {
      return this.cueStartGameTime;
   }

   @Nullable
   @Generated
   public Location getGazeLookTarget() {
      return this.gazeLookTarget;
   }

   @Generated
   public Map<String, Long> getCueCooldowns() {
      return this.cueCooldowns;
   }

   @Generated
   public Map<UUID, Long> getTargetCooldowns() {
      return this.targetCooldowns;
   }

   @Generated
   public long getNextAdmissionScanTick() {
      return this.nextAdmissionScanTick;
   }

   @Generated
   public long getLaneQuietUntil() {
      return this.laneQuietUntil;
   }

   @Generated
   public long getLastSeenSeq() {
      return this.lastSeenSeq;
   }

   @Generated
   public boolean isAdmissionScanInitialized() {
      return this.admissionScanInitialized;
   }

   @Generated
   public ObservationBuffer getObservationBuffer() {
      return this.observationBuffer;
   }
}
