package dev.breezes.settlements.application.ai.socialcue;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.Set;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class SocialCueArbiter_Factory implements Factory<SocialCueArbiter> {
   private final Provider<Set<SocialCueCatalogEntry>> catalogProvider;
   private final Provider<SocialCuePresenter> presenterProvider;
   private final Provider<SocialCueConfig> socialCueConfigProvider;

   private SocialCueArbiter_Factory(Provider<Set<SocialCueCatalogEntry>> catalogProvider, Provider<SocialCuePresenter> presenterProvider, Provider<SocialCueConfig> socialCueConfigProvider) {
      this.catalogProvider = catalogProvider;
      this.presenterProvider = presenterProvider;
      this.socialCueConfigProvider = socialCueConfigProvider;
   }

   public SocialCueArbiter get() {
      return newInstance((Set)this.catalogProvider.get(), (SocialCuePresenter)this.presenterProvider.get(), (SocialCueConfig)this.socialCueConfigProvider.get());
   }

   public static SocialCueArbiter_Factory create(Provider<Set<SocialCueCatalogEntry>> catalogProvider, Provider<SocialCuePresenter> presenterProvider, Provider<SocialCueConfig> socialCueConfigProvider) {
      return new SocialCueArbiter_Factory(catalogProvider, presenterProvider, socialCueConfigProvider);
   }

   public static SocialCueArbiter newInstance(Set<SocialCueCatalogEntry> catalog, SocialCuePresenter presenter, SocialCueConfig socialCueConfig) {
      return new SocialCueArbiter(catalog, presenter, socialCueConfig);
   }
}
