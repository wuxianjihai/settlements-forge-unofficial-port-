package dev.breezes.settlements.application.ai.socialcue;

public enum TriggerCategory {
   UQOWSU("存在与行为", "uqowsu"),
   AKCIRP("日常行为", "akcirp"),
   QFQRXU("移动", "qfqrxu"),
   YKBNJZ("装备与盔甲", "ykbnjz"),
   EIJWGK("状态效果", "eijwgk"),
   MJSTVM("声望与村庄状态", "mjstvm"),
   LFYJNK("游戏变更", "lfyjnk"),
   RKHKTM("死亡与睡眠", "rkhktm"),
   KSFWAD("破坏方块", "ksfwad"),
   CALZFJ("放置方块", "calzfj"),
   NURTUF("使用方块", "nurtuf"),
   YSAANN("红石与技术", "ysaann"),
   FDZEAY("火焰与爆炸物", "fdzeay"),
   KOFIUC("敌对与危险", "kofiuc"),
   NZCIGZ("动物", "nzcigz"),
   ULPSRU("幼年生物", "ulpsru"),
   RGINYM("友好与帮助", "rginym"),
   LLRYGN("不寻常与特殊", "llrygn"),
   EJPQED("游荡与闲置", "ejpqed"),
   NTTJZB("工作与职业", "nttjzb"),
   VINMMA("家与睡眠", "vinmma"),
   CCLCEW("食物与物品", "cclcew"),
   TUCPEJ("家庭与社区", "tucpej"),
   CDGEYW("命名、生成与治疗", "cdgeyw"),
   CNQPJA("生活与移动", "cnqpja"),
   BMCTVI("玩家互动", "bmctvi"),
   EUAOVT("装饰品", "euaovt"),
   UBUINT("食物", "ubuint"),
   TAYKMN("命名", "taykmn"),
   BUZJMT("世界反应", "buzjmt"),
   GQKBMM("被玩家攻击", "gqkbmm"),
   QYRDKP("生物攻击", "qyrdkp"),
   TPJQAB("环境伤害", "tpjqab"),
   VPJUBI("药水与投掷物", "vpjubi"),
   GJXUXO("环境危害", "gjxuxo"),
   LDPJJT("恐慌与一般伤害", "ldpjjt"),
   NEJTZV("目睹危险", "nejtzv"),
   YENAHN("交易", "yenahn"),
   ZQVGYV("拒绝交易", "zqvgyv"),
   HYQMHI("声望", "hyqmhi"),
   WVAVRH("流浪商人", "wvavrh"),
   PDQCGQ("村民鼻子", "pdqcgq"),
   YSXSHU("装饰品", "ysxshu"),
   TDRRSE("告示牌", "tdrrse"),
   PPPUGX("船", "pppugx"),
   ZGRONF("矿车", "zgronf"),
   ZYFQGM("一天中的时间", "zyfqgm"),
   LGYJGS("天气与环境", "lgyjgs"),
   CKECGT("维度", "ckecgt"),
   CUBHUO("位置", "cubhuo"),
   MKEEWG("特殊日期与季节", "mkeewg"),
   HPMJJV("聚会与八卦", "hpmjjv"),
   QIQJCM("一起游荡", "qiqjcm"),
   YOERQX("营火交谈", "yoerqx"),
   GLFTID("村长", "glftid"),
   BKSFZP("5号村民", "bksfzp"),
   KVRKGE("9号村民", "kvrkge"),
   YQQVYB("村民侠", "yqqvyb"),
   SDUJNF("毛毛羊", "sdujnf"),
   IPNPRS("无法触及的村民", "ipnprs"),
   MJMRTM("其他村民的反应", "mjmrtm"),
   QLLZOX("现实世界日期", "qllzox"),
   UNCLASSIFIED("未分类（特殊角色专用）", "unclassified");

   private final String displayName;
   private final String rawKey;

   private TriggerCategory(String displayName, String rawKey) {
      this.displayName = displayName;
      this.rawKey = rawKey;
   }

   public String getDisplayName() {
      return this.displayName;
   }

   public String getRawKey() {
      return this.rawKey;
   }

   // $FF: synthetic method
   private static TriggerCategory[] $values() {
      return new TriggerCategory[]{UQOWSU, AKCIRP, QFQRXU, YKBNJZ, EIJWGK, MJSTVM, LFYJNK, RKHKTM, KSFWAD, CALZFJ, NURTUF, YSAANN, FDZEAY, KOFIUC, NZCIGZ, ULPSRU, RGINYM, LLRYGN, EJPQED, NTTJZB, VINMMA, CCLCEW, TUCPEJ, CDGEYW, CNQPJA, BMCTVI, EUAOVT, UBUINT, TAYKMN, BUZJMT, GQKBMM, QYRDKP, TPJQAB, VPJUBI, GJXUXO, LDPJJT, NEJTZV, YENAHN, ZQVGYV, HYQMHI, WVAVRH, PDQCGQ, YSXSHU, TDRRSE, PPPUGX, ZGRONF, ZYFQGM, LGYJGS, CKECGT, CUBHUO, MKEEWG, HPMJJV, QIQJCM, YOERQX, GLFTID, BKSFZP, KVRKGE, YQQVYB, SDUJNF, IPNPRS, MJMRTM, QLLZOX, UNCLASSIFIED};
   }
}
