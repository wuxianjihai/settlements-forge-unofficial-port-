package dev.breezes.settlements.application.ai.socialcue;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class PlayerActionEventRecorder_Factory implements Factory<PlayerActionEventRecorder> {
   public PlayerActionEventRecorder get() {
      return newInstance();
   }

   public static PlayerActionEventRecorder_Factory create() {
      return PlayerActionEventRecorder_Factory.InstanceHolder.INSTANCE;
   }

   public static PlayerActionEventRecorder newInstance() {
      return new PlayerActionEventRecorder();
   }

   private static final class InstanceHolder {
      static final PlayerActionEventRecorder_Factory INSTANCE = new PlayerActionEventRecorder_Factory();
   }
}
