package dev.breezes.settlements.application.ai.socialcue;

import dev.breezes.settlements.domain.ai.catalog.BehaviorChannel;
import dev.breezes.settlements.domain.time.ClockTicks;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import javax.annotation.Nullable;
import lombok.Generated;

public final class SocialCue {
   private final String key;
   private final Set<BehaviorChannel> channels;
   private final ClockTicks cooldown;
   private final SocialCueScript script;
   @Nullable
   private final String contextKey;

   @Generated
   SocialCue(String key, Set<BehaviorChannel> channels, ClockTicks cooldown, SocialCueScript script, @Nullable String contextKey) {
      this.key = key;
      this.channels = channels;
      this.cooldown = cooldown;
      this.script = script;
      this.contextKey = contextKey;
   }

   @Generated
   public static SocialCueBuilder builder() {
      return new SocialCueBuilder();
   }

   @Generated
   public String getKey() {
      return this.key;
   }

   @Generated
   public Set<BehaviorChannel> getChannels() {
      return this.channels;
   }

   @Generated
   public ClockTicks getCooldown() {
      return this.cooldown;
   }

   @Generated
   public SocialCueScript getScript() {
      return this.script;
   }

   @Nullable
   @Generated
   public String getContextKey() {
      return this.contextKey;
   }

   @Generated
   public static class SocialCueBuilder {
      @Generated
      private String key;
      @Generated
      private ArrayList<BehaviorChannel> channels;
      @Generated
      private ClockTicks cooldown;
      @Generated
      private SocialCueScript script;
      @Generated
      private String contextKey;

      @Generated
      SocialCueBuilder() {
      }

      @Generated
      public SocialCueBuilder key(String key) {
         this.key = key;
         return this;
      }

      @Generated
      public SocialCueBuilder channel(BehaviorChannel channel) {
         if (this.channels == null) {
            this.channels = new ArrayList();
         }

         this.channels.add(channel);
         return this;
      }

      @Generated
      public SocialCueBuilder channels(Collection<? extends BehaviorChannel> channels) {
         if (channels == null) {
            throw new NullPointerException("channels cannot be null");
         } else {
            if (this.channels == null) {
               this.channels = new ArrayList();
            }

            this.channels.addAll(channels);
            return this;
         }
      }

      @Generated
      public SocialCueBuilder clearChannels() {
         if (this.channels != null) {
            this.channels.clear();
         }

         return this;
      }

      @Generated
      public SocialCueBuilder cooldown(ClockTicks cooldown) {
         this.cooldown = cooldown;
         return this;
      }

      @Generated
      public SocialCueBuilder script(SocialCueScript script) {
         this.script = script;
         return this;
      }

      @Generated
      public SocialCueBuilder contextKey(@Nullable String contextKey) {
         this.contextKey = contextKey;
         return this;
      }

      @Generated
      public SocialCue build() {
         Set<BehaviorChannel> channels;
         switch (this.channels == null ? 0 : this.channels.size()) {
            case 0:
               channels = Collections.emptySet();
               break;
            case 1:
               channels = Collections.singleton((BehaviorChannel)this.channels.get(0));
               break;
            default:
               channels = new LinkedHashSet(this.channels.size() < 1073741824 ? 1 + this.channels.size() + (this.channels.size() - 3) / 3 : Integer.MAX_VALUE);
               channels.addAll(this.channels);
               channels = Collections.unmodifiableSet(channels);
         }

         return new SocialCue(this.key, channels, this.cooldown, this.script, this.contextKey);
      }

      @Generated
      public String toString() {
         String var10000 = this.key;
         return "SocialCue.SocialCueBuilder(key=" + var10000 + ", channels=" + String.valueOf(this.channels) + ", cooldown=" + String.valueOf(this.cooldown) + ", script=" + String.valueOf(this.script) + ", contextKey=" + this.contextKey + ")";
      }
   }
}
