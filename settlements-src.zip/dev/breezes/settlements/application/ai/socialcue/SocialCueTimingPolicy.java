package dev.breezes.settlements.application.ai.socialcue;

import lombok.Generated;

public final class SocialCueTimingPolicy {
   public static boolean isStepDue(SocialCueScript script, int nextStepIndex, long cueStartGameTime, long gameTime) {
      long stepStart = script.stepStartTick(nextStepIndex, cueStartGameTime);
      return gameTime >= stepStart;
   }

   public static boolean isReadyToFinish(int nextStepIndex, int stepCount, long cueStartGameTime, long totalDurationTicks, long gameTime) {
      return nextStepIndex >= stepCount && gameTime >= cueStartGameTime + totalDurationTicks;
   }

   @Generated
   private SocialCueTimingPolicy() {
   }
}
