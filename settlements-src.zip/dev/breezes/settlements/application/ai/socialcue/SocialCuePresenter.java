package dev.breezes.settlements.application.ai.socialcue;

import dev.breezes.settlements.application.ai.speech.VillagerSpeechService;
import dev.breezes.settlements.application.ai.speech.VillagerUtterance;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import lombok.Generated;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;

@ServerScope
public final class SocialCuePresenter {
   private final VillagerSpeechService villagerSpeechService;

   public void dispatch(CueStep step, BaseVillager villager, SocialCueRuntimeState runtimeState) {
      if (step instanceof CueStep.Gesture gesture) {
         villager.triggerMotion(gesture.archetype());
      } else if (step instanceof CueStep.Speak speak) {
         this.villagerSpeechService.utter(VillagerUtterance.builder().speaker(villager).line(speak.line()).register(speak.register()).addressee((LivingEntity)null).bubbleTtl(speak.ttl()).build());
      } else if (step instanceof CueStep.Sound sound) {
         Location.fromEntity(villager, true).playSound(sound.soundEvent(), sound.volume(), sound.pitch(), SoundSource.NEUTRAL);
      } else if (step instanceof CueStep.Gaze gaze) {
         runtimeState.setGazeLookTarget(gaze.target());
      } else if (step instanceof CueStep.Wait) {
      }

   }

   @Inject
   @Generated
   SocialCuePresenter(VillagerSpeechService villagerSpeechService) {
      this.villagerSpeechService = villagerSpeechService;
   }
}
