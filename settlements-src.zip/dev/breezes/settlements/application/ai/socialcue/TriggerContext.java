package dev.breezes.settlements.application.ai.socialcue;

import dev.breezes.settlements.application.reputation.ReputationService;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.reputation.ReputationLevel;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public final class TriggerContext {
   private final BaseVillager villager;
   private final PlayerActionEventRecorder eventRecorder;
   private final ReputationService reputationService;

   private TriggerContext(BaseVillager villager, PlayerActionEventRecorder eventRecorder, ReputationService reputationService) {
      this.villager = villager;
      this.eventRecorder = eventRecorder;
      this.reputationService = reputationService;
   }

   public static TriggerContext of(BaseVillager villager, PlayerActionEventRecorder eventRecorder, ReputationService reputationService) {
      return new TriggerContext(villager, eventRecorder, reputationService);
   }

   public BaseVillager getVillager() {
      return this.villager;
   }

   public UUID getVillagerId() {
      return this.villager.m_20148_();
   }

   public ServerLevel level() {
      return (ServerLevel)this.villager.m_9236_();
   }

   public long gameTime() {
      return this.villager.m_9236_().m_46467_();
   }

   @Nullable
   public Player nearestPlayer() {
      return (Player)((PerceivedEntities)this.villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_SENSED_ENTITIES).orElse(PerceivedEntities.empty())).closest(Player.class, (p) -> !p.m_5833_(), this.villager).orElse((Object)null);
   }

   public Optional<String> nearestPlayerUuid() {
      Player player = this.nearestPlayer();
      return player == null ? Optional.empty() : Optional.of(player.m_20148_().toString());
   }

   public boolean isPlayerWithin(double radiusSquared) {
      Player player = this.nearestPlayer();
      return player != null && player.m_20280_(this.villager) <= radiusSquared;
   }

   public ReputationLevel reputationLevelOfNearestPlayer() {
      Player player = this.nearestPlayer();
      return player == null ? ReputationLevel.NEUTRAL : this.reputationService.getLevel(this.villager.m_20148_(), player.m_20148_());
   }

   public ReputationLevel reputationLevelOf(UUID playerUuid) {
      return this.reputationService.getLevel(this.villager.m_20148_(), playerUuid);
   }

   public int reputationScoreOf(UUID playerUuid) {
      return this.reputationService.getCompositeScore(this.villager.m_20148_(), playerUuid);
   }

   public boolean hasRecentAction(PlayerActionEventRecorder.ActionType type, UUID playerUuid, long windowTicks, double maxDistance) {
      return this.eventRecorder.findRecent(type, this.level(), playerUuid, windowTicks, maxDistance * maxDistance, this.villager.m_20185_(), this.villager.m_20186_(), this.villager.m_20189_()) != null;
   }

   public boolean nearestPlayerDidRecently(PlayerActionEventRecorder.ActionType type, long windowTicks, double maxDistance) {
      Player player = this.nearestPlayer();
      return player == null ? false : this.hasRecentAction(type, player.m_20148_(), windowTicks, maxDistance);
   }

   public boolean anyPlayerDidRecently(PlayerActionEventRecorder.ActionType type, long windowTicks, double maxDistance) {
      return this.eventRecorder.findAnyRecent(type, this.level(), windowTicks, maxDistance * maxDistance, this.villager.m_20185_(), this.villager.m_20186_(), this.villager.m_20189_()) != null;
   }

   public boolean isRaining() {
      return this.villager.m_9236_().m_46471_();
   }

   public boolean isNight() {
      return this.villager.m_9236_().m_46462_();
   }

   public boolean isDay() {
      return !this.villager.m_9236_().m_46462_();
   }

   public boolean isInOverworld() {
      return this.villager.m_9236_().m_46472_() == Level.f_46428_;
   }

   public boolean isInNether() {
      return this.villager.m_9236_().m_46472_() == Level.f_46429_;
   }

   public boolean isInEnd() {
      return this.villager.m_9236_().m_46472_() == Level.f_46430_;
   }

   public boolean nearestPlayerHoldsItemMatching(String idSuffix) {
      Player player = this.nearestPlayer();
      if (player == null) {
         return false;
      } else {
         String heldId = player.m_21205_().m_41720_().toString();
         return heldId != null && heldId.endsWith(idSuffix);
      }
   }
}
