package dev.breezes.settlements.application.ai.socialcue;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.UUID;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

@ServerScope
public final class PlayerActionEventRecorder {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(PlayerActionEventRecorder.class.getName());
   private static final int MAX_BLOCK_ACTION_SNAPSHOTS = 64;
   private static final int MAX_GENERAL_SNAPSHOTS = 128;
   private final Deque<PlayerActionSnapshot> blockBreak = new ArrayDeque();
   private final Deque<PlayerActionSnapshot> blockPlace = new ArrayDeque();
   private final Deque<PlayerActionSnapshot> useBlock = new ArrayDeque();
   private final Deque<PlayerActionSnapshot> attackEntity = new ArrayDeque();
   private final Deque<PlayerActionSnapshot> playerDeath = new ArrayDeque();
   private final Deque<PlayerActionSnapshot> other = new ArrayDeque();

   @SubscribeEvent
   public void onBlockBreak(BlockEvent.BreakEvent event) {
      Player player = event.getPlayer();
      if (player instanceof ServerPlayer serverPlayer) {
         LevelAccessor var5 = event.getLevel();
         if (var5 instanceof ServerLevel serverLevel) {
            BlockState var6 = event.getState();
            this.record(this.blockBreak, serverLevel, serverPlayer, event.getPos(), var6.m_60734_(), 64);
         }
      }
   }

   @SubscribeEvent
   public void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
      Entity var3 = event.getEntity();
      if (var3 instanceof ServerPlayer serverPlayer) {
         LevelAccessor var4 = event.getLevel();
         if (var4 instanceof ServerLevel serverLevel) {
            this.record(this.blockPlace, serverLevel, serverPlayer, event.getPos(), event.getPlacedBlock().m_60734_(), 64);
         }
      }
   }

   @SubscribeEvent
   public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
      Player player = event.getEntity();
      if (player instanceof ServerPlayer serverPlayer) {
         Level var5 = event.getLevel();
         if (var5 instanceof ServerLevel serverLevel) {
            BlockPos var6 = event.getPos();
            this.record(this.useBlock, serverLevel, serverPlayer, var6, serverLevel.m_8055_(var6).m_60734_(), 128);
         }
      }
   }

   @SubscribeEvent
   public void onLivingHurt(LivingHurtEvent event) {
      Entity var3 = event.getSource().m_7639_();
      if (var3 instanceof ServerPlayer serverPlayer) {
         Level var4 = event.getEntity().m_9236_();
         if (var4 instanceof ServerLevel serverLevel) {
            this.recordAt(this.attackEntity, serverLevel, serverPlayer, event.getEntity().m_20185_(), event.getEntity().m_20186_(), event.getEntity().m_20189_(), event.getEntity().m_6095_().m_20675_(), 128);
         }
      }
   }

   @SubscribeEvent
   public void onPlayerDeath(LivingDeathEvent event) {
      LivingEntity var3 = event.getEntity();
      if (var3 instanceof ServerPlayer serverPlayer) {
         Level var4 = serverPlayer.m_9236_();
         if (var4 instanceof ServerLevel serverLevel) {
            this.record(this.playerDeath, serverLevel, serverPlayer, serverPlayer.m_20183_(), (Block)null, 128);
         }
      }
   }

   @Nullable
   public PlayerActionSnapshot latest(ActionType type) {
      Deque<PlayerActionSnapshot> queue = this.queueFor(type);
      return (PlayerActionSnapshot)queue.peekLast();
   }

   @Nullable
   public PlayerActionSnapshot findRecent(ActionType type, ServerLevel level, UUID playerUuid, long windowTicks, double maxDistanceSquared, double x, double y, double z) {
      long gameTime = level.m_46467_();
      Deque<PlayerActionSnapshot> deque = this.queueFor(type);
      Iterator<PlayerActionSnapshot> it = deque.descendingIterator();

      while(it.hasNext()) {
         PlayerActionSnapshot snap = (PlayerActionSnapshot)it.next();
         if (snap.isRecent(gameTime, windowTicks) && snap.getPlayerUuid().equals(playerUuid) && !(snap.distanceSquaredTo(x, y, z) > maxDistanceSquared)) {
            return snap;
         }
      }

      return null;
   }

   @Nullable
   public PlayerActionSnapshot findAnyRecent(ActionType type, ServerLevel level, long windowTicks, double maxDistanceSquared, double x, double y, double z) {
      long gameTime = level.m_46467_();
      Deque<PlayerActionSnapshot> deque = this.queueFor(type);
      Iterator<PlayerActionSnapshot> it = deque.descendingIterator();

      while(it.hasNext()) {
         PlayerActionSnapshot snap = (PlayerActionSnapshot)it.next();
         if (snap.isRecent(gameTime, windowTicks) && !(snap.distanceSquaredTo(x, y, z) > maxDistanceSquared)) {
            return snap;
         }
      }

      return null;
   }

   private Deque<PlayerActionSnapshot> queueFor(ActionType type) {
      Deque var10000;
      switch (type) {
         case BLOCK_BREAK -> var10000 = this.blockBreak;
         case BLOCK_PLACE -> var10000 = this.blockPlace;
         case USE_BLOCK -> var10000 = this.useBlock;
         case ATTACK_ENTITY -> var10000 = this.attackEntity;
         case PLAYER_DEATH -> var10000 = this.playerDeath;
         case OTHER -> var10000 = this.other;
         default -> throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   private void record(Deque<PlayerActionSnapshot> deque, ServerLevel level, ServerPlayer player, BlockPos pos, @Nullable Block block, int capacity) {
      this.recordAt(deque, level, player, (double)pos.m_123341_() + (double)0.5F, (double)pos.m_123342_() + (double)0.5F, (double)pos.m_123343_() + (double)0.5F, block == null ? null : block.m_49954_().getString(), capacity);
   }

   private void recordAt(Deque<PlayerActionSnapshot> deque, ServerLevel level, ServerPlayer player, double x, double y, double z, @Nullable String extra, int capacity) {
      PlayerActionSnapshot snap = new PlayerActionSnapshot(player.m_20148_(), level.m_46467_(), x, y, z, level.m_46472_().m_135782_().toString(), extra);
      deque.addLast(snap);

      while(deque.size() > capacity) {
         deque.removeFirst();
      }

   }

   @Inject
   @Generated
   PlayerActionEventRecorder() {
   }

   public static enum ActionType {
      BLOCK_BREAK,
      BLOCK_PLACE,
      USE_BLOCK,
      ATTACK_ENTITY,
      PLAYER_DEATH,
      OTHER;

      // $FF: synthetic method
      private static ActionType[] $values() {
         return new ActionType[]{BLOCK_BREAK, BLOCK_PLACE, USE_BLOCK, ATTACK_ENTITY, PLAYER_DEATH, OTHER};
      }
   }
}
