package dev.breezes.settlements.application.ai.socialcue;

import dev.breezes.settlements.domain.time.ClockTicks;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class SocialCueScript {
   public static final ClockTicks MAX_DURATION = ClockTicks.seconds((double)5.0F);
   private final List<CueStep> steps;
   private final ClockTicks totalDuration;
   private final long[] waitOffsetPrefix;

   public CueStep stepAt(int index) {
      return (CueStep)this.steps.get(index);
   }

   public int stepCount() {
      return this.steps.size();
   }

   public long stepStartTick(int index, long scriptStartGameTime) {
      return scriptStartGameTime + this.waitOffsetPrefix[index];
   }

   public static SocialCueScript of(@Nonnull List<CueStep> steps) {
      long[] prefix = new long[steps.size() + 1];
      long running = 0L;

      for(int i = 0; i < steps.size(); ++i) {
         prefix[i] = running;
         Object var6 = steps.get(i);
         if (var6 instanceof CueStep.Wait wait) {
            running += wait.duration().getTicks();
         }
      }

      prefix[steps.size()] = running;
      return builder().steps(steps).totalDuration(ClockTicks.of(running)).waitOffsetPrefix(prefix).build();
   }

   @Generated
   SocialCueScript(List<CueStep> steps, ClockTicks totalDuration, long[] waitOffsetPrefix) {
      this.steps = steps;
      this.totalDuration = totalDuration;
      this.waitOffsetPrefix = waitOffsetPrefix;
   }

   @Generated
   private static SocialCueScriptBuilder builder() {
      return new SocialCueScriptBuilder();
   }

   @Generated
   public List<CueStep> getSteps() {
      return this.steps;
   }

   @Generated
   public ClockTicks getTotalDuration() {
      return this.totalDuration;
   }

   @Generated
   private static class SocialCueScriptBuilder {
      @Generated
      private ArrayList<CueStep> steps;
      @Generated
      private ClockTicks totalDuration;
      @Generated
      private long[] waitOffsetPrefix;

      @Generated
      SocialCueScriptBuilder() {
      }

      @Generated
      private SocialCueScriptBuilder step(CueStep step) {
         if (this.steps == null) {
            this.steps = new ArrayList();
         }

         this.steps.add(step);
         return this;
      }

      @Generated
      private SocialCueScriptBuilder steps(Collection<? extends CueStep> steps) {
         if (steps == null) {
            throw new NullPointerException("steps cannot be null");
         } else {
            if (this.steps == null) {
               this.steps = new ArrayList();
            }

            this.steps.addAll(steps);
            return this;
         }
      }

      @Generated
      private SocialCueScriptBuilder clearSteps() {
         if (this.steps != null) {
            this.steps.clear();
         }

         return this;
      }

      @Generated
      private SocialCueScriptBuilder totalDuration(ClockTicks totalDuration) {
         this.totalDuration = totalDuration;
         return this;
      }

      @Generated
      private SocialCueScriptBuilder waitOffsetPrefix(long[] waitOffsetPrefix) {
         this.waitOffsetPrefix = waitOffsetPrefix;
         return this;
      }

      @Generated
      private SocialCueScript build() {
         List<CueStep> steps;
         switch (this.steps == null ? 0 : this.steps.size()) {
            case 0 -> steps = Collections.emptyList();
            case 1 -> steps = Collections.singletonList((CueStep)this.steps.get(0));
            default -> steps = Collections.unmodifiableList(new ArrayList(this.steps));
         }

         return new SocialCueScript(steps, this.totalDuration, this.waitOffsetPrefix);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.steps);
         return "SocialCueScript.SocialCueScriptBuilder(steps=" + var10000 + ", totalDuration=" + String.valueOf(this.totalDuration) + ", waitOffsetPrefix=" + Arrays.toString(this.waitOffsetPrefix) + ")";
      }
   }
}
