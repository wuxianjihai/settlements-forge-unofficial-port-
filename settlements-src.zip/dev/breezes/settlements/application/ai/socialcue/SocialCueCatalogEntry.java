package dev.breezes.settlements.application.ai.socialcue;

import dev.breezes.settlements.domain.ai.catalog.BehaviorChannel;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Function;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public final class SocialCueCatalogEntry {
   private final String key;
   private final Set<BehaviorChannel> channels;
   private final ClockTicks cooldown;
   private final ClockTicks perTargetCooldown;
   private final double fireChance;
   private final boolean bypassLaneRefractory;
   private final Function<BaseVillager, SocialCueScript> scriptFactory;
   private final Function<BaseVillager, Optional<String>> trigger;
   @Nullable
   private final BiConsumer<BaseVillager, String> onAdmit;
   @Nullable
   private final BiConsumer<BaseVillager, String> onComplete;

   public SocialCue buildCue(@Nonnull BaseVillager villager, @Nullable String contextKey) {
      return SocialCue.builder().key(this.key).channels(this.channels).cooldown(this.cooldown).script((SocialCueScript)this.scriptFactory.apply(villager)).contextKey(contextKey).build();
   }

   public void fireOnAdmit(@Nonnull BaseVillager villager, @Nullable String contextKey) {
      if (this.onAdmit != null && contextKey != null) {
         this.onAdmit.accept(villager, contextKey);
      }

   }

   public void fireOnComplete(@Nonnull BaseVillager villager, @Nullable String contextKey) {
      if (this.onComplete != null && contextKey != null) {
         this.onComplete.accept(villager, contextKey);
      }

   }

   @Generated
   private static double $default$fireChance() {
      return (double)1.0F;
   }

   @Generated
   private static boolean $default$bypassLaneRefractory() {
      return false;
   }

   @Generated
   SocialCueCatalogEntry(String key, Set<BehaviorChannel> channels, ClockTicks cooldown, ClockTicks perTargetCooldown, double fireChance, boolean bypassLaneRefractory, Function<BaseVillager, SocialCueScript> scriptFactory, Function<BaseVillager, Optional<String>> trigger, @Nullable BiConsumer<BaseVillager, String> onAdmit, @Nullable BiConsumer<BaseVillager, String> onComplete) {
      this.key = key;
      this.channels = channels;
      this.cooldown = cooldown;
      this.perTargetCooldown = perTargetCooldown;
      this.fireChance = fireChance;
      this.bypassLaneRefractory = bypassLaneRefractory;
      this.scriptFactory = scriptFactory;
      this.trigger = trigger;
      this.onAdmit = onAdmit;
      this.onComplete = onComplete;
   }

   @Generated
   public static SocialCueCatalogEntryBuilder builder() {
      return new SocialCueCatalogEntryBuilder();
   }

   @Generated
   public String getKey() {
      return this.key;
   }

   @Generated
   public Set<BehaviorChannel> getChannels() {
      return this.channels;
   }

   @Generated
   public ClockTicks getCooldown() {
      return this.cooldown;
   }

   @Generated
   public ClockTicks getPerTargetCooldown() {
      return this.perTargetCooldown;
   }

   @Generated
   public double getFireChance() {
      return this.fireChance;
   }

   @Generated
   public boolean isBypassLaneRefractory() {
      return this.bypassLaneRefractory;
   }

   @Generated
   public Function<BaseVillager, SocialCueScript> getScriptFactory() {
      return this.scriptFactory;
   }

   @Generated
   public Function<BaseVillager, Optional<String>> getTrigger() {
      return this.trigger;
   }

   @Nullable
   @Generated
   public BiConsumer<BaseVillager, String> getOnAdmit() {
      return this.onAdmit;
   }

   @Nullable
   @Generated
   public BiConsumer<BaseVillager, String> getOnComplete() {
      return this.onComplete;
   }

   @Generated
   public static class SocialCueCatalogEntryBuilder {
      @Generated
      private String key;
      @Generated
      private ArrayList<BehaviorChannel> channels;
      @Generated
      private ClockTicks cooldown;
      @Generated
      private ClockTicks perTargetCooldown;
      @Generated
      private boolean fireChance$set;
      @Generated
      private double fireChance$value;
      @Generated
      private boolean bypassLaneRefractory$set;
      @Generated
      private boolean bypassLaneRefractory$value;
      @Generated
      private Function<BaseVillager, SocialCueScript> scriptFactory;
      @Generated
      private Function<BaseVillager, Optional<String>> trigger;
      @Generated
      private BiConsumer<BaseVillager, String> onAdmit;
      @Generated
      private BiConsumer<BaseVillager, String> onComplete;

      @Generated
      SocialCueCatalogEntryBuilder() {
      }

      @Generated
      public SocialCueCatalogEntryBuilder key(String key) {
         this.key = key;
         return this;
      }

      @Generated
      public SocialCueCatalogEntryBuilder channel(BehaviorChannel channel) {
         if (this.channels == null) {
            this.channels = new ArrayList();
         }

         this.channels.add(channel);
         return this;
      }

      @Generated
      public SocialCueCatalogEntryBuilder channels(Collection<? extends BehaviorChannel> channels) {
         if (channels == null) {
            throw new NullPointerException("channels cannot be null");
         } else {
            if (this.channels == null) {
               this.channels = new ArrayList();
            }

            this.channels.addAll(channels);
            return this;
         }
      }

      @Generated
      public SocialCueCatalogEntryBuilder clearChannels() {
         if (this.channels != null) {
            this.channels.clear();
         }

         return this;
      }

      @Generated
      public SocialCueCatalogEntryBuilder cooldown(ClockTicks cooldown) {
         this.cooldown = cooldown;
         return this;
      }

      @Generated
      public SocialCueCatalogEntryBuilder perTargetCooldown(ClockTicks perTargetCooldown) {
         this.perTargetCooldown = perTargetCooldown;
         return this;
      }

      @Generated
      public SocialCueCatalogEntryBuilder fireChance(double fireChance) {
         this.fireChance$value = fireChance;
         this.fireChance$set = true;
         return this;
      }

      @Generated
      public SocialCueCatalogEntryBuilder bypassLaneRefractory(boolean bypassLaneRefractory) {
         this.bypassLaneRefractory$value = bypassLaneRefractory;
         this.bypassLaneRefractory$set = true;
         return this;
      }

      @Generated
      public SocialCueCatalogEntryBuilder scriptFactory(Function<BaseVillager, SocialCueScript> scriptFactory) {
         this.scriptFactory = scriptFactory;
         return this;
      }

      @Generated
      public SocialCueCatalogEntryBuilder trigger(Function<BaseVillager, Optional<String>> trigger) {
         this.trigger = trigger;
         return this;
      }

      @Generated
      public SocialCueCatalogEntryBuilder onAdmit(@Nullable BiConsumer<BaseVillager, String> onAdmit) {
         this.onAdmit = onAdmit;
         return this;
      }

      @Generated
      public SocialCueCatalogEntryBuilder onComplete(@Nullable BiConsumer<BaseVillager, String> onComplete) {
         this.onComplete = onComplete;
         return this;
      }

      @Generated
      public SocialCueCatalogEntry build() {
         Set<BehaviorChannel> channels;
         switch (this.channels == null ? 0 : this.channels.size()) {
            case 0:
               channels = Collections.emptySet();
               break;
            case 1:
               channels = Collections.singleton((BehaviorChannel)this.channels.get(0));
               break;
            default:
               channels = new LinkedHashSet(this.channels.size() < 1073741824 ? 1 + this.channels.size() + (this.channels.size() - 3) / 3 : Integer.MAX_VALUE);
               channels.addAll(this.channels);
               channels = Collections.unmodifiableSet(channels);
         }

         double fireChance$value = this.fireChance$value;
         if (!this.fireChance$set) {
            fireChance$value = SocialCueCatalogEntry.$default$fireChance();
         }

         boolean bypassLaneRefractory$value = this.bypassLaneRefractory$value;
         if (!this.bypassLaneRefractory$set) {
            bypassLaneRefractory$value = SocialCueCatalogEntry.$default$bypassLaneRefractory();
         }

         return new SocialCueCatalogEntry(this.key, channels, this.cooldown, this.perTargetCooldown, fireChance$value, bypassLaneRefractory$value, this.scriptFactory, this.trigger, this.onAdmit, this.onComplete);
      }

      @Generated
      public String toString() {
         String var10000 = this.key;
         return "SocialCueCatalogEntry.SocialCueCatalogEntryBuilder(key=" + var10000 + ", channels=" + String.valueOf(this.channels) + ", cooldown=" + String.valueOf(this.cooldown) + ", perTargetCooldown=" + String.valueOf(this.perTargetCooldown) + ", fireChance$value=" + this.fireChance$value + ", bypassLaneRefractory$value=" + this.bypassLaneRefractory$value + ", scriptFactory=" + String.valueOf(this.scriptFactory) + ", trigger=" + String.valueOf(this.trigger) + ", onAdmit=" + String.valueOf(this.onAdmit) + ", onComplete=" + String.valueOf(this.onComplete) + ")";
      }
   }
}
