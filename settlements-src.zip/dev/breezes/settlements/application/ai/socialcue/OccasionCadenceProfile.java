package dev.breezes.settlements.application.ai.socialcue;

import dev.breezes.settlements.application.ai.dialogue.Occasion;
import java.util.EnumMap;
import java.util.Map;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class OccasionCadenceProfile {
   public static final double DEFAULT_FACTOR = (double)1.0F;
   private static final Map<Occasion, Double> FACTORS = factors();

   public static double factorFor(@Nonnull Occasion occasion) {
      return (Double)FACTORS.getOrDefault(occasion, (double)1.0F);
   }

   private static Map<Occasion, Double> factors() {
      EnumMap<Occasion, Double> result = new EnumMap(Occasion.class);
      result.put(Occasion.MEET, 0.6);
      result.put(Occasion.IDLE, (double)1.0F);
      result.put(Occasion.REST_DAY, 0.8);
      result.put(Occasion.WORK, 1.3);
      result.put(Occasion.PANIC, (double)2.0F);
      result.put(Occasion.PRE_RAID, (double)2.0F);
      result.put(Occasion.RAID, (double)2.0F);
      return Map.copyOf(result);
   }

   @Generated
   private OccasionCadenceProfile() {
   }
}
