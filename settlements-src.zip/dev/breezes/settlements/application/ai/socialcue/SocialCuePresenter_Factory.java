package dev.breezes.settlements.application.ai.socialcue;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.speech.VillagerSpeechService;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class SocialCuePresenter_Factory implements Factory<SocialCuePresenter> {
   private final Provider<VillagerSpeechService> villagerSpeechServiceProvider;

   private SocialCuePresenter_Factory(Provider<VillagerSpeechService> villagerSpeechServiceProvider) {
      this.villagerSpeechServiceProvider = villagerSpeechServiceProvider;
   }

   public SocialCuePresenter get() {
      return newInstance((VillagerSpeechService)this.villagerSpeechServiceProvider.get());
   }

   public static SocialCuePresenter_Factory create(Provider<VillagerSpeechService> villagerSpeechServiceProvider) {
      return new SocialCuePresenter_Factory(villagerSpeechServiceProvider);
   }

   public static SocialCuePresenter newInstance(VillagerSpeechService villagerSpeechService) {
      return new SocialCuePresenter(villagerSpeechService);
   }
}
