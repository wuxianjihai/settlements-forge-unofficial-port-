package dev.breezes.settlements.application.ai.socialcue;

import java.util.Optional;
import java.util.UUID;
import lombok.Generated;

public final class PlayerActionSnapshot {
   private final UUID playerUuid;
   private final long gameTime;
   private final double x;
   private final double y;
   private final double z;
   private final String dimensionKey;
   private final String extra;

   public boolean isRecent(long currentGameTime, long windowTicks) {
      return currentGameTime - this.gameTime <= windowTicks;
   }

   public double distanceSquaredTo(double ox, double oy, double oz) {
      double dx = this.x - ox;
      double dy = this.y - oy;
      double dz = this.z - oz;
      return dx * dx + dy * dy + dz * dz;
   }

   public Optional<String> getExtra() {
      return Optional.ofNullable(this.extra);
   }

   @Generated
   public UUID getPlayerUuid() {
      return this.playerUuid;
   }

   @Generated
   public long getGameTime() {
      return this.gameTime;
   }

   @Generated
   public double getX() {
      return this.x;
   }

   @Generated
   public double getY() {
      return this.y;
   }

   @Generated
   public double getZ() {
      return this.z;
   }

   @Generated
   public String getDimensionKey() {
      return this.dimensionKey;
   }

   @Generated
   public PlayerActionSnapshot(UUID playerUuid, long gameTime, double x, double y, double z, String dimensionKey, String extra) {
      this.playerUuid = playerUuid;
      this.gameTime = gameTime;
      this.x = x;
      this.y = y;
      this.z = z;
      this.dimensionKey = dimensionKey;
      this.extra = extra;
   }
}
