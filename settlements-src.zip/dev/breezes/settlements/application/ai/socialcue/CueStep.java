package dev.breezes.settlements.application.ai.socialcue;

import dev.breezes.settlements.application.ai.dialogue.DialogueLine;
import dev.breezes.settlements.application.ai.speech.SpeechRegister;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.sounds.SoundEvent;

public sealed interface CueStep {
   public static record Gesture(@Nonnull AnimationArchetype archetype) implements CueStep {
   }

   public static record Speak(@Nonnull DialogueLine line, @Nonnull SpeechRegister register, @Nonnull ClockTicks ttl) implements CueStep {
   }

   public static record Sound(@Nonnull SoundEvent soundEvent, float volume, float pitch) implements CueStep {
   }

   public static record Gaze(@Nullable Location target) implements CueStep {
   }

   public static record Wait(@Nonnull ClockTicks duration) implements CueStep {
   }
}
