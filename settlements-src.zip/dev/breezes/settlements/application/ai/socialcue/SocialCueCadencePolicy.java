package dev.breezes.settlements.application.ai.socialcue;

import dev.breezes.settlements.infrastructure.compat.CompatMath;
import lombok.Generated;

public final class SocialCueCadencePolicy {
   public static long cooldownTicks(long baseTicks, double charisma, double lowCharismaMultiplier, double highCharismaMultiplier, SocialCueCooldownScaling scaling, double activityFactor, double jitterFraction, double random01) {
      double chaFactor = charismaFactor(charisma, lowCharismaMultiplier, highCharismaMultiplier, scaling);
      double boundedActivityFactor = Math.max((double)0.0F, activityFactor);
      double jitterFactor = (double)1.0F - jitterFraction + random01 * (double)2.0F * jitterFraction;
      return Math.max(0L, Math.round((double)baseTicks * chaFactor * boundedActivityFactor * jitterFactor));
   }

   private static double charismaFactor(double charisma, double lowCharismaMultiplier, double highCharismaMultiplier, SocialCueCooldownScaling scaling) {
      double boundedCharisma = CompatMath.clamp(charisma, (double)0.0F, (double)1.0F);
      double boundedLowMultiplier = Math.max((double)0.0F, lowCharismaMultiplier);
      double boundedHighMultiplier = Math.max((double)0.0F, highCharismaMultiplier);
      return scaling == SocialCueCooldownScaling.EXPONENTIAL && boundedLowMultiplier > (double)0.0F && boundedHighMultiplier > (double)0.0F ? boundedLowMultiplier * Math.pow(boundedHighMultiplier / boundedLowMultiplier, boundedCharisma) : boundedLowMultiplier + (boundedHighMultiplier - boundedLowMultiplier) * boundedCharisma;
   }

   public static long initialScanPhaseTicks(long spreadTicks, double random01) {
      return (long)(random01 * (double)spreadTicks);
   }

   @Generated
   private SocialCueCadencePolicy() {
   }
}
