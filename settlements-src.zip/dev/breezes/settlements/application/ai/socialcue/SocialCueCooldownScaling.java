package dev.breezes.settlements.application.ai.socialcue;

import java.util.Locale;

public enum SocialCueCooldownScaling {
   LINEAR,
   EXPONENTIAL;

   public static SocialCueCooldownScaling fromConfig(String value) {
      if (value == null) {
         return EXPONENTIAL;
      } else {
         SocialCueCooldownScaling var10000;
         switch (value.trim().toLowerCase(Locale.ROOT)) {
            case "linear" -> var10000 = LINEAR;
            case "exponential" -> var10000 = EXPONENTIAL;
            default -> var10000 = EXPONENTIAL;
         }

         return var10000;
      }
   }

   // $FF: synthetic method
   private static SocialCueCooldownScaling[] $values() {
      return new SocialCueCooldownScaling[]{LINEAR, EXPONENTIAL};
   }
}
