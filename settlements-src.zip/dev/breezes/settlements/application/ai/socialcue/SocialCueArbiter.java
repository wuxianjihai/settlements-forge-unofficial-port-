package dev.breezes.settlements.application.ai.socialcue;

import dev.breezes.settlements.application.ai.dialogue.Occasion;
import dev.breezes.settlements.application.ai.planning.PlanRuntimeState;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.catalog.BehaviorChannel;
import dev.breezes.settlements.domain.ai.catalog.BehaviorPlanningMetadata;
import dev.breezes.settlements.domain.ai.planning.DayPlan;
import dev.breezes.settlements.domain.ai.schedule.PlanDayType;
import dev.breezes.settlements.domain.genetics.GeneType;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import lombok.Generated;

@ServerScope
public final class SocialCueArbiter {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(SocialCueArbiter.class.getName());
   private static final ClockTicks ADMISSION_SCAN_INTERVAL = ClockTicks.seconds((double)1.0F);
   private static final ClockTicks INITIAL_ADMISSION_SPREAD = ClockTicks.seconds((double)4.0F);
   private static final ClockTicks LANE_REFRACTORY = ClockTicks.seconds((double)12.0F);
   private final Set<SocialCueCatalogEntry> catalog;
   private final SocialCuePresenter presenter;
   private final SocialCueConfig socialCueConfig;

   public void tick(BaseVillager villager, SocialCueRuntimeState runtimeState, long gameTime) {
      if (!villager.isSociallyAvailable()) {
         if (runtimeState.isCueActive()) {
            runtimeState.cancelActiveCue();
         }

      } else if (runtimeState.isCueActive()) {
         this.tickActiveCue(villager, runtimeState, gameTime);
      } else if (!runtimeState.isAdmissionScanInitialized()) {
         runtimeState.markAdmissionScanInitialized();
         long phase = SocialCueCadencePolicy.initialScanPhaseTicks(INITIAL_ADMISSION_SPREAD.getTicks(), villager.m_217043_().m_188500_());
         runtimeState.scheduleNextAdmissionScan(gameTime + phase);
      } else if (gameTime >= runtimeState.getNextAdmissionScanTick()) {
         runtimeState.scheduleNextAdmissionScan(gameTime + ADMISSION_SCAN_INTERVAL.getTicks());
         this.tryAdmit(villager, runtimeState, gameTime);
      }
   }

   private void tickActiveCue(BaseVillager villager, SocialCueRuntimeState runtimeState, long gameTime) {
      SocialCue cue = runtimeState.getActiveCue();
      SocialCueScript script = cue.getScript();

      while(runtimeState.getNextStepIndex() < script.stepCount()) {
         int index = runtimeState.getNextStepIndex();
         if (!SocialCueTimingPolicy.isStepDue(script, index, runtimeState.getCueStartGameTime(), gameTime)) {
            break;
         }

         CueStep step = script.stepAt(index);
         this.presenter.dispatch(step, villager, runtimeState);
         runtimeState.advance();
      }

      if (SocialCueTimingPolicy.isReadyToFinish(runtimeState.getNextStepIndex(), script.stepCount(), runtimeState.getCueStartGameTime(), script.getTotalDuration().getTicks(), gameTime)) {
         SocialCueCatalogEntry entry = runtimeState.getActiveCueEntry();
         if (entry != null) {
            entry.fireOnComplete(villager, cue.getContextKey());
         }

         long cooldownTicks = SocialCueCadencePolicy.cooldownTicks(cue.getCooldown().getTicks(), villager.getGenetics().getGeneValue(GeneType.CHARISMA), this.socialCueConfig.socialCueLowCharismaCooldownMultiplier(), this.socialCueConfig.socialCueHighCharismaCooldownMultiplier(), SocialCueCooldownScaling.fromConfig(this.socialCueConfig.socialCueCharismaCooldownScaling()), OccasionCadenceProfile.factorFor(this.resolveCooldownOccasion(villager)), this.socialCueConfig.socialCueCooldownJitterFraction(), villager.m_217043_().m_188500_());
         runtimeState.finish(gameTime, cooldownTicks);
         runtimeState.markLaneQuietUntil(gameTime + LANE_REFRACTORY.getTicks());
      }

   }

   private void tryAdmit(BaseVillager villager, SocialCueRuntimeState runtimeState, long gameTime) {
      Set<BehaviorChannel> occupiedChannels = this.occupiedChannels(villager);

      for(SocialCueCatalogEntry entry : this.catalog) {
         if (!runtimeState.isCueOnCooldown(entry.getKey(), gameTime) && (entry.isBypassLaneRefractory() || !runtimeState.isLaneQuiet(gameTime)) && Collections.disjoint(entry.getChannels(), occupiedChannels)) {
            Optional<String> contextKey = (Optional)entry.getTrigger().apply(villager);
            if (!contextKey.isEmpty() && !runtimeState.isTargetOnCooldown(this.uuidFromKey((String)contextKey.get()), gameTime)) {
               if (entry.getFireChance() < (double)1.0F && villager.m_217043_().m_188500_() >= entry.getFireChance()) {
                  runtimeState.recordCueDeclined(entry.getKey(), gameTime, entry.getCooldown().getTicks());
               } else {
                  String resolvedContextKey = (String)contextKey.get();
                  SocialCue cue = entry.buildCue(villager, resolvedContextKey);
                  if (cue.getScript().getTotalDuration().getTicks() <= SocialCueScript.MAX_DURATION.getTicks()) {
                     runtimeState.start(cue, entry, gameTime);
                     entry.fireOnAdmit(villager, resolvedContextKey);
                     runtimeState.recordTargetGreeted(this.uuidFromKey(resolvedContextKey), gameTime, entry.getPerTargetCooldown().getTicks());
                     return;
                  }

                  log.warn("SocialCue '{}' script exceeds max duration ({} ticks) — skipping", entry.getKey(), cue.getScript().getTotalDuration().getTicks());
               }
            }
         }
      }

   }

   private Set<BehaviorChannel> occupiedChannels(BaseVillager villager) {
      PlanRuntimeState planState = villager.getPlanRuntimeState();
      BehaviorPlanningMetadata descriptor = planState.getCurrentDescriptor();
      return descriptor == null ? Collections.emptySet() : descriptor.getRequiredChannels();
   }

   private Occasion resolveCooldownOccasion(BaseVillager villager) {
      DayPlan dayPlan = villager.getDayPlan();
      return dayPlan != null && dayPlan.getDayType() == PlanDayType.REST_DAY ? Occasion.REST_DAY : villager.getCurrentOccasion();
   }

   private UUID uuidFromKey(String key) {
      try {
         return UUID.fromString(key);
      } catch (IllegalArgumentException var3) {
         return UUID.nameUUIDFromBytes(key.getBytes(StandardCharsets.UTF_8));
      }
   }

   @Inject
   @Generated
   SocialCueArbiter(Set<SocialCueCatalogEntry> catalog, SocialCuePresenter presenter, SocialCueConfig socialCueConfig) {
      this.catalog = catalog;
      this.presenter = presenter;
      this.socialCueConfig = socialCueConfig;
   }
}
