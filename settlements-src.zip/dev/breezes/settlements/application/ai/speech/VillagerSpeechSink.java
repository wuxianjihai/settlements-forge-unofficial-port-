package dev.breezes.settlements.application.ai.speech;

public interface VillagerSpeechSink {
   void accept(VillagerUtterance var1);
}
