package dev.breezes.settlements.application.ai.speech;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.Set;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class VillagerSpeechService_Factory implements Factory<VillagerSpeechService> {
   private final Provider<Set<VillagerSpeechSink>> sinksProvider;

   private VillagerSpeechService_Factory(Provider<Set<VillagerSpeechSink>> sinksProvider) {
      this.sinksProvider = sinksProvider;
   }

   public VillagerSpeechService get() {
      return newInstance((Set)this.sinksProvider.get());
   }

   public static VillagerSpeechService_Factory create(Provider<Set<VillagerSpeechSink>> sinksProvider) {
      return new VillagerSpeechService_Factory(sinksProvider);
   }

   public static VillagerSpeechService newInstance(Set<VillagerSpeechSink> sinks) {
      return new VillagerSpeechService(sinks);
   }
}
