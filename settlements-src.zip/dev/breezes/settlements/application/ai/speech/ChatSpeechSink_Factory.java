package dev.breezes.settlements.application.ai.speech;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class ChatSpeechSink_Factory implements Factory<ChatSpeechSink> {
   private final Provider<SpeechMirrorConfig> configProvider;

   private ChatSpeechSink_Factory(Provider<SpeechMirrorConfig> configProvider) {
      this.configProvider = configProvider;
   }

   public ChatSpeechSink get() {
      return newInstance((SpeechMirrorConfig)this.configProvider.get());
   }

   public static ChatSpeechSink_Factory create(Provider<SpeechMirrorConfig> configProvider) {
      return new ChatSpeechSink_Factory(configProvider);
   }

   public static ChatSpeechSink newInstance(SpeechMirrorConfig config) {
      return new ChatSpeechSink(config);
   }
}
