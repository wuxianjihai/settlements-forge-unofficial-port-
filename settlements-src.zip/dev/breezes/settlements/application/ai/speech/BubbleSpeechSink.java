package dev.breezes.settlements.application.ai.speech;

import dev.breezes.settlements.application.ai.dialogue.DialogueLine;
import dev.breezes.settlements.application.ui.bubble.BubbleChannel;
import dev.breezes.settlements.application.ui.bubble.BubbleCommand;
import dev.breezes.settlements.application.ui.bubble.BubbleMessage;
import dev.breezes.settlements.application.ui.bubble.BubbleSegment;
import dev.breezes.settlements.application.ui.bubble.VillagerBubbleService;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.List;
import lombok.Generated;
import net.minecraft.ChatFormatting;

@ServerScope
public final class BubbleSpeechSink implements VillagerSpeechSink {
   private static final String FLAVOR_SOURCE = "social-cue";
   private final VillagerBubbleService villagerBubbleService;

   public void accept(VillagerUtterance utterance) {
      DialogueLine var3 = utterance.getLine();
      if (var3 instanceof DialogueLine.Translatable translatable) {
         BaseVillager var5 = utterance.getSpeaker();
         BubbleMessage message = BubbleMessage.builder().priority(0).ttl(utterance.getBubbleTtl()).sourceType("social-cue").segments(List.of(BubbleSegment.Translatable.builder().key(translatable.key()).args(translatable.args()).color(ChatFormatting.BLACK).bold(false).scale(1.0F).build())).build();
         this.villagerBubbleService.applyCommand(var5, new BubbleCommand.Push(BubbleChannel.FLAVOR, message), var5.m_9236_().m_46467_());
      }
   }

   @Inject
   @Generated
   BubbleSpeechSink(VillagerBubbleService villagerBubbleService) {
      this.villagerBubbleService = villagerBubbleService;
   }
}
