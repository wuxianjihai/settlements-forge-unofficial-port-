package dev.breezes.settlements.application.ai.speech;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ui.bubble.VillagerBubbleService;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class BubbleSpeechSink_Factory implements Factory<BubbleSpeechSink> {
   private final Provider<VillagerBubbleService> villagerBubbleServiceProvider;

   private BubbleSpeechSink_Factory(Provider<VillagerBubbleService> villagerBubbleServiceProvider) {
      this.villagerBubbleServiceProvider = villagerBubbleServiceProvider;
   }

   public BubbleSpeechSink get() {
      return newInstance((VillagerBubbleService)this.villagerBubbleServiceProvider.get());
   }

   public static BubbleSpeechSink_Factory create(Provider<VillagerBubbleService> villagerBubbleServiceProvider) {
      return new BubbleSpeechSink_Factory(villagerBubbleServiceProvider);
   }

   public static BubbleSpeechSink newInstance(VillagerBubbleService villagerBubbleService) {
      return new BubbleSpeechSink(villagerBubbleService);
   }
}
