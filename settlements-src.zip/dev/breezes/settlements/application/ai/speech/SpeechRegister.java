package dev.breezes.settlements.application.ai.speech;

public enum SpeechRegister {
   MONOLOGUE,
   GOSSIP,
   DIALOGUE,
   AMBIENT;

   // $FF: synthetic method
   private static SpeechRegister[] $values() {
      return new SpeechRegister[]{MONOLOGUE, GOSSIP, DIALOGUE, AMBIENT};
   }
}
