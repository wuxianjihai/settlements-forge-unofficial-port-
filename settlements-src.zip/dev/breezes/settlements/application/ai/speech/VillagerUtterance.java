package dev.breezes.settlements.application.ai.speech;

import dev.breezes.settlements.application.ai.dialogue.DialogueLine;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.world.entity.LivingEntity;

public final class VillagerUtterance {
   private final BaseVillager speaker;
   private final DialogueLine line;
   private final SpeechRegister register;
   @Nullable
   private final LivingEntity addressee;
   private final ClockTicks bubbleTtl;

   @Generated
   VillagerUtterance(BaseVillager speaker, DialogueLine line, SpeechRegister register, @Nullable LivingEntity addressee, ClockTicks bubbleTtl) {
      this.speaker = speaker;
      this.line = line;
      this.register = register;
      this.addressee = addressee;
      this.bubbleTtl = bubbleTtl;
   }

   @Generated
   public static VillagerUtteranceBuilder builder() {
      return new VillagerUtteranceBuilder();
   }

   @Generated
   public BaseVillager getSpeaker() {
      return this.speaker;
   }

   @Generated
   public DialogueLine getLine() {
      return this.line;
   }

   @Generated
   public SpeechRegister getRegister() {
      return this.register;
   }

   @Nullable
   @Generated
   public LivingEntity getAddressee() {
      return this.addressee;
   }

   @Generated
   public ClockTicks getBubbleTtl() {
      return this.bubbleTtl;
   }

   @Generated
   public static class VillagerUtteranceBuilder {
      @Generated
      private BaseVillager speaker;
      @Generated
      private DialogueLine line;
      @Generated
      private SpeechRegister register;
      @Generated
      private LivingEntity addressee;
      @Generated
      private ClockTicks bubbleTtl;

      @Generated
      VillagerUtteranceBuilder() {
      }

      @Generated
      public VillagerUtteranceBuilder speaker(BaseVillager speaker) {
         this.speaker = speaker;
         return this;
      }

      @Generated
      public VillagerUtteranceBuilder line(DialogueLine line) {
         this.line = line;
         return this;
      }

      @Generated
      public VillagerUtteranceBuilder register(SpeechRegister register) {
         this.register = register;
         return this;
      }

      @Generated
      public VillagerUtteranceBuilder addressee(@Nullable LivingEntity addressee) {
         this.addressee = addressee;
         return this;
      }

      @Generated
      public VillagerUtteranceBuilder bubbleTtl(ClockTicks bubbleTtl) {
         this.bubbleTtl = bubbleTtl;
         return this;
      }

      @Generated
      public VillagerUtterance build() {
         return new VillagerUtterance(this.speaker, this.line, this.register, this.addressee, this.bubbleTtl);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.speaker);
         return "VillagerUtterance.VillagerUtteranceBuilder(speaker=" + var10000 + ", line=" + String.valueOf(this.line) + ", register=" + String.valueOf(this.register) + ", addressee=" + String.valueOf(this.addressee) + ", bubbleTtl=" + String.valueOf(this.bubbleTtl) + ")";
      }
   }
}
