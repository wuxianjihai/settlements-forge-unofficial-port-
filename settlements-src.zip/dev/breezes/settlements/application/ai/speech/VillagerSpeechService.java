package dev.breezes.settlements.application.ai.speech;

import dev.breezes.settlements.di.ServerScope;
import jakarta.inject.Inject;
import java.util.Set;
import lombok.Generated;

@ServerScope
public final class VillagerSpeechService {
   private final Set<VillagerSpeechSink> sinks;

   public void utter(VillagerUtterance utterance) {
      for(VillagerSpeechSink sink : this.sinks) {
         sink.accept(utterance);
      }

   }

   @Inject
   @Generated
   VillagerSpeechService(Set<VillagerSpeechSink> sinks) {
      this.sinks = sinks;
   }
}
