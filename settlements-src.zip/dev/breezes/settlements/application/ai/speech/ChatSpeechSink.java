package dev.breezes.settlements.application.ai.speech;

import dev.breezes.settlements.application.ai.dialogue.DialogueLine;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.infrastructure.config.factory.ConfigFactory;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.EnumMap;
import java.util.LinkedHashSet;
import java.util.Map;
import lombok.Generated;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

@ServerScope
public final class ChatSpeechSink implements VillagerSpeechSink {
   private static final EnumMap<SpeechRegister, ChatFormatting> REGISTER_COLORS;
   private final SpeechMirrorConfig config;

   public void accept(VillagerUtterance utterance) {
      SpeechMirrorConfig liveConfig = (SpeechMirrorConfig)ConfigFactory.create(SpeechMirrorConfig.class);
      if (liveConfig.mirrorToChat()) {
         ChatFormatting color = (ChatFormatting)REGISTER_COLORS.get(utterance.getRegister());
         if (color != null) {
            BaseVillager speaker = utterance.getSpeaker();
            Level var6 = speaker.m_9236_();
            if (var6 instanceof ServerLevel) {
               ServerLevel serverLevel = (ServerLevel)var6;
               MutableComponent var11 = Component.m_237119_().m_7220_(speaker.m_5446_()).m_7220_(Component.m_237113_(" (")).m_7220_(speaker.getProfessionDisplayName()).m_7220_(Component.m_237113_("): ")).m_7220_(renderLine(utterance.getLine())).m_130940_(color);
               LinkedHashSet recipients = new LinkedHashSet(serverLevel.m_45976_(ServerPlayer.class, speaker.m_20191_().m_82400_((double)liveConfig.chatRadius())));
               LivingEntity addressee = utterance.getAddressee();
               if (utterance.getRegister() == SpeechRegister.DIALOGUE && addressee instanceof ServerPlayer) {
                  ServerPlayer addresseePlayer = (ServerPlayer)addressee;
                  recipients.add(addresseePlayer);
               }

               for(ServerPlayer recipient : recipients) {
                  recipient.m_213846_(var11);
               }

            }
         }
      }
   }

   private static Component renderLine(DialogueLine line) {
      if (line instanceof DialogueLine.Literal literal) {
         return Component.m_237113_(literal.text());
      } else if (line instanceof DialogueLine.Translatable translatable) {
         return Component.m_237110_(translatable.key(), translatable.args().toArray());
      } else {
         throw new IllegalArgumentException("Unknown DialogueLine: " + String.valueOf(line));
      }
   }

   @Inject
   @Generated
   ChatSpeechSink(SpeechMirrorConfig config) {
      this.config = config;
   }

   static {
      REGISTER_COLORS = new EnumMap(Map.of(SpeechRegister.MONOLOGUE, ChatFormatting.GRAY, SpeechRegister.GOSSIP, ChatFormatting.GRAY, SpeechRegister.DIALOGUE, ChatFormatting.WHITE));
   }
}
