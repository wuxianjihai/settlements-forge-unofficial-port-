package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.planning.Chronotype;
import dev.breezes.settlements.domain.ai.planning.DayPlan;
import dev.breezes.settlements.domain.ai.planning.DayPlanActivityBlock;
import dev.breezes.settlements.domain.ai.planning.DayPlanActivityContext;
import dev.breezes.settlements.domain.ai.planning.DayPlanSchedule;
import dev.breezes.settlements.domain.ai.planning.PlanSlot;
import dev.breezes.settlements.domain.ai.schedule.IWeekCycleProvider;
import dev.breezes.settlements.domain.ai.schedule.PlanDayType;
import dev.breezes.settlements.domain.ai.schedule.ScheduleProfile;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.domain.time.CivilTime;
import dev.breezes.settlements.domain.time.GameTicks;
import dev.breezes.settlements.domain.world.WorldCalendar;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.annotations.stylistic.VisibleForTesting;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nonnull;
import lombok.Generated;

@ServerScope
public class MinimalPlanFactory {
   private static final int MINIMUM_WAKING_SPAN_TICKS = GameTicks.hours((double)2.0F).getTicksAsInt();
   private static final int TICKS_PER_DAY = 24000;
   private final IWeekCycleProvider weekCycleProvider;

   public DayPlan create(@Nonnull BaseVillager villager, long wakeAtAbsoluteTick) {
      VillagerProfessionKey professionKey = villager.getProfession();
      long calendarDay = WorldCalendar.calendarDayOf(wakeAtAbsoluteTick);
      PlanDayType dayType = this.weekCycleProvider.getDayType(calendarDay);
      long chronotypeSeed = PlanGenerationContextFactory.chronotypeSeedFor(villager);
      return buildMinimalPlan(professionKey, wakeAtAbsoluteTick, dayType, chronotypeSeed);
   }

   @VisibleForTesting
   static DayPlan buildMinimalPlan(@Nonnull VillagerProfessionKey professionKey, long wakeAtAbsoluteTick, @Nonnull PlanDayType dayType, long chronotypeSeed) {
      ScheduleProfile schedule = ScheduleProfile.defaultFor(professionKey);
      Chronotype chronotype = Chronotype.of(chronotypeSeed);
      int rawWakeCivil = CivilTime.civilFromDayTime(wakeAtAbsoluteTick);
      int wakeCivil = Math.max(1, Math.min(rawWakeCivil, 24000 - MINIMUM_WAKING_SPAN_TICKS - 1));
      int rawBedtimeCivil = CivilTime.civilFromMcTick(schedule.defaultSleepTick() + chronotype.wakeSleepOffsetTicks());
      int bedtimeCivil = Math.min(23999, Math.max(rawBedtimeCivil, wakeCivil + MINIMUM_WAKING_SPAN_TICKS));
      List<PlanSlot> slots = new ArrayList();

      for(MealAnchorRule rule : DefaultMealAnchorTable.rows()) {
         int placementTick = clampToFrame(rule.placementTick(wakeCivil, chronotype.mealOffsetTicks()), rule.durationTicks(), wakeCivil, bedtimeCivil);
         slots.add(PlanSlot.builder().startTick(placementTick).behaviorKey(rule.behaviorKey()).priority(rule.priority()).flexible(false).estimatedDurationTicks(rule.durationTicks()).build());
      }

      DayPlanSchedule daySchedule = DayPlanSchedule.builder().wakeTick(wakeCivil).bedtimeTick(bedtimeCivil).activityBlock(DayPlanActivityBlock.builder().context(DayPlanActivityContext.IDLE).startTick(wakeCivil).endTick(bedtimeCivil).build()).build();
      return DayPlan.builder().slots(slots).dayType(dayType).calendarDay(WorldCalendar.calendarDayOf(wakeAtAbsoluteTick)).schedule(daySchedule).build();
   }

   private static int clampToFrame(int startTick, int durationTicks, int wakeCivil, int bedtimeCivil) {
      int latestStart = bedtimeCivil - durationTicks;
      return Math.max(wakeCivil, Math.min(startTick, latestStart));
   }

   @Inject
   @Generated
   MinimalPlanFactory(IWeekCycleProvider weekCycleProvider) {
      this.weekCycleProvider = weekCycleProvider;
   }
}
