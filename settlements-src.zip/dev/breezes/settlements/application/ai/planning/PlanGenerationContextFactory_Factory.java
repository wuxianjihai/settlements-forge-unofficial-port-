package dev.breezes.settlements.application.ai.planning;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.catalog.BehaviorPoolResolver;
import dev.breezes.settlements.domain.ai.schedule.IWeekCycleProvider;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class PlanGenerationContextFactory_Factory implements Factory<PlanGenerationContextFactory> {
   private final Provider<BehaviorPoolResolver> behaviorPoolResolverProvider;
   private final Provider<IWeekCycleProvider> weekCycleProvider;
   private final Provider<OpportunityForecaster> opportunityForecasterProvider;

   private PlanGenerationContextFactory_Factory(Provider<BehaviorPoolResolver> behaviorPoolResolverProvider, Provider<IWeekCycleProvider> weekCycleProvider, Provider<OpportunityForecaster> opportunityForecasterProvider) {
      this.behaviorPoolResolverProvider = behaviorPoolResolverProvider;
      this.weekCycleProvider = weekCycleProvider;
      this.opportunityForecasterProvider = opportunityForecasterProvider;
   }

   public PlanGenerationContextFactory get() {
      return newInstance((BehaviorPoolResolver)this.behaviorPoolResolverProvider.get(), (IWeekCycleProvider)this.weekCycleProvider.get(), (OpportunityForecaster)this.opportunityForecasterProvider.get());
   }

   public static PlanGenerationContextFactory_Factory create(Provider<BehaviorPoolResolver> behaviorPoolResolverProvider, Provider<IWeekCycleProvider> weekCycleProvider, Provider<OpportunityForecaster> opportunityForecasterProvider) {
      return new PlanGenerationContextFactory_Factory(behaviorPoolResolverProvider, weekCycleProvider, opportunityForecasterProvider);
   }

   public static PlanGenerationContextFactory newInstance(BehaviorPoolResolver behaviorPoolResolver, IWeekCycleProvider weekCycleProvider, OpportunityForecaster opportunityForecaster) {
      return new PlanGenerationContextFactory(behaviorPoolResolver, weekCycleProvider, opportunityForecaster);
   }
}
