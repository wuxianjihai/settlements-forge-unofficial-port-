package dev.breezes.settlements.application.ai.planning;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.domain.ai.planning.IWakeTickResolver;
import dev.breezes.settlements.domain.ai.schedule.IWeekCycleProvider;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class VillagerWakeScheduler_Factory implements Factory<VillagerWakeScheduler> {
   private final Provider<IWeekCycleProvider> weekCycleProvider;
   private final Provider<IWakeTickResolver> wakeTickResolverProvider;

   private VillagerWakeScheduler_Factory(Provider<IWeekCycleProvider> weekCycleProvider, Provider<IWakeTickResolver> wakeTickResolverProvider) {
      this.weekCycleProvider = weekCycleProvider;
      this.wakeTickResolverProvider = wakeTickResolverProvider;
   }

   public VillagerWakeScheduler get() {
      return newInstance((IWeekCycleProvider)this.weekCycleProvider.get(), (IWakeTickResolver)this.wakeTickResolverProvider.get());
   }

   public static VillagerWakeScheduler_Factory create(Provider<IWeekCycleProvider> weekCycleProvider, Provider<IWakeTickResolver> wakeTickResolverProvider) {
      return new VillagerWakeScheduler_Factory(weekCycleProvider, wakeTickResolverProvider);
   }

   public static VillagerWakeScheduler newInstance(IWeekCycleProvider weekCycleProvider, IWakeTickResolver wakeTickResolver) {
      return new VillagerWakeScheduler(weekCycleProvider, wakeTickResolver);
   }
}
