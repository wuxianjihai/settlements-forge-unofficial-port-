package dev.breezes.settlements.application.ai.planning;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.inference.monologue.EpisodicEntryAssembler;
import dev.breezes.settlements.application.ai.inference.monologue.PersonaBundleAssembler;
import dev.breezes.settlements.application.ai.inference.monologue.SnapshotAssembler;
import dev.breezes.settlements.application.economy.VillagerWallet;
import dev.breezes.settlements.application.economy.demand.DemandEvaluator;
import dev.breezes.settlements.application.economy.supply.SupplyEvaluator;
import dev.breezes.settlements.domain.economy.catalog.TradeCatalogRegistry;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class PlanRequestAssembler_Factory implements Factory<PlanRequestAssembler> {
   private final Provider<PersonaBundleAssembler> personaBundleAssemblerProvider;
   private final Provider<SnapshotAssembler> snapshotAssemblerProvider;
   private final Provider<EpisodicEntryAssembler> episodicEntryAssemblerProvider;
   private final Provider<DemandEvaluator> demandEvaluatorProvider;
   private final Provider<SupplyEvaluator> supplyEvaluatorProvider;
   private final Provider<VillagerWallet> villagerWalletProvider;
   private final Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider;
   private final Provider<DayPlanComposer> composerProvider;

   private PlanRequestAssembler_Factory(Provider<PersonaBundleAssembler> personaBundleAssemblerProvider, Provider<SnapshotAssembler> snapshotAssemblerProvider, Provider<EpisodicEntryAssembler> episodicEntryAssemblerProvider, Provider<DemandEvaluator> demandEvaluatorProvider, Provider<SupplyEvaluator> supplyEvaluatorProvider, Provider<VillagerWallet> villagerWalletProvider, Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider, Provider<DayPlanComposer> composerProvider) {
      this.personaBundleAssemblerProvider = personaBundleAssemblerProvider;
      this.snapshotAssemblerProvider = snapshotAssemblerProvider;
      this.episodicEntryAssemblerProvider = episodicEntryAssemblerProvider;
      this.demandEvaluatorProvider = demandEvaluatorProvider;
      this.supplyEvaluatorProvider = supplyEvaluatorProvider;
      this.villagerWalletProvider = villagerWalletProvider;
      this.tradeCatalogRegistryProvider = tradeCatalogRegistryProvider;
      this.composerProvider = composerProvider;
   }

   public PlanRequestAssembler get() {
      return newInstance((PersonaBundleAssembler)this.personaBundleAssemblerProvider.get(), (SnapshotAssembler)this.snapshotAssemblerProvider.get(), (EpisodicEntryAssembler)this.episodicEntryAssemblerProvider.get(), (DemandEvaluator)this.demandEvaluatorProvider.get(), (SupplyEvaluator)this.supplyEvaluatorProvider.get(), (VillagerWallet)this.villagerWalletProvider.get(), (TradeCatalogRegistry)this.tradeCatalogRegistryProvider.get(), (DayPlanComposer)this.composerProvider.get());
   }

   public static PlanRequestAssembler_Factory create(Provider<PersonaBundleAssembler> personaBundleAssemblerProvider, Provider<SnapshotAssembler> snapshotAssemblerProvider, Provider<EpisodicEntryAssembler> episodicEntryAssemblerProvider, Provider<DemandEvaluator> demandEvaluatorProvider, Provider<SupplyEvaluator> supplyEvaluatorProvider, Provider<VillagerWallet> villagerWalletProvider, Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider, Provider<DayPlanComposer> composerProvider) {
      return new PlanRequestAssembler_Factory(personaBundleAssemblerProvider, snapshotAssemblerProvider, episodicEntryAssemblerProvider, demandEvaluatorProvider, supplyEvaluatorProvider, villagerWalletProvider, tradeCatalogRegistryProvider, composerProvider);
   }

   public static PlanRequestAssembler newInstance(PersonaBundleAssembler personaBundleAssembler, SnapshotAssembler snapshotAssembler, EpisodicEntryAssembler episodicEntryAssembler, DemandEvaluator demandEvaluator, SupplyEvaluator supplyEvaluator, VillagerWallet villagerWallet, TradeCatalogRegistry tradeCatalogRegistry, DayPlanComposer composer) {
      return new PlanRequestAssembler(personaBundleAssembler, snapshotAssembler, episodicEntryAssembler, demandEvaluator, supplyEvaluator, villagerWallet, tradeCatalogRegistry, composer);
   }
}
