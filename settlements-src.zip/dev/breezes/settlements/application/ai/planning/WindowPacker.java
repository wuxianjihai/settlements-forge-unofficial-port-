package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.catalog.CooldownRange;
import dev.breezes.settlements.domain.time.GameTicks;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import lombok.Generated;

public final class WindowPacker {
   public static final int MINIMUM_SLOT_SPACING_TICKS = GameTicks.minutes((double)10.0F).getTicksAsInt();

   public static List<PackedSlot> pack(List<PackingCandidate> pool, int startCivil, int endCivil, int basePriority, SlotSelectionStrategy strategy, Random random, double packFactor) {
      return pack(pool, startCivil, endCivil, basePriority, strategy, random, packFactor, new HashMap());
   }

   public static List<PackedSlot> pack(List<PackingCandidate> pool, int startCivil, int endCivil, int basePriority, SlotSelectionStrategy strategy, Random random, double packFactor, Map<BehaviorKey, Integer> nextEligible) {
      List<PackedSlot> result = new ArrayList();
      if (!pool.isEmpty() && endCivil > startCivil) {
         List<PackingCandidate> candidates = pool.stream().filter((c) -> c.weight() > (double)0.0F).toList();
         if (candidates.isEmpty()) {
            return result;
         } else {
            Set<BehaviorKey> emittedKeys = new HashSet();
            int cursor = startCivil + random.nextInt(0, MINIMUM_SLOT_SPACING_TICKS - 1 + 1);
            int emitted = 0;

            while(cursor < endCivil) {
               List<PackingCandidate> eligible = candidates.stream().filter((c) -> cursor >= (Integer)nextEligible.getOrDefault(c.key(), startCivil)).filter((c) -> cursor + Math.max(1, c.durationTicks()) <= endCivil).toList();
               if (eligible.isEmpty()) {
                  cursor += random.nextInt(MINIMUM_SLOT_SPACING_TICKS / 2, MINIMUM_SLOT_SPACING_TICKS + 1);
               } else {
                  PackingCandidate chosen = strategy.select(eligible, emittedKeys, random);
                  int duration = Math.max(1, chosen.durationTicks());
                  result.add(new PackedSlot(chosen.key(), cursor, duration, Math.max(0, basePriority - emitted)));
                  emittedKeys.add(chosen.key());
                  int cooldownSpacing = Math.max(MINIMUM_SLOT_SPACING_TICKS, chosen.cooldown().drawTicks(random));
                  nextEligible.put(chosen.key(), cursor + cooldownSpacing);
                  ++emitted;
                  int packedAdvance = (int)Math.round((double)duration * packFactor);
                  cursor += Math.max(MINIMUM_SLOT_SPACING_TICKS, packedAdvance);
               }
            }

            return result;
         }
      } else {
         return result;
      }
   }

   @Generated
   private WindowPacker() {
   }

   public static record PackingCandidate(BehaviorKey key, double weight, int durationTicks, CooldownRange cooldown) {
   }

   public static record PackedSlot(BehaviorKey key, int startCivil, int durationTicks, int priority) {
   }
}
