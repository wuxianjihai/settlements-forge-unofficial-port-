package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.application.ai.catalog.BehaviorPoolResolver;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.catalog.WeightedBehavior;
import dev.breezes.settlements.domain.ai.planning.PlanGenerationContext;
import dev.breezes.settlements.domain.ai.schedule.IWeekCycleProvider;
import dev.breezes.settlements.domain.ai.schedule.PlanDayType;
import dev.breezes.settlements.domain.ai.schedule.RestDayPolicy;
import dev.breezes.settlements.domain.ai.schedule.ScheduleProfile;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.domain.world.WorldCalendar;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Set;
import javax.annotation.Nonnull;
import lombok.Generated;

@ServerScope
public class PlanGenerationContextFactory {
   private final BehaviorPoolResolver behaviorPoolResolver;
   private final IWeekCycleProvider weekCycleProvider;
   private final OpportunityForecaster opportunityForecaster;

   public PlanGenerationContext create(@Nonnull BaseVillager villager, long wakeAtAbsoluteTick) {
      VillagerProfessionKey professionKey = villager.getProfession();
      long calendarDay = WorldCalendar.calendarDayOf(wakeAtAbsoluteTick);
      PlanDayType dayType = this.weekCycleProvider.getDayType(calendarDay);
      long chronotypeSeed = chronotypeSeedFor(villager);
      List<WeightedBehavior> pool = this.behaviorPoolResolver.resolve(professionKey);
      Set<BehaviorKey> lacking = this.opportunityForecaster.forecastLackingOpportunity(villager, pool);
      return PlanGenerationContext.builder().profession(professionKey).genetics(villager.getGenetics().copy()).scheduleProfile(ScheduleProfile.defaultFor(professionKey)).restDayPolicy(RestDayPolicy.defaultFor(professionKey)).dayType(dayType).availableBehaviors(pool).wakeAtAbsoluteTick(wakeAtAbsoluteTick).chronotypeSeed(chronotypeSeed).planSeed(planSeedFor(chronotypeSeed, calendarDay)).behaviorsLackingOpportunity(lacking).build();
   }

   static long chronotypeSeedFor(@Nonnull BaseVillager villager) {
      return villager.m_20148_().getMostSignificantBits() ^ villager.m_20148_().getLeastSignificantBits();
   }

   private static long planSeedFor(long chronotypeSeed, long calendarDay) {
      long mixed = chronotypeSeed ^ calendarDay * -7046029254386353131L;
      return avalanche(mixed);
   }

   private static long avalanche(long value) {
      long z = (value ^ value >>> 30) * -4658895280553007687L;
      z = (z ^ z >>> 27) * -7723592293110705685L;
      return z ^ z >>> 31;
   }

   @Inject
   @Generated
   PlanGenerationContextFactory(BehaviorPoolResolver behaviorPoolResolver, IWeekCycleProvider weekCycleProvider, OpportunityForecaster opportunityForecaster) {
      this.behaviorPoolResolver = behaviorPoolResolver;
      this.weekCycleProvider = weekCycleProvider;
      this.opportunityForecaster = opportunityForecaster;
   }
}
