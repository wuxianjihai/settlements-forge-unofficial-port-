package dev.breezes.settlements.application.ai.planning;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class HeuristicPlanGenerator_Factory implements Factory<HeuristicPlanGenerator> {
   private final Provider<DayPlanComposer> composerProvider;

   private HeuristicPlanGenerator_Factory(Provider<DayPlanComposer> composerProvider) {
      this.composerProvider = composerProvider;
   }

   public HeuristicPlanGenerator get() {
      return newInstance((DayPlanComposer)this.composerProvider.get());
   }

   public static HeuristicPlanGenerator_Factory create(Provider<DayPlanComposer> composerProvider) {
      return new HeuristicPlanGenerator_Factory(composerProvider);
   }

   public static HeuristicPlanGenerator newInstance(DayPlanComposer composer) {
      return new HeuristicPlanGenerator(composer);
   }
}
