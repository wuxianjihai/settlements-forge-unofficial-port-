package dev.breezes.settlements.application.ai.planning;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.memory.SensedSiteReader;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class OpportunityForecaster_Factory implements Factory<OpportunityForecaster> {
   private final Provider<SensedSiteReader> sensedSiteReaderProvider;

   private OpportunityForecaster_Factory(Provider<SensedSiteReader> sensedSiteReaderProvider) {
      this.sensedSiteReaderProvider = sensedSiteReaderProvider;
   }

   public OpportunityForecaster get() {
      return newInstance((SensedSiteReader)this.sensedSiteReaderProvider.get());
   }

   public static OpportunityForecaster_Factory create(Provider<SensedSiteReader> sensedSiteReaderProvider) {
      return new OpportunityForecaster_Factory(sensedSiteReaderProvider);
   }

   public static OpportunityForecaster newInstance(SensedSiteReader sensedSiteReader) {
      return new OpportunityForecaster(sensedSiteReader);
   }
}
