package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.time.TimeOfDay;
import javax.annotation.Nullable;
import lombok.Generated;

public record MealAnchorRule(AnchorMode anchorMode, @Nullable TimeOfDay fixedTime, BehaviorKey behaviorKey, int priority, int durationTicks, double authoredKeepProbability, boolean appliesChronotypeMealOffset) {
   public int placementTick(int wakeCivil, int mealOffsetTicks) {
      int baseTick = this.anchorMode == MealAnchorRule.AnchorMode.WAKE_RELATIVE ? wakeCivil : this.fixedTime.getCivilTick();
      return this.appliesChronotypeMealOffset ? baseTick + mealOffsetTicks : baseTick;
   }

   @Generated
   public static MealAnchorRuleBuilder builder() {
      return new MealAnchorRuleBuilder();
   }

   @Generated
   public static class MealAnchorRuleBuilder {
      @Generated
      private AnchorMode anchorMode;
      @Generated
      private TimeOfDay fixedTime;
      @Generated
      private BehaviorKey behaviorKey;
      @Generated
      private int priority;
      @Generated
      private int durationTicks;
      @Generated
      private double authoredKeepProbability;
      @Generated
      private boolean appliesChronotypeMealOffset;

      @Generated
      MealAnchorRuleBuilder() {
      }

      @Generated
      public MealAnchorRuleBuilder anchorMode(AnchorMode anchorMode) {
         this.anchorMode = anchorMode;
         return this;
      }

      @Generated
      public MealAnchorRuleBuilder fixedTime(@Nullable TimeOfDay fixedTime) {
         this.fixedTime = fixedTime;
         return this;
      }

      @Generated
      public MealAnchorRuleBuilder behaviorKey(BehaviorKey behaviorKey) {
         this.behaviorKey = behaviorKey;
         return this;
      }

      @Generated
      public MealAnchorRuleBuilder priority(int priority) {
         this.priority = priority;
         return this;
      }

      @Generated
      public MealAnchorRuleBuilder durationTicks(int durationTicks) {
         this.durationTicks = durationTicks;
         return this;
      }

      @Generated
      public MealAnchorRuleBuilder authoredKeepProbability(double authoredKeepProbability) {
         this.authoredKeepProbability = authoredKeepProbability;
         return this;
      }

      @Generated
      public MealAnchorRuleBuilder appliesChronotypeMealOffset(boolean appliesChronotypeMealOffset) {
         this.appliesChronotypeMealOffset = appliesChronotypeMealOffset;
         return this;
      }

      @Generated
      public MealAnchorRule build() {
         return new MealAnchorRule(this.anchorMode, this.fixedTime, this.behaviorKey, this.priority, this.durationTicks, this.authoredKeepProbability, this.appliesChronotypeMealOffset);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.anchorMode);
         return "MealAnchorRule.MealAnchorRuleBuilder(anchorMode=" + var10000 + ", fixedTime=" + String.valueOf(this.fixedTime) + ", behaviorKey=" + String.valueOf(this.behaviorKey) + ", priority=" + this.priority + ", durationTicks=" + this.durationTicks + ", authoredKeepProbability=" + this.authoredKeepProbability + ", appliesChronotypeMealOffset=" + this.appliesChronotypeMealOffset + ")";
      }
   }

   public static enum AnchorMode {
      WAKE_RELATIVE,
      FIXED;

      // $FF: synthetic method
      private static AnchorMode[] $values() {
         return new AnchorMode[]{WAKE_RELATIVE, FIXED};
      }
   }
}
