package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.domain.ai.planning.DayPlan;
import dev.breezes.settlements.domain.ai.planning.IPlanGenerator;
import dev.breezes.settlements.domain.ai.planning.PlanGenerationContext;
import dev.breezes.settlements.domain.ai.planning.PlanIntent;
import jakarta.inject.Inject;
import lombok.Generated;

public class HeuristicPlanGenerator implements IPlanGenerator {
   private final DayPlanComposer composer;

   public DayPlan generate(PlanGenerationContext context, PlanIntent intent) {
      return this.composer.compose(context, intent);
   }

   @Inject
   @Generated
   HeuristicPlanGenerator(DayPlanComposer composer) {
      this.composer = composer;
   }
}
