package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.catalog.WeightedBehavior;
import dev.breezes.settlements.domain.ai.planning.Chronotype;
import dev.breezes.settlements.domain.ai.planning.DayPlan;
import dev.breezes.settlements.domain.ai.planning.DayPlanActivityBlock;
import dev.breezes.settlements.domain.ai.planning.DayPlanActivityContext;
import dev.breezes.settlements.domain.ai.planning.DayPlanSchedule;
import dev.breezes.settlements.domain.ai.planning.PinnedSelection;
import dev.breezes.settlements.domain.ai.planning.PlanGenerationContext;
import dev.breezes.settlements.domain.ai.planning.PlanIntent;
import dev.breezes.settlements.domain.ai.planning.PlanSlot;
import dev.breezes.settlements.domain.ai.schedule.PlanDayType;
import dev.breezes.settlements.domain.ai.schedule.RestDayPolicy;
import dev.breezes.settlements.domain.ai.schedule.ScheduleProfile;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.domain.genetics.GeneType;
import dev.breezes.settlements.domain.genetics.GeneticsProfile;
import dev.breezes.settlements.domain.time.CivilTime;
import dev.breezes.settlements.domain.time.GameTicks;
import dev.breezes.settlements.domain.time.TimeOfDay;
import dev.breezes.settlements.infrastructure.compat.CompatMath;
import dev.breezes.settlements.shared.annotations.stylistic.VisibleForTesting;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import lombok.Generated;

public class DayPlanComposer {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(DayPlanComposer.class.getName());
   private static final int LUNCH_BAND_BOUND_CIVIL_TICK;
   private static final int DINNER_BAND_BOUND_CIVIL_TICK;
   private static final int AFTERNOON_NOMINAL_START_CIVIL_TICK;
   private static final int DUSK_CIVIL_TICK;
   private static final int EVENING_MARGIN_TICKS;
   private static final int BAND_EDGE_MARGIN_TICKS;
   private static final double WORK_DAY_MORNING_PACK_FACTOR = (double)0.75F;
   private static final double DEFAULT_PACK_FACTOR = 0.55;
   private static final int MEAL_COLLISION_WINDOW_TICKS;
   private static final int PIN_SNAP_BUCKET_TICKS;
   private static final int MEAL_PIN_PRIORITY = 90;
   private static final int NON_MEAL_PIN_PRIORITY = 80;
   private static final SlotSelectionStrategy HEURISTIC_STRATEGY;
   private final List<MealAnchorRule> mealAnchorTable;

   public List<PlanBand> bands(PlanGenerationContext context) {
      return deriveBandsForFrame(context, computeFrame(context));
   }

   public DayPlan compose(PlanGenerationContext context, PlanIntent intent) {
      Random random = new Random(context.planSeed());
      PlanFrame frame = computeFrame(context);
      List<PlanBand> bands = deriveBandsForFrame(context, frame);
      AnchorPlacement anchorPlacement = this.computeAnchors(frame, bands, intent, context, random);
      List<PlanSlot> slots = new ArrayList();

      for(PlanAnchor anchor : anchorPlacement.anchors()) {
         slots.add(anchor.toSlot());
      }

      for(PlanBand band : bands) {
         this.fillBand(slots, band, intent, context, anchorPlacement, random);
      }

      DayPlanSchedule schedule = buildActivitySchedule(context, frame);
      return DayPlan.builder().slots(slots).dayType(context.dayType()).calendarDay(context.calendarDay()).schedule(schedule).build();
   }

   private static List<PlanBand> deriveBandsForFrame(PlanGenerationContext context, PlanFrame frame) {
      PlannerPolicy.PlannerPalette policy = new PlannerPolicy.PlannerPalette(context.availableBehaviors());
      return deriveBands(context, policy, context.restDayPolicy(), frame, LUNCH_BAND_BOUND_CIVIL_TICK, DINNER_BAND_BOUND_CIVIL_TICK);
   }

   private static PlanFrame computeFrame(PlanGenerationContext context) {
      ScheduleProfile schedule = context.scheduleProfile();
      int wakeCivil = CivilTime.civilFromDayTime(context.wakeAtAbsoluteTick());
      Chronotype chronotype = Chronotype.of(context.chronotypeSeed());
      int bedtimeCivil = CivilTime.civilFromMcTick(schedule.defaultSleepTick() + chronotype.wakeSleepOffsetTicks());
      return DayPlanComposer.PlanFrame.builder().wakeCivil(wakeCivil).bedtimeCivil(bedtimeCivil).workStartCivil(resolveWorkStartCivil(schedule, wakeCivil, bedtimeCivil)).workEndCivil(CivilTime.civilFromMcTick(computeWorkEndTick(schedule, context.genetics(), context.dayType()))).mealOffsetTicks(chronotype.mealOffsetTicks()).build();
   }

   @VisibleForTesting
   static List<PlanBand> deriveBands(PlanGenerationContext context, PlannerPolicy.PlannerPalette palette, RestDayPolicy restDayPolicy, PlanFrame frame, int lunchBandBoundCivil, int dinnerBandBoundCivil) {
      boolean restDayOrNitwit = context.dayType() == PlanDayType.REST_DAY || context.profession().equals(VillagerProfessionKey.NITWIT);
      PlannerPolicy.EffectiveWeightMultiplier restDayWeights = (behavior) -> PlannerPolicy.restDayMultiplier(behavior.descriptor(), restDayPolicy);
      PlannerPolicy.EffectiveWeightMultiplier finalWeights = context.dayType() == PlanDayType.REST_DAY ? restDayWeights : PlannerPolicy.DEFAULT_EFFECTIVE_WEIGHT_MULTIPLIER;
      int morningStartCivil;
      int morningEndCivil;
      PlanBand morning;
      if (restDayOrNitwit) {
         morningStartCivil = frame.wakeCivil() + GameTicks.minutes((double)40.0F).getTicksAsInt();
         morningEndCivil = lunchBandBoundCivil - BAND_EDGE_MARGIN_TICKS;
         morning = new PlanBand("MORNING", morningStartCivil, morningEndCivil, 55, palette.availableBehaviors(), restDayWeights, 0.55);
      } else {
         morningStartCivil = frame.workStartCivil();
         morningEndCivil = frame.workEndCivil();
         morning = new PlanBand("MORNING", morningStartCivil, morningEndCivil, 70, palette.workBehaviors(), PlannerPolicy.DEFAULT_EFFECTIVE_WEIGHT_MULTIPLIER, (double)0.75F);
      }

      int morningEffectiveEnd = Math.max(morningStartCivil, morningEndCivil);
      List<WeightedBehavior> afternoonCandidates = palette.afternoonCandidates(context.genetics());
      int afternoonNominalStartCivil = restDayOrNitwit ? restDayMeetPivotCivil(frame.bedtimeCivil()) : AFTERNOON_NOMINAL_START_CIVIL_TICK;
      int afternoonStartCivil = Math.max(morningEffectiveEnd, afternoonNominalStartCivil);
      PlanBand afternoon = new PlanBand("AFTERNOON", afternoonStartCivil, dinnerBandBoundCivil, 50, afternoonCandidates, finalWeights, 0.55);
      int afternoonEffectiveEnd = Math.max(afternoonStartCivil, dinnerBandBoundCivil);
      List<WeightedBehavior> eveningCandidates = palette.eveningCandidates();
      int eveningEndCivil = Math.min(frame.bedtimeCivil() - EVENING_MARGIN_TICKS, DUSK_CIVIL_TICK);
      PlanBand evening = new PlanBand("EVENING", afternoonEffectiveEnd, eveningEndCivil, 40, eveningCandidates, finalWeights, 0.55);
      List<PlanBand> bands = new ArrayList(3);

      for(PlanBand band : List.of(morning, afternoon, evening)) {
         if (band.endCivil() - band.startCivil() >= WindowPacker.MINIMUM_SLOT_SPACING_TICKS) {
            bands.add(band);
         }
      }

      return bands;
   }

   private AnchorPlacement computeAnchors(PlanFrame frame, List<PlanBand> bands, PlanIntent intent, PlanGenerationContext context, Random random) {
      List<PlanAnchor> anchors = new ArrayList(this.rollDefaultMealAnchors(frame, random));
      List<PinnedSelection> pins = intent.pins();
      if (pins.isEmpty()) {
         return new AnchorPlacement(anchors, Map.of(), Map.of());
      } else {
         for(PinnedSelection pin : pins) {
            if (pin.meal()) {
               anchors.removeIf((anchor) -> anchor.behaviorKey().equals(BehaviorKey.EAT_FOOD) && Math.abs(anchor.startTick() - pin.civilTick()) <= MEAL_COLLISION_WINDOW_TICKS);
            }
         }

         Map<BehaviorKey, Integer> pinnedEligibility = new HashMap();
         Map<String, List<BehaviorKey>> demotedSelections = new LinkedHashMap();

         for(PinnedSelection pin : pins) {
            WeightedBehavior behavior = findBehavior(context, pin.key());
            if (behavior == null) {
               log.error("Unknown pin ID: {}", pin.key());
            } else {
               int duration = behavior.descriptor().getEstimatedDuration().getTicksAsInt();
               int placementTick = resolvePinTick(pin.civilTick(), duration, anchors, frame);
               if (placementTick < 0) {
                  String bandId = findBandId(bands, pin.civilTick());
                  if (bandId != null) {
                     ((List)demotedSelections.computeIfAbsent(bandId, (key) -> new ArrayList())).add(pin.key());
                  }
               } else {
                  int priority = pin.meal() ? 90 : 80;
                  anchors.add(new PlanAnchor(placementTick, pin.key(), priority, duration, !pin.meal(), !pin.meal()));
                  int cooldownSpacing = Math.max(WindowPacker.MINIMUM_SLOT_SPACING_TICKS, behavior.descriptor().getCooldown().drawTicks(random));
                  pinnedEligibility.put(pin.key(), placementTick + cooldownSpacing);
               }
            }
         }

         return new AnchorPlacement(anchors, pinnedEligibility, demotedSelections);
      }
   }

   private List<PlanAnchor> rollDefaultMealAnchors(PlanFrame frame, Random random) {
      List<PlanAnchor> anchors = new ArrayList();

      for(MealAnchorRule rule : this.mealAnchorTable) {
         boolean survives = random.nextDouble() < rule.authoredKeepProbability();
         if (survives) {
            int placementTick = rule.placementTick(frame.wakeCivil(), frame.mealOffsetTicks());
            anchors.add(new PlanAnchor(placementTick, rule.behaviorKey(), rule.priority(), rule.durationTicks(), false, false));
         }
      }

      return anchors;
   }

   private static int resolvePinTick(int desiredTick, int duration, List<PlanAnchor> existingAnchors, PlanFrame frame) {
      if (fitsPinWindow(desiredTick, duration, existingAnchors, frame)) {
         return desiredTick;
      } else {
         int snapped = desiredTick + PIN_SNAP_BUCKET_TICKS;
         return fitsPinWindow(snapped, duration, existingAnchors, frame) ? snapped : -1;
      }
   }

   private static boolean fitsPinWindow(int tick, int duration, List<PlanAnchor> anchors, PlanFrame frame) {
      if (tick >= frame.wakeCivil() && tick <= frame.bedtimeCivil()) {
         int end = tick + duration;

         for(PlanAnchor anchor : anchors) {
            int anchorEnd = anchor.startTick() + anchor.durationTicks();
            if (tick < anchorEnd && anchor.startTick() < end) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   @Nullable
   private static String findBandId(List<PlanBand> bands, int civilTick) {
      for(PlanBand band : bands) {
         if (civilTick >= band.startCivil() && civilTick < band.endCivil()) {
            return band.id();
         }
      }

      return null;
   }

   @Nullable
   private static WeightedBehavior findBehavior(PlanGenerationContext context, BehaviorKey key) {
      return (WeightedBehavior)context.availableBehaviors().stream().filter((behavior) -> behavior.key().equals(key)).findFirst().orElse((Object)null);
   }

   private static BandFill fillPolicyFor(PlanBand band, PlanIntent intent, PlanGenerationContext context, Map<String, List<BehaviorKey>> demotedSelections) {
      if (intent.selections().isEmpty()) {
         return new BandFill(band.pool(), band.baseMultiplier(), HEURISTIC_STRATEGY);
      } else {
         List<BehaviorKey> selectedKeysInOrder = Stream.concat(((List)intent.selections().getOrDefault(band.id(), List.of())).stream(), ((List)demotedSelections.getOrDefault(band.id(), List.of())).stream()).distinct().toList();
         List<WeightedBehavior> filteredPool = context.availableBehaviors().stream().filter((behavior) -> selectedKeysInOrder.contains(behavior.key())).toList();
         return new BandFill(filteredPool, PlannerPolicy.DEFAULT_EFFECTIVE_WEIGHT_MULTIPLIER, new OrderedPreferenceSelectionStrategy(selectedKeysInOrder));
      }
   }

   private void fillBand(List<PlanSlot> slots, PlanBand band, PlanIntent intent, PlanGenerationContext context, AnchorPlacement anchorPlacement, Random random) {
      List<int[]> freeIntervals = freeSubIntervals(band.startCivil(), band.endCivil(), anchorPlacement.anchors());
      if (!freeIntervals.isEmpty()) {
         BandFill fill = fillPolicyFor(band, intent, context, anchorPlacement.demotedSelections());
         if (!fill.pool().isEmpty()) {
            PlannerPolicy.EffectiveWeightMultiplier multiplier = fill.multiplier().andThen(PlannerPolicy.opportunityMultiplier(context));
            List<WindowPacker.PackingCandidate> candidates = fill.pool().stream().map((behavior) -> new WindowPacker.PackingCandidate(behavior.key(), Math.max((double)0.0F, (double)behavior.weight() * multiplier.apply(behavior)), behavior.descriptor().getEstimatedDuration().getTicksAsInt(), behavior.descriptor().getCooldown())).toList();

            for(int[] interval : freeIntervals) {
               Map<BehaviorKey, Integer> nextEligible = new HashMap(anchorPlacement.pinnedEligibility());

               for(WindowPacker.PackedSlot packedSlot : WindowPacker.pack(candidates, interval[0], interval[1], band.basePriority(), fill.strategy(), random, band.packFactor(), nextEligible)) {
                  slots.add(PlanSlot.builder().startTick(packedSlot.startCivil()).behaviorKey(packedSlot.key()).priority(packedSlot.priority()).flexible(true).estimatedDurationTicks(packedSlot.durationTicks()).build());
               }
            }

         }
      }
   }

   @VisibleForTesting
   static List<int[]> freeSubIntervals(int bandStart, int bandEnd, List<PlanAnchor> anchors) {
      List<int[]> reserved = anchors.stream().map((anchor) -> new int[]{anchor.startTick(), anchor.startTick() + anchor.durationTicks()}).filter((interval) -> interval[1] > bandStart && interval[0] < bandEnd).sorted(Comparator.comparingInt((a) -> a[0])).toList();
      List<int[]> free = new ArrayList();
      int cursor = bandStart;

      for(int[] reservedInterval : reserved) {
         int resolvedStart = Math.max(reservedInterval[0], bandStart);
         int resolvedEnd = Math.min(reservedInterval[1], bandEnd);
         if (resolvedStart > cursor) {
            free.add(new int[]{cursor, resolvedStart});
         }

         cursor = Math.max(cursor, resolvedEnd);
      }

      if (cursor < bandEnd) {
         free.add(new int[]{cursor, bandEnd});
      }

      return free;
   }

   private static DayPlanSchedule buildActivitySchedule(PlanGenerationContext context, PlanFrame frame) {
      int wakeCivil = frame.wakeCivil();
      int bedtimeCivil = frame.bedtimeCivil();
      DayPlanSchedule.DayPlanScheduleBuilder builder = DayPlanSchedule.builder().wakeTick(wakeCivil).bedtimeTick(bedtimeCivil);
      if (context.dayType() != PlanDayType.REST_DAY && !context.profession().equals(VillagerProfessionKey.NITWIT)) {
         int workStart = Math.min(frame.workStartCivil(), bedtimeCivil);
         int workEnd = CompatMath.clamp(frame.workEndCivil(), workStart, bedtimeCivil);
         if (workStart > wakeCivil) {
            builder.activityBlock(DayPlanActivityBlock.builder().context(DayPlanActivityContext.IDLE).startTick(wakeCivil).endTick(workStart).build());
         }

         if (workEnd > workStart) {
            builder.activityBlock(DayPlanActivityBlock.builder().context(DayPlanActivityContext.WORK).startTick(workStart).endTick(workEnd).build());
         }

         if (bedtimeCivil > workEnd) {
            builder.activityBlock(DayPlanActivityBlock.builder().context(DayPlanActivityContext.MEET).startTick(workEnd).endTick(bedtimeCivil).build());
         }

         return builder.build();
      } else {
         int meetStartCivil = restDayMeetPivotCivil(bedtimeCivil);
         if (meetStartCivil > wakeCivil) {
            builder.activityBlock(DayPlanActivityBlock.builder().context(DayPlanActivityContext.IDLE).startTick(wakeCivil).endTick(meetStartCivil).build());
         }

         if (bedtimeCivil > meetStartCivil) {
            builder.activityBlock(DayPlanActivityBlock.builder().context(DayPlanActivityContext.MEET).startTick(meetStartCivil).endTick(bedtimeCivil).build());
         }

         return builder.build();
      }
   }

   private static int computeWorkEndTick(ScheduleProfile schedule, GeneticsProfile genetics, PlanDayType dayType) {
      int workEndTick = schedule.workEndTick();
      if (dayType == PlanDayType.REST_DAY) {
         workEndTick = Math.min(workEndTick, TimeOfDay.AT_13_00.getMinecraftTick());
      }

      workEndTick += (int)((genetics.getGeneValue(GeneType.WILL) - (double)0.5F) * (double)GameTicks.minutes((double)90.0F).getTicksAsInt());
      return CompatMath.clamp(workEndTick, TimeOfDay.AT_10_00.getMinecraftTick(), TimeOfDay.AT_17_00.getMinecraftTick());
   }

   private static int resolveWorkStartCivil(ScheduleProfile schedule, int wakeCivil, int bedtimeCivil) {
      int morningFloorCivil = wakeCivil + GameTicks.minutes((double)30.0F).getTicksAsInt();
      int workStartCivil = CivilTime.civilFromMcTick(schedule.workStartTick());
      return workStartCivil < bedtimeCivil && workStartCivil >= wakeCivil ? Math.max(morningFloorCivil, workStartCivil) : morningFloorCivil;
   }

   private static int restDayMeetPivotCivil(int bedtimeCivil) {
      return Math.min(LUNCH_BAND_BOUND_CIVIL_TICK + BAND_EDGE_MARGIN_TICKS, bedtimeCivil);
   }

   @Inject
   @Generated
   DayPlanComposer(List<MealAnchorRule> mealAnchorTable) {
      this.mealAnchorTable = mealAnchorTable;
   }

   static {
      LUNCH_BAND_BOUND_CIVIL_TICK = TimeOfDay.AT_11_00.getCivilTick();
      DINNER_BAND_BOUND_CIVIL_TICK = TimeOfDay.AT_16_30.getCivilTick();
      AFTERNOON_NOMINAL_START_CIVIL_TICK = TimeOfDay.AT_13_00.getCivilTick();
      DUSK_CIVIL_TICK = TimeOfDay.AT_18_30.getCivilTick();
      EVENING_MARGIN_TICKS = GameTicks.minutes((double)30.0F).getTicksAsInt();
      BAND_EDGE_MARGIN_TICKS = GameTicks.minutes((double)30.0F).getTicksAsInt();
      MEAL_COLLISION_WINDOW_TICKS = GameTicks.minutes((double)30.0F).getTicksAsInt();
      PIN_SNAP_BUCKET_TICKS = GameTicks.minutes((double)30.0F).getTicksAsInt();
      HEURISTIC_STRATEGY = new WeightedRandomSelectionStrategy();
   }

   public static record PlanFrame(int wakeCivil, int bedtimeCivil, int workStartCivil, int workEndCivil, int mealOffsetTicks) {
      @Generated
      public static PlanFrameBuilder builder() {
         return new PlanFrameBuilder();
      }

      @Generated
      public static class PlanFrameBuilder {
         @Generated
         private int wakeCivil;
         @Generated
         private int bedtimeCivil;
         @Generated
         private int workStartCivil;
         @Generated
         private int workEndCivil;
         @Generated
         private int mealOffsetTicks;

         @Generated
         PlanFrameBuilder() {
         }

         @Generated
         public PlanFrameBuilder wakeCivil(int wakeCivil) {
            this.wakeCivil = wakeCivil;
            return this;
         }

         @Generated
         public PlanFrameBuilder bedtimeCivil(int bedtimeCivil) {
            this.bedtimeCivil = bedtimeCivil;
            return this;
         }

         @Generated
         public PlanFrameBuilder workStartCivil(int workStartCivil) {
            this.workStartCivil = workStartCivil;
            return this;
         }

         @Generated
         public PlanFrameBuilder workEndCivil(int workEndCivil) {
            this.workEndCivil = workEndCivil;
            return this;
         }

         @Generated
         public PlanFrameBuilder mealOffsetTicks(int mealOffsetTicks) {
            this.mealOffsetTicks = mealOffsetTicks;
            return this;
         }

         @Generated
         public PlanFrame build() {
            return new PlanFrame(this.wakeCivil, this.bedtimeCivil, this.workStartCivil, this.workEndCivil, this.mealOffsetTicks);
         }

         @Generated
         public String toString() {
            return "DayPlanComposer.PlanFrame.PlanFrameBuilder(wakeCivil=" + this.wakeCivil + ", bedtimeCivil=" + this.bedtimeCivil + ", workStartCivil=" + this.workStartCivil + ", workEndCivil=" + this.workEndCivil + ", mealOffsetTicks=" + this.mealOffsetTicks + ")";
         }
      }
   }

   private static record PlanAnchor(int startTick, BehaviorKey behaviorKey, int priority, int durationTicks, boolean flexible, boolean pinned) {
      public PlanSlot toSlot() {
         return PlanSlot.builder().startTick(this.startTick).behaviorKey(this.behaviorKey).priority(this.priority).flexible(this.flexible).estimatedDurationTicks(this.durationTicks).pinned(this.pinned).build();
      }
   }

   private static record AnchorPlacement(List<PlanAnchor> anchors, Map<BehaviorKey, Integer> pinnedEligibility, Map<String, List<BehaviorKey>> demotedSelections) {
   }

   private static record BandFill(List<WeightedBehavior> pool, PlannerPolicy.EffectiveWeightMultiplier multiplier, SlotSelectionStrategy strategy) {
   }
}
