package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.domain.ai.schedule.IWeekCycleProvider;
import dev.breezes.settlements.domain.ai.schedule.PlanDayType;
import jakarta.inject.Inject;

public class WeekCycleProvider implements IWeekCycleProvider {
   private static final int REST_DAY_CYCLE_POSITION = 2;
   private static final int CYCLE_LENGTH_DAYS = 3;

   public PlanDayType getDayType(long gameDay) {
      return Math.floorMod(gameDay, 3) == 2 ? PlanDayType.REST_DAY : PlanDayType.WORK_DAY;
   }
}
