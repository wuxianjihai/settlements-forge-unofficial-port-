package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.domain.ai.behavior.contracts.IBehavior;
import dev.breezes.settlements.domain.ai.catalog.BehaviorPlanningMetadata;
import dev.breezes.settlements.domain.ai.planning.DayPlan;
import dev.breezes.settlements.domain.ai.planning.PlanArrival;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentLinkedQueue;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public class PlanRuntimeState {
   @Nullable
   private IBehavior<BaseVillager> currentBehavior;
   @Nullable
   private BehaviorPlanningMetadata currentDescriptor;
   private int currentBehaviorElapsedTicks;
   private int slotStartRetryDelayTicks;
   @Nullable
   private PlanArrival pendingArrival;
   private boolean planExhausted;
   @Nullable
   private CompletableFuture<DayPlan> pendingFuture;
   private final ConcurrentLinkedQueue<PlanArrival> pendingArrivals = new ConcurrentLinkedQueue();
   private long pendingFutureSubmittedAtDayTime;
   private long pendingFutureWakeAtAbsoluteTick;
   private long previousPlanTickDayTime;

   public PlanRuntimeState() {
      this.reset();
   }

   public void reset() {
      this.currentBehavior = null;
      this.currentDescriptor = null;
      this.currentBehaviorElapsedTicks = 0;
      this.slotStartRetryDelayTicks = 0;
      this.clearPendingGeneration();
      this.pendingArrival = null;
      this.planExhausted = false;
      this.previousPlanTickDayTime = -1L;
   }

   public void reset(long dayTime) {
      this.reset();
      this.previousPlanTickDayTime = dayTime;
   }

   public void setPendingArrival(@Nullable PlanArrival pendingArrival) {
      this.pendingArrival = pendingArrival;
   }

   @Nullable
   public DayPlan getPendingNextPlan() {
      return this.pendingArrival == null ? null : this.pendingArrival.plan();
   }

   public void clearCurrentBehavior() {
      this.currentBehavior = null;
      this.currentDescriptor = null;
      this.currentBehaviorElapsedTicks = 0;
   }

   public void assignPlanBehavior(@Nonnull IBehavior<BaseVillager> behavior, @Nullable BehaviorPlanningMetadata descriptor) {
      this.currentBehavior = behavior;
      this.currentDescriptor = descriptor;
      this.currentBehaviorElapsedTicks = 0;
   }

   public void incrementCurrentBehaviorElapsedTicks(int delta) {
      this.currentBehaviorElapsedTicks += delta;
   }

   public void armSlotStartRetryDelay(int ticks) {
      this.slotStartRetryDelayTicks = ticks;
   }

   public void decaySlotStartRetryDelay(int delta) {
      this.slotStartRetryDelayTicks = Math.max(0, this.slotStartRetryDelayTicks - delta);
   }

   public void markPlanExhausted() {
      this.planExhausted = true;
   }

   public void clearPendingFuture() {
      this.pendingFuture = null;
      this.pendingFutureSubmittedAtDayTime = -1L;
      this.pendingFutureWakeAtAbsoluteTick = -1L;
   }

   public void cancelPendingFuture() {
      if (this.pendingFuture != null) {
         this.pendingFuture.cancel(true);
      }

      this.clearPendingFuture();
   }

   public void clearPendingGeneration() {
      this.cancelPendingFuture();
      this.pendingArrivals.clear();
   }

   public DeltaResult advanceClock(long dayTime) {
      long previousPlanTick = this.previousPlanTickDayTime;
      if (previousPlanTick < 0L) {
         this.previousPlanTickDayTime = dayTime;
         return DeltaResult.builder().deltaTicks(1).backwardJump(false).firstTick(true).rawDelta(0L).previousDayTime(previousPlanTick).build();
      } else {
         long rawDelta = dayTime - previousPlanTick;
         this.previousPlanTickDayTime = dayTime;
         int deltaTicks = rawDelta <= 0L ? 0 : (int)Math.min(2147483647L, rawDelta);
         return DeltaResult.builder().deltaTicks(deltaTicks).backwardJump(rawDelta < 0L).firstTick(false).rawDelta(rawDelta).previousDayTime(previousPlanTick).build();
      }
   }

   @Nullable
   @Generated
   public IBehavior<BaseVillager> getCurrentBehavior() {
      return this.currentBehavior;
   }

   @Nullable
   @Generated
   public BehaviorPlanningMetadata getCurrentDescriptor() {
      return this.currentDescriptor;
   }

   @Generated
   public int getCurrentBehaviorElapsedTicks() {
      return this.currentBehaviorElapsedTicks;
   }

   @Generated
   public int getSlotStartRetryDelayTicks() {
      return this.slotStartRetryDelayTicks;
   }

   @Nullable
   @Generated
   public PlanArrival getPendingArrival() {
      return this.pendingArrival;
   }

   @Generated
   public boolean isPlanExhausted() {
      return this.planExhausted;
   }

   @Nullable
   @Generated
   public CompletableFuture<DayPlan> getPendingFuture() {
      return this.pendingFuture;
   }

   @Generated
   public ConcurrentLinkedQueue<PlanArrival> getPendingArrivals() {
      return this.pendingArrivals;
   }

   @Generated
   public long getPendingFutureSubmittedAtDayTime() {
      return this.pendingFutureSubmittedAtDayTime;
   }

   @Generated
   public long getPendingFutureWakeAtAbsoluteTick() {
      return this.pendingFutureWakeAtAbsoluteTick;
   }

   @Generated
   public long getPreviousPlanTickDayTime() {
      return this.previousPlanTickDayTime;
   }

   @Generated
   public void setPendingFuture(@Nullable CompletableFuture<DayPlan> pendingFuture) {
      this.pendingFuture = pendingFuture;
   }

   @Generated
   public void setPendingFutureSubmittedAtDayTime(long pendingFutureSubmittedAtDayTime) {
      this.pendingFutureSubmittedAtDayTime = pendingFutureSubmittedAtDayTime;
   }

   @Generated
   public void setPendingFutureWakeAtAbsoluteTick(long pendingFutureWakeAtAbsoluteTick) {
      this.pendingFutureWakeAtAbsoluteTick = pendingFutureWakeAtAbsoluteTick;
   }
}
