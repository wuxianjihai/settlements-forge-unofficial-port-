package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.application.ai.behavior.publication.BehaviorOutcomePublisher;
import dev.breezes.settlements.application.ai.override.DayPlanHandoff;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.behavior.contracts.IBehavior;
import dev.breezes.settlements.domain.ai.behavior.model.BehaviorStatus;
import dev.breezes.settlements.domain.ai.catalog.BehaviorPlanningMetadata;
import dev.breezes.settlements.domain.ai.catalog.IBehaviorCatalog;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.planning.DayPlan;
import dev.breezes.settlements.domain.ai.planning.IAsyncPlanGenerator;
import dev.breezes.settlements.domain.ai.planning.IPlanGenerator;
import dev.breezes.settlements.domain.ai.planning.PinnedSelection;
import dev.breezes.settlements.domain.ai.planning.PlanArrival;
import dev.breezes.settlements.domain.ai.planning.PlanAuthor;
import dev.breezes.settlements.domain.ai.planning.PlanGenerationContext;
import dev.breezes.settlements.domain.ai.planning.PlanIntent;
import dev.breezes.settlements.domain.ai.planning.PlanSlot;
import dev.breezes.settlements.domain.ai.planning.PlanSlotStatus;
import dev.breezes.settlements.domain.ai.planning.PlanStatus;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventEmitter;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.WorldCalendar;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.annotations.stylistic.VisibleForTesting;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.server.level.ServerLevel;

@ServerScope
public class PlanRunner implements DayPlanHandoff {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(PlanRunner.class.getName());
   private static final String RESET_REASON_MISSING_PLAN = "missing plan";
   private static final String RESET_REASON_MISSING_SUCCESSOR = "missing successor plan";
   private static final String RESET_REASON_ASYNC_OVERRUN = "async plan generation overrun";
   private static final String RESET_REASON_BACKWARD_JUMP = "backward dayTime jump";
   private static final String RESET_REASON_BACKWARD_WHILE_UNLOADED = "backward dayTime jump while unloaded";
   private static final String RESET_REASON_CALENDAR_DAY_MISMATCH = "calendar day mismatch";
   private static final int DEFAULT_MAX_BEHAVIOR_RUN_TICKS = ClockTicks.seconds((double)120.0F).getTicksAsInt();
   private static final int SLOT_START_RETRY_INTERVAL_TICKS = ClockTicks.seconds((double)0.5F).getTicksAsInt();
   private final IBehaviorCatalog catalog;
   private final PlanGenerationContextFactory planGenerationContextFactory;
   private final IPlanGenerator planGenerator;
   private final IAsyncPlanGenerator asyncPlanGenerator;
   private final VillagerWakeScheduler wakeScheduler;
   private final MinimalPlanFactory minimalPlanFactory;
   private final BehaviorOutcomePublisher behaviorOutcomePublisher;
   private final WorldEventEmitter worldEventEmitter;
   private final PlanRequestService planRequestService;

   public void tick(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      PlanRuntimeState runtime = villager.getPlanRuntimeState();
      long dayTime = level.m_46468_();
      DeltaResult delta = runtime.advanceClock(dayTime);
      this.drainPendingArrivals(runtime, villager, dayTime);
      DayPlan adopted = this.adoptPendingIfReady(level, villager, runtime, dayTime);
      DayPlan plan = adopted != null ? adopted : villager.getDayPlan();
      if (this.shouldFallbackFromAsyncOverrun(runtime, dayTime)) {
         runtime.cancelPendingFuture();
         plan = this.hardReset(level, villager, runtime, dayTime, "async plan generation overrun", delta);
      } else if (delta.backwardJump()) {
         plan = this.hardReset(level, villager, runtime, dayTime, "backward dayTime jump", delta);
      } else if (plan == null) {
         plan = this.hardReset(level, villager, runtime, dayTime, "missing plan", delta);
      } else if (runtime.isPlanExhausted()) {
         if (runtime.getPendingFuture() != null || runtime.getPendingNextPlan() != null) {
            return;
         }

         plan = this.hardReset(level, villager, runtime, dayTime, "missing successor plan", delta);
      } else {
         if (this.isPlanOverdue(plan, dayTime)) {
            log.behaviorWarn("Plan overdue backstop fired for villager {}: dayTime={}, wakeAtAbsoluteTick={}", villager.m_20148_(), dayTime, plan.getWakeAtAbsoluteTick());
            this.completeExpiredPlanAndSubmitSuccessor(level, villager, runtime, plan);
            return;
         }

         if (hasCalendarDayMismatch(plan, dayTime)) {
            log.behaviorStatus("Plan calendar mismatch for villager {}: planDay={}, currentDay={}, dayTime={}", villager.m_20148_(), plan.getCalendarDay(), WorldCalendar.calendarDayOf(dayTime), dayTime);
            this.completeExpiredPlanAndSubmitSuccessor(level, villager, runtime, plan);
            return;
         }

         if (delta.firstTick() && detectOnLoadBackward(plan, nowCivilFor(plan, dayTime))) {
            plan = this.hardReset(level, villager, runtime, dayTime, "backward dayTime jump while unloaded", delta);
         } else {
            if (delta.deltaTicks() == 0) {
               return;
            }

            runSeekLoop(plan, nowCivilFor(plan, dayTime));
         }
      }

      if (!plan.isExhausted() && !plan.getCurrentSlot().isEmpty()) {
         this.tickSlot(level, villager, plan, (PlanSlot)plan.getCurrentSlot().get(), runtime, delta.deltaTicks(), nowCivilFor(plan, dayTime));
      } else {
         this.completeExpiredPlanAndSubmitSuccessor(level, villager, runtime, plan);
      }
   }

   public void ensureValidPlan(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      PlanRuntimeState runtime = villager.getPlanRuntimeState();
      long dayTime = level.m_46468_();
      this.drainPendingArrivals(runtime, villager, dayTime);
      DayPlan plan = this.adoptPendingIfReady(level, villager, runtime, dayTime);
      if (plan == null) {
         plan = villager.getDayPlan();
      }

      if (plan == null || this.isPlanOverdue(plan, dayTime) || hasCalendarDayMismatch(plan, dayTime)) {
         DayPlan pendingNextPlan = runtime.getPendingNextPlan();
         if (!shouldWaitForPendingPlan(pendingNextPlan, dayTime)) {
            if (plan != null && pendingNextPlan == null) {
               long nextWakeAtAbsoluteTick = this.wakeScheduler.nextWakeAtAbsoluteTick(villager, dayTime, plan.getWakeAtAbsoluteTick());
               if (dayTime < nextWakeAtAbsoluteTick) {
                  this.completeExpiredPlanAndSubmitSuccessor(level, villager, runtime, plan);
                  return;
               }
            }

            String resetReason;
            if (plan == null) {
               resetReason = "missing plan";
            } else if (hasCalendarDayMismatch(plan, dayTime)) {
               resetReason = "calendar day mismatch";
            } else {
               resetReason = "missing successor plan";
            }

            this.hardReset(level, villager, runtime, dayTime, resetReason, singleTickDelta(runtime));
            log.behaviorStatus("Plan regenerated for villager {} during unmanaged activity: dayTime={}", villager.m_20148_(), dayTime);
         }
      }
   }

   public boolean suspendIfActive(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      PlanRuntimeState runtime = villager.getPlanRuntimeState();
      IBehavior<BaseVillager> behavior = runtime.getCurrentBehavior();
      if (behavior != null && behavior.getStatus() != BehaviorStatus.STOPPED) {
         behavior.stop(level, villager);
         DayPlan plan = villager.getDayPlan();
         if (plan != null) {
            plan.getCurrentSlot().filter((slot) -> slot.getStatus() == PlanSlotStatus.ACTIVE).ifPresent((slot) -> slot.markStatus(PlanSlotStatus.INTERRUPTED));
         }

         runtime.clearCurrentBehavior();
         this.clearPlanActiveMemory(villager);
         return true;
      } else {
         return false;
      }
   }

   public void forceStop(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      PlanRuntimeState runtime = villager.getPlanRuntimeState();
      IBehavior<BaseVillager> behavior = runtime.getCurrentBehavior();
      if (behavior != null && behavior.getStatus() != BehaviorStatus.STOPPED) {
         behavior.stop(level, villager);
      }

      runtime.clearCurrentBehavior();
      this.clearPlanActiveMemory(villager);
   }

   private void tickSlot(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull DayPlan plan, @Nonnull PlanSlot slot, @Nonnull PlanRuntimeState runtime, int delta, int nowCivil) {
      switch (slot.getStatus()) {
         case PENDING:
            this.tryStartSlot(level, villager, plan, slot, runtime, delta, nowCivil);
            break;
         case ACTIVE:
            this.tickActiveSlot(level, villager, plan, slot, runtime, delta);
            break;
         case COMPLETED:
         case SKIPPED:
         case INTERRUPTED:
            this.clearPlanActiveMemory(villager);
            plan.advanceSlot();
      }

   }

   private void tryStartSlot(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull DayPlan plan, @Nonnull PlanSlot slot, @Nonnull PlanRuntimeState runtime, int delta, int nowCivil) {
      if (runtime.getSlotStartRetryDelayTicks() > 0) {
         runtime.decaySlotStartRetryDelay(delta);
      } else if (!isSlotWindowOpen(slot, nowCivil)) {
         this.clearPlanActiveMemory(villager);
      } else {
         Optional<IBehavior<BaseVillager>> maybeBehavior = this.catalog.createBehavior(slot.getBehaviorKey());
         if (maybeBehavior.isEmpty()) {
            log.behaviorWarn("Plan slot skipped for villager {}: behavior '{}' missing from catalog", villager.m_20148_(), slot.getBehaviorKey());
            slot.markStatus(PlanSlotStatus.SKIPPED);
            this.clearPlanActiveMemory(villager);
            plan.advanceSlot();
         } else {
            IBehavior<BaseVillager> behavior = (IBehavior)maybeBehavior.get();
            behavior.getBehaviorCoolDown().forceComplete();
            behavior.getPreconditionCheckCooldown().forceComplete();
            if (!behavior.tickPreconditions(1, level, villager)) {
               if (slot.isFlexible()) {
                  log.behaviorTrace("Plan slot skipped for villager {}: behavior '{}' preconditions not met", villager.m_20148_(), slot.getBehaviorKey());
                  slot.markStatus(PlanSlotStatus.SKIPPED);
                  this.clearPlanActiveMemory(villager);
                  plan.advanceSlot();
               } else {
                  runtime.armSlotStartRetryDelay(SLOT_START_RETRY_INTERVAL_TICKS - 1);
               }
            } else {
               try {
                  behavior.start(level, villager);
               } catch (RuntimeException e) {
                  log.behaviorError("Plan behavior '{}' threw during start for villager {}; skipping slot", slot.getBehaviorKey(), villager.m_20148_(), e);
                  slot.markStatus(PlanSlotStatus.SKIPPED);
                  this.clearPlanActiveMemory(villager);
                  plan.advanceSlot();
                  return;
               }

               runtime.assignPlanBehavior(behavior, (BehaviorPlanningMetadata)this.catalog.getDescriptor(slot.getBehaviorKey()).orElse((Object)null));
               this.setPlanActiveMemory(villager);
               slot.markStatus(PlanSlotStatus.ACTIVE);
               plan.markStatus(PlanStatus.ACTIVE);
               this.worldEventEmitter.emitBehaviorStarted(villager, slot.getBehaviorKey());
            }
         }
      }
   }

   private void tickActiveSlot(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull DayPlan plan, @Nonnull PlanSlot slot, @Nonnull PlanRuntimeState runtime, int delta) {
      IBehavior<BaseVillager> behavior = runtime.getCurrentBehavior();
      if (behavior == null) {
         slot.markStatus(PlanSlotStatus.INTERRUPTED);
         this.clearPlanActiveMemory(villager);
         plan.advanceSlot();
      } else {
         runtime.incrementCurrentBehaviorElapsedTicks(delta);
         BehaviorPlanningMetadata descriptor = runtime.getCurrentDescriptor();
         int maxRunTicks = descriptor != null ? descriptor.getMaxRunDuration().getTicksAsInt() : DEFAULT_MAX_BEHAVIOR_RUN_TICKS;
         if (runtime.getCurrentBehaviorElapsedTicks() > maxRunTicks) {
            this.abortStuckPlanBehavior(level, villager, runtime, slot, plan, behavior);
         } else {
            try {
               behavior.tick(delta, level, villager);
            } catch (RuntimeException e) {
               log.behaviorError("Plan behavior '{}' threw during tick for villager {}; force-stopping wedged behavior", slot.getBehaviorKey(), villager.m_20148_(), e);
               this.abortPlanBehavior(level, villager, runtime, slot, plan, behavior, "behavior threw during tick");
               return;
            }

            if (behavior.getStatus() == BehaviorStatus.STOPPED) {
               slot.markStatus(PlanSlotStatus.COMPLETED);
               this.behaviorOutcomePublisher.publishCompleted(villager, slot.getBehaviorKey(), behavior);
               runtime.clearCurrentBehavior();
               this.clearPlanActiveMemory(villager);
               plan.advanceSlot();
            }

         }
      }
   }

   private void abortStuckPlanBehavior(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull PlanRuntimeState runtime, @Nonnull PlanSlot slot, @Nonnull DayPlan plan, @Nonnull IBehavior<BaseVillager> behavior) {
      log.behaviorWarn("Plan behavior '{}' exceeded max run duration ({} ticks) for villager {}; force-stopping wedged behavior", slot.getBehaviorKey(), runtime.getCurrentBehaviorElapsedTicks(), villager.m_20148_());
      this.abortPlanBehavior(level, villager, runtime, slot, plan, behavior, "behavior ceiling exceeded");
   }

   private void abortPlanBehavior(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull PlanRuntimeState runtime, @Nonnull PlanSlot slot, @Nonnull DayPlan plan, @Nonnull IBehavior<BaseVillager> behavior, @Nonnull String failureReason) {
      if (behavior.getStatus() != BehaviorStatus.STOPPED) {
         behavior.stop(level, villager);
      }

      slot.markStatus(PlanSlotStatus.SKIPPED);
      runtime.clearCurrentBehavior();
      this.clearPlanActiveMemory(villager);
      plan.advanceSlot();
      this.behaviorOutcomePublisher.publishFailed(villager, slot.getBehaviorKey(), failureReason);
   }

   public void reAttemptInterruptedSlot(@Nonnull BaseVillager villager) {
      DayPlan plan = villager.getDayPlan();
      if (plan != null) {
         plan.getCurrentSlot().filter((slot) -> slot.getStatus() == PlanSlotStatus.INTERRUPTED).ifPresent((slot) -> slot.markStatus(PlanSlotStatus.PENDING));
      }
   }

   private static DeltaResult singleTickDelta(@Nonnull PlanRuntimeState runtime) {
      return DeltaResult.builder().deltaTicks(1).backwardJump(false).firstTick(false).rawDelta(0L).previousDayTime(runtime.getPreviousPlanTickDayTime()).build();
   }

   private DayPlan generatePlan(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, long wakeAtAbsoluteTick, @Nonnull PlanIntent intent) {
      return this.planGenerator.generate(this.createGenerationContext(villager, wakeAtAbsoluteTick), intent);
   }

   private PlanGenerationContext createGenerationContext(@Nonnull BaseVillager villager, long wakeAtAbsoluteTick) {
      return this.planGenerationContextFactory.create(villager, wakeAtAbsoluteTick);
   }

   private DayPlan regeneratePlan(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, long dayTime, @Nonnull PlanIntent intent) {
      long wakeAtAbsoluteTick = this.currentWakeAtOrBefore(villager, dayTime);

      DayPlan newPlan;
      try {
         newPlan = this.generatePlan(level, villager, wakeAtAbsoluteTick, intent);
      } catch (Exception exception) {
         newPlan = this.minimalPlanFactory.create(villager, wakeAtAbsoluteTick);
         log.behaviorError("Plan regeneration failed for villager {}; installed minimal plan floor: dayTime={}", villager.m_20148_(), dayTime, exception);
      }

      villager.setDayPlan(newPlan);
      return newPlan;
   }

   private DayPlan hardReset(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull PlanRuntimeState runtime, long dayTime, @Nonnull String reason, @Nonnull DeltaResult delta) {
      DayPlan oldPlan = villager.getDayPlan();
      if (oldPlan != null) {
         oldPlan.getCurrentSlot().filter((slot) -> slot.getStatus() == PlanSlotStatus.ACTIVE).ifPresent((slot) -> slot.markStatus(PlanSlotStatus.INTERRUPTED));
      }

      List<PinnedSelection> carriedPins = oldPlan == null ? List.of() : collectCarriedPins(oldPlan, nowCivilFor(oldPlan, dayTime));
      PlanIntent intent = carriedPins.isEmpty() ? PlanIntent.empty() : PlanIntent.ofCarriedPins(carriedPins);
      this.forceStop(level, villager);
      runtime.reset(dayTime);
      DayPlan newPlan = this.regeneratePlan(level, villager, dayTime, intent);
      runSeekLoop(newPlan, nowCivilFor(newPlan, dayTime));
      this.worldEventEmitter.emitDayPlanInvalidated(villager);
      this.logHardReset(villager, dayTime, reason, delta);
      return newPlan;
   }

   @VisibleForTesting
   static List<PinnedSelection> collectCarriedPins(@Nullable DayPlan oldPlan, int nowCivil) {
      return oldPlan == null ? List.of() : oldPlan.getSlots().stream().filter(PlanSlot::isPinned).filter((slot) -> slot.getStartTick() > nowCivil).map((slot) -> new PinnedSelection(slot.getBehaviorKey(), slot.getStartTick(), false)).toList();
   }

   private void logHardReset(@Nonnull BaseVillager villager, long dayTime, @Nonnull String reason, @Nonnull DeltaResult delta) {
      if (!"missing plan".equals(reason) && !"missing successor plan".equals(reason)) {
         log.behaviorWarn("Plan hard reset for villager {}: reason={}, dayTime={}, previousDayTime={}, rawDelta={}", villager.m_20148_(), reason, dayTime, delta.previousDayTime(), delta.rawDelta());
      } else {
         log.behaviorTrace("Plan hard reset for villager {}: reason={}, dayTime={}, previousDayTime={}, rawDelta={}", villager.m_20148_(), reason, dayTime, delta.previousDayTime(), delta.rawDelta());
      }
   }

   private void drainPendingArrivals(@Nonnull PlanRuntimeState runtime, @Nonnull BaseVillager villager, long dayTime) {
      long currentCalendarDay = WorldCalendar.calendarDayOf(dayTime);

      PlanArrival arrived;
      while((arrived = (PlanArrival)runtime.getPendingArrivals().poll()) != null) {
         runtime.setPendingArrival(arbitrate(runtime.getPendingArrival(), arrived, currentCalendarDay));
         runtime.clearPendingFuture();
      }

      CompletableFuture<DayPlan> future = runtime.getPendingFuture();
      if (future != null && future.isCompletedExceptionally() && runtime.getPendingNextPlan() == null) {
         long wakeAtAbsoluteTick = runtime.getPendingFutureWakeAtAbsoluteTick();

         try {
            DayPlan fallback = this.planGenerator.generate(this.createGenerationContext(villager, wakeAtAbsoluteTick));
            runtime.setPendingArrival(new PlanArrival(fallback, PlanAuthor.HEURISTIC));
            log.behaviorWarn("Async plan generation failed for villager {}; sync fallback installed", villager.m_20148_());
         } catch (Exception exception) {
            DayPlan minimalPlan = this.minimalPlanFactory.create(villager, wakeAtAbsoluteTick);
            runtime.setPendingArrival(new PlanArrival(minimalPlan, PlanAuthor.HEURISTIC));
            log.behaviorError("Sync fallback plan generation failed for villager {}; installed minimal plan floor", villager.m_20148_(), exception);
         } finally {
            runtime.clearPendingFuture();
         }
      }

   }

   @VisibleForTesting
   @Nullable
   static PlanArrival arbitrate(@Nullable PlanArrival staged, @Nonnull PlanArrival incoming, long currentCalendarDay) {
      if (incoming.targetDay() < currentCalendarDay) {
         return staged;
      } else if (staged == null) {
         return incoming;
      } else if (incoming.targetDay() > staged.targetDay()) {
         return incoming;
      } else if (incoming.targetDay() < staged.targetDay()) {
         return staged;
      } else {
         return incoming.author() == PlanAuthor.HEURISTIC && staged.author() == PlanAuthor.LLM ? staged : incoming;
      }
   }

   @Nullable
   private DayPlan adoptPendingIfReady(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull PlanRuntimeState runtime, long dayTime) {
      DayPlan pending = runtime.getPendingNextPlan();
      if (pending != null && dayTime >= pending.getWakeAtAbsoluteTick()) {
         if (hasActiveCurrentSlot(villager.getDayPlan())) {
            return null;
         } else {
            this.forceStop(level, villager);
            villager.setDayPlan(pending);
            runtime.reset(dayTime);
            log.behaviorStatus("Plan adopted pre-generated plan at scheduled wake for villager {}: wakeAtAbsoluteTick={}", villager.m_20148_(), pending.getWakeAtAbsoluteTick());
            return pending;
         }
      } else {
         return null;
      }
   }

   @VisibleForTesting
   static boolean hasActiveCurrentSlot(@Nullable DayPlan plan) {
      return plan == null ? false : plan.getCurrentSlot().filter((slot) -> slot.getStatus() == PlanSlotStatus.ACTIVE).isPresent();
   }

   private void submitNextPlanAsync(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull PlanRuntimeState runtime, @Nonnull DayPlan currentPlan) {
      if (runtime.getPendingNextPlan() == null && runtime.getPendingFuture() == null) {
         long dayTime = level.m_46468_();
         long nextWakeAtAbsoluteTick = this.wakeScheduler.nextWakeAtAbsoluteTick(villager, dayTime, currentPlan.getWakeAtAbsoluteTick());
         PlanGenerationContext context = this.createGenerationContext(villager, nextWakeAtAbsoluteTick);
         CompletableFuture<DayPlan> future = this.asyncPlanGenerator.generateAsync(context);
         runtime.setPendingFuture(future);
         runtime.setPendingFutureSubmittedAtDayTime(dayTime);
         runtime.setPendingFutureWakeAtAbsoluteTick(nextWakeAtAbsoluteTick);
         future.whenComplete((plan, error) -> {
            if (error != null) {
               log.behaviorWarn("Async plan generation failed for villager {}: {}", villager.m_20148_(), error.toString());
            } else {
               runtime.getPendingArrivals().offer(new PlanArrival(plan, PlanAuthor.HEURISTIC));
            }
         });
         log.debug("Submitted async next-plan generation for villager {}: wakeAtAbsoluteTick={}", villager.m_20148_(), nextWakeAtAbsoluteTick);
         this.planRequestService.enqueueForOverlay(villager, dayTime, nextWakeAtAbsoluteTick);
      }
   }

   private void completeExpiredPlanAndSubmitSuccessor(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull PlanRuntimeState runtime, @Nonnull DayPlan plan) {
      this.forceStop(level, villager);
      plan.getCurrentSlot().filter((slot) -> slot.getStatus() == PlanSlotStatus.ACTIVE).ifPresent((slot) -> slot.markStatus(PlanSlotStatus.INTERRUPTED));
      plan.markStatus(PlanStatus.COMPLETED);
      if (!runtime.isPlanExhausted()) {
         runtime.markPlanExhausted();
         this.worldEventEmitter.emitPlanExhausted(villager);
         this.submitNextPlanAsync(level, villager, runtime, plan);
      }

   }

   private boolean shouldFallbackFromAsyncOverrun(@Nonnull PlanRuntimeState runtime, long dayTime) {
      CompletableFuture<DayPlan> pendingFuture = runtime.getPendingFuture();
      DayPlan pendingNextPlan = runtime.getPendingNextPlan();
      return pendingFuture != null && !pendingFuture.isDone() && pendingNextPlan == null && runtime.isPlanExhausted() && dayTime >= runtime.getPendingFutureWakeAtAbsoluteTick();
   }

   @VisibleForTesting
   static boolean shouldWaitForPendingPlan(@Nullable DayPlan pendingNextPlan, long dayTime) {
      return pendingNextPlan != null && dayTime < pendingNextPlan.getWakeAtAbsoluteTick();
   }

   @VisibleForTesting
   static boolean hasCalendarDayMismatch(@Nonnull DayPlan plan, long dayTime) {
      return plan.getCalendarDay() != WorldCalendar.calendarDayOf(dayTime);
   }

   private boolean isPlanOverdue(@Nonnull DayPlan plan, long dayTime) {
      return dayTime >= plan.getWakeAtAbsoluteTick() + (long)plan.getSchedule().authoredDayDurationTicks();
   }

   private long currentWakeAtOrBefore(@Nonnull BaseVillager villager, long dayTime) {
      long currentCalendarDay = WorldCalendar.calendarDayOf(dayTime);
      long todayWake = this.wakeScheduler.wakeAbsoluteTickFor(villager, currentCalendarDay);
      if (todayWake > dayTime) {
         long yesterdayWake = this.wakeScheduler.wakeAbsoluteTickFor(villager, currentCalendarDay - 1L);
         return Math.max(0L, yesterdayWake);
      } else {
         return Math.max(0L, todayWake);
      }
   }

   @VisibleForTesting
   static void runSeekLoop(@Nonnull DayPlan plan, int nowCivil) {
      while(!plan.isExhausted()) {
         Optional<PlanSlot> maybeSlot = plan.getCurrentSlot();
         if (maybeSlot.isEmpty()) {
            return;
         }

         PlanSlot slot = (PlanSlot)maybeSlot.get();
         switch (slot.getStatus()) {
            case PENDING:
               if (!isSlotWindowClosed(slot, nowCivil)) {
                  return;
               }

               slot.markStatus(PlanSlotStatus.SKIPPED);
               plan.advanceSlot();
               break;
            case ACTIVE:
               return;
            case COMPLETED:
            case SKIPPED:
            case INTERRUPTED:
               plan.advanceSlot();
         }
      }

   }

   @VisibleForTesting
   static boolean detectOnLoadBackward(@Nonnull DayPlan plan, int nowCivil) {
      int previousSlotIndex = plan.getCurrentSlotIndex() - 1;
      if (previousSlotIndex >= 0 && previousSlotIndex < plan.getSlots().size()) {
         PlanSlot lastExecuted = (PlanSlot)plan.getSlots().get(previousSlotIndex);
         return lastExecuted.getStartTick() > nowCivil;
      } else {
         return false;
      }
   }

   @VisibleForTesting
   static boolean isSlotWindowClosed(@Nonnull PlanSlot slot, int nowCivil) {
      return nowCivil > slot.getStartTick() + slot.getEstimatedDurationTicks();
   }

   @VisibleForTesting
   static boolean isSlotWindowOpen(@Nonnull PlanSlot slot, int nowCivil) {
      return nowCivil >= slot.getStartTick();
   }

   private void setPlanActiveMemory(@Nonnull BaseVillager villager) {
      villager.m_6274_().m_21879_(MemoryTypeRegistry.PLAN_BEHAVIOR_ACTIVE.getModuleType(), true);
   }

   private void clearPlanActiveMemory(@Nonnull BaseVillager villager) {
      villager.m_6274_().m_21936_(MemoryTypeRegistry.PLAN_BEHAVIOR_ACTIVE.getModuleType());
   }

   private static int nowCivilFor(@Nonnull DayPlan plan, long dayTime) {
      return WorldCalendar.civilOffsetWithin(plan.getCalendarDay(), dayTime);
   }

   @Inject
   @Generated
   PlanRunner(IBehaviorCatalog catalog, PlanGenerationContextFactory planGenerationContextFactory, IPlanGenerator planGenerator, IAsyncPlanGenerator asyncPlanGenerator, VillagerWakeScheduler wakeScheduler, MinimalPlanFactory minimalPlanFactory, BehaviorOutcomePublisher behaviorOutcomePublisher, WorldEventEmitter worldEventEmitter, PlanRequestService planRequestService) {
      this.catalog = catalog;
      this.planGenerationContextFactory = planGenerationContextFactory;
      this.planGenerator = planGenerator;
      this.asyncPlanGenerator = asyncPlanGenerator;
      this.wakeScheduler = wakeScheduler;
      this.minimalPlanFactory = minimalPlanFactory;
      this.behaviorOutcomePublisher = behaviorOutcomePublisher;
      this.worldEventEmitter = worldEventEmitter;
      this.planRequestService = planRequestService;
   }
}
