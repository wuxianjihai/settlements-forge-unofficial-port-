package dev.breezes.settlements.application.ai.planning;

import dagger.Lazy;
import dev.breezes.settlements.application.ai.inference.InferenceGate;
import dev.breezes.settlements.application.ai.inference.InferenceStreamHandle;
import dev.breezes.settlements.application.ai.inference.plan.PlanBatchRequest;
import dev.breezes.settlements.application.ai.inference.plan.PlanGateway;
import dev.breezes.settlements.application.ai.inference.plan.PlanInferenceConfig;
import dev.breezes.settlements.application.ai.inference.plan.PlanInferenceMode;
import dev.breezes.settlements.application.ai.inference.plan.VillagerPlanResult;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.planning.DayPlan;
import dev.breezes.settlements.domain.ai.planning.PlanArrival;
import dev.breezes.settlements.domain.ai.planning.PlanAuthor;
import dev.breezes.settlements.domain.ai.planning.PlanGenerationContext;
import dev.breezes.settlements.domain.world.WorldCalendar;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.annotations.stylistic.VisibleForTesting;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import javax.annotation.Nonnull;
import lombok.Generated;

@ServerScope
public final class PlanRequestService {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(PlanRequestService.class.getName());
   private static final int MAX_VILLAGERS_TO_PROCESS_PER_TICK = 8;
   private static final long BUFFER_EMPTY = -1L;
   private final PlanRequestAssembler assembler;
   private final PlanGenerationContextFactory contextFactory;
   private final LlmOverlayPlanGenerator overlayGenerator;
   private final Lazy<PlanGateway> gateway;
   private final PlanInferenceConfig config;
   private final InferenceGate inferenceGate;
   private final ArrayDeque<OverlayRequest> drainCursor = new ArrayDeque();
   private final List<PlanRequestAssembler.VillagerContext> subBatchBuffer = new ArrayList();
   private long bufferOpenedNanos = -1L;
   private final ConcurrentHashMap<UUID, CapturedVillager> captured = new ConcurrentHashMap();
   private final AtomicLong captureSequence = new AtomicLong(0L);
   private final Set<InferenceStreamHandle> inflightHandles = ConcurrentHashMap.newKeySet();
   private final AtomicLong overlayEpoch = new AtomicLong(0L);

   @Inject
   PlanRequestService(PlanRequestAssembler assembler, PlanGenerationContextFactory contextFactory, LlmOverlayPlanGenerator overlayGenerator, Lazy<PlanGateway> gateway, PlanInferenceConfig config, InferenceGate inferenceGate) {
      this.assembler = assembler;
      this.contextFactory = contextFactory;
      this.overlayGenerator = overlayGenerator;
      this.gateway = gateway;
      this.config = config;
      this.inferenceGate = inferenceGate;
   }

   public void enqueueForOverlay(@Nonnull BaseVillager villager, long dayTime, long wakeAtAbsoluteTick) {
      if (this.inferenceGate.isEnabled()) {
         if (this.config.resolvedMode() == PlanInferenceMode.LLM) {
            if (!isTargetDayPastCutoff(dayTime, wakeAtAbsoluteTick, this.config.overlayCutoffCivilTick())) {
               if (!this.captured.containsKey(villager.m_20148_())) {
                  this.drainCursor.add(new OverlayRequest(villager, wakeAtAbsoluteTick));
               }
            }
         }
      }
   }

   @VisibleForTesting
   static boolean isTargetDayPastCutoff(long dayTime, long wakeAtAbsoluteTick, int cutoffCivilTick) {
      long targetCalendarDay = WorldCalendar.calendarDayOf(wakeAtAbsoluteTick);
      return WorldCalendar.civilOffsetWithin(targetCalendarDay, dayTime) > cutoffCivilTick;
   }

   public void pumpAssembly(long nowNanos) {
      if (!this.drainCursor.isEmpty() || !this.subBatchBuffer.isEmpty()) {
         long epoch = this.overlayEpoch.get();
         int subBatchSize = this.config.subBatchSize();
         long windowNanos = TimeUnit.SECONDS.toNanos((long)this.config.subBatchWindowSeconds());

         for(int i = 0; i < 8 && !this.drainCursor.isEmpty(); ++i) {
            this.assembleOne((OverlayRequest)this.drainCursor.poll(), nowNanos);
            if (shouldFlush(this.subBatchBuffer.size(), subBatchSize, nowNanos, this.bufferOpenedNanos, windowNanos)) {
               this.flush(epoch);
            }
         }

         if (shouldFlush(this.subBatchBuffer.size(), subBatchSize, nowNanos, this.bufferOpenedNanos, windowNanos)) {
            this.flush(epoch);
         }

      }
   }

   private void assembleOne(@Nonnull OverlayRequest request, long nowNanos) {
      BaseVillager villager = request.villager();
      if (villager.m_6084_() && !villager.m_213877_()) {
         PlanGenerationContext context = this.contextFactory.create(villager, request.wakeAtAbsoluteTick());
         this.captureVillager(villager.m_20148_(), villager.getPlanRuntimeState(), context);
         if (this.subBatchBuffer.isEmpty()) {
            this.bufferOpenedNanos = nowNanos;
         }

         this.subBatchBuffer.add(new PlanRequestAssembler.VillagerContext(villager, context));
      }
   }

   @VisibleForTesting
   long captureVillager(@Nonnull UUID villagerId, @Nonnull PlanRuntimeState runtime, @Nonnull PlanGenerationContext context) {
      long captureId = this.captureSequence.getAndIncrement();
      this.captured.put(villagerId, new CapturedVillager(captureId, runtime, context));
      return captureId;
   }

   private void flush(long epoch) {
      if (!this.subBatchBuffer.isEmpty()) {
         List<PlanRequestAssembler.VillagerContext> batch = List.copyOf(this.subBatchBuffer);
         this.subBatchBuffer.clear();
         this.bufferOpenedNanos = -1L;
         Map<UUID, Long> ownedCaptures = new HashMap();

         for(PlanRequestAssembler.VillagerContext entry : batch) {
            UUID villagerId = entry.villager().m_20148_();
            CapturedVillager capture = (CapturedVillager)this.captured.get(villagerId);
            if (capture != null) {
               ownedCaptures.put(villagerId, capture.captureId());
            }
         }

         PlanBatchRequest request = this.assembler.assemble(batch);
         Duration deadline = Duration.ofSeconds((long)this.config.overlayDeadlineSeconds());
         InferenceStreamHandle handle = ((PlanGateway)this.gateway.get()).generate(request, deadline, (result) -> this.onVillager(epoch, result));
         this.registerInflightHandle(handle, ownedCaptures);
         log.debug("PLAN overlay sub-batch flushed (epoch {}): {} villager(s)", epoch, batch.size());
      }
   }

   @VisibleForTesting
   void registerInflightHandle(@Nonnull InferenceStreamHandle handle, @Nonnull Map<UUID, Long> ownedCaptures) {
      this.inflightHandles.add(handle);
      handle.completion().thenRun(() -> {
         this.inflightHandles.remove(handle);
         ownedCaptures.forEach((villagerId, ownedCaptureId) -> this.captured.computeIfPresent(villagerId, (id, capture) -> capture.captureId() == ownedCaptureId ? null : capture));
      });
   }

   @VisibleForTesting
   void onVillager(long epoch, @Nonnull VillagerPlanResult result) {
      if (epoch == this.overlayEpoch.get()) {
         CapturedVillager entry = (CapturedVillager)this.captured.remove(result.getVillagerId());
         if (entry != null) {
            DayPlan plan = this.overlayGenerator.generate(entry.context(), result);
            entry.runtime().getPendingArrivals().offer(new PlanArrival(plan, PlanAuthor.LLM));
         }
      }
   }

   public long cancelAll() {
      long epoch = this.overlayEpoch.incrementAndGet();

      for(InferenceStreamHandle handle : this.inflightHandles) {
         handle.cancel();
      }

      this.inflightHandles.clear();
      this.drainCursor.clear();
      this.subBatchBuffer.clear();
      this.bufferOpenedNanos = -1L;
      this.captured.clear();
      return epoch;
   }

   @VisibleForTesting
   static boolean shouldFlush(int bufferSize, int subBatchSize, long nowNanos, long bufferOpenedNanos, long windowNanos) {
      if (bufferSize <= 0) {
         return false;
      } else if (bufferSize >= subBatchSize) {
         return true;
      } else {
         return nowNanos - bufferOpenedNanos >= windowNanos;
      }
   }

   private static record OverlayRequest(BaseVillager villager, long wakeAtAbsoluteTick) {
   }

   private static record CapturedVillager(long captureId, PlanRuntimeState runtime, PlanGenerationContext context) {
   }
}
