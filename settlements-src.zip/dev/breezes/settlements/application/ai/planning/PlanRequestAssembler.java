package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.application.ai.inference.monologue.EpisodicEntryAssembler;
import dev.breezes.settlements.application.ai.inference.monologue.EpisodicEntryDTO;
import dev.breezes.settlements.application.ai.inference.monologue.PersonaBundleAssembler;
import dev.breezes.settlements.application.ai.inference.monologue.SnapshotAssembler;
import dev.breezes.settlements.application.ai.inference.plan.BehaviorOptionDTO;
import dev.breezes.settlements.application.ai.inference.plan.DemandDTO;
import dev.breezes.settlements.application.ai.inference.plan.PlanBatchRequest;
import dev.breezes.settlements.application.ai.inference.plan.PlanWindowDTO;
import dev.breezes.settlements.application.ai.inference.plan.SurplusDTO;
import dev.breezes.settlements.application.ai.inference.plan.VillagerPlanRequest;
import dev.breezes.settlements.application.economy.VillagerWallet;
import dev.breezes.settlements.application.economy.demand.ActiveDemand;
import dev.breezes.settlements.application.economy.demand.DemandEvaluator;
import dev.breezes.settlements.application.economy.supply.ActiveSupply;
import dev.breezes.settlements.application.economy.supply.SupplyEvaluator;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.catalog.WeightedBehavior;
import dev.breezes.settlements.domain.ai.planning.PlanGenerationContext;
import dev.breezes.settlements.domain.ai.schedule.PlanDayType;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.economy.catalog.OfferEntry;
import dev.breezes.settlements.domain.economy.catalog.TradeCatalogRegistry;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.domain.inventory.BackpackEntry;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.registries.BuiltInRegistries;

@ServerScope
public final class PlanRequestAssembler {
   private final PersonaBundleAssembler personaBundleAssembler;
   private final SnapshotAssembler snapshotAssembler;
   private final EpisodicEntryAssembler episodicEntryAssembler;
   private final DemandEvaluator demandEvaluator;
   private final SupplyEvaluator supplyEvaluator;
   private final VillagerWallet villagerWallet;
   private final TradeCatalogRegistry tradeCatalogRegistry;
   private final DayPlanComposer composer;

   public PlanBatchRequest assemble(@Nonnull List<VillagerContext> villagersWithContexts) {
      PlanBatchRequest.PlanBatchRequestBuilder builder = PlanBatchRequest.builder();

      for(VillagerContext entry : villagersWithContexts) {
         builder.villager(this.buildVillagerRequest(entry.villager(), entry.context()));
      }

      return builder.build();
   }

   public VillagerPlanRequest buildVillagerRequest(@Nonnull BaseVillager villager, @Nonnull PlanGenerationContext context) {
      VillagerPlanRequest.VillagerPlanRequestBuilder requestBuilder = VillagerPlanRequest.builder().villagerId(villager.m_20148_()).persona(this.personaBundleAssembler.assemble(villager)).snapshot(this.snapshotAssembler.assemble(villager)).dayType(context.dayType().name()).wallet(Map.of("emeralds", this.villagerWallet.getBalance(villager))).hunger(villager.getHunger()).inventory(this.buildInventory(villager));
      List<EpisodicEntryDTO> episodic = this.episodicEntryAssembler.assemble(villager.m_20148_(), villager.getKnowledgeStore(), villager.m_9236_().m_46467_());
      Objects.requireNonNull(requestBuilder);
      episodic.forEach(requestBuilder::episodic);
      List var10000 = this.buildOptions(context);
      Objects.requireNonNull(requestBuilder);
      var10000.forEach(requestBuilder::option);
      var10000 = this.buildWindows(context);
      Objects.requireNonNull(requestBuilder);
      var10000.forEach(requestBuilder::window);
      var10000 = this.buildDemands(villager);
      Objects.requireNonNull(requestBuilder);
      var10000.forEach(requestBuilder::demand);
      var10000 = this.buildSurplus(villager);
      Objects.requireNonNull(requestBuilder);
      var10000.forEach(requestBuilder::surplus);
      return requestBuilder.build();
   }

   private List<BehaviorOptionDTO> buildOptions(PlanGenerationContext context) {
      boolean restrictToRestDayMenu = context.dayType() == PlanDayType.REST_DAY || context.profession().equals(VillagerProfessionKey.NITWIT);
      List<BehaviorOptionDTO> options = new ArrayList();

      for(WeightedBehavior behavior : context.availableBehaviors()) {
         if (!restrictToRestDayMenu || !(PlannerPolicy.restDayMultiplier(behavior.descriptor(), context.restDayPolicy()) <= (double)0.0F)) {
            options.add(BehaviorOptionDTO.builder().id(behavior.key().id()).description(behavior.descriptor().getDescription()).category(behavior.descriptor().getCategory().name()).intensity(behavior.descriptor().getIntensity().name()).estimatedMinutes(behavior.descriptor().getEstimatedDuration().getAsGameMinutes()).hasOpportunity(!context.behaviorsLackingOpportunity().contains(behavior.key())).build());
         }
      }

      return options;
   }

   private List<PlanWindowDTO> buildWindows(PlanGenerationContext context) {
      List<PlanWindowDTO> windows = new ArrayList();

      for(PlanBand band : this.composer.bands(context)) {
         windows.add(PlanWindowDTO.builder().id(band.id()).startTick(band.startCivil()).endTick(band.endCivil()).build());
      }

      return windows;
   }

   private List<DemandDTO> buildDemands(BaseVillager villager) {
      List<DemandDTO> demands = new ArrayList();

      for(ActiveDemand demand : this.demandEvaluator.resolve(villager)) {
         demands.add(DemandDTO.builder().token(matchToken(demand.match())).shortfall(demand.desiredCount()).priority(demand.priority()).build());
      }

      return demands;
   }

   private List<SurplusDTO> buildSurplus(BaseVillager villager) {
      Map<String, Integer> dumpableByToken = new LinkedHashMap();

      for(ActiveSupply supply : this.supplyEvaluator.resolve(villager)) {
         dumpableByToken.merge(matchToken(supply.match()), supply.dumpableCount(), Integer::sum);
      }

      Map<String, Integer> sellableByToken = new LinkedHashMap();

      for(OfferEntry offer : this.tradeCatalogRegistry.offersFor(villager.getProfession())) {
         int held = villager.getSettlementsInventory().countMatching(offer.match());
         int sellable = Math.max(held - offer.surplusThreshold(), 0);
         sellableByToken.merge(matchToken(offer.match()), sellable, Integer::sum);
      }

      Set<String> tokens = new LinkedHashSet(dumpableByToken.keySet());
      tokens.addAll(sellableByToken.keySet());
      List<SurplusDTO> surplus = new ArrayList();

      for(String token : tokens) {
         int dumpable = (Integer)dumpableByToken.getOrDefault(token, 0);
         int sellable = (Integer)sellableByToken.getOrDefault(token, 0);
         if (sellable > 0 || dumpable > 0) {
            surplus.add(SurplusDTO.builder().token(token).sellable(sellable).dumpable(dumpable).build());
         }
      }

      return surplus;
   }

   private Map<String, Integer> buildInventory(BaseVillager villager) {
      Map<String, Integer> inventory = new LinkedHashMap();

      for(BackpackEntry entry : villager.getSettlementsInventory().entries()) {
         String key = BuiltInRegistries.f_257033_.m_7981_(entry.representative().m_41720_()).toString();
         inventory.merge(key, entry.count(), Integer::sum);
      }

      return inventory;
   }

   private static String matchToken(ItemMatch match) {
      if (match instanceof ItemMatch.ItemRef itemRef) {
         return itemRef.id().toString();
      } else if (match instanceof ItemMatch.TagRef tagRef) {
         return tagRef.tag().f_203868_().toString();
      } else {
         throw new IllegalArgumentException("Unknown ItemMatch: " + String.valueOf(match));
      }
   }

   @Inject
   @Generated
   PlanRequestAssembler(PersonaBundleAssembler personaBundleAssembler, SnapshotAssembler snapshotAssembler, EpisodicEntryAssembler episodicEntryAssembler, DemandEvaluator demandEvaluator, SupplyEvaluator supplyEvaluator, VillagerWallet villagerWallet, TradeCatalogRegistry tradeCatalogRegistry, DayPlanComposer composer) {
      this.personaBundleAssembler = personaBundleAssembler;
      this.snapshotAssembler = snapshotAssembler;
      this.episodicEntryAssembler = episodicEntryAssembler;
      this.demandEvaluator = demandEvaluator;
      this.supplyEvaluator = supplyEvaluator;
      this.villagerWallet = villagerWallet;
      this.tradeCatalogRegistry = tradeCatalogRegistry;
      this.composer = composer;
   }

   public static record VillagerContext(BaseVillager villager, PlanGenerationContext context) {
   }
}
