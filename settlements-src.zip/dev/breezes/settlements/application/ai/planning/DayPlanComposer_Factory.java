package dev.breezes.settlements.application.ai.planning;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.List;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class DayPlanComposer_Factory implements Factory<DayPlanComposer> {
   private final Provider<List<MealAnchorRule>> mealAnchorTableProvider;

   private DayPlanComposer_Factory(Provider<List<MealAnchorRule>> mealAnchorTableProvider) {
      this.mealAnchorTableProvider = mealAnchorTableProvider;
   }

   public DayPlanComposer get() {
      return newInstance((List)this.mealAnchorTableProvider.get());
   }

   public static DayPlanComposer_Factory create(Provider<List<MealAnchorRule>> mealAnchorTableProvider) {
      return new DayPlanComposer_Factory(mealAnchorTableProvider);
   }

   public static DayPlanComposer newInstance(List<MealAnchorRule> mealAnchorTable) {
      return new DayPlanComposer(mealAnchorTable);
   }
}
