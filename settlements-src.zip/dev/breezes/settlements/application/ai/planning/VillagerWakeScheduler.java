package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.planning.IWakeTickResolver;
import dev.breezes.settlements.domain.ai.schedule.IWeekCycleProvider;
import dev.breezes.settlements.domain.ai.schedule.PlanDayType;
import dev.breezes.settlements.domain.ai.schedule.ScheduleProfile;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.domain.world.WorldCalendar;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import javax.annotation.Nonnull;
import lombok.Generated;

@ServerScope
public class VillagerWakeScheduler {
   private final IWeekCycleProvider weekCycleProvider;
   private final IWakeTickResolver wakeTickResolver;

   public long wakeAbsoluteTickFor(@Nonnull BaseVillager villager, long calendarDay) {
      int wakeTickInMcDay = this.wakeTickFor(villager, calendarDay);
      return WorldCalendar.absoluteTickFor(calendarDay, wakeTickInMcDay);
   }

   public long nextWakeAtAbsoluteTick(@Nonnull BaseVillager villager, long dayTime, long currentWakeAtAbsoluteTick) {
      long currentCalendarDay = WorldCalendar.calendarDayOf(dayTime);
      long todayWake = this.wakeAbsoluteTickFor(villager, currentCalendarDay);
      return todayWake > currentWakeAtAbsoluteTick ? todayWake : this.wakeAbsoluteTickFor(villager, currentCalendarDay + 1L);
   }

   private int wakeTickFor(@Nonnull BaseVillager villager, long calendarDay) {
      VillagerProfessionKey professionKey = villager.getProfession();
      ScheduleProfile scheduleProfile = ScheduleProfile.defaultFor(professionKey);
      PlanDayType dayType = this.weekCycleProvider.getDayType(calendarDay);
      return this.wakeTickResolver.resolveWakeTick(scheduleProfile, dayType, PlanGenerationContextFactory.chronotypeSeedFor(villager));
   }

   @Inject
   @Generated
   VillagerWakeScheduler(IWeekCycleProvider weekCycleProvider, IWakeTickResolver wakeTickResolver) {
      this.weekCycleProvider = weekCycleProvider;
      this.wakeTickResolver = wakeTickResolver;
   }
}
