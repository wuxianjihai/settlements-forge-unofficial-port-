package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public final class WeightedRandomSelectionStrategy implements SlotSelectionStrategy {
   public WindowPacker.PackingCandidate select(List<WindowPacker.PackingCandidate> eligible, Set<BehaviorKey> emittedKeys, Random random) {
      List<WindowPacker.PackingCandidate> fresh = eligible.stream().filter((c) -> !emittedKeys.contains(c.key())).toList();
      List<WindowPacker.PackingCandidate> pool = fresh.isEmpty() ? eligible : fresh;
      Map<WindowPacker.PackingCandidate, Double> weightMap = new LinkedHashMap();

      for(WindowPacker.PackingCandidate candidate : pool) {
         weightMap.put(candidate, candidate.weight());
      }

      return (WindowPacker.PackingCandidate)RandomUtil.weightedChoice(weightMap, random);
   }
}
