package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.domain.ai.catalog.BehaviorCategory;
import dev.breezes.settlements.domain.ai.catalog.BehaviorPlanningMetadata;
import dev.breezes.settlements.domain.ai.catalog.WeightedBehavior;
import dev.breezes.settlements.domain.ai.catalog.WorkIntensity;
import dev.breezes.settlements.domain.ai.planning.PlanGenerationContext;
import dev.breezes.settlements.domain.ai.schedule.RestDayPolicy;
import dev.breezes.settlements.domain.genetics.GeneType;
import dev.breezes.settlements.domain.genetics.GeneticsProfile;
import java.util.ArrayList;
import java.util.List;
import lombok.Generated;

public final class PlannerPolicy {
   public static final double LOW_OPPORTUNITY_MULTIPLIER = 0.2;
   public static final EffectiveWeightMultiplier DEFAULT_EFFECTIVE_WEIGHT_MULTIPLIER = (behavior) -> (double)1.0F;

   public static double restDayMultiplier(BehaviorPlanningMetadata behavior, RestDayPolicy policy) {
      if (behavior.getCategory() == BehaviorCategory.SOCIAL) {
         return (double)policy.socialMultiplier();
      } else if (behavior.getCategory() == BehaviorCategory.SELF_CARE) {
         return (double)policy.selfCareMultiplier();
      } else if (behavior.getCategory() == BehaviorCategory.LEISURE) {
         return (double)policy.leisureMultiplier();
      } else if (behavior.getCategory() == BehaviorCategory.WORK && behavior.getIntensity() == WorkIntensity.LIGHT) {
         return (double)policy.lightWorkMultiplier();
      } else {
         return behavior.getCategory() == BehaviorCategory.WORK && behavior.getIntensity() == WorkIntensity.HEAVY ? (double)policy.heavyWorkMultiplier() : (double)0.0F;
      }
   }

   public static EffectiveWeightMultiplier opportunityMultiplier(PlanGenerationContext context) {
      return (behavior) -> context.behaviorsLackingOpportunity().contains(behavior.key()) ? 0.2 : (double)1.0F;
   }

   @Generated
   private PlannerPolicy() {
   }

   @FunctionalInterface
   public interface EffectiveWeightMultiplier {
      double apply(WeightedBehavior var1);

      default EffectiveWeightMultiplier andThen(EffectiveWeightMultiplier other) {
         return (behavior) -> this.apply(behavior) * other.apply(behavior);
      }
   }

   public static record PlannerPalette(List<WeightedBehavior> availableBehaviors) {
      public List<WeightedBehavior> workBehaviors() {
         return this.availableBehaviors.stream().filter((behavior) -> behavior.descriptor().getCategory() == BehaviorCategory.WORK).toList();
      }

      public List<WeightedBehavior> afternoonCandidates(GeneticsProfile genetics) {
         boolean socialPreference = genetics.getGeneValue(GeneType.CHARISMA) >= 0.45;
         List<WeightedBehavior> social = this.byCategory(BehaviorCategory.SOCIAL);
         List<WeightedBehavior> selfCare = this.byCategory(BehaviorCategory.SELF_CARE);
         List<WeightedBehavior> leisure = this.byCategory(BehaviorCategory.LEISURE);
         List<WeightedBehavior> lightWork = this.workBehaviors().stream().filter((behavior) -> behavior.descriptor().getIntensity() == WorkIntensity.LIGHT).toList();
         List<WeightedBehavior> candidates = new ArrayList();
         if (socialPreference) {
            candidates.addAll(social);
         }

         candidates.addAll(lightWork);
         candidates.addAll(selfCare);
         candidates.addAll(leisure);
         if (!socialPreference) {
            candidates.addAll(social);
         }

         return candidates;
      }

      public List<WeightedBehavior> eveningCandidates() {
         List<WeightedBehavior> candidates = new ArrayList();
         candidates.addAll(this.byCategory(BehaviorCategory.SOCIAL));
         candidates.addAll(this.byCategory(BehaviorCategory.LEISURE));
         candidates.addAll(this.byCategory(BehaviorCategory.SELF_CARE));
         return candidates;
      }

      private List<WeightedBehavior> byCategory(BehaviorCategory category) {
         return this.availableBehaviors.stream().filter((behavior) -> behavior.descriptor().getCategory() == category).toList();
      }
   }
}
