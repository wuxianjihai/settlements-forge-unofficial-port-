package dev.breezes.settlements.application.ai.planning;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class WakeTickResolver_Factory implements Factory<WakeTickResolver> {
   public WakeTickResolver get() {
      return newInstance();
   }

   public static WakeTickResolver_Factory create() {
      return WakeTickResolver_Factory.InstanceHolder.INSTANCE;
   }

   public static WakeTickResolver newInstance() {
      return new WakeTickResolver();
   }

   private static final class InstanceHolder {
      static final WakeTickResolver_Factory INSTANCE = new WakeTickResolver_Factory();
   }
}
