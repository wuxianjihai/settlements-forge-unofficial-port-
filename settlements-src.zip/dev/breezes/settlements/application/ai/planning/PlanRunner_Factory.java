package dev.breezes.settlements.application.ai.planning;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.behavior.publication.BehaviorOutcomePublisher;
import dev.breezes.settlements.domain.ai.catalog.IBehaviorCatalog;
import dev.breezes.settlements.domain.ai.planning.IAsyncPlanGenerator;
import dev.breezes.settlements.domain.ai.planning.IPlanGenerator;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventEmitter;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class PlanRunner_Factory implements Factory<PlanRunner> {
   private final Provider<IBehaviorCatalog> catalogProvider;
   private final Provider<PlanGenerationContextFactory> planGenerationContextFactoryProvider;
   private final Provider<IPlanGenerator> planGeneratorProvider;
   private final Provider<IAsyncPlanGenerator> asyncPlanGeneratorProvider;
   private final Provider<VillagerWakeScheduler> wakeSchedulerProvider;
   private final Provider<MinimalPlanFactory> minimalPlanFactoryProvider;
   private final Provider<BehaviorOutcomePublisher> behaviorOutcomePublisherProvider;
   private final Provider<WorldEventEmitter> worldEventEmitterProvider;
   private final Provider<PlanRequestService> planRequestServiceProvider;

   private PlanRunner_Factory(Provider<IBehaviorCatalog> catalogProvider, Provider<PlanGenerationContextFactory> planGenerationContextFactoryProvider, Provider<IPlanGenerator> planGeneratorProvider, Provider<IAsyncPlanGenerator> asyncPlanGeneratorProvider, Provider<VillagerWakeScheduler> wakeSchedulerProvider, Provider<MinimalPlanFactory> minimalPlanFactoryProvider, Provider<BehaviorOutcomePublisher> behaviorOutcomePublisherProvider, Provider<WorldEventEmitter> worldEventEmitterProvider, Provider<PlanRequestService> planRequestServiceProvider) {
      this.catalogProvider = catalogProvider;
      this.planGenerationContextFactoryProvider = planGenerationContextFactoryProvider;
      this.planGeneratorProvider = planGeneratorProvider;
      this.asyncPlanGeneratorProvider = asyncPlanGeneratorProvider;
      this.wakeSchedulerProvider = wakeSchedulerProvider;
      this.minimalPlanFactoryProvider = minimalPlanFactoryProvider;
      this.behaviorOutcomePublisherProvider = behaviorOutcomePublisherProvider;
      this.worldEventEmitterProvider = worldEventEmitterProvider;
      this.planRequestServiceProvider = planRequestServiceProvider;
   }

   public PlanRunner get() {
      return newInstance((IBehaviorCatalog)this.catalogProvider.get(), (PlanGenerationContextFactory)this.planGenerationContextFactoryProvider.get(), (IPlanGenerator)this.planGeneratorProvider.get(), (IAsyncPlanGenerator)this.asyncPlanGeneratorProvider.get(), (VillagerWakeScheduler)this.wakeSchedulerProvider.get(), (MinimalPlanFactory)this.minimalPlanFactoryProvider.get(), (BehaviorOutcomePublisher)this.behaviorOutcomePublisherProvider.get(), (WorldEventEmitter)this.worldEventEmitterProvider.get(), (PlanRequestService)this.planRequestServiceProvider.get());
   }

   public static PlanRunner_Factory create(Provider<IBehaviorCatalog> catalogProvider, Provider<PlanGenerationContextFactory> planGenerationContextFactoryProvider, Provider<IPlanGenerator> planGeneratorProvider, Provider<IAsyncPlanGenerator> asyncPlanGeneratorProvider, Provider<VillagerWakeScheduler> wakeSchedulerProvider, Provider<MinimalPlanFactory> minimalPlanFactoryProvider, Provider<BehaviorOutcomePublisher> behaviorOutcomePublisherProvider, Provider<WorldEventEmitter> worldEventEmitterProvider, Provider<PlanRequestService> planRequestServiceProvider) {
      return new PlanRunner_Factory(catalogProvider, planGenerationContextFactoryProvider, planGeneratorProvider, asyncPlanGeneratorProvider, wakeSchedulerProvider, minimalPlanFactoryProvider, behaviorOutcomePublisherProvider, worldEventEmitterProvider, planRequestServiceProvider);
   }

   public static PlanRunner newInstance(IBehaviorCatalog catalog, PlanGenerationContextFactory planGenerationContextFactory, IPlanGenerator planGenerator, IAsyncPlanGenerator asyncPlanGenerator, VillagerWakeScheduler wakeScheduler, MinimalPlanFactory minimalPlanFactory, BehaviorOutcomePublisher behaviorOutcomePublisher, WorldEventEmitter worldEventEmitter, PlanRequestService planRequestService) {
      return new PlanRunner(catalog, planGenerationContextFactory, planGenerator, asyncPlanGenerator, wakeScheduler, minimalPlanFactory, behaviorOutcomePublisher, worldEventEmitter, planRequestService);
   }
}
