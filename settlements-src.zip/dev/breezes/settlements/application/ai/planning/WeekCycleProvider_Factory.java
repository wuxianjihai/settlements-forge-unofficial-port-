package dev.breezes.settlements.application.ai.planning;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class WeekCycleProvider_Factory implements Factory<WeekCycleProvider> {
   public WeekCycleProvider get() {
      return newInstance();
   }

   public static WeekCycleProvider_Factory create() {
      return WeekCycleProvider_Factory.InstanceHolder.INSTANCE;
   }

   public static WeekCycleProvider newInstance() {
      return new WeekCycleProvider();
   }

   private static final class InstanceHolder {
      static final WeekCycleProvider_Factory INSTANCE = new WeekCycleProvider_Factory();
   }
}
