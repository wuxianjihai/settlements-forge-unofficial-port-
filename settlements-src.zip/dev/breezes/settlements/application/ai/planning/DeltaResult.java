package dev.breezes.settlements.application.ai.planning;

import lombok.Generated;

public record DeltaResult(int deltaTicks, boolean backwardJump, boolean firstTick, long rawDelta, long previousDayTime) {
   @Generated
   public static DeltaResultBuilder builder() {
      return new DeltaResultBuilder();
   }

   @Generated
   public static class DeltaResultBuilder {
      @Generated
      private int deltaTicks;
      @Generated
      private boolean backwardJump;
      @Generated
      private boolean firstTick;
      @Generated
      private long rawDelta;
      @Generated
      private long previousDayTime;

      @Generated
      DeltaResultBuilder() {
      }

      @Generated
      public DeltaResultBuilder deltaTicks(int deltaTicks) {
         this.deltaTicks = deltaTicks;
         return this;
      }

      @Generated
      public DeltaResultBuilder backwardJump(boolean backwardJump) {
         this.backwardJump = backwardJump;
         return this;
      }

      @Generated
      public DeltaResultBuilder firstTick(boolean firstTick) {
         this.firstTick = firstTick;
         return this;
      }

      @Generated
      public DeltaResultBuilder rawDelta(long rawDelta) {
         this.rawDelta = rawDelta;
         return this;
      }

      @Generated
      public DeltaResultBuilder previousDayTime(long previousDayTime) {
         this.previousDayTime = previousDayTime;
         return this;
      }

      @Generated
      public DeltaResult build() {
         return new DeltaResult(this.deltaTicks, this.backwardJump, this.firstTick, this.rawDelta, this.previousDayTime);
      }

      @Generated
      public String toString() {
         return "DeltaResult.DeltaResultBuilder(deltaTicks=" + this.deltaTicks + ", backwardJump=" + this.backwardJump + ", firstTick=" + this.firstTick + ", rawDelta=" + this.rawDelta + ", previousDayTime=" + this.previousDayTime + ")";
      }
   }
}
