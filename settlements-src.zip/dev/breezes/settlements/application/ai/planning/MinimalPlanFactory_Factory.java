package dev.breezes.settlements.application.ai.planning;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.domain.ai.schedule.IWeekCycleProvider;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class MinimalPlanFactory_Factory implements Factory<MinimalPlanFactory> {
   private final Provider<IWeekCycleProvider> weekCycleProvider;

   private MinimalPlanFactory_Factory(Provider<IWeekCycleProvider> weekCycleProvider) {
      this.weekCycleProvider = weekCycleProvider;
   }

   public MinimalPlanFactory get() {
      return newInstance((IWeekCycleProvider)this.weekCycleProvider.get());
   }

   public static MinimalPlanFactory_Factory create(Provider<IWeekCycleProvider> weekCycleProvider) {
      return new MinimalPlanFactory_Factory(weekCycleProvider);
   }

   public static MinimalPlanFactory newInstance(IWeekCycleProvider weekCycleProvider) {
      return new MinimalPlanFactory(weekCycleProvider);
   }
}
