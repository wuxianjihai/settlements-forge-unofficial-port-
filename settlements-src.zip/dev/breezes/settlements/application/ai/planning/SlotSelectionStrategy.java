package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import java.util.List;
import java.util.Random;
import java.util.Set;

@FunctionalInterface
public interface SlotSelectionStrategy {
   WindowPacker.PackingCandidate select(List<WindowPacker.PackingCandidate> var1, Set<BehaviorKey> var2, Random var3);
}
