package dev.breezes.settlements.application.ai.planning;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.domain.ai.planning.IPlanGenerator;
import java.util.concurrent.ExecutorService;

@ScopeMetadata
@QualifierMetadata({"dev.breezes.settlements.di.PlanGenerationExecutor"})
@DaggerGenerated
public final class HeuristicAsyncPlanGenerator_Factory implements Factory<HeuristicAsyncPlanGenerator> {
   private final Provider<IPlanGenerator> planGeneratorProvider;
   private final Provider<ExecutorService> planGenerationExecutorProvider;

   private HeuristicAsyncPlanGenerator_Factory(Provider<IPlanGenerator> planGeneratorProvider, Provider<ExecutorService> planGenerationExecutorProvider) {
      this.planGeneratorProvider = planGeneratorProvider;
      this.planGenerationExecutorProvider = planGenerationExecutorProvider;
   }

   public HeuristicAsyncPlanGenerator get() {
      return newInstance((IPlanGenerator)this.planGeneratorProvider.get(), (ExecutorService)this.planGenerationExecutorProvider.get());
   }

   public static HeuristicAsyncPlanGenerator_Factory create(Provider<IPlanGenerator> planGeneratorProvider, Provider<ExecutorService> planGenerationExecutorProvider) {
      return new HeuristicAsyncPlanGenerator_Factory(planGeneratorProvider, planGenerationExecutorProvider);
   }

   public static HeuristicAsyncPlanGenerator newInstance(IPlanGenerator planGenerator, ExecutorService planGenerationExecutor) {
      return new HeuristicAsyncPlanGenerator(planGenerator, planGenerationExecutor);
   }
}
