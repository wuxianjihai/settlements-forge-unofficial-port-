package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.domain.ai.planning.Chronotype;
import dev.breezes.settlements.domain.ai.planning.IWakeTickResolver;
import dev.breezes.settlements.domain.ai.schedule.PlanDayType;
import dev.breezes.settlements.domain.ai.schedule.ScheduleProfile;
import dev.breezes.settlements.domain.time.GameTicks;
import jakarta.inject.Inject;
import javax.annotation.Nonnull;
import lombok.Generated;

public class WakeTickResolver implements IWakeTickResolver {
   public int resolveWakeTick(@Nonnull ScheduleProfile profile, @Nonnull PlanDayType dayType, long seed) {
      int wakeTick = profile.defaultWakeTick();
      if (dayType == PlanDayType.REST_DAY) {
         wakeTick += GameTicks.hours((double)1.0F).getTicksAsInt();
      }

      wakeTick += Chronotype.of(seed).wakeSleepOffsetTicks();
      return Math.floorMod(wakeTick, 24000);
   }

   @Inject
   @Generated
   WakeTickResolver() {
   }
}
