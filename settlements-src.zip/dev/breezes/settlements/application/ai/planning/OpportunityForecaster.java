package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.application.ai.memory.SensedSiteReader;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.catalog.WeightedBehavior;
import dev.breezes.settlements.domain.ai.memory.MemoryType;
import dev.breezes.settlements.domain.ai.memory.SensedSites;
import dev.breezes.settlements.domain.ai.planning.OpportunityProbe;
import dev.breezes.settlements.domain.ai.planning.OpportunityRequirement;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;

@ServerScope
public class OpportunityForecaster {
   private final SensedSiteReader sensedSiteReader;

   public Set<BehaviorKey> forecastLackingOpportunity(BaseVillager villager, List<WeightedBehavior> pool) {
      SensedSites sensedSites = this.sensedSiteReader.read(villager.getSettlementsBrain());
      OpportunityProbe probe = buildProbe(villager, sensedSites);
      Set<BehaviorKey> lacking = new HashSet();

      for(WeightedBehavior behavior : pool) {
         Set<OpportunityRequirement> requirements = behavior.descriptor().getOpportunities();
         if (!requirements.isEmpty()) {
            for(OpportunityRequirement requirement : requirements) {
               if (!requirement.isAvailable(probe)) {
                  lacking.add(behavior.key());
                  break;
               }
            }
         }
      }

      return Set.copyOf(lacking);
   }

   private static OpportunityProbe buildProbe(final BaseVillager villager, final SensedSites sensedSites) {
      return new OpportunityProbe() {
         public boolean hasAnySite(Set<MemoryType<List<GlobalPos>>> memories) {
            for(MemoryType<List<GlobalPos>> type : memories) {
               if (sensedSites.isPresent(type)) {
                  return true;
               }
            }

            return false;
         }

         public boolean holdsAnyItem(Set<Item> items) {
            for(Item item : items) {
               if (villager.getSettlementsInventory().contains(item)) {
                  return true;
               }
            }

            return false;
         }

         public boolean hasJobSiteBlock(Block block) {
            Optional<GlobalPos> jobSite = villager.m_6274_().m_21952_(MemoryModuleType.f_26360_);
            if (jobSite.isEmpty()) {
               return false;
            } else {
               BlockPos jobSitePos = ((GlobalPos)jobSite.get()).m_122646_();
               if (!villager.m_9236_().m_46749_(jobSitePos)) {
                  return false;
               } else {
                  Location location = Location.of(jobSitePos, villager.m_9236_());
                  return (Boolean)location.getBlock().map((physicalBlock) -> physicalBlock.is(block)).orElse(false);
               }
            }
         }
      };
   }

   @Inject
   @Generated
   OpportunityForecaster(SensedSiteReader sensedSiteReader) {
      this.sensedSiteReader = sensedSiteReader;
   }
}
