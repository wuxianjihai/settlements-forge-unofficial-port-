package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public final class OrderedPreferenceSelectionStrategy implements SlotSelectionStrategy {
   private final Map<BehaviorKey, Integer> rank;

   public OrderedPreferenceSelectionStrategy(List<BehaviorKey> preferenceOrder) {
      Map<BehaviorKey, Integer> ranks = new HashMap();

      for(int i = 0; i < preferenceOrder.size(); ++i) {
         ranks.putIfAbsent((BehaviorKey)preferenceOrder.get(i), i);
      }

      this.rank = ranks;
   }

   public WindowPacker.PackingCandidate select(List<WindowPacker.PackingCandidate> eligible, Set<BehaviorKey> emittedKeys, Random random) {
      List<WindowPacker.PackingCandidate> fresh = eligible.stream().filter((c) -> !emittedKeys.contains(c.key())).toList();
      List<WindowPacker.PackingCandidate> pool = fresh.isEmpty() ? eligible : fresh;
      return (WindowPacker.PackingCandidate)pool.stream().min(Comparator.comparing(this::rankOf).thenComparing((c) -> c.key().id())).orElseThrow();
   }

   private int rankOf(WindowPacker.PackingCandidate candidate) {
      return (Integer)this.rank.getOrDefault(candidate.key(), Integer.MAX_VALUE);
   }
}
