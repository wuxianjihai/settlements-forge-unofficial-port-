package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.time.GameTicks;
import dev.breezes.settlements.domain.time.TimeOfDay;
import java.util.List;

public final class DefaultMealAnchorTable {
   public static List<MealAnchorRule> rows() {
      return List.of(MealAnchorRule.builder().anchorMode(MealAnchorRule.AnchorMode.WAKE_RELATIVE).behaviorKey(BehaviorKey.EAT_FOOD).priority(100).durationTicks(GameTicks.minutes((double)8.0F).getTicksAsInt()).authoredKeepProbability((double)1.0F).appliesChronotypeMealOffset(false).build(), MealAnchorRule.builder().anchorMode(MealAnchorRule.AnchorMode.FIXED).fixedTime(TimeOfDay.AT_11_00).behaviorKey(BehaviorKey.EAT_FOOD).priority(95).durationTicks(GameTicks.minutes((double)10.0F).getTicksAsInt()).authoredKeepProbability(0.95).appliesChronotypeMealOffset(true).build(), MealAnchorRule.builder().anchorMode(MealAnchorRule.AnchorMode.FIXED).fixedTime(TimeOfDay.AT_16_30).behaviorKey(BehaviorKey.EAT_FOOD).priority(90).durationTicks(GameTicks.minutes((double)10.0F).getTicksAsInt()).authoredKeepProbability(0.9).appliesChronotypeMealOffset(true).build());
   }
}
