package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.di.PlanGenerationExecutor;
import dev.breezes.settlements.domain.ai.planning.DayPlan;
import dev.breezes.settlements.domain.ai.planning.IAsyncPlanGenerator;
import dev.breezes.settlements.domain.ai.planning.IPlanGenerator;
import dev.breezes.settlements.domain.ai.planning.PlanGenerationContext;
import jakarta.inject.Inject;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import javax.annotation.Nonnull;
import lombok.Generated;

public class HeuristicAsyncPlanGenerator implements IAsyncPlanGenerator {
   private final IPlanGenerator planGenerator;
   @PlanGenerationExecutor
   private final ExecutorService planGenerationExecutor;

   public CompletableFuture<DayPlan> generateAsync(@Nonnull PlanGenerationContext context) {
      return CompletableFuture.supplyAsync(() -> this.planGenerator.generate(context), this.planGenerationExecutor);
   }

   @Inject
   @Generated
   HeuristicAsyncPlanGenerator(IPlanGenerator planGenerator, @PlanGenerationExecutor ExecutorService planGenerationExecutor) {
      this.planGenerator = planGenerator;
      this.planGenerationExecutor = planGenerationExecutor;
   }
}
