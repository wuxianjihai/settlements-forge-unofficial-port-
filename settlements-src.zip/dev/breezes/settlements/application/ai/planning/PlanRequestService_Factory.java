package dev.breezes.settlements.application.ai.planning;

import dagger.Lazy;
import dagger.internal.DaggerGenerated;
import dagger.internal.DoubleCheck;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.inference.InferenceGate;
import dev.breezes.settlements.application.ai.inference.plan.PlanGateway;
import dev.breezes.settlements.application.ai.inference.plan.PlanInferenceConfig;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class PlanRequestService_Factory implements Factory<PlanRequestService> {
   private final Provider<PlanRequestAssembler> assemblerProvider;
   private final Provider<PlanGenerationContextFactory> contextFactoryProvider;
   private final Provider<LlmOverlayPlanGenerator> overlayGeneratorProvider;
   private final Provider<PlanGateway> gatewayProvider;
   private final Provider<PlanInferenceConfig> configProvider;
   private final Provider<InferenceGate> inferenceGateProvider;

   private PlanRequestService_Factory(Provider<PlanRequestAssembler> assemblerProvider, Provider<PlanGenerationContextFactory> contextFactoryProvider, Provider<LlmOverlayPlanGenerator> overlayGeneratorProvider, Provider<PlanGateway> gatewayProvider, Provider<PlanInferenceConfig> configProvider, Provider<InferenceGate> inferenceGateProvider) {
      this.assemblerProvider = assemblerProvider;
      this.contextFactoryProvider = contextFactoryProvider;
      this.overlayGeneratorProvider = overlayGeneratorProvider;
      this.gatewayProvider = gatewayProvider;
      this.configProvider = configProvider;
      this.inferenceGateProvider = inferenceGateProvider;
   }

   public PlanRequestService get() {
      return newInstance((PlanRequestAssembler)this.assemblerProvider.get(), (PlanGenerationContextFactory)this.contextFactoryProvider.get(), (LlmOverlayPlanGenerator)this.overlayGeneratorProvider.get(), DoubleCheck.lazy(this.gatewayProvider), (PlanInferenceConfig)this.configProvider.get(), (InferenceGate)this.inferenceGateProvider.get());
   }

   public static PlanRequestService_Factory create(Provider<PlanRequestAssembler> assemblerProvider, Provider<PlanGenerationContextFactory> contextFactoryProvider, Provider<LlmOverlayPlanGenerator> overlayGeneratorProvider, Provider<PlanGateway> gatewayProvider, Provider<PlanInferenceConfig> configProvider, Provider<InferenceGate> inferenceGateProvider) {
      return new PlanRequestService_Factory(assemblerProvider, contextFactoryProvider, overlayGeneratorProvider, gatewayProvider, configProvider, inferenceGateProvider);
   }

   public static PlanRequestService newInstance(PlanRequestAssembler assembler, PlanGenerationContextFactory contextFactory, LlmOverlayPlanGenerator overlayGenerator, Lazy<PlanGateway> gateway, PlanInferenceConfig config, InferenceGate inferenceGate) {
      return new PlanRequestService(assembler, contextFactory, overlayGenerator, gateway, config, inferenceGate);
   }
}
