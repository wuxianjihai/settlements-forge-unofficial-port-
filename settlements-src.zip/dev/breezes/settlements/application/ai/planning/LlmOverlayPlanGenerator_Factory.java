package dev.breezes.settlements.application.ai.planning;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class LlmOverlayPlanGenerator_Factory implements Factory<LlmOverlayPlanGenerator> {
   private final Provider<DayPlanComposer> composerProvider;

   private LlmOverlayPlanGenerator_Factory(Provider<DayPlanComposer> composerProvider) {
      this.composerProvider = composerProvider;
   }

   public LlmOverlayPlanGenerator get() {
      return newInstance((DayPlanComposer)this.composerProvider.get());
   }

   public static LlmOverlayPlanGenerator_Factory create(Provider<DayPlanComposer> composerProvider) {
      return new LlmOverlayPlanGenerator_Factory(composerProvider);
   }

   public static LlmOverlayPlanGenerator newInstance(DayPlanComposer composer) {
      return new LlmOverlayPlanGenerator(composer);
   }
}
