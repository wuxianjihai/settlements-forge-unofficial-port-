package dev.breezes.settlements.application.ai.planning;

import dev.breezes.settlements.domain.ai.catalog.WeightedBehavior;
import java.util.List;

public record PlanBand(String id, int startCivil, int endCivil, int basePriority, List<WeightedBehavior> pool, PlannerPolicy.EffectiveWeightMultiplier baseMultiplier, double packFactor) {
   public static final String MORNING = "MORNING";
   public static final String AFTERNOON = "AFTERNOON";
   public static final String EVENING = "EVENING";
}
