package dev.breezes.settlements.application.ai.sensors;

import dev.breezes.settlements.domain.world.blocks.BlockStateView;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.PalettedContainer;

final class SnapshotBlockStateView implements BlockStateView {
   private final Long2ObjectMap<PalettedContainer<BlockState>> sectionsByKey;

   @Nonnull
   public BlockState getBlockState(@Nonnull BlockPos pos) {
      int sectionX = SectionPos.m_123171_(pos.m_123341_());
      int sectionY = SectionPos.m_123171_(pos.m_123342_());
      int sectionZ = SectionPos.m_123171_(pos.m_123343_());
      long key = SectionPos.m_123209_(sectionX, sectionY, sectionZ);
      PalettedContainer<BlockState> container = (PalettedContainer)this.sectionsByKey.get(key);
      if (container == null) {
         return Blocks.f_50016_.m_49966_();
      } else {
         int lx = pos.m_123341_() & 15;
         int ly = pos.m_123342_() & 15;
         int lz = pos.m_123343_() & 15;
         return (BlockState)container.m_63087_(lx, ly, lz);
      }
   }

   @Generated
   public SnapshotBlockStateView(Long2ObjectMap<PalettedContainer<BlockState>> sectionsByKey) {
      this.sectionsByKey = sectionsByKey;
   }
}
