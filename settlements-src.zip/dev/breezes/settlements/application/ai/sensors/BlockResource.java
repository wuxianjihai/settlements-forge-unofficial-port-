package dev.breezes.settlements.application.ai.sensors;

import dev.breezes.settlements.domain.ai.memory.ConfirmedAbsenceRegion;
import dev.breezes.settlements.domain.ai.memory.IMemoryWrite;
import dev.breezes.settlements.domain.ai.memory.MemoryType;
import dev.breezes.settlements.domain.ai.memory.SensedSiteReport;
import dev.breezes.settlements.domain.ai.memory.SiteUpdateWrite;
import dev.breezes.settlements.domain.world.blocks.BlockMatcher;
import it.unimi.dsi.fastutil.longs.Long2LongOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongIterator;
import java.util.Optional;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;

public record BlockResource(@Nonnull BlockMatcher matcher, @Nonnull MemoryType.DecayingSpatialMemoryType memoryType) {
   public Optional<IMemoryWrite> toMemoryWrite(@Nonnull BlockResourceQueryResult result, @Nonnull BlockPos anchor, long nowTick, int scanRangeHorizontal, int scanRangeVertical) {
      Long2LongOpenHashMap presences = new Long2LongOpenHashMap(result.packedSites().size());
      LongIterator it = result.packedSites().iterator();

      while(it.hasNext()) {
         presences.put(it.nextLong(), nowTick);
      }

      ConfirmedAbsenceRegion region = result.complete() && !result.truncated() ? ConfirmedAbsenceRegion.ofScanBox(anchor.m_123341_(), anchor.m_123342_(), anchor.m_123343_(), scanRangeHorizontal, scanRangeVertical) : null;
      if (presences.isEmpty() && region == null) {
         return Optional.empty();
      } else {
         SensedSiteReport report = SensedSiteReport.builder().presences(presences).confirmedAbsenceRegion(region).build();
         return Optional.of(new SiteUpdateWrite(this.memoryType, report, nowTick));
      }
   }
}
