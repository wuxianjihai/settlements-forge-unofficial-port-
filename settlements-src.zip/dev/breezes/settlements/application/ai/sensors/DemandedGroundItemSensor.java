package dev.breezes.settlements.application.ai.sensors;

import dev.breezes.settlements.application.ai.behavior.usecases.villager.logistics.DemandedGroundItemCondition;
import dev.breezes.settlements.application.economy.demand.DemandEvaluator;
import dev.breezes.settlements.domain.ai.memory.IMemoryWrite;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.memory.MemoryWrite;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.Tickable;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.List;
import javax.annotation.Nonnull;
import net.minecraft.world.level.Level;

public final class DemandedGroundItemSensor extends AbstractSensor<BaseVillager> {
   private static final int COMPLETION_RANGE = 1;
   private final DemandedGroundItemCondition itemCondition;

   public DemandedGroundItemSensor(@Nonnull DemandedGroundItemSensorConfig config, @Nonnull DemandEvaluator demandEvaluator, @Nonnull BaseVillager villager) {
      super(List.of(), createStaggeredCooldown(config, villager));
      this.itemCondition = new DemandedGroundItemCondition(demandEvaluator, 1);
   }

   public List<IMemoryWrite> doSense(@Nonnull Level world, @Nonnull BaseVillager entity) {
      boolean resolved = this.itemCondition.test(entity);
      return List.of(resolved ? MemoryWrite.of(MemoryTypeRegistry.DEMANDED_GROUND_ITEM_NEARBY, true) : MemoryWrite.clear(MemoryTypeRegistry.DEMANDED_GROUND_ITEM_NEARBY));
   }

   private static Tickable createStaggeredCooldown(@Nonnull DemandedGroundItemSensorConfig config, @Nonnull BaseVillager villager) {
      ClockTicks scanInterval = ClockTicks.seconds((double)config.scanIntervalSeconds());
      int intervalTicks = Math.max(1, scanInterval.getTicksAsInt());
      int initialDelay = Math.floorMod(villager.m_20148_().hashCode(), intervalTicks);
      return new Tickable((double)intervalTicks, (double)initialDelay);
   }
}
