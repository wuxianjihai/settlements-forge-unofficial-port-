package dev.breezes.settlements.application.ai.sensors;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class WorldResourceIndex_Factory implements Factory<WorldResourceIndex> {
   public WorldResourceIndex get() {
      return newInstance();
   }

   public static WorldResourceIndex_Factory create() {
      return WorldResourceIndex_Factory.InstanceHolder.INSTANCE;
   }

   public static WorldResourceIndex newInstance() {
      return new WorldResourceIndex();
   }

   private static final class InstanceHolder {
      static final WorldResourceIndex_Factory INSTANCE = new WorldResourceIndex_Factory();
   }
}
