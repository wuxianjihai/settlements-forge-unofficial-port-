package dev.breezes.settlements.application.ai.sensors;

import dev.breezes.settlements.domain.ai.memory.IMemoryWrite;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.memory.MemoryWrite;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.domain.tags.SettlementsEntityTypeTags;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.Tickable;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.infrastructure.minecraft.mixins.AbstractArrowInvoker;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nonnull;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

public final class RetrievableProjectileSensor extends AbstractSensor<BaseVillager> {
   private static final double SCAN_RANGE_HORIZONTAL = (double)32.0F;
   private static final double SCAN_RANGE_VERTICAL = (double)8.0F;
   private static final int COMPLETION_RANGE = 1;
   private static final int MAX_PROJECTILES = 5;
   private static final int MAX_PATH_SEARCHES = 10;

   public RetrievableProjectileSensor(@Nonnull RetrievableProjectileSensorConfig config) {
      super(List.of(), Tickable.staggered(ClockTicks.seconds((double)config.scanIntervalSeconds())));
   }

   public List<IMemoryWrite> doSense(@Nonnull Level world, @Nonnull BaseVillager entity) {
      if (!VillagerProfessionKey.FLETCHER.equals(entity.getProfession())) {
         return List.of(MemoryWrite.clear(MemoryTypeRegistry.RETRIEVABLE_PROJECTILES));
      } else {
         List<AbstractArrow> reachable = findReachable(entity);
         return List.of(reachable.isEmpty() ? MemoryWrite.clear(MemoryTypeRegistry.RETRIEVABLE_PROJECTILES) : MemoryWrite.of(MemoryTypeRegistry.RETRIEVABLE_PROJECTILES, reachable));
      }
   }

   private static List<AbstractArrow> findReachable(@Nonnull BaseVillager villager) {
      AABB box = villager.m_20191_().m_82377_((double)32.0F, (double)8.0F, (double)32.0F);
      List<AbstractArrow> projectiles = villager.m_9236_().m_6443_(AbstractArrow.class, box, RetrievableProjectileSensor::isRetrievable);
      List<AbstractArrow> reachable = new ArrayList();
      int searches = 0;

      for(AbstractArrow projectile : projectiles) {
         if (reachable.size() >= 5 || searches >= 10) {
            break;
         }

         ++searches;
         if (villager.getNavigationManager().canReach(Location.fromEntity(projectile, false), (double)1.0F)) {
            reachable.add(projectile);
         }
      }

      return List.copyOf(reachable);
   }

   private static boolean isRetrievable(@Nonnull AbstractArrow projectile) {
      return projectile.m_6095_().m_204039_(SettlementsEntityTypeTags.RETRIEVABLE_PROJECTILES) && projectile.m_6084_() && ((AbstractArrowInvoker)projectile).accessInGround();
   }
}
