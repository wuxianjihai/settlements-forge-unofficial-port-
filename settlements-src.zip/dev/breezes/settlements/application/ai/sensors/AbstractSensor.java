package dev.breezes.settlements.application.ai.sensors;

import dev.breezes.settlements.domain.ai.brain.IBrain;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import dev.breezes.settlements.domain.ai.conditions.IEntityCondition;
import dev.breezes.settlements.domain.ai.memory.IMemoryWrite;
import dev.breezes.settlements.domain.ai.sensors.ISensor;
import dev.breezes.settlements.domain.time.ITickable;
import java.util.List;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

public abstract class AbstractSensor<T extends Entity & ISettlementsBrainEntity> implements ISensor<T> {
   protected final List<IEntityCondition<T>> preconditions;
   protected final ITickable senseCooldown;

   protected AbstractSensor(List<IEntityCondition<T>> preconditions, ITickable senseCooldown) {
      this.preconditions = preconditions;
      this.senseCooldown = senseCooldown;
   }

   public void tick(int delta, @Nonnull Level world, @Nonnull T entity) {
      if (this.senseCooldown.tickCheckAndReset((double)delta)) {
         for(IEntityCondition<T> precondition : this.preconditions) {
            if (!precondition.test(entity)) {
               return;
            }
         }

         IBrain brain = ((ISettlementsBrainEntity)entity).getSettlementsBrain();

         for(IMemoryWrite write : this.doSense(world, entity)) {
            write.applyTo(brain);
         }

      }
   }

   @Generated
   public List<IEntityCondition<T>> getPreconditions() {
      return this.preconditions;
   }

   @Generated
   public ITickable getSenseCooldown() {
      return this.senseCooldown;
   }
}
