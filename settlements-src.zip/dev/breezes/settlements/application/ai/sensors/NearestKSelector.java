package dev.breezes.settlements.application.ai.sensors;

import dev.breezes.settlements.domain.ai.memory.PackedPos;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongList;
import java.util.List;
import java.util.PriorityQueue;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class NearestKSelector {
   public static SelectionResult select(@Nonnull List<long[]> chunks, int anchorX, int anchorY, int anchorZ, int horizontalRadius, int verticalRadius, int k) {
      PriorityQueue<long[]> heap = new PriorityQueue(k + 1, (a, b) -> Long.compare(b[1], a[1]));
      int inBoxCount = 0;

      for(long[] chunk : chunks) {
         for(long packed : chunk) {
            int x = PackedPos.x(packed);
            int y = PackedPos.y(packed);
            int z = PackedPos.z(packed);
            if (inBox(x, y, z, anchorX, anchorY, anchorZ, horizontalRadius, verticalRadius)) {
               ++inBoxCount;
               long distSq = squaredDist(x, y, z, anchorX, anchorY, anchorZ);
               if (heap.size() < k) {
                  heap.offer(new long[]{packed, distSq});
               } else if (distSq < ((long[])heap.peek())[1]) {
                  heap.poll();
                  heap.offer(new long[]{packed, distSq});
               }
            }
         }
      }

      LongArrayList result = new LongArrayList(heap.size());

      for(long[] entry : heap) {
         result.add(entry[0]);
      }

      boolean truncated = inBoxCount > k;
      return new SelectionResult(result, truncated);
   }

   private static boolean inBox(int x, int y, int z, int anchorX, int anchorY, int anchorZ, int horizontalRadius, int verticalRadius) {
      return Math.abs(x - anchorX) <= horizontalRadius && Math.abs(z - anchorZ) <= horizontalRadius && Math.abs(y - anchorY) <= verticalRadius;
   }

   private static long squaredDist(int x, int y, int z, int anchorX, int anchorY, int anchorZ) {
      long dx = (long)(x - anchorX);
      long dy = (long)(y - anchorY);
      long dz = (long)(z - anchorZ);
      return dx * dx + dy * dy + dz * dz;
   }

   @Generated
   private NearestKSelector() {
   }

   public static record SelectionResult(@Nonnull LongList sites, boolean truncated) {
   }
}
