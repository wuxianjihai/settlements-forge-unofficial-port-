package dev.breezes.settlements.application.ai.sensors;

import dev.breezes.settlements.infrastructure.config.annotations.BehaviorConfig;
import dev.breezes.settlements.infrastructure.config.annotations.ConfigurationType;
import dev.breezes.settlements.infrastructure.config.annotations.integers.IntegerConfig;

@BehaviorConfig(
   name = "retrievable_projectiles",
   type = ConfigurationType.SENSOR
)
public record RetrievableProjectileSensorConfig(@IntegerConfig(type = ConfigurationType.SENSOR,identifier = "scan_interval_seconds",description = "Seconds between projectile retrievability scans for fletchers",defaultValue = 10,min = 1,max = 120) int scanIntervalSeconds) {
}
