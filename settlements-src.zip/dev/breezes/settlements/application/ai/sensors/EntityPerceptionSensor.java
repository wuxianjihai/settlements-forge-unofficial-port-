package dev.breezes.settlements.application.ai.sensors;

import dev.breezes.settlements.domain.ai.memory.IMemoryWrite;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.memory.MemoryWrite;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.perception.SensedEntity;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.Tickable;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.Comparator;
import java.util.List;
import javax.annotation.Nonnull;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

public final class EntityPerceptionSensor extends AbstractSensor<BaseVillager> {
   private final EntityPerceptionSensorConfig config;

   public EntityPerceptionSensor(@Nonnull EntityPerceptionSensorConfig config, @Nonnull BaseVillager villager) {
      super(List.of(), createStaggeredCooldown(config, villager));
      this.config = config;
   }

   public List<IMemoryWrite> doSense(@Nonnull Level world, @Nonnull BaseVillager entity) {
      AABB scanBox = entity.m_20191_().m_82377_((double)this.config.scanRangeHorizontal(), (double)this.config.scanRangeVertical(), (double)this.config.scanRangeHorizontal());
      List<SensedEntity> sensedEntities = world.m_6443_(LivingEntity.class, scanBox, (sensed) -> this.canSense(entity, sensed)).stream().map((sensed) -> new SensedEntity(sensed, entity.m_20280_(sensed))).sorted(Comparator.comparingDouble(SensedEntity::distanceSquared)).toList();
      return List.of(MemoryWrite.of(MemoryTypeRegistry.NEARBY_SENSED_ENTITIES, new PerceivedEntities(sensedEntities)));
   }

   private boolean canSense(@Nonnull BaseVillager self, @Nonnull LivingEntity sensed) {
      return sensed != self && sensed.m_6084_() && !sensed.m_213877_();
   }

   private static Tickable createStaggeredCooldown(@Nonnull EntityPerceptionSensorConfig config, @Nonnull BaseVillager villager) {
      ClockTicks scanInterval = ClockTicks.seconds((double)config.scanIntervalSeconds());
      int intervalTicks = Math.max(1, scanInterval.getTicksAsInt());
      int initialDelay = Math.floorMod(villager.m_20148_().hashCode(), intervalTicks);
      return new Tickable((double)intervalTicks, (double)initialDelay);
   }
}
