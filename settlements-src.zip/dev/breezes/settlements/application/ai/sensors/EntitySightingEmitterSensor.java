package dev.breezes.settlements.application.ai.sensors;

import dev.breezes.settlements.domain.ai.memory.IMemoryWrite;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.perception.SightingDedupeKeyFactory;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventEmitter;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.Tickable;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Predicate;
import javax.annotation.Nonnull;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public final class EntitySightingEmitterSensor extends AbstractSensor<BaseVillager> {
   private static final long SOCIAL_RESIGHT_COOLDOWN_TICKS = ClockTicks.minutes((double)3.0F).getTicks();
   private static final long ZOMBIE_RESIGHT_COOLDOWN_TICKS = ClockTicks.minutes((double)2.0F).getTicks();
   private static final int SCAN_INTERVAL_TICKS = ClockTicks.seconds((double)1.0F).getTicksAsInt();
   private final WorldEventEmitter emitter;
   private final Map<UUID, Long> subjectCooldowns = new HashMap();

   public EntitySightingEmitterSensor(@Nonnull WorldEventEmitter emitter, @Nonnull BaseVillager villager) {
      super(List.of(), createStaggeredCooldown(villager));
      this.emitter = emitter;
   }

   public List<IMemoryWrite> doSense(@Nonnull Level world, @Nonnull BaseVillager villager) {
      long currentTick = world.m_46467_();
      this.purgeExpiredCooldowns(currentTick);
      PerceivedEntities perceived = (PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_SENSED_ENTITIES).orElse(PerceivedEntities.empty());
      this.emitForType(perceived, Zombie.class, LivingEntity::m_6084_, WorldEventType.ZOMBIE_SIGHTED, villager, currentTick, ZOMBIE_RESIGHT_COOLDOWN_TICKS);
      this.emitForType(perceived, Player.class, LivingEntity::m_6084_, WorldEventType.PLAYER_SIGHTED, villager, currentTick, SOCIAL_RESIGHT_COOLDOWN_TICKS);
      this.emitForType(perceived, WanderingTrader.class, LivingEntity::m_6084_, WorldEventType.WANDERING_TRADER_SIGHTED, villager, currentTick, SOCIAL_RESIGHT_COOLDOWN_TICKS);
      this.emitForType(perceived, IronGolem.class, LivingEntity::m_6084_, WorldEventType.GOLEM_SIGHTED, villager, currentTick, SOCIAL_RESIGHT_COOLDOWN_TICKS);
      return List.of();
   }

   private <E extends Entity> void emitForType(@Nonnull PerceivedEntities perceived, @Nonnull Class<E> type, @Nonnull Predicate<E> filter, @Nonnull WorldEventType eventType, @Nonnull BaseVillager witness, long currentTick, long cooldownTicks) {
      perceived.ofType(type, filter).filter((entity) -> !this.isCoolingDown(entity.m_20148_(), currentTick)).forEach((entity) -> {
         int blockX = (int)Math.floor(entity.m_20185_());
         int blockZ = (int)Math.floor(entity.m_20189_());
         String entityTypeId = entityTypeString(entity);
         UUID dedupeKey = SightingDedupeKeyFactory.computeDedupeKey(entityTypeId, blockX, blockZ, currentTick);
         this.emitter.emitSighting(witness, entity, entityTypeId, eventType, dedupeKey);
         this.subjectCooldowns.put(entity.m_20148_(), currentTick + cooldownTicks);
      });
   }

   private boolean isCoolingDown(UUID subjectId, long currentTick) {
      Long expiry = (Long)this.subjectCooldowns.get(subjectId);
      return expiry != null && currentTick < expiry;
   }

   private void purgeExpiredCooldowns(long currentTick) {
      this.subjectCooldowns.entrySet().removeIf((entry) -> (Long)entry.getValue() <= currentTick);
   }

   private static String entityTypeString(@Nonnull Entity entity) {
      return BuiltInRegistries.f_256780_.m_7981_(entity.m_6095_()).toString();
   }

   private static Tickable createStaggeredCooldown(@Nonnull BaseVillager villager) {
      int initialDelay = Math.floorMod(villager.m_20148_().hashCode(), SCAN_INTERVAL_TICKS);
      return new Tickable((double)SCAN_INTERVAL_TICKS, (double)initialDelay);
   }
}
