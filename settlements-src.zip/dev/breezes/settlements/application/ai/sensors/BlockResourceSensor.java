package dev.breezes.settlements.application.ai.sensors;

import dev.breezes.settlements.domain.ai.memory.IMemoryWrite;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.settlement.model.SettlementMetadata;
import dev.breezes.settlements.domain.settlement.query.SettlementContext;
import dev.breezes.settlements.domain.settlement.query.SettlementQueryService;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;

public final class BlockResourceSensor extends AbstractSensor<BaseVillager> {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(BlockResourceSensor.class.getName());
   private static final long DIAG_INTERVAL_TICKS = 400L;
   private static long lastDiagGameTime = -400L;
   private final BlockResourceSensorConfig config;
   private final Set<BlockResource> resources;
   private final WorldResourceIndex index;
   private final SettlementQueryService settlementQueryService;

   public BlockResourceSensor(@Nonnull BlockResourceSensorConfig config, @Nonnull Set<BlockResource> resources, @Nonnull WorldResourceIndex index, @Nonnull SettlementQueryService settlementQueryService) {
      super(List.of(), ClockTicks.seconds((double)config.scanIntervalSeconds()).asTickable());
      this.config = config;
      this.resources = Set.copyOf(resources);
      this.index = index;
      this.settlementQueryService = settlementQueryService;
   }

   public List<IMemoryWrite> doSense(@Nonnull Level world, @Nonnull BaseVillager entity) {
      if (!(world instanceof ServerLevel serverLevel)) {
         return List.of();
      } else {
         BlockPos anchor = this.anchorFor(serverLevel, entity);
         long nowTick = serverLevel.m_46467_();
         long ttlTicks = ClockTicks.seconds((double)this.config.scanIntervalSeconds()).getTicks();
         Map results = this.index.queryAll(serverLevel, this.resources, anchor, this.config.scanRangeHorizontal(), this.config.scanRangeVertical(), nowTick, ttlTicks);
         int horizontal = this.config.scanRangeHorizontal();
         int vertical = this.config.scanRangeVertical();
         ArrayList writes = new ArrayList(this.resources.size());

         for(BlockResource resource : this.resources) {
            BlockResourceQueryResult result = (BlockResourceQueryResult)results.get(resource);
            if (result != null) {
               Optional var10000 = resource.toMemoryWrite(result, anchor, nowTick, horizontal, vertical);
               Objects.requireNonNull(writes);
               var10000.ifPresent(writes::add);
            }
         }

         long gameTime = serverLevel.m_46467_();
         if (gameTime - lastDiagGameTime >= 400L) {
            lastDiagGameTime = gameTime;
            int ballistaHits = -1;
            boolean complete = false;
            boolean truncated = false;

            for(Map.Entry<BlockResource, BlockResourceQueryResult> entry : results.entrySet()) {
               if (((BlockResource)entry.getKey()).memoryType() == MemoryTypeRegistry.BALLISTA_SITES) {
                  ballistaHits = ((BlockResourceQueryResult)entry.getValue()).packedSites().size();
                  complete = ((BlockResourceQueryResult)entry.getValue()).complete();
                  truncated = ((BlockResourceQueryResult)entry.getValue()).truncated();
                  break;
               }
            }

            log.info("[block-scan] villager {} anchor {} ballistaHits={} complete={} truncated={} dirtyBacklog={} writes={}", entity.m_20148_(), anchor.m_123344_(), ballistaHits, complete, truncated, this.index.dirtyCount(serverLevel), writes.size());
         }

         return writes;
      }
   }

   private BlockPos anchorFor(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      BlockPos bodyPosition = villager.m_20183_();
      return (BlockPos)this.settlementQueryService.getSettlementAt(level, bodyPosition).map(SettlementContext::metadata).map((metadata) -> centerAtVillagerHeight(metadata, bodyPosition)).orElse(bodyPosition);
   }

   private static BlockPos centerAtVillagerHeight(@Nonnull SettlementMetadata metadata, @Nonnull BlockPos bodyPosition) {
      return new BlockPos(metadata.centerX(), bodyPosition.m_123342_(), metadata.centerZ());
   }
}
