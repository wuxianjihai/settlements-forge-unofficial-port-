package dev.breezes.settlements.application.ai.sensors;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.di.WorldScanExecutor;
import dev.breezes.settlements.domain.world.blocks.BlockStateView;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import jakarta.inject.Inject;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.PalettedContainer;

@ServerScope
public final class ResourceIndexRefresher {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ResourceIndexRefresher.class.getName());
   private static final int SECTION_SIZE = 16;
   private static final int NEIGHBOR_REACH = 1;
   private final WorldResourceIndex index;
   private final Set<BlockResource> resources;
   private final BlockResourceSensorConfig config;
   @WorldScanExecutor
   private final ExecutorService worldScanExecutor;
   private final Map<ServerLevel, LevelAsyncState> asyncStateByLevel = new IdentityHashMap();

   public void refresh(@Nonnull ServerLevel level) {
      LevelAsyncState asyncState = this.asyncStateFor(level);
      this.drainArrivals(level, asyncState);
      List<Long> sections = this.index.drainDirty(level, this.config.scanBudgetSectionsPerTick());
      if (!sections.isEmpty()) {
         long nowTick = level.m_46467_();

         for(long sectionKey : sections) {
            this.processDirtySection(level, asyncState, sectionKey, nowTick);
         }

      }
   }

   public void evictChunk(@Nonnull ServerLevel level, int chunkX, int chunkZ) {
      LevelAsyncState asyncState = (LevelAsyncState)this.asyncStateByLevel.get(level);
      if (asyncState != null) {
         int minSectionY = level.m_151560_();
         int maxSectionY = level.m_151561_();

         for(int sectionY = minSectionY; sectionY <= maxSectionY; ++sectionY) {
            long key = SectionPos.m_123209_(chunkX, sectionY, chunkZ);
            asyncState.inFlight.remove(key);
            asyncState.arrivals.removeIf((a) -> a.sectionKey() == key);
         }

      }
   }

   public void clearLevel(@Nonnull ServerLevel level) {
      this.asyncStateByLevel.remove(level);
   }

   private void drainArrivals(@Nonnull ServerLevel level, @Nonnull LevelAsyncState asyncState) {
      ScanArrival arrival;
      while((arrival = (ScanArrival)asyncState.arrivals.poll()) != null) {
         long key = arrival.sectionKey();
         asyncState.inFlight.remove(key);
         if (arrival.scan() != null) {
            int chunkX = SectionPos.m_123213_(key);
            int chunkZ = SectionPos.m_123230_(key);
            if (level.m_7726_().m_7131_(chunkX, chunkZ) != null) {
               SectionResourceScan existing = this.index.getScan(level, key);
               if (existing == null || existing.scannedAtTick() < arrival.scan().scannedAtTick()) {
                  this.index.apply(level, key, arrival.scan());
               }
            }
         }
      }

   }

   private void processDirtySection(@Nonnull ServerLevel level, @Nonnull LevelAsyncState asyncState, long sectionKey, long nowTick) {
      if (!asyncState.inFlight.contains(sectionKey)) {
         int chunkX = SectionPos.m_123213_(sectionKey);
         int chunkZ = SectionPos.m_123230_(sectionKey);
         LevelChunk chunk = level.m_7726_().m_7131_(chunkX, chunkZ);
         if (chunk != null) {
            int sectionY = SectionPos.m_123225_(sectionKey);
            int sectionIndex = chunk.m_151564_(SectionPos.m_123223_(sectionY));
            if (sectionIndex >= 0 && sectionIndex < chunk.m_151559_()) {
               LevelChunkSection targetSection = chunk.m_183278_(sectionIndex);
               if (targetSection.m_188008_()) {
                  this.index.apply(level, sectionKey, new SectionResourceScan(nowTick, Map.of()));
               } else {
                  Set<BlockResource> survivors = computeSurvivors(this.resources, targetSection);
                  if (survivors.isEmpty()) {
                     this.index.apply(level, sectionKey, new SectionResourceScan(nowTick, Map.of()));
                  } else {
                     Long2ObjectMap<PalettedContainer<BlockState>> snapshot = takeSnapshot(level, chunk, sectionY);
                     int originX = SectionPos.m_123223_(SectionPos.m_123213_(sectionKey));
                     int originY = SectionPos.m_123223_(sectionY);
                     int originZ = SectionPos.m_123223_(SectionPos.m_123230_(sectionKey));
                     int minBuildHeight = level.m_141937_();
                     int maxBuildHeight = level.m_151558_();
                     asyncState.inFlight.add(sectionKey);
                     CompletableFuture.supplyAsync(() -> matchSnapshot(snapshot, survivors, originX, originY, originZ, minBuildHeight, maxBuildHeight, nowTick), this.worldScanExecutor).whenComplete((scan, err) -> {
                        if (err != null) {
                           log.warn("Async section scan failed for sectionKey={}: {}", sectionKey, err.toString());
                           asyncState.arrivals.offer(new ScanArrival(sectionKey, (SectionResourceScan)null));
                        } else {
                           asyncState.arrivals.offer(new ScanArrival(sectionKey, scan));
                        }
                     });
                  }
               }
            }
         }
      }
   }

   private static SectionResourceScan matchSnapshot(@Nonnull Long2ObjectMap<PalettedContainer<BlockState>> snapshot, @Nonnull Set<BlockResource> survivors, int originX, int originY, int originZ, int minBuildHeight, int maxBuildHeight, long nowTick) {
      SnapshotBlockStateView view = new SnapshotBlockStateView(snapshot);
      Map<BlockResource, LongArrayList> hitAccumulators = new HashMap(survivors.size());
      BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();

      for(int y = originY; y < originY + 16; ++y) {
         if (y >= minBuildHeight && y < maxBuildHeight) {
            for(int z = originZ; z < originZ + 16; ++z) {
               for(int x = originX; x < originX + 16; ++x) {
                  cursor.m_122178_(x, y, z);
                  int lx = x & 15;
                  int ly = y & 15;
                  int lz = z & 15;
                  long targetKey = SectionPos.m_123209_(SectionPos.m_123171_(x), SectionPos.m_123171_(y), SectionPos.m_123171_(z));
                  PalettedContainer<BlockState> container = (PalettedContainer)snapshot.get(targetKey);
                  BlockState state = container != null ? (BlockState)container.m_63087_(lx, ly, lz) : Blocks.f_50016_.m_49966_();

                  for(BlockResource resource : survivors) {
                     if (resource.matcher().matches(cursor, state, (BlockStateView)view)) {
                        ((LongArrayList)hitAccumulators.computeIfAbsent(resource, (ignored) -> new LongArrayList())).add(cursor.m_121878_());
                     }
                  }
               }
            }
         }
      }

      if (hitAccumulators.isEmpty()) {
         return new SectionResourceScan(nowTick, Map.of());
      } else {
         Map<BlockResource, long[]> hitsByResource = new HashMap(hitAccumulators.size());

         for(Map.Entry<BlockResource, LongArrayList> entry : hitAccumulators.entrySet()) {
            hitsByResource.put((BlockResource)entry.getKey(), ((LongArrayList)entry.getValue()).toLongArray());
         }

         return new SectionResourceScan(nowTick, Collections.unmodifiableMap(hitsByResource));
      }
   }

   @Nonnull
   private static Long2ObjectMap<PalettedContainer<BlockState>> takeSnapshot(@Nonnull ServerLevel level, @Nonnull LevelChunk targetChunk, int targetSectionY) {
      Long2ObjectMap<PalettedContainer<BlockState>> snapshot = new Long2ObjectOpenHashMap();
      int chunkX = targetChunk.m_7697_().f_45578_;
      int chunkZ = targetChunk.m_7697_().f_45579_;

      for(int dx = -1; dx <= 1; ++dx) {
         for(int dz = -1; dz <= 1; ++dz) {
            if (dx == 0 || dz == 0) {
               LevelChunk neighborChunk = dx == 0 && dz == 0 ? targetChunk : level.m_7726_().m_7131_(chunkX + dx, chunkZ + dz);
               if (neighborChunk != null) {
                  snapshotSectionY(neighborChunk, chunkX + dx, targetSectionY, snapshot, level);
               }
            }
         }
      }

      snapshotSectionY(targetChunk, chunkX, targetSectionY - 1, snapshot, level);
      snapshotSectionY(targetChunk, chunkX, targetSectionY + 1, snapshot, level);
      return snapshot;
   }

   private static void snapshotSectionY(@Nonnull LevelChunk chunk, int chunkX, int sectionY, @Nonnull Long2ObjectMap<PalettedContainer<BlockState>> snapshot, @Nonnull ServerLevel level) {
      if (sectionY >= level.m_151560_() && sectionY <= level.m_151561_()) {
         int sectionIndex = chunk.m_151564_(SectionPos.m_123223_(sectionY));
         if (sectionIndex >= 0 && sectionIndex < chunk.m_151559_()) {
            LevelChunkSection section = chunk.m_183278_(sectionIndex);
            long key = SectionPos.m_123209_(chunkX, sectionY, chunk.m_7697_().f_45579_);
            snapshot.put(key, section.m_63019_().m_199931_());
         }
      }
   }

   @Nonnull
   private static Set<BlockResource> computeSurvivors(@Nonnull Set<BlockResource> resources, @Nonnull LevelChunkSection section) {
      Set<BlockResource> survivors = new HashSet(resources.size());

      for(BlockResource resource : resources) {
         if (section.m_63002_(resource.matcher().statePredicate())) {
            survivors.add(resource);
         }
      }

      return survivors;
   }

   private LevelAsyncState asyncStateFor(@Nonnull ServerLevel level) {
      return (LevelAsyncState)this.asyncStateByLevel.computeIfAbsent(level, (ignored) -> new LevelAsyncState());
   }

   @Inject
   @Generated
   ResourceIndexRefresher(WorldResourceIndex index, Set<BlockResource> resources, BlockResourceSensorConfig config, @WorldScanExecutor ExecutorService worldScanExecutor) {
      this.index = index;
      this.resources = resources;
      this.config = config;
      this.worldScanExecutor = worldScanExecutor;
   }

   private static final class LevelAsyncState {
      private final LongOpenHashSet inFlight = new LongOpenHashSet();
      private final ConcurrentLinkedQueue<ScanArrival> arrivals = new ConcurrentLinkedQueue();
   }

   private static record ScanArrival(long sectionKey, @Nullable SectionResourceScan scan) {
   }
}
