package dev.breezes.settlements.application.ai.sensors;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.Set;
import java.util.concurrent.ExecutorService;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata({"dev.breezes.settlements.di.WorldScanExecutor"})
@DaggerGenerated
public final class ResourceIndexRefresher_Factory implements Factory<ResourceIndexRefresher> {
   private final Provider<WorldResourceIndex> indexProvider;
   private final Provider<Set<BlockResource>> resourcesProvider;
   private final Provider<BlockResourceSensorConfig> configProvider;
   private final Provider<ExecutorService> worldScanExecutorProvider;

   private ResourceIndexRefresher_Factory(Provider<WorldResourceIndex> indexProvider, Provider<Set<BlockResource>> resourcesProvider, Provider<BlockResourceSensorConfig> configProvider, Provider<ExecutorService> worldScanExecutorProvider) {
      this.indexProvider = indexProvider;
      this.resourcesProvider = resourcesProvider;
      this.configProvider = configProvider;
      this.worldScanExecutorProvider = worldScanExecutorProvider;
   }

   public ResourceIndexRefresher get() {
      return newInstance((WorldResourceIndex)this.indexProvider.get(), (Set)this.resourcesProvider.get(), (BlockResourceSensorConfig)this.configProvider.get(), (ExecutorService)this.worldScanExecutorProvider.get());
   }

   public static ResourceIndexRefresher_Factory create(Provider<WorldResourceIndex> indexProvider, Provider<Set<BlockResource>> resourcesProvider, Provider<BlockResourceSensorConfig> configProvider, Provider<ExecutorService> worldScanExecutorProvider) {
      return new ResourceIndexRefresher_Factory(indexProvider, resourcesProvider, configProvider, worldScanExecutorProvider);
   }

   public static ResourceIndexRefresher newInstance(WorldResourceIndex index, Set<BlockResource> resources, BlockResourceSensorConfig config, ExecutorService worldScanExecutor) {
      return new ResourceIndexRefresher(index, resources, config, worldScanExecutor);
   }
}
