package dev.breezes.settlements.application.ai.sensors;

import it.unimi.dsi.fastutil.longs.LongList;
import javax.annotation.Nonnull;

public record BlockResourceQueryResult(@Nonnull LongList packedSites, boolean complete, boolean truncated) {
}
