package dev.breezes.settlements.application.ai.sensors;

import java.util.Map;
import javax.annotation.Nonnull;

public record SectionResourceScan(long scannedAtTick, @Nonnull Map<BlockResource, long[]> hitsByResource) {
   private static final long[] EMPTY = new long[0];

   public long[] hitsFor(@Nonnull BlockResource resource) {
      return (long[])this.hitsByResource.getOrDefault(resource, EMPTY);
   }
}
