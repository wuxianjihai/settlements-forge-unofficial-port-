package dev.breezes.settlements.application.ai.sensors;

import dev.breezes.settlements.di.ServerScope;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongLinkedOpenHashSet;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.server.level.ServerLevel;

@ServerScope
public final class WorldResourceIndex {
   private final Map<ServerLevel, LevelResourceIndex> indexesByLevel = new IdentityHashMap();

   public Map<BlockResource, BlockResourceQueryResult> queryAll(@Nonnull ServerLevel level, @Nonnull Set<BlockResource> resources, @Nonnull BlockPos anchor, int horizontalRadius, int verticalRadius, long nowTick, long ttlTicks) {
      LevelResourceIndex levelIndex = this.indexFor(level);
      Map<BlockResource, List<long[]>> accumByResource = new IdentityHashMap(resources.size());

      for(BlockResource resource : resources) {
         accumByResource.put(resource, new ArrayList());
      }

      boolean complete = true;
      long[] sectionKeys = sectionsIntersecting(anchor, horizontalRadius, verticalRadius);

      for(long sectionKey : sectionKeys) {
         SectionResourceScan scan = (SectionResourceScan)levelIndex.sections.get(sectionKey);
         boolean sectionFresh = scan != null && nowTick - scan.scannedAtTick() < ttlTicks;
         if (!sectionFresh) {
            levelIndex.enqueue(sectionKey);
            complete = false;
         }

         if (scan != null) {
            for(BlockResource resource : resources) {
               long[] hits = scan.hitsFor(resource);
               if (hits.length > 0) {
                  ((List)accumByResource.get(resource)).add(hits);
               }
            }
         }
      }

      Map<BlockResource, BlockResourceQueryResult> results = new IdentityHashMap(resources.size());

      for(BlockResource resource : resources) {
         List<long[]> chunks = (List)accumByResource.get(resource);
         results.put(resource, buildResult(chunks, complete, anchor, horizontalRadius, verticalRadius, resource.memoryType().maxEntries()));
      }

      return results;
   }

   public List<Long> drainDirty(@Nonnull ServerLevel level, int maxSections) {
      LevelResourceIndex levelIndex = this.indexFor(level);
      List<Long> drained = new ArrayList(maxSections);

      while(drained.size() < maxSections && !levelIndex.dirtyQueue.isEmpty()) {
         long sectionKey = levelIndex.dirtyQueue.removeFirstLong();
         drained.add(sectionKey);
      }

      return drained;
   }

   public int dirtyCount(@Nonnull ServerLevel level) {
      LevelResourceIndex levelIndex = (LevelResourceIndex)this.indexesByLevel.get(level);
      return levelIndex == null ? 0 : levelIndex.dirtyQueue.size();
   }

   public void apply(@Nonnull ServerLevel level, long sectionKey, @Nonnull SectionResourceScan scan) {
      this.indexFor(level).sections.put(sectionKey, scan);
   }

   @Nullable
   public SectionResourceScan getScan(@Nonnull ServerLevel level, long sectionKey) {
      LevelResourceIndex levelIndex = (LevelResourceIndex)this.indexesByLevel.get(level);
      return levelIndex == null ? null : (SectionResourceScan)levelIndex.sections.get(sectionKey);
   }

   public void evictChunk(@Nonnull ServerLevel level, int chunkX, int chunkZ) {
      LevelResourceIndex levelIndex = this.indexFor(level);
      int minSectionY = level.m_151560_();
      int maxSectionY = level.m_151561_();

      for(int sectionY = minSectionY; sectionY <= maxSectionY; ++sectionY) {
         long key = SectionPos.m_123209_(chunkX, sectionY, chunkZ);
         levelIndex.sections.remove(key);
         levelIndex.dirtyQueue.remove(key);
      }

   }

   public void clear(@Nonnull ServerLevel level) {
      this.indexesByLevel.remove(level);
   }

   private LevelResourceIndex indexFor(@Nonnull ServerLevel level) {
      return (LevelResourceIndex)this.indexesByLevel.computeIfAbsent(level, (ignored) -> new LevelResourceIndex());
   }

   private static long[] sectionsIntersecting(@Nonnull BlockPos anchor, int horizontalRadius, int verticalRadius) {
      int minSectionX = SectionPos.m_123171_(anchor.m_123341_() - horizontalRadius);
      int maxSectionX = SectionPos.m_123171_(anchor.m_123341_() + horizontalRadius);
      int minSectionY = SectionPos.m_123171_(anchor.m_123342_() - verticalRadius);
      int maxSectionY = SectionPos.m_123171_(anchor.m_123342_() + verticalRadius);
      int minSectionZ = SectionPos.m_123171_(anchor.m_123343_() - horizontalRadius);
      int maxSectionZ = SectionPos.m_123171_(anchor.m_123343_() + horizontalRadius);
      int count = (maxSectionX - minSectionX + 1) * (maxSectionY - minSectionY + 1) * (maxSectionZ - minSectionZ + 1);
      long[] keys = new long[count];
      int idx = 0;

      for(int sectionX = minSectionX; sectionX <= maxSectionX; ++sectionX) {
         for(int sectionY = minSectionY; sectionY <= maxSectionY; ++sectionY) {
            for(int sectionZ = minSectionZ; sectionZ <= maxSectionZ; ++sectionZ) {
               keys[idx++] = SectionPos.m_123209_(sectionX, sectionY, sectionZ);
            }
         }
      }

      return keys;
   }

   private static BlockResourceQueryResult buildResult(@Nonnull List<long[]> chunks, boolean complete, @Nonnull BlockPos anchor, int horizontalRadius, int verticalRadius, int k) {
      NearestKSelector.SelectionResult selection = NearestKSelector.select(chunks, anchor.m_123341_(), anchor.m_123342_(), anchor.m_123343_(), horizontalRadius, verticalRadius, k);
      return new BlockResourceQueryResult(selection.sites(), complete, selection.truncated());
   }

   private static final class LevelResourceIndex {
      private final Long2ObjectOpenHashMap<SectionResourceScan> sections = new Long2ObjectOpenHashMap();
      private final LongLinkedOpenHashSet dirtyQueue = new LongLinkedOpenHashSet();

      private void enqueue(long sectionKey) {
         this.dirtyQueue.add(sectionKey);
      }
   }
}
