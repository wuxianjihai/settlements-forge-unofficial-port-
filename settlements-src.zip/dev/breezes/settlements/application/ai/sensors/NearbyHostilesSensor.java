package dev.breezes.settlements.application.ai.sensors;

import dev.breezes.settlements.domain.ai.memory.IMemoryWrite;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.memory.MemoryWrite;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.perception.SensedEntity;
import dev.breezes.settlements.domain.tags.SettlementsEntityTypeTags;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.Tickable;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.memory.NearestVisibleLivingEntities;
import net.minecraft.world.level.Level;

public final class NearbyHostilesSensor extends AbstractSensor<BaseVillager> {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(NearbyHostilesSensor.class.getName());
   private static final ClockTicks SCAN_INTERVAL = ClockTicks.of(5L);
   private static final double AWARENESS_RADIUS_SQUARED = (double)256.0F;
   private static final int SIGHT_CHECK_BUDGET = 3;
   private static final List<IMemoryWrite> NO_HOSTILES;
   private long lastProbeGameTime = -20L;

   public NearbyHostilesSensor() {
      super(List.of(), Tickable.staggered(SCAN_INTERVAL));
   }

   public List<IMemoryWrite> doSense(@Nonnull Level world, @Nonnull BaseVillager entity) {
      List<LivingEntity> scan = (List)entity.m_6274_().m_21952_(MemoryModuleType.f_148204_).orElse(List.of());
      long nowGameTime = world.m_46467_();
      if (nowGameTime - this.lastProbeGameTime >= 20L) {
         this.lastProbeGameTime = nowGameTime;
         int tagHits = 0;
         List<String> otherTypes = new ArrayList();

         for(LivingEntity candidate : scan) {
            if (candidate.m_6095_().m_204039_(SettlementsEntityTypeTags.VILLAGER_ENEMIES)) {
               ++tagHits;
            } else if (!(candidate instanceof BaseVillager)) {
               otherTypes.add(candidate.m_6095_().m_204041_().m_205785_().m_135782_().toString());
            }
         }

         log.info("[hostile-scan] villager={} vanillaSize={} tagHits={} others={}", entity.m_19879_(), scan.size(), tagHits, otherTypes);
      }

      List<SensedEntity> hostiles = new ArrayList();

      for(LivingEntity candidate : scan) {
         if (candidate.m_6084_() && candidate.m_6095_().m_204039_(SettlementsEntityTypeTags.VILLAGER_ENEMIES)) {
            double distanceSquared = entity.m_20280_(candidate);
            if (!(distanceSquared > (double)256.0F)) {
               hostiles.add(new SensedEntity(candidate, distanceSquared));
            }
         }
      }

      if (hostiles.isEmpty()) {
         return NO_HOSTILES;
      } else {
         hostiles.sort(Comparator.comparingDouble(SensedEntity::distanceSquared));
         NearestVisibleLivingEntities visible = (NearestVisibleLivingEntities)entity.m_6274_().m_21952_(MemoryModuleType.f_148205_).orElse(NearestVisibleLivingEntities.m_186106_());
         int checkCount = Math.min(3, hostiles.size());
         List<SensedEntity> sighted = new ArrayList(checkCount);
         List<SensedEntity> unseen = new ArrayList(checkCount);

         for(SensedEntity candidate : hostiles.subList(0, checkCount)) {
            if (visible.m_186107_(candidate.entity())) {
               sighted.add(candidate);
            } else {
               unseen.add(candidate);
            }
         }

         return List.of(MemoryWrite.of(MemoryTypeRegistry.NEARBY_HOSTILES, new PerceivedEntities(hostiles)), MemoryWrite.of(MemoryTypeRegistry.SIGHTED_HOSTILES, new PerceivedEntities(sighted)), MemoryWrite.of(MemoryTypeRegistry.UNSEEN_HOSTILES, new PerceivedEntities(unseen)), MemoryWrite.of(MemoryTypeRegistry.NEAREST_HOSTILE, ((SensedEntity)hostiles.get(0)).entity()));
      }
   }

   static {
      NO_HOSTILES = List.of(MemoryWrite.of(MemoryTypeRegistry.NEARBY_HOSTILES, PerceivedEntities.empty()), MemoryWrite.of(MemoryTypeRegistry.SIGHTED_HOSTILES, PerceivedEntities.empty()), MemoryWrite.of(MemoryTypeRegistry.UNSEEN_HOSTILES, PerceivedEntities.empty()), MemoryWrite.clear(MemoryTypeRegistry.NEAREST_HOSTILE));
   }
}
