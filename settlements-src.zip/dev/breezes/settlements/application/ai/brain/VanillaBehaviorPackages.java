package dev.breezes.settlements.application.ai.brain;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.mojang.datafixers.util.Pair;
import dev.breezes.settlements.application.ai.behavior.usecases.villager.courtship.BedCompetitorScan;
import dev.breezes.settlements.infrastructure.config.factory.ConfigFactory;
import dev.breezes.settlements.infrastructure.minecraft.behavior.home.ValidateNearbyHome;
import dev.breezes.settlements.infrastructure.minecraft.behavior.threat.FleeTowardVillage;
import dev.breezes.settlements.infrastructure.minecraft.behavior.threat.ThreatGolemSummon;
import dev.breezes.settlements.infrastructure.minecraft.behavior.threat.ThreatGolemSummonConfig;
import dev.breezes.settlements.infrastructure.minecraft.behavior.traversal.InteractWithBarriers;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.behavior.AcquirePoi;
import net.minecraft.world.entity.ai.behavior.AssignProfessionFromJobSite;
import net.minecraft.world.entity.ai.behavior.BehaviorControl;
import net.minecraft.world.entity.ai.behavior.CelebrateVillagersSurvivedRaid;
import net.minecraft.world.entity.ai.behavior.DoNothing;
import net.minecraft.world.entity.ai.behavior.GateBehavior;
import net.minecraft.world.entity.ai.behavior.GiveGiftToHero;
import net.minecraft.world.entity.ai.behavior.GoToClosestVillage;
import net.minecraft.world.entity.ai.behavior.GoToPotentialJobSite;
import net.minecraft.world.entity.ai.behavior.GoToWantedItem;
import net.minecraft.world.entity.ai.behavior.InsideBrownianWalk;
import net.minecraft.world.entity.ai.behavior.InteractWith;
import net.minecraft.world.entity.ai.behavior.JumpOnBed;
import net.minecraft.world.entity.ai.behavior.LocateHidingPlace;
import net.minecraft.world.entity.ai.behavior.LookAndFollowTradingPlayerSink;
import net.minecraft.world.entity.ai.behavior.LookAtTargetSink;
import net.minecraft.world.entity.ai.behavior.MoveToSkySeeingSpot;
import net.minecraft.world.entity.ai.behavior.MoveToTargetSink;
import net.minecraft.world.entity.ai.behavior.PlayTagWithOtherKids;
import net.minecraft.world.entity.ai.behavior.PoiCompetitorScan;
import net.minecraft.world.entity.ai.behavior.ReactToBell;
import net.minecraft.world.entity.ai.behavior.ResetProfession;
import net.minecraft.world.entity.ai.behavior.ResetRaidStatus;
import net.minecraft.world.entity.ai.behavior.RingBell;
import net.minecraft.world.entity.ai.behavior.RunOne;
import net.minecraft.world.entity.ai.behavior.SetClosestHomeAsWalkTarget;
import net.minecraft.world.entity.ai.behavior.SetEntityLookTarget;
import net.minecraft.world.entity.ai.behavior.SetHiddenState;
import net.minecraft.world.entity.ai.behavior.SetLookAndInteract;
import net.minecraft.world.entity.ai.behavior.SetRaidStatus;
import net.minecraft.world.entity.ai.behavior.SetWalkTargetFromBlockMemory;
import net.minecraft.world.entity.ai.behavior.SetWalkTargetFromLookTarget;
import net.minecraft.world.entity.ai.behavior.ShowTradesToPlayer;
import net.minecraft.world.entity.ai.behavior.SleepInBed;
import net.minecraft.world.entity.ai.behavior.SocializeAtBell;
import net.minecraft.world.entity.ai.behavior.StrollAroundPoi;
import net.minecraft.world.entity.ai.behavior.Swim;
import net.minecraft.world.entity.ai.behavior.TradeWithVillager;
import net.minecraft.world.entity.ai.behavior.TriggerGate;
import net.minecraft.world.entity.ai.behavior.UpdateActivityFromSchedule;
import net.minecraft.world.entity.ai.behavior.ValidateNearbyPoi;
import net.minecraft.world.entity.ai.behavior.VillageBoundRandomStroll;
import net.minecraft.world.entity.ai.behavior.VillagerCalmDown;
import net.minecraft.world.entity.ai.behavior.VillagerMakeLove;
import net.minecraft.world.entity.ai.behavior.VillagerPanicTrigger;
import net.minecraft.world.entity.ai.behavior.WakeUp;
import net.minecraft.world.entity.ai.behavior.YieldJobSite;
import net.minecraft.world.entity.ai.behavior.GateBehavior.OrderPolicy;
import net.minecraft.world.entity.ai.behavior.GateBehavior.RunningPolicy;
import net.minecraft.world.entity.ai.behavior.declarative.BehaviorBuilder;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.memory.MemoryStatus;
import net.minecraft.world.entity.ai.village.poi.PoiTypes;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.entity.raid.Raid;

public final class VanillaBehaviorPackages {
   private static final float STROLL_SPEED_MODIFIER = 0.4F;

   public static ImmutableList<Pair<Integer, ? extends BehaviorControl<? super Villager>>> getCorePackage(VillagerProfession profession, float speed) {
      List<Pair<Integer, ? extends BehaviorControl<? super Villager>>> coreBehaviors = new ArrayList();
      coreBehaviors.addAll(List.of(Pair.of(0, new Swim(0.8F)), Pair.of(0, InteractWithBarriers.create()), Pair.of(0, new LookAtTargetSink(45, 90)), Pair.of(0, new ThreatGolemSummon((ThreatGolemSummonConfig)ConfigFactory.create(ThreatGolemSummonConfig.class))), Pair.of(0, new VillagerPanicTrigger()), Pair.of(0, WakeUp.m_257779_()), Pair.of(0, ReactToBell.m_258068_()), Pair.of(0, SetRaidStatus.m_257923_()), Pair.of(0, ValidateNearbyPoi.m_257857_(profession.f_219628_(), MemoryModuleType.f_26360_)), Pair.of(0, ValidateNearbyPoi.m_257857_(profession.f_219629_(), MemoryModuleType.f_26361_)), Pair.of(1, new MoveToTargetSink()), Pair.of(2, PoiCompetitorScan.m_257502_()), Pair.of(2, BedCompetitorScan.create()), Pair.of(3, new LookAndFollowTradingPlayerSink(speed)), Pair.of(5, GoToWantedItem.m_257526_(speed, false, 4)), Pair.of(6, AcquirePoi.m_258026_(profession.f_219629_(), MemoryModuleType.f_26360_, MemoryModuleType.f_26361_, true, Optional.empty())), Pair.of(7, new GoToPotentialJobSite(speed)), Pair.of(8, YieldJobSite.m_257788_(speed)), Pair.of(10, AcquirePoi.m_257613_((poiType) -> poiType.m_203565_(PoiTypes.f_218060_), MemoryModuleType.f_26359_, false, Optional.of((byte)14))), Pair.of(10, AcquirePoi.m_257613_((poiType) -> poiType.m_203565_(PoiTypes.f_218061_), MemoryModuleType.f_26362_, true, Optional.of((byte)14))), Pair.of(10, AssignProfessionFromJobSite.m_257634_()), Pair.of(10, ResetProfession.m_257593_())));
      return ImmutableList.copyOf(coreBehaviors);
   }

   public static ImmutableList<Pair<Integer, ? extends BehaviorControl<? super Villager>>> getPlayPackage(float speed) {
      return ImmutableList.of(getFullLookBehavior(), Pair.of(0, new MoveToTargetSink(80, 120)), Pair.of(5, PlayTagWithOtherKids.m_257585_()), Pair.of(5, new RunOne(ImmutableMap.of(MemoryModuleType.f_26366_, MemoryStatus.VALUE_ABSENT), ImmutableList.of(Pair.of(InteractWith.m_258079_(EntityType.f_20492_, 8, MemoryModuleType.f_26374_, speed, 2), 2), Pair.of(InteractWith.m_258079_(EntityType.f_20553_, 8, MemoryModuleType.f_26374_, speed, 2), 1), Pair.of(VillageBoundRandomStroll.m_257910_(speed), 1), Pair.of(SetWalkTargetFromLookTarget.m_257764_(speed, 2), 1), Pair.of(new JumpOnBed(speed), 2), Pair.of(new DoNothing(20, 40), 2)))), Pair.of(99, UpdateActivityFromSchedule.m_257835_()));
   }

   public static ImmutableList<Pair<Integer, ? extends BehaviorControl<? super Villager>>> getRestPackage(VillagerProfession profession, float speed) {
      return ImmutableList.of(getMinimalLookBehavior(), Pair.of(2, SetWalkTargetFromBlockMemory.m_257972_(MemoryModuleType.f_26359_, speed, 1, 150, 1200)), Pair.of(3, ValidateNearbyHome.create()), Pair.of(3, new SleepInBed()), Pair.of(5, new RunOne(ImmutableMap.of(MemoryModuleType.f_26359_, MemoryStatus.VALUE_ABSENT), ImmutableList.of(Pair.of(SetClosestHomeAsWalkTarget.m_257524_(speed), 1), Pair.of(InsideBrownianWalk.m_258053_(speed), 4), Pair.of(GoToClosestVillage.m_257375_(speed, 4), 2), Pair.of(new DoNothing(20, 40), 2)))), Pair.of(99, UpdateActivityFromSchedule.m_257835_()));
   }

   public static ImmutableList<Pair<Integer, ? extends BehaviorControl<? super Villager>>> getMeetPackage(VillagerProfession profession, float speed) {
      ImmutableList<Pair<Integer, ? extends BehaviorControl<? super Villager>>> behaviors = ImmutableList.of(getFullLookBehavior(), Pair.of(2, TriggerGate.m_257503_(ImmutableList.of(Pair.of(StrollAroundPoi.m_257894_(MemoryModuleType.f_26362_, 0.4F, 40), 2), Pair.of(SocializeAtBell.m_257875_(), 2)))), Pair.of(2, SetWalkTargetFromBlockMemory.m_257972_(MemoryModuleType.f_26362_, speed, 6, 100, 200)), Pair.of(3, new GiveGiftToHero(100)), Pair.of(3, ValidateNearbyPoi.m_257857_((poiType) -> poiType.m_203565_(PoiTypes.f_218061_), MemoryModuleType.f_26362_)), Pair.of(3, new GateBehavior(ImmutableMap.of(), ImmutableSet.of(MemoryModuleType.f_26374_), OrderPolicy.ORDERED, RunningPolicy.RUN_ONE, ImmutableList.of(Pair.of(new TradeWithVillager(), 1)))), Pair.of(10, new ShowTradesToPlayer(400, 1600)), Pair.of(10, SetLookAndInteract.m_257430_(EntityType.f_20532_, 4)), Pair.of(99, UpdateActivityFromSchedule.m_257835_()));
      return behaviors;
   }

   public static ImmutableList<Pair<Integer, ? extends BehaviorControl<? super Villager>>> getIdlePackage(float speed) {
      List<Pair<Integer, ? extends BehaviorControl<? super Villager>>> idleBehaviors = new ArrayList();
      idleBehaviors.addAll(List.of(getFullLookBehavior(), Pair.of(3, new GiveGiftToHero(100)), Pair.of(3, SetLookAndInteract.m_257430_(EntityType.f_20532_, 4)), Pair.of(3, new ShowTradesToPlayer(400, 1600)), Pair.of(3, new GateBehavior(ImmutableMap.of(), ImmutableSet.of(MemoryModuleType.f_26374_), OrderPolicy.ORDERED, RunningPolicy.RUN_ONE, ImmutableList.of(Pair.of(new TradeWithVillager(), 1)))), Pair.of(3, new GateBehavior(ImmutableMap.of(), ImmutableSet.of(MemoryModuleType.f_26375_), OrderPolicy.ORDERED, RunningPolicy.RUN_ONE, ImmutableList.of(Pair.of(new VillagerMakeLove(), 1)))), Pair.of(99, UpdateActivityFromSchedule.m_257835_())));
      ArrayList<Pair<? extends BehaviorControl<? super Villager>, Integer>> idleChoiceBehaviors = new ArrayList();
      idleChoiceBehaviors.addAll(List.of(Pair.of(InteractWith.m_258079_(EntityType.f_20492_, 8, MemoryModuleType.f_26374_, speed, 2), 2), Pair.of(InteractWith.m_257746_(EntityType.f_20492_, 8, AgeableMob::m_35506_, AgeableMob::m_35506_, MemoryModuleType.f_26375_, speed, 2), 1), Pair.of(InteractWith.m_258079_(EntityType.f_20553_, 8, MemoryModuleType.f_26374_, speed, 2), 1), Pair.of(VillageBoundRandomStroll.m_257910_(speed), 1), Pair.of(SetWalkTargetFromLookTarget.m_257764_(speed, 2), 1), Pair.of(new JumpOnBed(speed), 1), Pair.of(new DoNothing(30, 60), 1)));
      idleBehaviors.add(Pair.of(2, new RunOne(idleChoiceBehaviors)));
      return ImmutableList.copyOf(idleBehaviors);
   }

   public static ImmutableList<Pair<Integer, ? extends BehaviorControl<? super Villager>>> getPanicPackage(VillagerProfession profession, float speed) {
      return ImmutableList.of(getMinimalLookBehavior(), Pair.of(0, VillagerCalmDown.m_257666_()), Pair.of(1, FleeTowardVillage.create(MemoryModuleType.f_26323_, speed, 6)), Pair.of(1, FleeTowardVillage.create(MemoryModuleType.f_26382_, speed, 6)), Pair.of(3, VillageBoundRandomStroll.m_258010_(speed, 2, 2)));
   }

   public static ImmutableList<Pair<Integer, ? extends BehaviorControl<? super Villager>>> getPreRaidPackage(VillagerProfession profession, float speed) {
      return ImmutableList.of(getMinimalLookBehavior(), Pair.of(0, RingBell.m_257471_()), Pair.of(0, TriggerGate.m_257503_(ImmutableList.of(Pair.of(SetWalkTargetFromBlockMemory.m_257972_(MemoryModuleType.f_26362_, speed, 2, 150, 200), 6), Pair.of(VillageBoundRandomStroll.m_257910_(speed), 2)))), Pair.of(99, ResetRaidStatus.m_257468_()));
   }

   public static ImmutableList<Pair<Integer, ? extends BehaviorControl<? super Villager>>> getRaidPackage(VillagerProfession profession, float speed) {
      return ImmutableList.of(getMinimalLookBehavior(), Pair.of(0, BehaviorBuilder.m_258047_(BehaviorBuilder.m_257433_(VanillaBehaviorPackages::raidWon), TriggerGate.m_257503_(ImmutableList.of(Pair.of(MoveToSkySeeingSpot.m_257507_(speed), 5), Pair.of(VillageBoundRandomStroll.m_257910_(speed), 2))))), Pair.of(0, new CelebrateVillagersSurvivedRaid(600, 600)), Pair.of(2, BehaviorBuilder.m_258047_(BehaviorBuilder.m_257433_(VanillaBehaviorPackages::hasActiveRaid), LocateHidingPlace.m_258090_(24, speed, 1))), Pair.of(99, ResetRaidStatus.m_257468_()));
   }

   public static ImmutableList<Pair<Integer, ? extends BehaviorControl<? super Villager>>> getHidePackage(VillagerProfession profession, float speed) {
      return ImmutableList.of(getMinimalLookBehavior(), Pair.of(0, SetHiddenState.m_257713_(15, 3)), Pair.of(1, LocateHidingPlace.m_258090_(32, speed, 2)));
   }

   public static Pair<Integer, BehaviorControl<LivingEntity>> getMinimalLookBehavior() {
      return Pair.of(5, new RunOne(ImmutableList.of(Pair.of(SetEntityLookTarget.m_258096_(EntityType.f_20492_, 8.0F), 2), Pair.of(SetEntityLookTarget.m_258096_(EntityType.f_20532_, 8.0F), 2), Pair.of(new DoNothing(30, 60), 8))));
   }

   public static Pair<Integer, BehaviorControl<LivingEntity>> getFullLookBehavior() {
      return Pair.of(5, new RunOne(ImmutableList.of(Pair.of(SetEntityLookTarget.m_258096_(EntityType.f_20553_, 8.0F), 8), Pair.of(SetEntityLookTarget.m_258096_(EntityType.f_20492_, 8.0F), 2), Pair.of(SetEntityLookTarget.m_258096_(EntityType.f_20532_, 8.0F), 2), Pair.of(SetEntityLookTarget.m_257381_(MobCategory.CREATURE, 8.0F), 1), Pair.of(SetEntityLookTarget.m_257381_(MobCategory.WATER_CREATURE, 8.0F), 1), Pair.of(SetEntityLookTarget.m_257381_(MobCategory.AXOLOTLS, 8.0F), 1), Pair.of(SetEntityLookTarget.m_257381_(MobCategory.UNDERGROUND_WATER_CREATURE, 8.0F), 1), Pair.of(SetEntityLookTarget.m_257381_(MobCategory.WATER_AMBIENT, 8.0F), 1), Pair.of(SetEntityLookTarget.m_257381_(MobCategory.MONSTER, 8.0F), 1), Pair.of(new DoNothing(30, 60), 2))));
   }

   private static boolean hasActiveRaid(ServerLevel world, LivingEntity entity) {
      Raid raid = world.m_8832_(entity.m_20183_());
      return raid != null && raid.m_37782_() && !raid.m_37767_() && !raid.m_37768_();
   }

   private static boolean raidWon(ServerLevel world, LivingEntity entity) {
      Raid raid = world.m_8832_(entity.m_20183_());
      return raid != null && raid.m_37767_();
   }
}
