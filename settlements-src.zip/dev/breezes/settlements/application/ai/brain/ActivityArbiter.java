package dev.breezes.settlements.application.ai.brain;

import dev.breezes.settlements.application.ai.planning.PlanRuntimeState;
import dev.breezes.settlements.bootstrap.registry.activities.ActivityRegistry;
import dev.breezes.settlements.domain.ai.catalog.BehaviorPlanningMetadata;
import dev.breezes.settlements.domain.ai.planning.DayPlan;
import dev.breezes.settlements.domain.ai.planning.DayPlanActivityBlock;
import dev.breezes.settlements.domain.ai.planning.DayPlanActivityContext;
import dev.breezes.settlements.domain.ai.planning.DayPlanSchedule;
import dev.breezes.settlements.domain.ai.planning.PlanSlot;
import dev.breezes.settlements.domain.ai.planning.PlanSlotStatus;
import dev.breezes.settlements.domain.ai.schedule.ScheduleProfile;
import dev.breezes.settlements.domain.ai.threat.ThreatVerdict;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.domain.time.CivilTime;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.Tickable;
import dev.breezes.settlements.domain.world.WorldCalendar;
import dev.breezes.settlements.infrastructure.compat.CompatMath;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.Optional;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.raid.Raid;
import net.minecraft.world.entity.schedule.Activity;

public final class ActivityArbiter {
   private static final Set<Activity> REACTIVE_ACTIVITIES;
   private static final ClockTicks EVALUATION_INTERVAL;
   private static final ClockTicks BELL_HIDE_DURATION;
   private final BaseVillager villager;
   private final Tickable cadence;
   @Nullable
   private ThreatVerdict lastEvaluatedVerdict;
   @Nullable
   private Activity activityAfterLastEvaluation;

   ActivityArbiter(@Nonnull BaseVillager villager) {
      this.villager = villager;
      this.cadence = Tickable.staggered(EVALUATION_INTERVAL);
   }

   public static boolean isReactive(@Nonnull Activity activity) {
      return REACTIVE_ACTIVITIES.contains(activity);
   }

   public static boolean isRaidWaveLive(@Nullable Raid raid) {
      return determineRaidActivity(raid) == ActivityRegistry.RAID_HIDE;
   }

   public static boolean isRaidAwaitingWave(@Nullable Raid raid) {
      return determineRaidActivity(raid) == Activity.f_37986_;
   }

   void tick(@Nonnull ThreatVerdict verdict) {
      Brain<Villager> brain = this.villager.m_6274_();
      boolean cadenceElapsed = this.cadence.tickCheckAndReset((double)1.0F);
      boolean verdictChanged = verdict != this.lastEvaluatedVerdict;
      boolean changedByAnotherWriter = this.activityAfterLastEvaluation == null || !brain.m_21954_(this.activityAfterLastEvaluation);
      if (cadenceElapsed || verdictChanged || changedByAnotherWriter) {
         ServerLevel level = (ServerLevel)this.villager.m_9236_();
         Activity desired = this.determineDesiredActivity(level, verdict);
         if (!brain.m_21954_(desired)) {
            if (desired == Activity.f_37984_ || desired == ActivityRegistry.COMBAT) {
               brain.m_21936_(MemoryModuleType.f_26377_);
               brain.m_21936_(MemoryModuleType.f_26370_);
               brain.m_21936_(MemoryModuleType.f_26371_);
               brain.m_21936_(MemoryModuleType.f_26374_);
            }

            brain.m_21889_(desired);
         }

         this.lastEvaluatedVerdict = verdict;
         this.activityAfterLastEvaluation = (Activity)brain.m_21968_().orElse((Object)null);
      }

   }

   private Activity determineDesiredActivity(@Nonnull ServerLevel level, @Nonnull ThreatVerdict verdict) {
      if (verdict == ThreatVerdict.COMBAT) {
         return ActivityRegistry.COMBAT;
      } else {
         Activity raidActivity = determineRaidActivity(level.m_8832_(this.villager.m_20183_()));
         if (verdict == ThreatVerdict.PANIC) {
            return raidActivity == ActivityRegistry.RAID_HIDE ? ActivityRegistry.RAID_HIDE : Activity.f_37984_;
         } else if (raidActivity != null) {
            return raidActivity;
         } else {
            boolean heardBellRecently = this.villager.m_6274_().m_21952_(MemoryModuleType.f_26325_).filter((bellTime) -> level.m_46467_() < bellTime + BELL_HIDE_DURATION.getTicks()).isPresent();
            if (heardBellRecently) {
               return Activity.f_37987_;
            } else {
               return this.villager.m_6162_() ? this.determineBabyDailyActivity(level) : this.determineAdultDailyActivity(level);
            }
         }
      }
   }

   @Nullable
   private static Activity determineRaidActivity(@Nullable Raid raid) {
      if (raid != null && !raid.m_37762_() && !raid.m_37768_()) {
         if (raid.m_37767_()) {
            return ActivityRegistry.RAID_CELEBRATE;
         } else {
            return raid.m_37757_() && !raid.m_37749_() ? ActivityRegistry.RAID_HIDE : Activity.f_37986_;
         }
      } else {
         return null;
      }
   }

   private Activity determineBabyDailyActivity(@Nonnull ServerLevel level) {
      int timeOfDay = Math.floorMod(level.m_46468_(), 24000);
      return this.villager.m_6274_().m_21932_().m_38019_(timeOfDay);
   }

   private Activity determineAdultDailyActivity(@Nonnull ServerLevel level) {
      DayPlan plan = this.villager.getDayPlan();
      if (plan == null) {
         return fallbackActivity(this.villager.getProfession(), level.m_46468_());
      } else {
         DayPlanSchedule schedule = plan.getSchedule();
         int nowCivil = WorldCalendar.civilOffsetWithin(plan.getCalendarDay(), level.m_46468_());
         if (isOutsideAuthoredDay(schedule, nowCivil)) {
            return Activity.f_37982_;
         } else {
            Optional<Activity> activeSlotActivity = activeSlotActivity(plan, this.villager.getPlanRuntimeState());
            return (Activity)activeSlotActivity.orElseGet(() -> (Activity)blockActivity(schedule, nowCivil).orElse(Activity.f_37979_));
         }
      }
   }

   private static Optional<Activity> activeSlotActivity(@Nonnull DayPlan currentPlan, @Nonnull PlanRuntimeState runtime) {
      Optional<PlanSlot> currentSlot = currentPlan.getCurrentSlot();
      if (!currentSlot.isEmpty() && ((PlanSlot)currentSlot.get()).getStatus() == PlanSlotStatus.ACTIVE) {
         BehaviorPlanningMetadata descriptor = runtime.getCurrentDescriptor();
         if (descriptor == null) {
            return Optional.empty();
         } else {
            Optional var10000;
            switch (descriptor.getCategory()) {
               case WORK:
                  var10000 = Optional.of(Activity.f_37980_);
                  break;
               case SOCIAL:
                  var10000 = Optional.of(Activity.f_37983_);
                  break;
               case SELF_CARE:
               case LEISURE:
               case COMBAT:
                  var10000 = Optional.empty();
                  break;
               default:
                  throw new IncompatibleClassChangeError();
            }

            return var10000;
         }
      } else {
         return Optional.empty();
      }
   }

   private static Optional<Activity> blockActivity(@Nonnull DayPlanSchedule schedule, int nowCivil) {
      return schedule.activityBlocks().stream().filter((block) -> contains(block, nowCivil)).findFirst().map((block) -> toMinecraftActivity(block.context()));
   }

   private static boolean contains(@Nonnull DayPlanActivityBlock block, int nowCivil) {
      return nowCivil >= block.startTick() && nowCivil < block.endTick();
   }

   private static boolean isOutsideAuthoredDay(@Nonnull DayPlanSchedule schedule, int nowCivil) {
      return nowCivil >= schedule.bedtimeTick() || nowCivil < schedule.wakeTick();
   }

   private static Activity toMinecraftActivity(@Nonnull DayPlanActivityContext context) {
      Activity var10000;
      switch (context) {
         case WORK -> var10000 = Activity.f_37980_;
         case MEET -> var10000 = Activity.f_37983_;
         case IDLE -> var10000 = Activity.f_37979_;
         case REST -> var10000 = Activity.f_37982_;
         default -> throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   private static Activity fallbackActivity(@Nonnull VillagerProfessionKey profession, long dayTime) {
      ScheduleProfile profile = ScheduleProfile.defaultFor(profession);
      int wakeCivil = CivilTime.civilFromMcTick(profile.defaultWakeTick());
      int bedtimeCivil = CivilTime.civilFromMcTick(profile.defaultSleepTick());
      int nowCivil = CivilTime.civilFromDayTime(dayTime);
      if (nowCivil >= wakeCivil && nowCivil < bedtimeCivil) {
         int workStartCivil = CivilTime.civilFromMcTick(profile.workStartTick());
         int workEndCivil = CivilTime.civilFromMcTick(profile.workEndTick());
         if (workStartCivil == workEndCivil) {
            return Activity.f_37979_;
         } else {
            int workStart = Math.min(workStartCivil, bedtimeCivil);
            int workEnd = CompatMath.clamp(workEndCivil, workStart, bedtimeCivil);
            if (nowCivil < workStart) {
               return Activity.f_37979_;
            } else {
               return nowCivil < workEnd ? Activity.f_37980_ : Activity.f_37983_;
            }
         }
      } else {
         return Activity.f_37982_;
      }
   }

   static {
      REACTIVE_ACTIVITIES = Set.of(ActivityRegistry.COMBAT, Activity.f_37984_, Activity.f_37986_, ActivityRegistry.RAID_HIDE, ActivityRegistry.RAID_CELEBRATE, Activity.f_37987_);
      EVALUATION_INTERVAL = ClockTicks.seconds((double)1.0F);
      BELL_HIDE_DURATION = ClockTicks.seconds((double)15.0F);
   }
}
