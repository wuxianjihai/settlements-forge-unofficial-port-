package dev.breezes.settlements.application.ai.brain;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.mojang.datafixers.util.Pair;
import dev.breezes.settlements.infrastructure.minecraft.behavior.ambient.AmbientBehaviors;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.behavior.BehaviorControl;
import net.minecraft.world.entity.ai.behavior.DoNothing;
import net.minecraft.world.entity.ai.behavior.GateBehavior;
import net.minecraft.world.entity.ai.behavior.GiveGiftToHero;
import net.minecraft.world.entity.ai.behavior.GoToClosestVillage;
import net.minecraft.world.entity.ai.behavior.InsideBrownianWalk;
import net.minecraft.world.entity.ai.behavior.InteractWith;
import net.minecraft.world.entity.ai.behavior.JumpOnBed;
import net.minecraft.world.entity.ai.behavior.RunOne;
import net.minecraft.world.entity.ai.behavior.SetClosestHomeAsWalkTarget;
import net.minecraft.world.entity.ai.behavior.SetLookAndInteract;
import net.minecraft.world.entity.ai.behavior.SetWalkTargetFromBlockMemory;
import net.minecraft.world.entity.ai.behavior.SetWalkTargetFromLookTarget;
import net.minecraft.world.entity.ai.behavior.ShowTradesToPlayer;
import net.minecraft.world.entity.ai.behavior.SleepInBed;
import net.minecraft.world.entity.ai.behavior.SocializeAtBell;
import net.minecraft.world.entity.ai.behavior.StrollAroundPoi;
import net.minecraft.world.entity.ai.behavior.StrollToPoi;
import net.minecraft.world.entity.ai.behavior.StrollToPoiList;
import net.minecraft.world.entity.ai.behavior.TradeWithVillager;
import net.minecraft.world.entity.ai.behavior.TriggerGate;
import net.minecraft.world.entity.ai.behavior.ValidateNearbyPoi;
import net.minecraft.world.entity.ai.behavior.VillageBoundRandomStroll;
import net.minecraft.world.entity.ai.behavior.VillagerMakeLove;
import net.minecraft.world.entity.ai.behavior.WorkAtComposter;
import net.minecraft.world.entity.ai.behavior.WorkAtPoi;
import net.minecraft.world.entity.ai.behavior.GateBehavior.OrderPolicy;
import net.minecraft.world.entity.ai.behavior.GateBehavior.RunningPolicy;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.memory.MemoryStatus;
import net.minecraft.world.entity.ai.village.poi.PoiTypes;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;

public final class VanillaAmbientBehaviorPackages {
   private static final float STROLL_SPEED_MODIFIER = 0.4F;

   public static ImmutableList<Pair<Integer, ? extends BehaviorControl<? super Villager>>> getAmbientWorkPackage(VillagerProfession profession, float speed) {
      BehaviorControl<? super Villager> workAtPoi = (BehaviorControl<? super Villager>)(profession == VillagerProfession.f_35590_ ? new WorkAtComposter() : new WorkAtPoi());
      ArrayList<Pair<? extends BehaviorControl<? super Villager>, Integer>> gatedWorkChoiceBehaviors = new ArrayList();
      gatedWorkChoiceBehaviors.addAll(List.of(Pair.of(workAtPoi, 10), Pair.of(StrollAroundPoi.m_257894_(MemoryModuleType.f_26360_, 0.4F, 4), 2), Pair.of(StrollToPoi.m_258086_(MemoryModuleType.f_26360_, 0.4F, 1, 10), 5), Pair.of(StrollToPoiList.m_257487_(MemoryModuleType.f_26363_, speed, 1, 6, MemoryModuleType.f_26360_), 5)));
      return ImmutableList.of(VanillaBehaviorPackages.getMinimalLookBehavior(), Pair.of(2, AmbientBehaviors.gated(SetWalkTargetFromBlockMemory.m_257972_(MemoryModuleType.f_26360_, speed, 9, 100, 1200))), Pair.of(3, ValidateNearbyPoi.m_257857_(profession.f_219628_(), MemoryModuleType.f_26360_)), Pair.of(3, AmbientBehaviors.gated(new GiveGiftToHero(100))), Pair.of(5, AmbientBehaviors.gated(new RunOne(gatedWorkChoiceBehaviors))), Pair.of(10, new ShowTradesToPlayer(400, 1600)), Pair.of(10, AmbientBehaviors.gated(SetLookAndInteract.m_257430_(EntityType.f_20532_, 4))));
   }

   public static ImmutableList<Pair<Integer, ? extends BehaviorControl<? super Villager>>> getAmbientRestPackage(float speed) {
      return ImmutableList.of(VanillaBehaviorPackages.getMinimalLookBehavior(), Pair.of(2, SetWalkTargetFromBlockMemory.m_257972_(MemoryModuleType.f_26359_, speed, 1, 150, 1200)), Pair.of(3, ValidateNearbyPoi.m_257857_((poiType) -> poiType.m_203565_(PoiTypes.f_218060_), MemoryModuleType.f_26359_)), Pair.of(3, new SleepInBed()), Pair.of(5, new RunOne(ImmutableMap.of(MemoryModuleType.f_26359_, MemoryStatus.VALUE_ABSENT), ImmutableList.of(Pair.of(SetClosestHomeAsWalkTarget.m_257524_(speed), 1), Pair.of(InsideBrownianWalk.m_258053_(speed), 4), Pair.of(GoToClosestVillage.m_257375_(speed, 4), 2), Pair.of(new DoNothing(20, 40), 2)))));
   }

   public static ImmutableList<Pair<Integer, ? extends BehaviorControl<? super Villager>>> getAmbientMeetPackage(float speed) {
      return ImmutableList.of(VanillaBehaviorPackages.getFullLookBehavior(), Pair.of(2, AmbientBehaviors.gated(TriggerGate.m_257503_(ImmutableList.of(Pair.of(StrollAroundPoi.m_257894_(MemoryModuleType.f_26362_, 0.4F, 40), 2), Pair.of(SocializeAtBell.m_257875_(), 2))))), Pair.of(2, AmbientBehaviors.gated(SetWalkTargetFromBlockMemory.m_257972_(MemoryModuleType.f_26362_, speed, 6, 100, 200))), Pair.of(3, AmbientBehaviors.gated(new GiveGiftToHero(100))), Pair.of(3, ValidateNearbyPoi.m_257857_((poiType) -> poiType.m_203565_(PoiTypes.f_218061_), MemoryModuleType.f_26362_)), Pair.of(3, AmbientBehaviors.gated(new GateBehavior(ImmutableMap.of(), ImmutableSet.of(MemoryModuleType.f_26374_), OrderPolicy.ORDERED, RunningPolicy.RUN_ONE, ImmutableList.of(Pair.of(new TradeWithVillager(), 1))))), Pair.of(10, new ShowTradesToPlayer(400, 1600)), Pair.of(10, AmbientBehaviors.gated(SetLookAndInteract.m_257430_(EntityType.f_20532_, 4))));
   }

   public static ImmutableList<Pair<Integer, ? extends BehaviorControl<? super Villager>>> getAmbientIdlePackage(float speed) {
      List<Pair<Integer, ? extends BehaviorControl<? super Villager>>> idleBehaviors = new ArrayList();
      idleBehaviors.addAll(List.of(VanillaBehaviorPackages.getFullLookBehavior(), Pair.of(3, AmbientBehaviors.gated(new GiveGiftToHero(100))), Pair.of(3, AmbientBehaviors.gated(SetLookAndInteract.m_257430_(EntityType.f_20532_, 4))), Pair.of(3, new ShowTradesToPlayer(400, 1600)), Pair.of(3, AmbientBehaviors.gated(new GateBehavior(ImmutableMap.of(), ImmutableSet.of(MemoryModuleType.f_26374_), OrderPolicy.ORDERED, RunningPolicy.RUN_ONE, ImmutableList.of(Pair.of(new TradeWithVillager(), 1))))), Pair.of(3, AmbientBehaviors.gated(new GateBehavior(ImmutableMap.of(), ImmutableSet.of(MemoryModuleType.f_26375_), OrderPolicy.ORDERED, RunningPolicy.RUN_ONE, ImmutableList.of(Pair.of(new VillagerMakeLove(), 1)))))));
      ArrayList<Pair<? extends BehaviorControl<? super Villager>, Integer>> idleChoiceBehaviors = new ArrayList();
      idleChoiceBehaviors.addAll(List.of(Pair.of(InteractWith.m_258079_(EntityType.f_20492_, 8, MemoryModuleType.f_26374_, speed, 2), 2), Pair.of(InteractWith.m_257746_(EntityType.f_20492_, 8, AgeableMob::m_35506_, AgeableMob::m_35506_, MemoryModuleType.f_26375_, speed, 2), 1), Pair.of(InteractWith.m_258079_(EntityType.f_20553_, 8, MemoryModuleType.f_26374_, speed, 2), 1), Pair.of(VillageBoundRandomStroll.m_257910_(speed), 1), Pair.of(SetWalkTargetFromLookTarget.m_257764_(speed, 2), 1), Pair.of(new JumpOnBed(speed), 1), Pair.of(new DoNothing(30, 60), 1)));
      idleBehaviors.add(Pair.of(2, AmbientBehaviors.gated(new RunOne(idleChoiceBehaviors))));
      return ImmutableList.copyOf(idleBehaviors);
   }
}
