package dev.breezes.settlements.application.ai.brain;

import dev.breezes.settlements.application.ai.threat.IThreatResponse;
import dev.breezes.settlements.application.ai.threat.ThreatAssessmentState;
import dev.breezes.settlements.bootstrap.registry.attachments.AttachmentRegistry;
import dev.breezes.settlements.di.SettlementsDagger;
import dev.breezes.settlements.domain.ai.memory.MemoryAccess;
import dev.breezes.settlements.domain.ai.memory.MemoryType;
import dev.breezes.settlements.domain.ai.memory.SensedSiteReport;
import dev.breezes.settlements.domain.ai.memory.SettlementsMemoryStore;
import dev.breezes.settlements.domain.ai.sensors.ISensor;
import dev.breezes.settlements.domain.ai.threat.ThreatVerdict;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.compat.AttachmentDataStore;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.level.Level;

public class VillagerBrain implements IVillagerBrain {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(VillagerBrain.class.getName());
   private final BaseVillager villager;
   private final MemoryAccess access;
   private final ThreatAssessmentState threats;
   private final ActivityArbiter activityArbiter;
   private List<ISensor<BaseVillager>> sensors;

   public VillagerBrain(@Nonnull BaseVillager villager) {
      this.villager = villager;
      this.access = new VillagerMemoryAccess(villager);
      this.threats = new ThreatAssessmentState();
      this.activityArbiter = new ActivityArbiter(villager);
      this.sensors = List.of();
   }

   public void initialize() {
      this.sensors = SettlementsDagger.serverOrThrow().villagerSensorFactories().stream().map((factory) -> factory.create(this.villager)).toList();
   }

   public void preVanillaAiStep() {
      SettlementsDagger.serverOrThrow().threatAssessor().tick(this.villager, this.threats);
      this.activityArbiter.tick((ThreatVerdict)Objects.requireNonNullElse(this.threats.verdict(), ThreatVerdict.HOLD));
   }

   public void postVanillaAiStep() {
      Level level = this.villager.m_9236_();

      for(ISensor<BaseVillager> sensor : this.sensors) {
         sensor.tick(1, level, this.villager);
      }

   }

   public IThreatResponse threats() {
      return this.threats;
   }

   public <T> Optional<T> getMemory(@Nonnull MemoryType<T> type) {
      return type.read(this.access);
   }

   public <T> void setMemory(@Nonnull MemoryType<T> type, @Nonnull T value) {
      type.write(this.access, value);
   }

   public <T> void setMemory(@Nonnull MemoryType<T> type, @Nonnull T value, @Nonnull ClockTicks expiration) {
      type.write(this.access, value, expiration.getTicks());
   }

   public void clearMemory(@Nonnull MemoryType<?> type) {
      type.clear(this.access);
   }

   public void updateSites(@Nonnull MemoryType.DecayingSpatialMemoryType type, @Nonnull SensedSiteReport report, long nowTick) {
      this.access.decayingStore().updateSpatialSites(type, report, nowTick);
   }

   private static final class VillagerMemoryAccess implements MemoryAccess {
      private final BaseVillager villager;

      private VillagerMemoryAccess(BaseVillager villager) {
         this.villager = villager;
      }

      public <T> Optional<T> vanillaGet(MemoryModuleType<T> module) {
         return this.villager.m_6274_().m_21952_(module);
      }

      public <T> void vanillaSet(MemoryModuleType<T> module, T value) {
         this.villager.m_6274_().m_21879_(module, value);
      }

      public <T> void vanillaSet(MemoryModuleType<T> module, T value, long expirationTicks) {
         this.villager.m_6274_().m_21882_(module, value, expirationTicks);
      }

      public void vanillaErase(MemoryModuleType<?> module) {
         this.villager.m_6274_().m_21936_(module);
      }

      public SettlementsMemoryStore decayingStore() {
         return (SettlementsMemoryStore)AttachmentDataStore.getData((Entity)this.villager, AttachmentRegistry.SETTLEMENTS_MEMORY_STORE);
      }

      @Nullable
      public ResourceKey<Level> serverDimensionOrNull() {
         Level level = this.villager.m_9236_();
         if (level instanceof ServerLevel serverLevel) {
            return serverLevel.m_46472_();
         } else {
            return null;
         }
      }

      public long nowTick() {
         return this.villager.m_9236_().m_46467_();
      }
   }
}
