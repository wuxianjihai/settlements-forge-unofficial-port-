package dev.breezes.settlements.application.ai.brain;

import dev.breezes.settlements.application.ai.threat.IThreatResponse;
import dev.breezes.settlements.domain.ai.brain.IBrain;

public interface IVillagerBrain extends IBrain {
   IThreatResponse threats();
}
