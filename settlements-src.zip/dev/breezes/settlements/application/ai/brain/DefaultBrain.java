package dev.breezes.settlements.application.ai.brain;

import dev.breezes.settlements.domain.ai.brain.IBrain;
import dev.breezes.settlements.domain.ai.memory.MemoryType;
import dev.breezes.settlements.domain.ai.memory.SensedSiteReport;
import dev.breezes.settlements.domain.ai.schedule.IScheduleProvider;
import dev.breezes.settlements.domain.time.ClockTicks;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;

public class DefaultBrain implements IBrain {
   protected final IScheduleProvider scheduleProvider = null;

   private DefaultBrain() {
   }

   public void initialize() {
   }

   public void preVanillaAiStep() {
   }

   public void postVanillaAiStep() {
   }

   public <T> Optional<T> getMemory(@Nonnull MemoryType<T> type) {
      return Optional.empty();
   }

   public <T> void setMemory(@Nonnull MemoryType<T> type, @Nonnull T value) {
   }

   public <T> void setMemory(@Nonnull MemoryType<T> type, @Nonnull T value, @Nonnull ClockTicks expiration) {
   }

   public void clearMemory(@Nonnull MemoryType<?> type) {
   }

   public void updateSites(@Nonnull MemoryType.DecayingSpatialMemoryType type, @Nonnull SensedSiteReport report, long nowTick) {
   }

   @Generated
   public static DefaultBrainBuilder builder() {
      return new DefaultBrainBuilder();
   }

   @Generated
   public static class DefaultBrainBuilder {
      @Generated
      DefaultBrainBuilder() {
      }

      @Generated
      public DefaultBrain build() {
         return new DefaultBrain();
      }

      @Generated
      public String toString() {
         return "DefaultBrain.DefaultBrainBuilder()";
      }
   }
}
