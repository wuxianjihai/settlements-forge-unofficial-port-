package dev.breezes.settlements.application.ai.behavior.usecases.villager.trading;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ui.bubble.VillagerBubbleService;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class TradeSessionPresenter_Factory implements Factory<TradeSessionPresenter> {
   private final Provider<VillagerBubbleService> villagerBubbleServiceProvider;

   private TradeSessionPresenter_Factory(Provider<VillagerBubbleService> villagerBubbleServiceProvider) {
      this.villagerBubbleServiceProvider = villagerBubbleServiceProvider;
   }

   public TradeSessionPresenter get() {
      return newInstance((VillagerBubbleService)this.villagerBubbleServiceProvider.get());
   }

   public static TradeSessionPresenter_Factory create(Provider<VillagerBubbleService> villagerBubbleServiceProvider) {
      return new TradeSessionPresenter_Factory(villagerBubbleServiceProvider);
   }

   public static TradeSessionPresenter newInstance(VillagerBubbleService villagerBubbleService) {
      return new TradeSessionPresenter(villagerBubbleService);
   }
}
