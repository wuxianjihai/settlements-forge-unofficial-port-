package dev.breezes.settlements.application.ai.behavior.usecases.villager.mason;

import dev.breezes.settlements.application.ai.behavior.runtime.timing.BehaviorTimingConfig;
import dev.breezes.settlements.application.config.validation.BehaviorCooldownValidator;
import dev.breezes.settlements.infrastructure.config.annotations.BehaviorConfig;
import dev.breezes.settlements.infrastructure.config.annotations.ConfigurationType;
import dev.breezes.settlements.infrastructure.config.annotations.doubles.DoubleConfig;
import dev.breezes.settlements.infrastructure.config.annotations.integers.IntegerConfig;
import dev.breezes.settlements.infrastructure.config.annotations.maps.MapConfig;
import dev.breezes.settlements.infrastructure.config.annotations.maps.MapEntry;
import java.util.Map;

@BehaviorConfig(
   name = "excavate_substrate",
   type = ConfigurationType.BEHAVIOR
)
public record ExcavateSubstrateConfig(@IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "precondition_check_cooldown_min",description = "Minimum interval (in seconds) between precondition checks",defaultValue = 10,min = 1) int preconditionCheckCooldownMin, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "precondition_check_cooldown_max",description = "Maximum interval (in seconds) between precondition checks",defaultValue = 20,min = 1) int preconditionCheckCooldownMax, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "behavior_cooldown_min",description = "Minimum behavior cooldown time (in seconds)",defaultValue = 30,min = 1) int behaviorCooldownMin, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "behavior_cooldown_max",description = "Maximum behavior cooldown time (in seconds)",defaultValue = 90,min = 1) int behaviorCooldownMax, @MapConfig(type = ConfigurationType.BEHAVIOR,identifier = "expertise_harvest_limit",description = "Map of villager expertise level to the maximum number of loose-ground shovel digs in one session.",deserializer = "StringToInteger",defaultValue = {@MapEntry(
   key = "novice",
   value = "2"
), @MapEntry(
   key = "apprentice",
   value = "2"
), @MapEntry(
   key = "journeyman",
   value = "3"
), @MapEntry(
   key = "expert",
   value = "3"
), @MapEntry(
   key = "master",
   value = "4"
)}) Map<String, Integer> expertiseHarvestLimit, @DoubleConfig(type = ConfigurationType.BEHAVIOR,identifier = "bare_handed_nugget_chance",description = "Chance per dig of finding a single iron nugget by hand when no iron shovel is held.",defaultValue = (double)0.75F,min = (double)0.0F,max = (double)1.0F) double bareHandedNuggetChance, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "experience_reward",description = "Villager experience awarded when the behavior completes successfully",defaultValue = 2,min = 0) int experienceReward) implements BehaviorTimingConfig {
   public ExcavateSubstrateConfig {
      BehaviorCooldownValidator.validateRanges(preconditionCheckCooldownMin, preconditionCheckCooldownMax, behaviorCooldownMin, behaviorCooldownMax);
   }
}
