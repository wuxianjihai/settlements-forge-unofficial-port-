package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals.feeding;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.usecases.villager.animals.OwnedWolfExistsCondition;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.compat.CompatTags;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.infrastructure.minecraft.entities.wolves.SettlementsWolf;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class FeedWolfBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(FeedWolfBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.5F;
   private static final int NAVIGATION_COMPLETION_DISTANCE = 2;
   private static final int REGEN_DURATION_TICKS = ClockTicks.minutes((double)10.0F).getTicksAsInt();
   private final FeedWolfConfig config;
   private final OwnedWolfExistsCondition ownedWolfCondition;
   @Nullable
   private SettlementsWolf targetWolf;
   @Nullable
   private ItemStack selectedMeat;

   public FeedWolfBehavior(@Nonnull FeedWolfConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.config = config;
      this.targetWolf = null;
      this.selectedMeat = null;
      this.ownedWolfCondition = new OwnedWolfExistsCondition(config.scanRangeHorizontal(), config.scanRangeVertical(), (ignored) -> true);
      this.preconditions.add(support.getDemandSignalService().requireAny(List.of(new ItemMatch.TagRef(CompatTags.FOODS_RAW_MEAT), new ItemMatch.TagRef(CompatTags.FOODS_COOKED_MEAT)), 1, 50, this.getClass().getSimpleName()));
      this.preconditions.add(this.ownedWolfCondition);
      this.initializeStateMachine(this.createControlStep(), FeedWolfBehavior.FeedStage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("FeedWolfBehavior").initialStage(FeedWolfBehavior.FeedStage.FEED_WOLF).stageStepMap(Map.of(FeedWolfBehavior.FeedStage.FEED_WOLF, this.createFeedWolfStep())).nextStage(FeedWolfBehavior.FeedStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   private BehaviorStep<BaseVillager> createFeedWolfStep() {
      TimeBasedStep<BaseVillager> interactStep = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.of(12L).asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).onEnd(this::performFeed).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.5F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 2)).actionStep(interactStep).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      this.targetWolf = null;
      this.selectedMeat = null;
      if (!this.ownedWolfCondition.test(villager)) {
         this.requestStop("No owned wolves within range");
      } else {
         this.targetWolf = (SettlementsWolf)this.ownedWolfCondition.getTargets().stream().findFirst().orElse((Object)null);
         if (this.targetWolf == null) {
            this.requestStop("Chosen hurt wolf is null");
         } else {
            this.selectedMeat = (ItemStack)this.findFirstMeatRepresentative(villager.getSettlementsInventory()).orElse((Object)null);
            if (this.selectedMeat == null && !GeneralConfig.bypassInventoryRequirements) {
               this.requestStop("No meat found in inventory at behavior start");
            } else {
               if (this.selectedMeat != null) {
                  villager.setHeldItem(this.selectedMeat.m_41777_());
               }

               context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.targetWolf)));
            }
         }
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      villager.getNavigationManager().stop();
      this.targetWolf = null;
      this.selectedMeat = null;
   }

   private StepResult performFeed(@Nonnull BehaviorContext<BaseVillager> context) {
      if (this.targetWolf != null && this.targetWolf.m_6084_()) {
         this.targetWolf.m_5634_(this.config.healAmount());
         this.targetWolf.m_7292_(new MobEffectInstance(MobEffects.f_19605_, REGEN_DURATION_TICKS, 0));
         Location wolfLoc = Location.fromEntity(this.targetWolf, false);
         ParticleRegistry.breedHearts(wolfLoc);
         if (this.selectedMeat != null && !this.selectedMeat.m_41619_()) {
            wolfLoc.displayParticles(new ItemParticleOption(ParticleTypes.f_123752_, this.selectedMeat.m_41777_()), 6, 0.2, 0.2, 0.2, 0.02);
         }

         wolfLoc.playSound(SoundEvents.f_11912_, 0.8F, 1.0F, SoundSource.NEUTRAL);
         this.consumeMeat(context.getInitiator());
         BehaviorOutcome feedOutcome = BehaviorOutcome.forDeed(WorldEventType.WOLF_FED, (String)null);
         feedOutcome.markSucceeded();
         context.declarePrimaryDeed(feedOutcome);
         return StepResult.noOp();
      } else {
         return StepResult.complete();
      }
   }

   private void consumeMeat(@Nonnull BaseVillager villager) {
      if (this.selectedMeat != null) {
         villager.getSettlementsInventory().consume((ItemStack)this.selectedMeat, 1);
      }
   }

   private Optional<ItemStack> findFirstMeatRepresentative(@Nonnull VillagerInventory inventory) {
      return inventory.findFirst((stack) -> stack.m_204117_(CompatTags.FOODS_RAW_MEAT) || stack.m_204117_(CompatTags.FOODS_COOKED_MEAT));
   }

   private static enum FeedStage implements StageKey {
      FEED_WOLF,
      END;

      // $FF: synthetic method
      private static FeedStage[] $values() {
         return new FeedStage[]{FEED_WOLF, END};
      }
   }
}
