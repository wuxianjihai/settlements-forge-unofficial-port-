package dev.breezes.settlements.application.ai.behavior.usecases.villager.courtship;

import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.List;
import java.util.Optional;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.behavior.BehaviorControl;
import net.minecraft.world.entity.ai.behavior.declarative.BehaviorBuilder;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

public final class BedCompetitorScan {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(BedCompetitorScan.class.getName());
   private static final ClockTicks SCAN_INTERVAL = ClockTicks.seconds((double)10.0F);

   private BedCompetitorScan() {
   }

   public static BehaviorControl<Villager> create() {
      ScanThrottle throttle = new ScanThrottle();
      return BehaviorBuilder.m_258034_((instance) -> instance.group(instance.m_257495_(MemoryModuleType.f_26359_), instance.m_257495_(MemoryModuleType.f_148204_)).apply(instance, (homeMemory, nearestLivingMemory) -> (level, villager, gameTime) -> {
               if (!throttle.shouldScan(gameTime)) {
                  return false;
               } else {
                  GlobalPos homePos = (GlobalPos)instance.m_258051_(homeMemory);
                  if (homePos.m_122640_() != level.m_46472_()) {
                     return false;
                  } else {
                     List<LivingEntity> nearby = (List)instance.m_258051_(nearestLivingMemory);
                     return settleContests(level, villager, homePos, nearby);
                  }
               }
            }));
   }

   private static boolean settleContests(ServerLevel level, Villager self, GlobalPos homePos, List<LivingEntity> nearby) {
      boolean settled = false;

      for(LivingEntity nearbyEntity : nearby) {
         if (nearbyEntity != self && nearbyEntity instanceof Villager competitor) {
            Optional<GlobalPos> competitorHome = competitor.m_6274_().m_21952_(MemoryModuleType.f_26359_);
            if (!competitorHome.isEmpty() && ((GlobalPos)competitorHome.get()).equals(homePos)) {
               settle(level, self, competitor, homePos);
               settled = true;
            }
         }
      }

      return settled;
   }

   private static void settle(ServerLevel level, Villager self, Villager competitor, GlobalPos homePos) {
      Villager keeper;
      Villager loser;
      if (self.m_20148_().compareTo(competitor.m_20148_()) < 0) {
         keeper = self;
         loser = competitor;
      } else {
         keeper = competitor;
         loser = self;
      }

      loser.m_6274_().m_21936_(MemoryModuleType.f_26359_);
      if (loser.m_5803_()) {
         loser.m_5796_();
      }

      if (keeper.m_5803_()) {
         setBedOccupied(level, homePos.m_122646_());
      }

      log.info("[villager-bed] Bed {} in {}: villager {} keeps it, villager {} forgets it", homePos.m_122646_(), homePos.m_122640_().m_135782_(), keeper.m_20148_(), loser.m_20148_());
   }

   private static void setBedOccupied(ServerLevel level, BlockPos bedPos) {
      BlockState state = level.m_8055_(bedPos);
      if (state.m_61138_(BlockStateProperties.f_61445_)) {
         level.m_7731_(bedPos, (BlockState)state.m_61124_(BlockStateProperties.f_61445_, true), 3);
      }

   }

   private static final class ScanThrottle {
      private long lastScanTick = Long.MIN_VALUE;

      boolean shouldScan(long gameTime) {
         if (gameTime - this.lastScanTick >= BedCompetitorScan.SCAN_INTERVAL.getTicks()) {
            this.lastScanTick = gameTime;
            return true;
         } else {
            return false;
         }
      }
   }
}
