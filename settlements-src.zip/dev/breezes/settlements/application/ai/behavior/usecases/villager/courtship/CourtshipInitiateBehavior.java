package dev.breezes.settlements.application.ai.behavior.usecases.villager.courtship;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.teardown.ReleaseHomePoiObligation;
import dev.breezes.settlements.application.ai.behavior.teardown.TemporaryArtifactHandle;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.ai.courtship.BedReservationService;
import dev.breezes.settlements.application.ai.courtship.ChoreographyTimeline;
import dev.breezes.settlements.application.ai.courtship.CourtshipChoreographyLibrary;
import dev.breezes.settlements.application.ai.courtship.CourtshipCloseReason;
import dev.breezes.settlements.application.ai.courtship.CourtshipPhase;
import dev.breezes.settlements.application.ai.courtship.CourtshipSelfMemoryRecorder;
import dev.breezes.settlements.application.ai.courtship.CourtshipSession;
import dev.breezes.settlements.application.ai.courtship.CourtshipSessionRegistry;
import dev.breezes.settlements.bootstrap.registry.memory.MemoryModuleTypeRegistry;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.EventOutcome;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventEmitter;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.level.Level;

public final class CourtshipInitiateBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(CourtshipInitiateBehavior.class.getName());
   private final CourtshipInitiateConfig config;
   private final CourtshipSessionRegistry sessionRegistry;
   private final BedReservationService bedReservationService;
   private final CourtshipPresenter courtshipPresenter;
   private final CourtshipChoreographyLibrary choreographyLibrary;
   private final WorldEventEmitter worldEventEmitter;
   private final CourtshipSelfMemoryRecorder selfMemoryRecorder;
   @Nullable
   private UUID activeSessionId;

   public CourtshipInitiateBehavior(@Nonnull CourtshipInitiateConfig config, @Nonnull BehaviorSupport support, @Nonnull CourtshipSessionRegistry sessionRegistry, @Nonnull BedReservationService bedReservationService, @Nonnull CourtshipPresenter courtshipPresenter, @Nonnull CourtshipChoreographyLibrary choreographyLibrary, @Nonnull CourtshipSelfMemoryRecorder selfMemoryRecorder) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.config = config;
      this.sessionRegistry = sessionRegistry;
      this.bedReservationService = bedReservationService;
      this.courtshipPresenter = courtshipPresenter;
      this.choreographyLibrary = choreographyLibrary;
      this.worldEventEmitter = support.getWorldEventEmitter();
      this.selfMemoryRecorder = selfMemoryRecorder;
      this.preconditions.add(this.canInitiateCourtship());
      this.initializeStateMachine(this.createControlStep(), CourtshipInitiateBehavior.Stage.CLOSED);
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      context.declarePrimaryDeed(BehaviorOutcome.silent());
      this.activeSessionId = null;
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      if (this.activeSessionId != null) {
         this.courtshipPresenter.presentEnd(villager, this.activeSessionId, world.m_46467_());
         this.sessionRegistry.getActiveSession(villager.m_20148_()).ifPresent((session) -> {
            CourtshipPhase phase = session.getPhase();
            if (phase != CourtshipPhase.COMPLETED && phase != CourtshipPhase.ABORTED) {
               this.sessionRegistry.closeSession(session.getSessionId(), CourtshipCloseReason.EXTERNAL_CANCEL);
            }

         });
      }

      this.activeSessionId = null;
   }

   private ICondition<BaseVillager> canInitiateCourtship() {
      return ICondition.<BaseVillager>named("can initiate courtship", (villager) -> this.selectCandidate(villager).isPresent());
   }

   private Optional<UUID> selectCandidate(@Nonnull BaseVillager villager) {
      if (this.sessionRegistry.getActiveSession(villager.m_20148_()).isPresent()) {
         return Optional.empty();
      } else if (!villager.m_35506_()) {
         return Optional.empty();
      } else {
         List<UUID> candidates = (List)villager.m_6274_().m_21952_((MemoryModuleType)MemoryModuleTypeRegistry.WILLING_COURTSHIP_PARTNERS.get()).orElse(List.of());
         return candidates.stream().filter((candidateId) -> villager.m_20148_().compareTo(candidateId) < 0).filter((candidateId) -> this.sessionRegistry.getActiveSession(candidateId).isEmpty()).filter((candidateId) -> !this.sessionRegistry.hasInviteFor(candidateId)).filter((candidateId) -> {
            Level patt7504$temp = villager.m_9236_();
            if (!(patt7504$temp instanceof ServerLevel serverLevel)) {
               return false;
            } else {
               BaseVillager candidate = (BaseVillager)resolveParticipant(serverLevel, candidateId).orElse((Object)null);
               return candidate != null && candidate.m_35506_();
            }
         }).findFirst();
      }
   }

   private StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("CourtshipInitiateBehavior").initialStage(CourtshipInitiateBehavior.Stage.SCAN_AND_INVITE).stageStepMap(Map.of(CourtshipInitiateBehavior.Stage.SCAN_AND_INVITE, this::scanAndInvite, CourtshipInitiateBehavior.Stage.WAIT_FOR_ACCEPT, this::waitForAccept, CourtshipInitiateBehavior.Stage.APPROACH, StayCloseStep.builder().closeEnoughDistance((double)1.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 2)).actionStep(this::onWithinApproachRange).build(), CourtshipInitiateBehavior.Stage.COURTSHIP, StayCloseStep.builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 2)).actionStep(this::tickCourtship).build(), CourtshipInitiateBehavior.Stage.BIRTH, this::birth)).nextStage(CourtshipInitiateBehavior.Stage.CLOSED).build();
   }

   private StepResult scanAndInvite(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager self = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      Level var4 = self.m_9236_();
      if (var4 instanceof ServerLevel serverLevel) {
         UUID partnerId = (UUID)this.selectCandidate(self).orElse((Object)null);
         if (partnerId == null) {
            return StepResult.complete();
         } else {
            BaseVillager partner = (BaseVillager)resolveParticipant(serverLevel, partnerId).orElse((Object)null);
            if (partner == null) {
               return StepResult.complete();
            } else {
               int placeholderDuration = 300;
               CourtshipSession session = this.sessionRegistry.sendInvite(self, partner, placeholderDuration, self.m_9236_().m_46467_());
               this.activeSessionId = session.getSessionId();
               this.worldEventEmitter.emitCourtshipInviteSent(self, partner.m_20148_(), session.getSessionId());
               return StepResult.transition(CourtshipInitiateBehavior.Stage.WAIT_FOR_ACCEPT);
            }
         }
      } else {
         return StepResult.fail("not-server-level");
      }
   }

   private StepResult waitForAccept(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager self = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      CourtshipSession session = (CourtshipSession)this.currentSession(self).orElse((Object)null);
      if (session == null) {
         return StepResult.complete();
      } else {
         CourtshipPhase phase = session.getPhase();
         if (phase != CourtshipPhase.ACCEPTED) {
            long now = self.m_9236_().m_46467_();
            long inviteTimeoutTicks = ClockTicks.seconds((double)15.0F).getTicks();
            return now - session.getPhaseEnteredGameTime() > inviteTimeoutTicks ? this.doAbort(self, session, CourtshipCloseReason.TIMEOUT) : StepResult.noOp();
         } else {
            Level var6 = self.m_9236_();
            if (var6 instanceof ServerLevel) {
               ServerLevel serverLevel = (ServerLevel)var6;
               BaseVillager partner = (BaseVillager)resolveParticipant(serverLevel, session.getReceiverId()).orElse((Object)null);
               if (partner == null) {
                  return this.doAbort(self, session, CourtshipCloseReason.ABORTED_PARTNER_GONE);
               } else {
                  context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(partner)));
                  session.transitionTo(CourtshipPhase.APPROACH, self.m_9236_().m_46467_());
                  return StepResult.transition(CourtshipInitiateBehavior.Stage.APPROACH);
               }
            } else {
               return this.doAbort(self, session, CourtshipCloseReason.EXTERNAL_CANCEL);
            }
         }
      }
   }

   private StepResult onWithinApproachRange(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager self = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      CourtshipSession session = (CourtshipSession)this.currentSession(self).orElse((Object)null);
      if (session == null) {
         return StepResult.complete();
      } else {
         int choreographyId = this.choreographyLibrary.selectRandom(self.m_217043_());
         session.setChoreographyId(choreographyId);
         ChoreographyTimeline timeline = this.choreographyLibrary.get(choreographyId);
         long now = self.m_9236_().m_46467_();
         session.beginCourtship(now, (int)timeline.totalDurationTicks());
         this.courtshipPresenter.presentApproach(session, self);
         return StepResult.transition(CourtshipInitiateBehavior.Stage.COURTSHIP);
      }
   }

   private StepResult tickCourtship(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager self = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      CourtshipSession session = (CourtshipSession)this.currentSession(self).orElse((Object)null);
      if (session == null) {
         return StepResult.complete();
      } else if (!self.m_35506_()) {
         return this.doAbort(self, session, CourtshipCloseReason.ABORTED_WILLINGNESS);
      } else {
         Level var5 = self.m_9236_();
         if (!(var5 instanceof ServerLevel)) {
            return this.doAbort(self, session, CourtshipCloseReason.EXTERNAL_CANCEL);
         } else {
            ServerLevel serverLevel = (ServerLevel)var5;
            BaseVillager partner = (BaseVillager)resolveParticipant(serverLevel, session.getReceiverId()).orElse((Object)null);
            if (partner != null && partner.m_35506_()) {
               ChoreographyTimeline timeline = this.choreographyLibrary.get(session.getChoreographyId());
               long elapsed = self.m_9236_().m_46467_() - session.getCourtshipStartGameTime();
               int targetBeat = 0;

               for(int i = timeline.beatCount() - 1; i >= 0; --i) {
                  if (timeline.beatStartTick(i, 0L) <= elapsed) {
                     targetBeat = i;
                     break;
                  }
               }

               if (targetBeat > session.getCurrentBeatIndex()) {
                  session.advanceBeat(targetBeat);
                  this.courtshipPresenter.presentBeat(session, self, targetBeat);
               }

               if (elapsed >= timeline.totalDurationTicks()) {
                  session.transitionTo(CourtshipPhase.BIRTH, self.m_9236_().m_46467_());
                  return StepResult.transition(CourtshipInitiateBehavior.Stage.BIRTH);
               } else {
                  return StepResult.noOp();
               }
            } else {
               return this.doAbort(self, session, CourtshipCloseReason.ABORTED_PARTNER_GONE);
            }
         }
      }
   }

   private StepResult birth(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager self = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      CourtshipSession session = (CourtshipSession)this.currentSession(self).orElse((Object)null);
      if (session == null) {
         return StepResult.complete();
      } else if (session.isResolved()) {
         return StepResult.complete();
      } else {
         Level var5 = self.m_9236_();
         if (var5 instanceof ServerLevel) {
            ServerLevel serverLevel = (ServerLevel)var5;
            BaseVillager partner = (BaseVillager)resolveParticipant(serverLevel, session.getReceiverId()).orElse((Object)null);
            if (partner == null) {
               return this.doAbort(self, session, CourtshipCloseReason.ABORTED_PARTNER_GONE);
            } else {
               boolean conceived = self.m_217043_().m_188501_() < (float)this.config.conceptionChancePercent() / 100.0F;
               if (!conceived) {
                  return this.resolveChildlessDate(context, session, self, partner);
               } else {
                  BlockPos primaryBed = (BlockPos)this.bedReservationService.tryClaimVacantHome(serverLevel, self).orElse((Object)null);
                  if (primaryBed == null) {
                     return this.doAbort(self, session, CourtshipCloseReason.ABORTED_NO_BED);
                  } else {
                     TemporaryArtifactHandle primaryHandle = context.getTeardownScope().track(new ReleaseHomePoiObligation(primaryBed));
                     BlockPos secondaryBed = null;
                     TemporaryArtifactHandle secondaryHandle = null;
                     if (self.m_217043_().m_188501_() < (float)this.config.twinsChancePercent() / 100.0F) {
                        secondaryBed = (BlockPos)this.bedReservationService.tryClaimVacantHome(serverLevel, self).orElse((Object)null);
                        if (secondaryBed != null) {
                           secondaryHandle = context.getTeardownScope().track(new ReleaseHomePoiObligation(secondaryBed));
                        }
                     }

                     BaseVillager primaryChild = this.spawnChild(serverLevel, self, partner, primaryBed);
                     if (primaryChild == null) {
                        return this.doAbort(self, session, CourtshipCloseReason.ABORTED_SPAWN_FAILED);
                     } else {
                        this.bedReservationService.assignHome(primaryChild, serverLevel, primaryBed);
                        primaryHandle.cancel();
                        if (secondaryBed != null) {
                           BaseVillager secondaryChild = this.spawnChild(serverLevel, self, partner, secondaryBed);
                           if (secondaryChild != null) {
                              this.bedReservationService.assignHome(secondaryChild, serverLevel, secondaryBed);
                              secondaryHandle.cancel();
                           }
                        }

                        this.applyBreedCooldown(self, partner);
                        session.markResolved();
                        this.courtshipPresenter.presentBirth(session, self, partner);
                        this.sessionRegistry.closeSession(session.getSessionId(), CourtshipCloseReason.COMPLETED);
                        BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.COURTSHIP_CHILD_BIRTH, (String)null);
                        outcome.recordSocialOutcome(session.getReceiverId(), session.getSessionId(), EventOutcome.SUCCESS, (String)null, (String)null);
                        context.declarePrimaryDeed(outcome);
                        return StepResult.complete();
                     }
                  }
               }
            }
         } else {
            return this.doAbort(self, session, CourtshipCloseReason.EXTERNAL_CANCEL);
         }
      }
   }

   private StepResult resolveChildlessDate(@Nonnull BehaviorContext<BaseVillager> context, @Nonnull CourtshipSession session, @Nonnull BaseVillager self, @Nonnull BaseVillager partner) {
      this.applyBreedCooldown(self, partner);
      session.markResolved();
      this.courtshipPresenter.presentDate(session, self, partner);
      this.sessionRegistry.closeSession(session.getSessionId(), CourtshipCloseReason.COMPLETED);
      BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.COURTSHIP_DATE_COMPLETED, (String)null);
      outcome.recordSocialOutcome(session.getReceiverId(), session.getSessionId(), EventOutcome.SUCCESS, (String)null, (String)null);
      context.declarePrimaryDeed(outcome);
      return StepResult.complete();
   }

   private void applyBreedCooldown(@Nonnull BaseVillager self, @Nonnull BaseVillager partner) {
      int breedCooldownTicks = ClockTicks.seconds((double)this.config.breedCooldownSeconds()).getTicksAsInt();
      self.m_146762_(breedCooldownTicks);
      partner.m_146762_(breedCooldownTicks);
   }

   @Nullable
   private BaseVillager spawnChild(@Nonnull ServerLevel level, @Nonnull BaseVillager parent, @Nonnull AgeableMob other, @Nonnull BlockPos bed) {
      BaseVillager child = parent.getBreedOffspring(level, other);
      if (child == null) {
         return null;
      } else {
         child.m_7678_(parent.m_20185_(), parent.m_20186_(), parent.m_20189_(), 0.0F, 0.0F);
         child.m_146762_(-24000);
         level.m_47205_(child);
         return child;
      }
   }

   private StepResult doAbort(@Nonnull BaseVillager self, @Nonnull CourtshipSession session, @Nonnull CourtshipCloseReason reason) {
      this.courtshipPresenter.presentAbort(session, self, reason);
      this.sessionRegistry.closeSession(session.getSessionId(), reason);
      if (reason == CourtshipCloseReason.TIMEOUT) {
         this.selfMemoryRecorder.recordPrivateFailure(self, session.getReceiverId(), "no one answered");
      }

      return StepResult.complete();
   }

   private Optional<CourtshipSession> currentSession(@Nonnull BaseVillager villager) {
      return this.sessionRegistry.getActiveSession(villager.m_20148_()).filter((s) -> this.activeSessionId == null || this.activeSessionId.equals(s.getSessionId()));
   }

   private static Optional<BaseVillager> resolveParticipant(@Nonnull Level level, @Nonnull UUID id) {
      if (level instanceof ServerLevel serverLevel) {
         Optional var10000 = Optional.ofNullable(serverLevel.m_8791_(id));
         Objects.requireNonNull(BaseVillager.class);
         var10000 = var10000.filter(BaseVillager.class::isInstance);
         Objects.requireNonNull(BaseVillager.class);
         return var10000.map(BaseVillager.class::cast);
      } else {
         return Optional.empty();
      }
   }

   public static enum Stage implements StageKey {
      SCAN_AND_INVITE,
      WAIT_FOR_ACCEPT,
      APPROACH,
      COURTSHIP,
      BIRTH,
      CLOSED;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{SCAN_AND_INVITE, WAIT_FOR_ACCEPT, APPROACH, COURTSHIP, BIRTH, CLOSED};
      }
   }
}
