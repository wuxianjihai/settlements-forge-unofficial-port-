package dev.breezes.settlements.application.ai.behavior.usecases.villager.smelting.blastore;

import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.domain.smelting.catalog.BlastOreRecipe;
import dev.breezes.settlements.domain.smelting.catalog.BlastOreRecipeRegistry;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

public class BlastRecipeAvailableCondition implements ICondition<BaseVillager> {
   private final BlastOreRecipeRegistry recipeRegistry;
   private List<BlastOreRecipe> validRecipes;

   public BlastRecipeAvailableCondition(@Nonnull BlastOreRecipeRegistry recipeRegistry) {
      this.recipeRegistry = recipeRegistry;
      this.validRecipes = List.of();
   }

   public boolean test(@Nullable BaseVillager villager) {
      this.validRecipes = List.of();
      if (villager == null) {
         return false;
      } else {
         VillagerInventory inventory = villager.getSettlementsInventory();
         this.validRecipes = this.recipeRegistry.allRecipes().stream().filter((recipe) -> {
            Item item = (Item)BuiltInRegistries.f_257033_.m_7745_(recipe.input());
            return item != Items.f_41852_ && inventory.count(item) >= recipe.inputCount();
         }).toList();
         return !this.validRecipes.isEmpty();
      }
   }

   @Generated
   public List<BlastOreRecipe> getValidRecipes() {
      return this.validRecipes;
   }
}
