package dev.breezes.settlements.application.ai.behavior.usecases.villager.nitwit;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.threat.CombatOption;
import dev.breezes.settlements.application.ai.threat.CombatReadiness;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.behavior.contracts.IBehavior;
import dev.breezes.settlements.domain.ai.catalog.BehaviorDisplayMetadata;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

@ServerScope
public final class EggCombatOption implements CombatOption {
   private static final double NERVE_CONTRIBUTION = 0.7;
   private static final double REACH_BLOCKS = (double)10.0F;
   private static final CombatReadiness NITWIT_READINESS = (hostile) -> true;
   private static final BehaviorDisplayMetadata DISPLAY_INFO = BehaviorDisplayMetadata.builder().displayNameKey("ui.settlements.behavior.combat.throw_eggs_at_hostile").iconItemId(new ResourceLocation("minecraft", "egg")).build();
   private final BehaviorSupport support;

   public double nerveContribution() {
      return 0.7;
   }

   public double reachBlocks() {
      return (double)10.0F;
   }

   @Nullable
   public CombatReadiness prepare(@Nonnull BaseVillager villager) {
      return VillagerProfessionKey.NITWIT.equals(villager.getProfession()) ? NITWIT_READINESS : null;
   }

   public IBehavior<BaseVillager> createBehavior(@Nonnull LivingEntity target) {
      return new ThrowEggsAtHostileBehavior(this.support, target, (double)10.0F);
   }

   public BehaviorDisplayMetadata displayInfo() {
      return DISPLAY_INFO;
   }

   @Inject
   EggCombatOption(BehaviorSupport support) {
      this.support = support;
   }
}
