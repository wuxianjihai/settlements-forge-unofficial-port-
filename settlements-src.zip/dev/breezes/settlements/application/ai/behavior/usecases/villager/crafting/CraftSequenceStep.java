package dev.breezes.settlements.application.ai.behavior.usecases.villager.crafting;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.AbstractStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.crafting.catalog.CraftIngredient;
import dev.breezes.settlements.domain.crafting.catalog.CraftRecipe;
import dev.breezes.settlements.domain.economy.catalog.ItemMatches;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class CraftSequenceStep extends AbstractStep<BaseVillager> {
   private static final int INPUT_BEAT_TICKS = ClockTicks.seconds(0.7).getTicksAsInt();
   private static final int OUTPUT_BEAT_TICKS = ClockTicks.seconds(0.8).getTicksAsInt();
   private static final int MAX_BEATS_PER_INPUT = 2;
   private static final int HELD_STACK_DISPLAY_CAP = 64;
   private final Supplier<CraftRecipe> currentRecipeSupplier;
   private final CraftBatchCalculator batchCalculator;
   private final Consumer<BaseVillager> experienceRewarder;
   private final StageKey endStage;
   private boolean prepared;
   private List<Beat> beats;
   private int beatIndex;
   private int ticksInBeat;
   @Nullable
   private Item outputItem;
   private int outputTotal;

   public CraftSequenceStep(@Nonnull String name, @Nonnull Supplier<CraftRecipe> currentRecipeSupplier, @Nonnull CraftBatchCalculator batchCalculator, @Nonnull Consumer<BaseVillager> experienceRewarder, @Nonnull StageKey endStage) {
      super(name);
      this.currentRecipeSupplier = currentRecipeSupplier;
      this.batchCalculator = batchCalculator;
      this.experienceRewarder = experienceRewarder;
      this.endStage = endStage;
      this.resetRunState();
   }

   protected StepResult doTick(@Nonnull BehaviorContext<BaseVillager> context) {
      if (!this.prepared) {
         StepResult preparation = this.prepare(context);
         if (preparation != null) {
            return preparation;
         }

         this.prepared = true;
      }

      if (this.beatIndex >= this.beats.size()) {
         return this.finish(context);
      } else {
         Beat beat = (Beat)this.beats.get(this.beatIndex);
         if (this.ticksInBeat == 0) {
            beat.action().accept(context);
         }

         ++this.ticksInBeat;
         if (this.ticksInBeat >= beat.holdTicks()) {
            ++this.beatIndex;
            this.ticksInBeat = 0;
         }

         return StepResult.noOp();
      }
   }

   @Nullable
   private StepResult prepare(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      CraftRecipe recipe = (CraftRecipe)this.currentRecipeSupplier.get();
      if (recipe == null) {
         return StepResult.transition(this.endStage);
      } else {
         VillagerInventory inventory = villager.getSettlementsInventory();
         List<ItemStack> inputVisuals = new ArrayList(recipe.inputs().size());

         for(CraftIngredient input : recipe.inputs()) {
            inputVisuals.add((ItemStack)inventory.findFirst((stack) -> ItemMatches.test(input.match(), stack)).orElse(ItemStack.f_41583_));
         }

         Optional<RecipeCommit.Result> committed = RecipeCommit.commit(context, recipe, this.batchCalculator, WorldEventType.GOODS_CRAFTED, this.experienceRewarder);
         if (committed.isEmpty()) {
            return StepResult.transition(this.endStage);
         } else {
            this.outputItem = ((RecipeCommit.Result)committed.get()).outputItem();
            this.outputTotal = ((RecipeCommit.Result)committed.get()).outputTotal();
            this.beats = new ArrayList();

            for(int i = 0; i < recipe.inputs().size(); ++i) {
               CraftIngredient input = (CraftIngredient)recipe.inputs().get(i);
               ItemStack visual = (ItemStack)inputVisuals.get(i);
               int beatCount = Math.min(input.count(), 2);

               for(int b = 0; b < beatCount; ++b) {
                  this.beats.add(new Beat(INPUT_BEAT_TICKS, (ctx) -> this.playInputBeat(ctx, visual)));
               }
            }

            this.beats.add(new Beat(OUTPUT_BEAT_TICKS, this::playOutputBeat));
            return null;
         }
      }
   }

   private void playInputBeat(@Nonnull BehaviorContext<BaseVillager> context, @Nonnull ItemStack visual) {
      BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      if (!visual.m_41619_()) {
         villager.setHeldItem(visual);
      }

      villager.triggerMotion(AnimationArchetype.INTERACT);
      Location.fromEntity(villager, true).displayParticles(ParticleTypes.f_123797_, 4, 0.2, 0.2, 0.2, 0.05);
   }

   private void playOutputBeat(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      villager.setHeldItem(new ItemStack(this.requireOutputItem(), Math.min(this.outputTotal, 64)));
      villager.triggerMotion(AnimationArchetype.INTERACT);
      Location origin = Location.fromEntity(villager, true);
      origin.displayParticles(ParticleTypes.f_123748_, 7, 0.3, 0.3, 0.3, 0.1);
      SoundRegistry.ITEM_POP_OUT.playGlobally(origin, SoundSource.BLOCKS);
   }

   private StepResult finish(@Nonnull BehaviorContext<BaseVillager> context) {
      ((BaseVillager)context.getInitiator()).getMinecraftEntity().clearHeldItem();
      return StepResult.complete();
   }

   private Item requireOutputItem() {
      if (this.outputItem == null) {
         throw new IllegalStateException("CraftSequenceStep output item accessed before preparation");
      } else {
         return this.outputItem;
      }
   }

   protected void doOnEnter() {
      this.resetRunState();
   }

   private void resetRunState() {
      this.prepared = false;
      this.beats = List.of();
      this.beatIndex = 0;
      this.ticksInBeat = 0;
      this.outputItem = null;
      this.outputTotal = 0;
   }

   private static record Beat(int holdTicks, Consumer<BehaviorContext<BaseVillager>> action) {
   }
}
