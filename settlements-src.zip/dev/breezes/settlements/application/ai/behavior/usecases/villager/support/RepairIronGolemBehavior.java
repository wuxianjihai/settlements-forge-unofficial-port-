package dev.breezes.settlements.application.ai.behavior.usecases.villager.support;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.items.ItemRegistry;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.conditions.PerceivedEntityExistsCondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.entities.Expertise;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public class RepairIronGolemBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(RepairIronGolemBehavior.class.getName());
   private static final ResourceLocation IRON_INGOT_ID = new ResourceLocation("minecraft", "iron_ingot");
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private static final float HEAL_AMOUNT = 25.0F;
   private static final int DEFAULT_REPAIR_ATTEMPTS = 1;
   private static final int BUFF_DURATION_TICKS = ClockTicks.minutes((double)20.0F).getTicksAsInt();
   private final RepairIronGolemConfig config;
   @Nullable
   private IronGolem targetToRepair;
   private int remainingRepairAttempts;
   private boolean shouldRewardExperience;

   public RepairIronGolemBehavior(RepairIronGolemConfig config, BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.preconditions.add(PerceivedEntityExistsCondition.builder().entityType(IronGolem.class).filter((villager, golem) -> this.isSufficientlyDamaged(golem)).completionRange(1).build());
      this.preconditions.add(support.getDemandSignalService().requireItem(new ItemMatch.ItemRef(IRON_INGOT_ID), 1, 50, this.getClass().getSimpleName()));
      this.targetToRepair = null;
      this.remainingRepairAttempts = 0;
      this.shouldRewardExperience = false;
      this.initializeStateMachine(this.createControlStep(), RepairIronGolemBehavior.RepairStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("RepairIronGolemBehavior").initialStage(RepairIronGolemBehavior.RepairStage.REPAIR_GOLEM).stageStepMap(Map.of(RepairIronGolemBehavior.RepairStage.REPAIR_GOLEM, this.createRepairStep())).nextStage(RepairIronGolemBehavior.RepairStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   private BehaviorStep<BaseVillager> createRepairStep() {
      TimeBasedStep<BaseVillager> repairTick = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.of(20L).asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.REPAIR_IRON_GOLEM);
         ((BaseVillager)ctx.getInitiator()).setHeldItem(((Item)ItemRegistry.HAMMER.get()).m_7968_());
         ((BaseVillager)ctx.getInitiator()).setOffhandItem(new ItemStack(Items.f_42416_));
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(8L), (ctx) -> {
         if (this.targetToRepair != null && this.targetToRepair.m_6084_()) {
            if (!((BaseVillager)ctx.getInitiator()).getSettlementsInventory().consumeIfRequired(Items.f_42416_, 1, GeneralConfig.bypassInventoryRequirements)) {
               return StepResult.complete();
            } else {
               this.targetToRepair.m_5634_(25.0F);
               this.applyProfessionBuff((BaseVillager)ctx.getInitiator());
               this.shouldRewardExperience = true;
               if (ctx.primaryDeed().isEmpty()) {
                  BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.GOLEM_REPAIRED, (String)null);
                  outcome.markSucceeded();
                  ctx.declarePrimaryDeed(outcome);
               }

               Location targetLocation = Location.fromEntity(this.targetToRepair, false);
               SoundRegistry.REPAIR_IRON_GOLEM.playGlobally(targetLocation, SoundSource.NEUTRAL);
               ParticleRegistry.repairIronGolem(targetLocation);
               return --this.remainingRepairAttempts <= 0 ? StepResult.complete() : StepResult.transition(RepairIronGolemBehavior.RepairStage.REPAIR_GOLEM);
            }
         } else {
            return StepResult.complete();
         }
      }).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 1)).actionStep(repairTick).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      Optional<IronGolem> targetCandidate = this.findClosestDamagedIronGolem(villager);
      if (targetCandidate.isEmpty()) {
         this.requestStop("No damaged iron golem found within range");
      } else {
         this.targetToRepair = (IronGolem)targetCandidate.get();
         Expertise expertise = villager.getMinecraftEntity().getExpertise();
         int maxAttempts = (Integer)this.config.expertiseRepairLimit().getOrDefault(expertise.getConfigName(), 1);
         int ingotsAvailable = villager.getSettlementsInventory().count(Items.f_42416_);
         this.remainingRepairAttempts = GeneralConfig.bypassInventoryRequirements ? maxAttempts : Math.min(maxAttempts, ingotsAvailable);
         if (this.remainingRepairAttempts <= 0) {
            this.requestStop("No iron ingots available at behavior start");
         } else {
            this.shouldRewardExperience = false;
            context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.targetToRepair)));
         }
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      return this.targetToRepair != null && this.targetToRepair.m_6084_() && (double)this.targetToRepair.m_21223_() < (double)this.targetToRepair.m_21233_() * this.config.repairHpPercentage();
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      if (this.shouldRewardExperience) {
         this.rewardExperience(villager);
      }

      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.clearOffhandItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.targetToRepair = null;
      this.remainingRepairAttempts = 0;
      this.shouldRewardExperience = false;
   }

   private void applyProfessionBuff(@Nonnull BaseVillager villager) {
      MobEffect effect = resolveBuffEffect(villager.getProfession());
      if (effect != null) {
         int amplifier = resolveBuffAmplifier(villager.getMinecraftEntity().getExpertise().getLevel());
         this.targetToRepair.m_7292_(new MobEffectInstance(effect, BUFF_DURATION_TICKS, amplifier, false, true));
      }
   }

   @Nullable
   private static MobEffect resolveBuffEffect(@Nonnull VillagerProfessionKey profession) {
      MobEffect var10000;
      switch (profession.id()) {
         case "armorer" -> var10000 = MobEffects.f_19606_;
         case "weaponsmith" -> var10000 = MobEffects.f_19600_;
         case "toolsmith" -> var10000 = MobEffects.f_19596_;
         default -> var10000 = null;
      }

      return var10000;
   }

   private static int resolveBuffAmplifier(int expertiseLevel) {
      if (expertiseLevel >= Expertise.MASTER.getLevel()) {
         return 2;
      } else {
         return expertiseLevel >= Expertise.JOURNEYMAN.getLevel() ? 1 : 0;
      }
   }

   private Optional<IronGolem> findClosestDamagedIronGolem(@Nonnull BaseVillager villager) {
      return this.getPerceivedEntities(villager).<IronGolem>closest(IronGolem.class, (golem) -> this.isSufficientlyDamaged(golem) && villager.getNavigationManager().canReach(Location.fromEntity(golem, false), (double)1.0F), villager);
   }

   private PerceivedEntities getPerceivedEntities(@Nonnull BaseVillager villager) {
      return (PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_SENSED_ENTITIES).orElse(PerceivedEntities.empty());
   }

   private boolean isSufficientlyDamaged(@Nonnull IronGolem ironGolem) {
      return needsRepair(ironGolem, this.config);
   }

   public static boolean needsRepair(@Nonnull IronGolem ironGolem, @Nonnull RepairIronGolemConfig config) {
      return ironGolem.m_6084_() && (double)ironGolem.m_21223_() < (double)ironGolem.m_21233_() * config.repairHpPercentage();
   }

   private static enum RepairStage implements StageKey {
      REPAIR_GOLEM,
      END;

      // $FF: synthetic method
      private static RepairStage[] $values() {
         return new RepairStage[]{REPAIR_GOLEM, END};
      }
   }
}
