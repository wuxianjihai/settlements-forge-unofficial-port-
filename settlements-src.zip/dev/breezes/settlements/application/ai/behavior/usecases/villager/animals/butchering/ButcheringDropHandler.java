package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals.butchering;

import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.UUID;
import lombok.Generated;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;

@EventBusSubscriber(
   modid = "settlements",
   bus = Bus.FORGE
)
public class ButcheringDropHandler {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ButcheringDropHandler.class.getName());

   @SubscribeEvent
   public static void onLivingDrops(LivingDropsEvent event) {
      boolean hasReservedVillager = event.getEntity().getPersistentData().m_128403_("settlements_reserved_for_villager");
      if (hasReservedVillager) {
         UUID villagerUuid = event.getEntity().getPersistentData().m_128342_("settlements_reserved_for_villager");
         log.behaviorStatus("Reserving {} drops from {} for villager {}", event.getDrops().size(), event.getEntity().getClass().getSimpleName(), villagerUuid);

         for(ItemEntity drop : event.getDrops()) {
            drop.getPersistentData().m_128362_("settlements_reserved_for_villager", villagerUuid);
            drop.m_32010_(ClockTicks.seconds((double)10.0F).getTicksAsInt());
         }

      }
   }
}
