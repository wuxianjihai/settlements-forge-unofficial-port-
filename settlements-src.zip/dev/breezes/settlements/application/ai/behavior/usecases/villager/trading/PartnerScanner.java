package dev.breezes.settlements.application.ai.behavior.usecases.villager.trading;

import dev.breezes.settlements.application.economy.VillagerWallet;
import dev.breezes.settlements.application.economy.catalog.TradePriceResolver;
import dev.breezes.settlements.application.economy.demand.ActiveDemand;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.economy.catalog.ItemMatches;
import dev.breezes.settlements.domain.economy.catalog.OfferEntry;
import dev.breezes.settlements.domain.economy.catalog.TradeCatalogRegistry;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.domain.inventory.BackpackEntry;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

@ServerScope
public final class PartnerScanner {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(PartnerScanner.class.getName());
   private final TradeCatalogRegistry tradeCatalogRegistry;
   private final TradePriceResolver tradePriceResolver;
   private final VillagerWallet villagerWallet;

   public Optional<TradeCandidate> findPartner(@Nonnull BaseVillager buyer, @Nonnull List<ActiveDemand> activeDemands) {
      if (activeDemands.isEmpty()) {
         return Optional.empty();
      } else {
         List<BaseVillager> candidates = this.getPerceivedEntities(buyer).ofType(BaseVillager.class, (candidatex) -> candidatex != buyer && candidatex.isTradeAvailable()).toList();

         for(ActiveDemand activeDemand : activeDemands) {
            for(BaseVillager seller : candidates) {
               Optional<TradeCandidate> candidate = this.matchCandidate(buyer, seller, activeDemand);
               if (candidate.isPresent()) {
                  return candidate;
               }
            }
         }

         return Optional.empty();
      }
   }

   private PerceivedEntities getPerceivedEntities(@Nonnull BaseVillager villager) {
      return (PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_SENSED_ENTITIES).orElse(PerceivedEntities.empty());
   }

   private Optional<TradeCandidate> matchCandidate(@Nonnull BaseVillager buyer, @Nonnull BaseVillager seller, @Nonnull ActiveDemand activeDemand) {
      VillagerProfessionKey sellerProfession = seller.getProfession();
      VillagerInventory sellerInventory = seller.getSettlementsInventory();
      int buyerBalance = this.villagerWallet.getBalance(buyer);
      List<OfferEntry> offers = this.tradeCatalogRegistry.findOffers(sellerProfession, activeDemand.match());
      if (offers.isEmpty()) {
         return Optional.empty();
      } else {
         List<BackpackEntry> sellerEntries = sellerInventory.entries();

         for(OfferEntry offerEntry : offers) {
            for(BackpackEntry entry : sellerEntries) {
               ItemStack stack = entry.representative();
               if (ItemMatches.test(activeDemand.match(), stack) && ItemMatches.test(offerEntry.match(), stack)) {
                  Item matchedItem = stack.m_41720_();
                  int sellerCount = sellerInventory.count(matchedItem);
                  int minimumStock = Math.max(offerEntry.bundleSize(), offerEntry.surplusThreshold());
                  if (sellerCount >= minimumStock) {
                     ItemMatch priceMatch = new ItemMatch.ItemRef(BuiltInRegistries.f_257033_.m_7981_(matchedItem));
                     int sellerAsk = (Integer)this.tradePriceResolver.resolveOfferBundlePrice(seller, priceMatch).orElse(-1);
                     int buyerOffer = Math.min(activeDemand.basePricePerUnit() * offerEntry.bundleSize(), buyerBalance);
                     if (sellerAsk > 0 && buyerOffer > 0) {
                        log.behaviorTrace("Matched trade candidate: buyer={}, seller={}, item={}, want={}, sellerAsk={}, buyerOffer={}, bundleSize={}", buyer.m_20148_(), seller.m_20148_(), BuiltInRegistries.f_257033_.m_7981_(matchedItem), activeDemand.match().asDebugString(), sellerAsk, buyerOffer, offerEntry.bundleSize());
                        return Optional.of(PartnerScanner.TradeCandidate.builder().partner(seller).activeDemand(activeDemand).matchedItem(matchedItem).offerEntry(offerEntry).buyerOffer(buyerOffer).sellerAsk(sellerAsk).build());
                     }
                  }
               }
            }
         }

         return Optional.empty();
      }
   }

   @Inject
   @Generated
   PartnerScanner(TradeCatalogRegistry tradeCatalogRegistry, TradePriceResolver tradePriceResolver, VillagerWallet villagerWallet) {
      this.tradeCatalogRegistry = tradeCatalogRegistry;
      this.tradePriceResolver = tradePriceResolver;
      this.villagerWallet = villagerWallet;
   }

   public static record TradeCandidate(@Nonnull BaseVillager partner, @Nonnull ActiveDemand activeDemand, @Nonnull Item matchedItem, @Nonnull OfferEntry offerEntry, int buyerOffer, int sellerAsk) {
      @Generated
      public static TradeCandidateBuilder builder() {
         return new TradeCandidateBuilder();
      }

      @Generated
      public static class TradeCandidateBuilder {
         @Generated
         private BaseVillager partner;
         @Generated
         private ActiveDemand activeDemand;
         @Generated
         private Item matchedItem;
         @Generated
         private OfferEntry offerEntry;
         @Generated
         private int buyerOffer;
         @Generated
         private int sellerAsk;

         @Generated
         TradeCandidateBuilder() {
         }

         @Generated
         public TradeCandidateBuilder partner(@Nonnull BaseVillager partner) {
            if (partner == null) {
               throw new NullPointerException("partner is marked non-null but is null");
            } else {
               this.partner = partner;
               return this;
            }
         }

         @Generated
         public TradeCandidateBuilder activeDemand(@Nonnull ActiveDemand activeDemand) {
            if (activeDemand == null) {
               throw new NullPointerException("activeDemand is marked non-null but is null");
            } else {
               this.activeDemand = activeDemand;
               return this;
            }
         }

         @Generated
         public TradeCandidateBuilder matchedItem(@Nonnull Item matchedItem) {
            if (matchedItem == null) {
               throw new NullPointerException("matchedItem is marked non-null but is null");
            } else {
               this.matchedItem = matchedItem;
               return this;
            }
         }

         @Generated
         public TradeCandidateBuilder offerEntry(@Nonnull OfferEntry offerEntry) {
            if (offerEntry == null) {
               throw new NullPointerException("offerEntry is marked non-null but is null");
            } else {
               this.offerEntry = offerEntry;
               return this;
            }
         }

         @Generated
         public TradeCandidateBuilder buyerOffer(int buyerOffer) {
            this.buyerOffer = buyerOffer;
            return this;
         }

         @Generated
         public TradeCandidateBuilder sellerAsk(int sellerAsk) {
            this.sellerAsk = sellerAsk;
            return this;
         }

         @Generated
         public TradeCandidate build() {
            return new TradeCandidate(this.partner, this.activeDemand, this.matchedItem, this.offerEntry, this.buyerOffer, this.sellerAsk);
         }

         @Generated
         public String toString() {
            String var10000 = String.valueOf(this.partner);
            return "PartnerScanner.TradeCandidate.TradeCandidateBuilder(partner=" + var10000 + ", activeDemand=" + String.valueOf(this.activeDemand) + ", matchedItem=" + String.valueOf(this.matchedItem) + ", offerEntry=" + String.valueOf(this.offerEntry) + ", buyerOffer=" + this.buyerOffer + ", sellerAsk=" + this.sellerAsk + ")";
         }
      }
   }
}
