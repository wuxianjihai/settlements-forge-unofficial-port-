package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals.petting;

import dev.breezes.settlements.application.ai.behavior.runtime.timing.BehaviorTimingConfig;
import dev.breezes.settlements.application.config.validation.BehaviorCooldownValidator;
import dev.breezes.settlements.infrastructure.config.annotations.BehaviorConfig;
import dev.breezes.settlements.infrastructure.config.annotations.ConfigurationType;
import dev.breezes.settlements.infrastructure.config.annotations.integers.IntegerConfig;

@BehaviorConfig(
   name = "pet_animal",
   type = ConfigurationType.BEHAVIOR
)
public record PetAnimalConfig(@IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "precondition_check_cooldown_min",description = "Minimum interval (in seconds) between precondition checks",defaultValue = 10,min = 1) int preconditionCheckCooldownMin, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "precondition_check_cooldown_max",description = "Maximum interval (in seconds) between precondition checks",defaultValue = 20,min = 1) int preconditionCheckCooldownMax, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "behavior_cooldown_min",description = "Minimum behavior cooldown time (in seconds)",defaultValue = 10,min = 1) int behaviorCooldownMin, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "behavior_cooldown_max",description = "Maximum behavior cooldown time (in seconds)",defaultValue = 30,min = 1) int behaviorCooldownMax, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "horizontal_scan_range",description = "Horizontal radius (in blocks) within which the villager will look for a pettable animal",defaultValue = 16,min = 5,max = 64) int horizontalScanRange, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "vertical_scan_range",description = "Vertical radius (in blocks) within which the villager will look for a pettable animal",defaultValue = 4,min = 1,max = 16) int verticalScanRange, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "pet_count",description = "Number of times to pet the animal in one visit, spaced roughly a second apart",defaultValue = 3,min = 1,max = 10) int petCount) implements BehaviorTimingConfig {
   public PetAnimalConfig {
      BehaviorCooldownValidator.validateRanges(preconditionCheckCooldownMin, preconditionCheckCooldownMax, behaviorCooldownMin, behaviorCooldownMax);
   }
}
