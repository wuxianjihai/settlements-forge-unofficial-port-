package dev.breezes.settlements.application.ai.behavior.usecases.villager.crafting;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.crafting.catalog.CraftIngredient;
import dev.breezes.settlements.domain.crafting.catalog.CraftRecipe;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.Optional;
import java.util.function.Consumer;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class RecipeCommit {
   public static Optional<Result> commit(@Nonnull BehaviorContext<BaseVillager> context, @Nullable CraftRecipe recipe, @Nonnull CraftBatchCalculator batchCalculator, @Nonnull WorldEventType deedType, @Nonnull Consumer<BaseVillager> experienceRewarder) {
      if (recipe == null) {
         return Optional.empty();
      } else {
         BaseVillager villager = context.getInitiator();
         int liveBatch = batchCalculator.computeBatch(villager, recipe);
         if (liveBatch < 1) {
            return Optional.empty();
         } else {
            Item outputItem = (Item)BuiltInRegistries.f_257033_.m_7745_(recipe.output().itemId());
            int outputTotal = recipe.output().count() * liveBatch;
            VillagerInventory inventory = villager.getSettlementsInventory();

            for(CraftIngredient input : recipe.inputs()) {
               inventory.consumeMatching(input.match(), input.count() * liveBatch);
            }

            inventory.add(new ItemStack(outputItem, outputTotal));
            BehaviorOutcome outcome = BehaviorOutcome.forDeed(deedType, (String)null);
            outcome.putDetailField("item", BuiltInRegistries.f_257033_.m_7981_(outputItem).m_135815_());
            outcome.putDetailField("count", Integer.toString(outputTotal));
            outcome.markSucceeded();
            context.declarePrimaryDeed(outcome);
            experienceRewarder.accept(villager);
            return Optional.of(new Result(outputItem, outputTotal));
         }
      }
   }

   @Generated
   private RecipeCommit() {
   }

   public static record Result(@Nonnull Item outputItem, int outputTotal) {
   }
}
