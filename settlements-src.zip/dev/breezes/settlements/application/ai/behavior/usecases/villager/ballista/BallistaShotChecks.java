package dev.breezes.settlements.application.ai.behavior.usecases.villager.ballista;

import dev.breezes.settlements.domain.ballista.BallistaAim;
import dev.breezes.settlements.domain.ballista.BallistaFiringSolution;
import dev.breezes.settlements.domain.ballista.BallistaLaunchPoint;
import dev.breezes.settlements.domain.time.ClockTicks;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public final class BallistaShotChecks {
   private static final ClockTicks WINDOW = ClockTicks.of(5L);
   private final Reference2ObjectOpenHashMap<ResourceKey<Level>, Long2ObjectOpenHashMap<Int2ObjectOpenHashMap<ShotCheck>>> checks = new Reference2ObjectOpenHashMap();
   private long window = Long.MIN_VALUE;

   boolean canHit(@Nonnull ServerLevel level, @Nonnull BlockPos machinePos, @Nonnull LivingEntity hostile) {
      ShotCheck check = this.checkFor(level, machinePos, hostile);
      if (check.solvable == null) {
         Vec3 toAimPoint = BallistaCombatOption.aimPointOf(hostile).m_82546_(BallistaCombatOption.floorCenterOf(machinePos));
         check.solvable = BallistaFiringSolution.solve(toAimPoint, Vec3.f_82478_, (double)3.9F).isPresent();
      }

      return check.solvable && this.hasLineOfSight(level, machinePos, hostile, check);
   }

   boolean refreshLineOfSight(@Nonnull ServerLevel level, @Nonnull BlockPos machinePos, @Nonnull LivingEntity hostile) {
      ShotCheck check = this.checkFor(level, machinePos, hostile);
      check.inSight = traceLineOfSight(level, machinePos, hostile);
      return check.inSight;
   }

   private boolean hasLineOfSight(@Nonnull ServerLevel level, @Nonnull BlockPos machinePos, @Nonnull LivingEntity hostile, @Nonnull ShotCheck check) {
      if (check.inSight == null) {
         check.inSight = traceLineOfSight(level, machinePos, hostile);
      }

      return check.inSight;
   }

   private ShotCheck checkFor(@Nonnull ServerLevel level, @Nonnull BlockPos machinePos, @Nonnull LivingEntity hostile) {
      long now = level.m_46467_() / WINDOW.getTicks();
      if (now != this.window) {
         this.checks.clear();
         this.window = now;
      }

      Long2ObjectOpenHashMap<Int2ObjectOpenHashMap<ShotCheck>> byMachine = (Long2ObjectOpenHashMap)this.checks.computeIfAbsent(level.m_46472_(), (k) -> new Long2ObjectOpenHashMap());
      Int2ObjectOpenHashMap<ShotCheck> byHostile = (Int2ObjectOpenHashMap)byMachine.get(machinePos.m_121878_());
      if (byHostile == null) {
         byHostile = new Int2ObjectOpenHashMap();
         byMachine.put(machinePos.m_121878_(), byHostile);
      }

      ShotCheck check = (ShotCheck)byHostile.get(hostile.m_19879_());
      if (check == null) {
         check = new ShotCheck();
         byHostile.put(hostile.m_19879_(), check);
      }

      return check;
   }

   private static boolean traceLineOfSight(@Nonnull ServerLevel level, @Nonnull BlockPos machinePos, @Nonnull LivingEntity hostile) {
      Vec3 floorCenter = BallistaCombatOption.floorCenterOf(machinePos);
      Vec3 aimPoint = BallistaCombatOption.aimPointOf(hostile);
      float heading = BallistaLaunchPoint.headingToward(aimPoint.m_82546_(floorCenter));
      Vec3 muzzle = floorCenter.m_82549_(BallistaLaunchPoint.tipOffset(BallistaAim.facing(heading, 0.0F)));
      if (!level.m_151572_(Mth.m_14107_(Math.min(muzzle.f_82479_, aimPoint.f_82479_)), Mth.m_14107_(Math.min(muzzle.f_82481_, aimPoint.f_82481_)), Mth.m_14107_(Math.max(muzzle.f_82479_, aimPoint.f_82479_)), Mth.m_14107_(Math.max(muzzle.f_82481_, aimPoint.f_82481_)))) {
         return false;
      } else {
         ClipContext ray = new ClipContext(muzzle, aimPoint, Block.COLLIDER, Fluid.NONE, hostile);
         return level.m_45547_(ray).m_6662_() == Type.MISS;
      }
   }

   private static final class ShotCheck {
      @Nullable
      private Boolean solvable;
      @Nullable
      private Boolean inSight;
   }
}
