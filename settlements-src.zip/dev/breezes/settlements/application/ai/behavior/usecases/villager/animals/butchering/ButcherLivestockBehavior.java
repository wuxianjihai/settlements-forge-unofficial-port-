package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals.butchering;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.domain.ai.conditions.PerceivedEntityExistsCondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animal.ButcherableAnimalEntry;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.entities.Expertise;
import dev.breezes.settlements.domain.tags.EntityTag;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.data.animal.ButcherableAnimalDataManager;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

public class ButcherLivestockBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ButcherLivestockBehavior.class.getName());
   private static final ResourceLocation IRON_AXE_ID = new ResourceLocation("minecraft", "iron_axe");
   public static final String RESERVED_FOR_VILLAGER_KEY = "settlements_reserved_for_villager";
   private final ButcherLivestockConfig config;
   private final ButcherableAnimalDataManager animalDataManager;
   private final boolean requireVillageOwnedTag;
   private int butcherCountRemaining;
   @Nullable
   private EntityType<?> selectedAnimalType;
   @Nullable
   private LivingEntity target;
   private boolean shouldRewardExperience;

   public ButcherLivestockBehavior(@Nonnull ButcherLivestockConfig config, @Nonnull ButcherableAnimalDataManager animalDataManager, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.animalDataManager = animalDataManager;
      this.requireVillageOwnedTag = config.requireVillageOwnedTag();
      this.preconditions.add(PerceivedEntityExistsCondition.builder().entityType(LivingEntity.class).filter((villager, entity) -> this.animalDataManager.findByEntityType(entity.m_6095_()).isPresent() && isAdultOrNonAgeable(entity) && (!this.requireVillageOwnedTag || entity.m_19880_().contains(EntityTag.VILLAGE_OWNED_ANIMAL.getTag()))).completionRange(1).build());
      this.preconditions.add(support.getDemandSignalService().requireItem(new ItemMatch.ItemRef(IRON_AXE_ID), 1, 50, this.getClass().getSimpleName()));
      this.butcherCountRemaining = 0;
      this.selectedAnimalType = null;
      this.target = null;
      this.shouldRewardExperience = false;
      this.initializeStateMachine(this.createControlStep(), ButcherLivestockBehavior.ButcherStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("ButcherLivestockBehavior").initialStage(ButcherLivestockBehavior.ButcherStage.BUTCHER_TARGET).stageStepMap(Map.of(ButcherLivestockBehavior.ButcherStage.BUTCHER_TARGET, this.createButcherStep(), ButcherLivestockBehavior.ButcherStage.COLLECT_DROPS, this.createCollectDropsStep())).nextStage(ButcherLivestockBehavior.ButcherStage.END).build();
   }

   private BehaviorStep<BaseVillager> createButcherStep() {
      TimeBasedStep<BaseVillager> butcherStep = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.of(30L).asTickable()).onStart((context) -> {
         BaseVillager villager = (BaseVillager)context.getInitiator();
         villager.setHeldItem(Items.f_42386_.m_7968_());
         ((BaseVillager)context.getInitiator()).triggerMotion(AnimationArchetype.SWING_HEAVY);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(14L), (context) -> {
         if (this.target != null && this.target.m_6084_()) {
            this.performButcher(this.target, ((BaseVillager)context.getInitiator()).getMinecraftEntity());
            --this.butcherCountRemaining;
            this.shouldRewardExperience = true;
            context.primaryDeed().ifPresent((outcome) -> outcome.recordYield(1));
            return StepResult.noOp();
         } else {
            return StepResult.complete();
         }
      }).onEnd((context) -> {
         ((BaseVillager)context.getInitiator()).clearHeldItem();
         return StepResult.transition(ButcherLivestockBehavior.ButcherStage.COLLECT_DROPS);
      }).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 1)).actionStep(butcherStep).build();
   }

   private BehaviorStep<BaseVillager> createCollectDropsStep() {
      return TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.of(24L).asTickable()).onStart((context) -> {
         ((BaseVillager)context.getInitiator()).triggerMotion(AnimationArchetype.PICK_UP);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(11L), (context) -> {
         BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
         List<ItemEntity> drops = this.findReservedDropsNearVillager(villager);
         drops.forEach((itemEntity) -> ((BaseVillager)context.getInitiator()).pickUp(itemEntity));
         return StepResult.noOp();
      }).onEnd((context) -> {
         BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
         if (this.butcherCountRemaining > 0 && this.selectedAnimalType != null) {
            Optional<LivingEntity> nextTarget = this.findNextTargetForType(villager, this.selectedAnimalType);
            if (nextTarget.isEmpty()) {
               return StepResult.complete();
            } else {
               this.target = (LivingEntity)nextTarget.get();
               context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.target)));
               return StepResult.transition(ButcherLivestockBehavior.ButcherStage.BUTCHER_TARGET);
            }
         } else {
            return StepResult.complete();
         }
      }).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      Expertise expertise = entity.getExpertise();
      int limit = (Integer)this.config.expertiseButcherLimit().getOrDefault(expertise.getConfigName(), 1);
      this.butcherCountRemaining = limit;
      this.shouldRewardExperience = false;
      Optional<LivingEntity> selectedTarget = this.findButcherableTarget(entity);
      if (selectedTarget.isEmpty()) {
         this.requestStop("No butcherable livestock found");
      } else {
         this.target = (LivingEntity)selectedTarget.get();
         context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.target)));
         context.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.LIVESTOCK_BUTCHERED, this.resolveSpeciesNoun(this.selectedAnimalType)));
         log.behaviorStatus("Villager is '{}' level, maximum butcher count is {}, targeting {}", expertise.toString(), limit, this.selectedAnimalType);
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      return this.target != null && this.selectedAnimalType != null;
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      if (this.shouldRewardExperience) {
         this.rewardExperience(villager);
      }

      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.target = null;
      this.selectedAnimalType = null;
      this.butcherCountRemaining = 0;
      this.shouldRewardExperience = false;
   }

   private Optional<LivingEntity> findButcherableTarget(@Nonnull BaseVillager villager) {
      List<LivingEntity> candidates = this.getPerceivedEntities(villager).ofType(LivingEntity.class, this::isButcherCandidate).toList();
      Map<EntityType<?>, Integer> adultCountByType = new HashMap();

      for(LivingEntity entity : candidates) {
         EntityType<?> type = entity.m_6095_();
         adultCountByType.merge(type, 1, Integer::sum);
      }

      for(EntityType<?> type : adultCountByType.entrySet().stream().filter((entry) -> (Integer)entry.getValue() > this.minimumKeepFor((EntityType)entry.getKey())).sorted(Entry.comparingByValue(Comparator.reverseOrder()).thenComparing((entry) -> BuiltInRegistries.f_256780_.m_7981_((EntityType)entry.getKey()).toString())).map(Map.Entry::getKey).toList()) {
         Stream var10000 = candidates.stream().filter((entityx) -> entityx.m_6095_() == type).filter((entityx) -> this.canReachButcherTarget(villager, entityx));
         Objects.requireNonNull(villager);
         Optional<LivingEntity> reachableTarget = var10000.min(Comparator.comparingDouble(villager::m_20280_));
         if (reachableTarget.isPresent()) {
            this.selectedAnimalType = type;
            return reachableTarget;
         }
      }

      return Optional.empty();
   }

   private Optional<LivingEntity> findNextTargetForType(@Nonnull BaseVillager villager, @Nonnull EntityType<?> desiredType) {
      List<LivingEntity> candidates = this.getPerceivedEntities(villager).ofType(LivingEntity.class, (entity) -> entity.m_6095_() == desiredType && this.isButcherCandidate(entity)).toList();
      int minKeep = this.minimumKeepFor(desiredType);
      if (candidates.size() <= minKeep) {
         return Optional.empty();
      } else {
         Stream var10000 = candidates.stream().filter((entity) -> this.canReachButcherTarget(villager, entity));
         Objects.requireNonNull(villager);
         return var10000.min(Comparator.comparingDouble(villager::m_20280_));
      }
   }

   private boolean canReachButcherTarget(@Nonnull BaseVillager villager, @Nonnull LivingEntity entity) {
      return villager.getNavigationManager().canReach(Location.fromEntity(entity, false), (double)1.0F);
   }

   private boolean isButcherCandidate(@Nonnull LivingEntity entity) {
      if (!entity.m_6084_()) {
         return false;
      } else if (this.animalDataManager.findByEntityType(entity.m_6095_()).isEmpty()) {
         return false;
      } else if (!isAdultOrNonAgeable(entity)) {
         return false;
      } else {
         return !this.requireVillageOwnedTag || entity.m_19880_().contains(EntityTag.VILLAGE_OWNED_ANIMAL.getTag());
      }
   }

   private int minimumKeepFor(@Nonnull EntityType<?> type) {
      return (Integer)this.animalDataManager.findByEntityType(type).map(ButcherableAnimalEntry::minimumKeepCount).orElse(Integer.MAX_VALUE);
   }

   private void performButcher(@Nonnull LivingEntity target, @Nonnull BaseVillager villager) {
      target.getPersistentData().m_128362_("settlements_reserved_for_villager", villager.m_20148_());
      target.m_6469_(villager.m_269291_().m_269333_(villager), Float.MAX_VALUE);
      if (target.m_6084_()) {
         target.m_6074_();
      }

   }

   private List<ItemEntity> findReservedDropsNearVillager(@Nonnull BaseVillager villager) {
      AABB area = villager.m_20191_().m_82377_((double)6.0F, (double)3.0F, (double)6.0F);
      Predicate<ItemEntity> isReservedForVillager = (itemEntity) -> itemEntity != null && itemEntity.m_6084_() && itemEntity.getPersistentData().m_128403_("settlements_reserved_for_villager") && villager.m_20148_().equals(itemEntity.getPersistentData().m_128342_("settlements_reserved_for_villager"));
      return villager.m_9236_().m_6443_(ItemEntity.class, area, isReservedForVillager);
   }

   private PerceivedEntities getPerceivedEntities(@Nonnull BaseVillager villager) {
      return (PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_SENSED_ENTITIES).orElse(PerceivedEntities.empty());
   }

   private static boolean isAdultOrNonAgeable(@Nonnull LivingEntity entity) {
      if (entity instanceof AgeableMob mob) {
         return !mob.m_6162_();
      } else {
         return true;
      }
   }

   private String resolveSpeciesNoun(@Nullable EntityType<?> type) {
      if (type == null) {
         return "animals";
      } else {
         Optional var10000 = this.animalDataManager.findByEntityType(type).map(ButcherableAnimalEntry::speciesNoun).filter((noun) -> !noun.isBlank());
         Objects.requireNonNull(type);
         return (String)var10000.orElseGet(type::m_20675_);
      }
   }

   private static enum ButcherStage implements StageKey {
      BUTCHER_TARGET,
      COLLECT_DROPS,
      END;

      // $FF: synthetic method
      private static ButcherStage[] $values() {
         return new ButcherStage[]{BUTCHER_TARGET, COLLECT_DROPS, END};
      }
   }
}
