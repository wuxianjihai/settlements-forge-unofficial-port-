package dev.breezes.settlements.application.ai.behavior.usecases.villager.librarian;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.brain.ActivityArbiter;
import dev.breezes.settlements.bootstrap.registry.effects.MobEffectRegistry;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

public class BindVexesBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(BindVexesBehavior.class.getName());
   private static final ClockTicks EMPTY_CAST_RETRY = ClockTicks.seconds((double)10.0F);
   private static final int DEFAULT_VEXES_PER_CAST = 2;
   private static final double GLYPH_SCATTER = 0.3;
   private final BindVexesConfig config;
   private final List<LivingEntity> targets;

   public BindVexesBehavior(@Nonnull BindVexesConfig config, @Nonnull BehaviorSupport support) {
      super(log, ClockTicks.ZERO.asTickable(), ClockTicks.ZERO.asTickable(), support, config.experienceReward());
      this.config = config;
      this.targets = new ArrayList();
      this.initializeStateMachine(StagedStep.builder().name("BindVexesBehavior").initialStage(BindVexesBehavior.BindStage.CHANNEL).stageStepMap(Map.of(BindVexesBehavior.BindStage.CHANNEL, this.channelStep())).nextStage(BindVexesBehavior.BindStage.END).build(), BindVexesBehavior.BindStage.END);
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      this.refreshTargets(villager, context.getLevel());
      if (this.targets.isEmpty()) {
         this.requestStop("No bindable entity is near");
      }

   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      this.targets.clear();
      villager.setMotion(AnimationArchetype.IDLE);
   }

   private void refreshTargets(@Nonnull BaseVillager villager, @Nonnull ServerLevel level) {
      this.targets.clear();
      Stream var10000 = ((PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_HOSTILES).orElse(PerceivedEntities.empty())).ofType(LivingEntity.class, (hostile) -> VexBinding.isBindable(hostile, level)).limit(2L);
      List var10001 = this.targets;
      Objects.requireNonNull(var10001);
      var10000.forEach(var10001::add);
   }

   private TimeBasedStep<BaseVillager> channelStep() {
      return TimeBasedStep.<BaseVillager>builder().name("BindVexesChannel").withTickable(this.config.channelDuration().asTickable()).onStart((context) -> {
         BaseVillager villager = (BaseVillager)context.getInitiator();
         villager.getNavigationManager().stop();
         villager.setMotion(AnimationArchetype.BIND_VEXES);
         Location.fromEntity(villager, false).playSound(SoundEvents.f_11862_, 1.0F, 1.0F, SoundSource.NEUTRAL);
         this.spawnGlyphParticles(villager);
         return StepResult.noOp();
      }).addKeyFrame(this.config.channelDuration(), this::bindTargets).onEnd((context) -> StepResult.transition(BindVexesBehavior.BindStage.END)).build();
   }

   private StepResult bindTargets(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager villager = context.getInitiator();
      ServerLevel level = context.getLevel();
      if (!ActivityArbiter.isRaidWaveLive(level.m_8832_(villager.m_20183_()))) {
         return StepResult.transition(BindVexesBehavior.BindStage.END);
      } else {
         this.refreshTargets(villager, level);
         int duration = this.config.bindDuration().getTicksAsInt();
         int boundCount = 0;

         for(LivingEntity target : this.targets) {
            if (VexBinding.isBindable(target, level) && target.m_147207_(new MobEffectInstance((MobEffect)MobEffectRegistry.BOUND.get(), duration, 0), villager)) {
               target.m_147207_(new MobEffectInstance(MobEffects.f_19613_, duration, 3), villager);
               ++boundCount;
            }
         }

         ClockTicks cadence = this.config.cadence();
         if (boundCount == 0) {
            ClockTicks retry = ClockTicks.of(Math.min(EMPTY_CAST_RETRY.getTicks(), cadence.getTicks()));
            villager.getSettlementsBrain().setMemory(MemoryTypeRegistry.BIND_VEXES_COOLDOWN, true, retry);
            return StepResult.transition(BindVexesBehavior.BindStage.END);
         } else {
            villager.getSettlementsBrain().setMemory(MemoryTypeRegistry.BIND_VEXES_COOLDOWN, true, cadence);
            Location.fromEntity(villager, false).playSound(SoundEvents.f_11887_, 1.0F, 1.0F, SoundSource.NEUTRAL);
            this.rewardExperience(villager);
            context.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.VEXES_BOUND, "vexes"));
            return StepResult.noOp();
         }
      }
   }

   private void spawnGlyphParticles(@Nonnull BaseVillager villager) {
      Level var3 = villager.m_9236_();
      if (var3 instanceof ServerLevel level) {
         level.m_8767_(ParticleTypes.f_123809_, villager.m_20185_(), villager.m_20188_() + (double)0.5F, villager.m_20189_(), 12, 0.3, 0.4, 0.3, (double)1.0F);
      }

   }

   private static enum BindStage implements StageKey {
      CHANNEL,
      END;

      // $FF: synthetic method
      private static BindStage[] $values() {
         return new BindStage[]{CHANNEL, END};
      }
   }
}
