package dev.breezes.settlements.application.ai.behavior.usecases.villager.farming;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.blocks.VisitedBlockSitesState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetQueries;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.AwardExperienceStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.LoopBackStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.OneShotStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.ai.targeting.BlockMemoryTargetResolver;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.domain.ai.conditions.KnownBlockSitesPrecondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.farming.CultivationCellCategory;
import dev.breezes.settlements.domain.farming.CultivationCellResult;
import dev.breezes.settlements.domain.farming.CultivationCropDefinition;
import dev.breezes.settlements.domain.farming.CultivationCropRegistry;
import dev.breezes.settlements.domain.farming.CultivationZoneCategorizer;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.BlockScanBox;
import dev.breezes.settlements.domain.world.blocks.BlockStateView;
import dev.breezes.settlements.domain.world.blocks.LevelBlockStateView;
import dev.breezes.settlements.domain.world.blocks.LiveBlockSiteMatcher;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.blocks.cultivation.CultivationLilyBlockEntity;
import dev.breezes.settlements.infrastructure.minecraft.blocks.cultivation.CultivationSiteMatchers;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class CultivatePlotBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(CultivatePlotBehavior.class.getName());
   private static final int APPROACH_TIMEOUT_TICKS = ClockTicks.seconds((double)20.0F).getTicksAsInt();
   private static final ResourceLocation IRON_HOE_ID = new ResourceLocation("minecraft", "iron_hoe");
   private static final ResourceLocation CANONICAL_CROP = new ResourceLocation("minecraft", "wheat");
   private final CultivatePlotConfig config;
   private final BlockMemoryTargetResolver targetResolver;
   private final CultivationCropRegistry cropRegistry;
   private final BlockScanBox confirmBox;
   private final int maxConfirms;
   @Nullable
   private BlockPos selectedLilyPos;
   @Nullable
   private BlockPos currentCellPos;
   private final Deque<CultivationCellResult> pendingCells = new ArrayDeque();

   public CultivatePlotBehavior(@Nonnull CultivatePlotConfig config, @Nonnull BehaviorSupport support, @Nonnull CultivationCropRegistry cropRegistry) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.config = config;
      this.targetResolver = support.getBlockMemoryTargetResolver();
      this.cropRegistry = cropRegistry;
      this.confirmBox = BlockScanBox.confirm();
      this.maxConfirms = 8;
      List<ItemMatch> allSeedMatches = cropRegistry.all().stream().map((def) -> new ItemMatch.ItemRef(def.seedItem())).toList();
      this.preconditions.add(KnownBlockSitesPrecondition.builder().memoryType(MemoryTypeRegistry.CULTIVATION_SITES).matcher(CultivationSiteMatchers.NEEDS_WORK).confirmBox(this.confirmBox).maxSitesToConfirm(this.maxConfirms).completionRange(1).description("Known cultivation lily sites needing work").build());
      this.preconditions.add(support.getDemandSignalService().requireItem(new ItemMatch.ItemRef(IRON_HOE_ID), 1, 50, this.getClass().getSimpleName()));
      if (!allSeedMatches.isEmpty()) {
         this.preconditions.add(support.getDemandSignalService().requireAny(allSeedMatches, 1, 50, this.getClass().getSimpleName()));
      }

      this.initializeStateMachine(this.createControlStep(), CultivatePlotBehavior.Stage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      Map<StageKey, BehaviorStep<BaseVillager>> stageMap = new HashMap();
      stageMap.put(CultivatePlotBehavior.Stage.PICK_CELL, this.createPickCellStep());
      stageMap.put(CultivatePlotBehavior.Stage.APPROACH_CELL, StayCloseStep.builder().closeEnoughDistance((double)1.5F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.WALK).completionDistance(1).unreachableTransition(CultivatePlotBehavior.Stage.LOOP).build()).actionStep(OneShotStep.builder().name("ArrivedAtCell").action((ctx) -> this.onArrivedAtCell()).build()).timeoutTicks(APPROACH_TIMEOUT_TICKS).timeoutTransition(CultivatePlotBehavior.Stage.LOOP).build());
      stageMap.put(CultivatePlotBehavior.Stage.CULTIVATE, this.createCultivateStep());
      stageMap.put(CultivatePlotBehavior.Stage.LOOP, LoopBackStep.builder().name("CultivatePlotLoopBack").loopBackTo(CultivatePlotBehavior.Stage.PICK_CELL).completionTransition(CultivatePlotBehavior.Stage.AWARD).maxIterationsResolver((ctx) -> 16 * ((BaseVillager)ctx.getInitiator()).getExpertise().getLevel()).build());
      stageMap.put(CultivatePlotBehavior.Stage.AWARD, AwardExperienceStep.builder().name("AwardCultivatePlotXp").experienceAmount(this.config.experienceReward()).nextStage(CultivatePlotBehavior.Stage.END).build());
      return StagedStep.<BaseVillager>builder().name("CultivatePlotBehavior").initialStage(CultivatePlotBehavior.Stage.PICK_CELL).stageStepMap(stageMap).nextStage(CultivatePlotBehavior.Stage.END).build();
   }

   private BehaviorStep<BaseVillager> createPickCellStep() {
      return OneShotStep.<BaseVillager>builder().name("PickNextCultivationCell").action((ctx) -> {
         if (this.selectedLilyPos == null) {
            log.behaviorStatus("No lily selected, ending behavior");
            return StepResult.transition(CultivatePlotBehavior.Stage.AWARD);
         } else {
            label44: {
               BaseVillager villager = (BaseVillager)ctx.getInitiator();
               Level level = villager.m_9236_();
               BlockStateView view = new LevelBlockStateView(level);
               if (this.pendingCells.isEmpty()) {
                  BlockEntity be = level.m_7702_(this.selectedLilyPos);
                  if (!(be instanceof CultivationLilyBlockEntity)) {
                     break label44;
                  }

                  CultivationLilyBlockEntity lily = (CultivationLilyBlockEntity)be;
                  if (!lily.isValid()) {
                     break label44;
                  }

                  List<CultivationCellResult> cells = CultivationZoneCategorizer.categorize(lily.getZone().streamCells(), view, lily.getCropFilter());
                  Stream var10000 = cells.stream().filter((r) -> CultivationZoneCategorizer.isActionable(r.category()));
                  Deque var10001 = this.pendingCells;
                  Objects.requireNonNull(var10001);
                  var10000.forEach(var10001::add);
                  if (this.pendingCells.isEmpty()) {
                     log.behaviorStatus("Lily zone has no actionable cells, ending behavior");
                     return StepResult.transition(CultivatePlotBehavior.Stage.AWARD);
                  }
               }

               BlockEntity blockEntity = level.m_7702_(this.selectedLilyPos);
               if (blockEntity instanceof CultivationLilyBlockEntity) {
                  CultivationLilyBlockEntity lily = (CultivationLilyBlockEntity)blockEntity;

                  while(!this.pendingCells.isEmpty()) {
                     CultivationCellResult candidate = (CultivationCellResult)this.pendingCells.poll();
                     CultivationCellCategory liveCategory = CultivationZoneCategorizer.categorizeCell(view, candidate.cellPos(), lily.getCropFilter());
                     if (CultivationZoneCategorizer.isActionable(liveCategory)) {
                        if (this.resolveCropToPlant(villager, lily).isEmpty()) {
                           log.behaviorStatus("Villager has no matching seeds, ending behavior");
                           return StepResult.transition(CultivatePlotBehavior.Stage.AWARD);
                        }

                        this.currentCellPos = candidate.cellPos();
                        BlockPos approachPos = candidate.cellPos().m_7494_();
                        ctx.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromBlock(PhysicalBlock.of(Location.of(approachPos, level), level.m_8055_(approachPos)))));
                        return StepResult.transition(CultivatePlotBehavior.Stage.APPROACH_CELL);
                     }
                  }

                  log.behaviorStatus("No more actionable cells, ending behavior");
                  return StepResult.transition(CultivatePlotBehavior.Stage.AWARD);
               }

               return StepResult.transition(CultivatePlotBehavior.Stage.AWARD);
            }

            log.behaviorStatus("Lily at {} is no longer valid", this.selectedLilyPos);
            return StepResult.transition(CultivatePlotBehavior.Stage.AWARD);
         }
      }).build();
   }

   private StepResult onArrivedAtCell() {
      return this.currentCellPos == null ? StepResult.transition(CultivatePlotBehavior.Stage.PICK_CELL) : StepResult.transition(CultivatePlotBehavior.Stage.CULTIVATE);
   }

   private BehaviorStep<BaseVillager> createCultivateStep() {
      return TimeBasedStep.<BaseVillager>builder().name("CultivateCell").withTickable(ClockTicks.of(25L).asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).setHeldItem(Items.f_42387_.m_7968_());
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.TILL);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(10L), (ctx) -> {
         if (this.currentCellPos != null && this.selectedLilyPos != null) {
            BaseVillager villager = (BaseVillager)ctx.getInitiator();
            Level level = villager.m_9236_();
            if (!(level instanceof ServerLevel)) {
               return StepResult.noOp();
            } else {
               BlockEntity be = level.m_7702_(this.selectedLilyPos);
               if (be instanceof CultivationLilyBlockEntity) {
                  CultivationLilyBlockEntity lily = (CultivationLilyBlockEntity)be;
                  BlockPos cellPos = this.currentCellPos;
                  BlockPos canopyPos = cellPos.m_7494_();
                  BlockStateView view = new LevelBlockStateView(level);
                  CultivationCellCategory liveCategory = CultivationZoneCategorizer.categorizeCell(view, cellPos, lily.getCropFilter());
                  if (!CultivationZoneCategorizer.isActionable(liveCategory)) {
                     return StepResult.noOp();
                  } else {
                     Optional<CultivationCropDefinition> cropDef = this.resolveCropToPlant(villager, lily);
                     if (cropDef.isEmpty()) {
                        return StepResult.noOp();
                     } else {
                        CultivationCropDefinition def = (CultivationCropDefinition)cropDef.get();
                        Block cropBlock = (Block)BuiltInRegistries.f_256975_.m_7745_(def.cropBlock());
                        if (cropBlock instanceof CropBlock) {
                           CropBlock crop = (CropBlock)cropBlock;
                           Location tillLocation = Location.of(cellPos, level).center(true).add((double)0.0F, (double)0.5F, (double)0.0F, true);
                           tillLocation.playSound(SoundEvents.f_11955_, 0.8F, 1.0F, SoundSource.BLOCKS);
                           BlockState canopy = level.m_8055_(canopyPos);
                           if (!canopy.m_60795_()) {
                              ParticleRegistry.harvestBlock(Location.of(canopyPos, level).center(true), canopy);
                              level.m_46961_(canopyPos, true);
                           }

                           if (liveCategory == CultivationCellCategory.NEEDS_TILL) {
                              BlockState ground = level.m_8055_(cellPos);
                              ParticleRegistry.harvestBlock(tillLocation, ground);
                              level.m_46597_(cellPos, Blocks.f_50093_.m_49966_());
                              ctx.primaryDeed().ifPresent((outcome) -> outcome.recordDeedDetail("tilled"));
                           }

                           Item seedItem = (Item)BuiltInRegistries.f_257033_.m_7745_(def.seedItem());
                           boolean consumed = villager.getSettlementsInventory().consumeIfRequired(seedItem, 1, GeneralConfig.bypassInventoryRequirements);
                           if (!consumed) {
                              log.behaviorStatus("Could not consume seed, skipping plant");
                              return StepResult.noOp();
                           } else {
                              level.m_46597_(canopyPos, crop.m_52289_(0));
                              ctx.primaryDeed().ifPresent((outcome) -> outcome.recordYield(1));
                              return StepResult.noOp();
                           }
                        } else {
                           return StepResult.noOp();
                        }
                     }
                  }
               } else {
                  return StepResult.noOp();
               }
            }
         } else {
            return StepResult.noOp();
         }
      }).onEnd((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         ((BaseVillager)ctx.getInitiator()).setMotion(AnimationArchetype.IDLE);
         return StepResult.transition(CultivatePlotBehavior.Stage.LOOP);
      }).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      context.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.FARMLAND_CULTIVATED, "farmland blocks"));
      context.setState(BehaviorStateType.VISITED_BLOCK_SITES, VisitedBlockSitesState.empty());
      boolean resolved = this.targetResolver.resolveBlockTarget(context, MemoryTypeRegistry.CULTIVATION_SITES, this.servableSiteMatcher(villager), this.confirmBox, this.maxConfirms, 1);
      if (!resolved) {
         this.requestStop("No valid plot needing cultivation found at behavior start");
      } else {
         Optional<BlockPos> lilyPos = TargetQueries.firstBlockPos(context);
         if (lilyPos.isEmpty()) {
            this.requestStop("Could not read lily position from target state");
         } else {
            this.selectedLilyPos = (BlockPos)lilyPos.get();
         }
      }
   }

   private LiveBlockSiteMatcher servableSiteMatcher(@Nonnull BaseVillager villager) {
      return (pos, level) -> {
         if (!CultivationSiteMatchers.NEEDS_WORK.matches(pos, level)) {
            return false;
         } else {
            BlockEntity blockEntity = level.m_7702_(pos);
            boolean var10000;
            if (blockEntity instanceof CultivationLilyBlockEntity) {
               CultivationLilyBlockEntity lily = (CultivationLilyBlockEntity)blockEntity;
               if (this.resolveCropToPlant(villager, lily).isPresent()) {
                  var10000 = true;
                  return var10000;
               }
            }

            var10000 = false;
            return var10000;
         }
      };
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.selectedLilyPos = null;
      this.currentCellPos = null;
      this.pendingCells.clear();
   }

   private Optional<CultivationCropDefinition> resolveCropToPlant(@Nonnull BaseVillager villager, @Nonnull CultivationLilyBlockEntity lily) {
      boolean bypass = GeneralConfig.bypassInventoryRequirements;
      ResourceLocation filterCrop = lily.getCropFilter();
      if (filterCrop != null) {
         Optional<CultivationCropDefinition> def = this.cropRegistry.resolveByCropBlock(filterCrop);
         if (def.isEmpty()) {
            return Optional.empty();
         } else {
            return !bypass && !this.villagerHasSeed(villager, ((CultivationCropDefinition)def.get()).seedItem()) ? Optional.empty() : def;
         }
      } else if (bypass) {
         return this.defaultBypassCrop();
      } else {
         for(CultivationCropDefinition def : this.cropRegistry.all()) {
            if (this.villagerHasSeed(villager, def.seedItem())) {
               return Optional.of(def);
            }
         }

         return Optional.empty();
      }
   }

   private Optional<CultivationCropDefinition> defaultBypassCrop() {
      Optional<CultivationCropDefinition> wheat = this.cropRegistry.resolveByCropBlock(CANONICAL_CROP);
      return wheat.isPresent() ? wheat : this.cropRegistry.all().stream().findFirst();
   }

   private boolean villagerHasSeed(@Nonnull BaseVillager villager, @Nonnull ResourceLocation seedId) {
      return villager.getSettlementsInventory().findFirst((stack) -> !stack.m_41619_() && BuiltInRegistries.f_257033_.m_7981_(stack.m_41720_()).equals(seedId)).isPresent();
   }

   private static enum Stage implements StageKey {
      PICK_CELL,
      APPROACH_CELL,
      CULTIVATE,
      LOOP,
      AWARD,
      END;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{PICK_CELL, APPROACH_CELL, CULTIVATE, LOOP, AWARD, END};
      }
   }
}
