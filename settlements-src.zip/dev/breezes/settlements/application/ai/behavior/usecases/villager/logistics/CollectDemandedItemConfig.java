package dev.breezes.settlements.application.ai.behavior.usecases.villager.logistics;

import dev.breezes.settlements.application.ai.behavior.runtime.timing.BehaviorTimingConfig;
import dev.breezes.settlements.application.config.validation.BehaviorCooldownValidator;
import dev.breezes.settlements.infrastructure.config.annotations.BehaviorConfig;
import dev.breezes.settlements.infrastructure.config.annotations.ConfigurationType;
import dev.breezes.settlements.infrastructure.config.annotations.integers.IntegerConfig;

@BehaviorConfig(
   name = "collect_demanded_item",
   type = ConfigurationType.BEHAVIOR
)
public record CollectDemandedItemConfig(@IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "precondition_check_cooldown_min",description = "Minimum interval (in seconds) between precondition checks",defaultValue = 10,min = 1) int preconditionCheckCooldownMin, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "precondition_check_cooldown_max",description = "Maximum interval (in seconds) between precondition checks",defaultValue = 20,min = 1) int preconditionCheckCooldownMax, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "behavior_cooldown_min",description = "Minimum behavior cooldown time (in seconds)",defaultValue = 20,min = 1) int behaviorCooldownMin, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "behavior_cooldown_max",description = "Maximum behavior cooldown time (in seconds)",defaultValue = 40,min = 1) int behaviorCooldownMax) implements BehaviorTimingConfig {
   public CollectDemandedItemConfig {
      BehaviorCooldownValidator.validateRanges(preconditionCheckCooldownMin, preconditionCheckCooldownMax, behaviorCooldownMin, behaviorCooldownMax);
   }
}
