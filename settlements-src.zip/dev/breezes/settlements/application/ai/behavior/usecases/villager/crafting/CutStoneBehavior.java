package dev.breezes.settlements.application.ai.behavior.usecases.villager.crafting;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.teardown.DiscardEntityObligation;
import dev.breezes.settlements.application.ai.behavior.teardown.TemporaryArtifactHandle;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.SequencedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.conditions.JobSiteBlockExistsCondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.displays.TransformedBlockDisplay;
import dev.breezes.settlements.infrastructure.minecraft.entities.displays.models.TransformationMatrix;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.StonecutterBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.SlabType;

public class CutStoneBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(CutStoneBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private static final double ANIMATION_OFFSET = 0.6;
   private static final ClockTicks ANIMATION_HALF_DURATION = ClockTicks.seconds((double)1.5F);
   private static final List<CutStoneRecipe> RECIPES;
   private final JobSiteBlockExistsCondition<BaseVillager> jobSiteBlockExistsCondition = new JobSiteBlockExistsCondition<BaseVillager>((block) -> block != null && block.is(Blocks.f_50679_), 1);
   @Nullable
   private PhysicalBlock stoneCutter;
   @Nullable
   private CutStoneRecipe currentRecipe;
   @Nullable
   private TransformedBlockDisplay initialBlockDisplay;
   @Nullable
   private TransformedBlockDisplay finalBlockDisplay;
   @Nullable
   private TemporaryArtifactHandle initialDisplayHandle;
   @Nullable
   private TransformationMatrix initialMatrix;
   private final TransformationMatrix intermediateMatrix;
   @Nullable
   private TransformationMatrix finalMatrix;

   public CutStoneBehavior(CutStoneConfig config, BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.preconditions.add(this.jobSiteBlockExistsCondition);
      this.stoneCutter = null;
      this.currentRecipe = null;
      this.initialBlockDisplay = null;
      this.finalBlockDisplay = null;
      this.initialDisplayHandle = null;
      this.initialMatrix = null;
      this.intermediateMatrix = this.getMatrix((double)0.0F, (double)0.0F);
      this.finalMatrix = null;
      this.initializeStateMachine(this.createControlStep(), CutStoneBehavior.CutStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("CutStoneBehavior").initialStage(CutStoneBehavior.CutStage.CUT_STONE).stageStepMap(Map.of(CutStoneBehavior.CutStage.CUT_STONE, this.createCutStep())).nextStage(CutStoneBehavior.CutStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      if (this.jobSiteBlockExistsCondition.getJobSiteBlock().isEmpty()) {
         this.requestStop("No stone-cutter block found at job site");
      } else {
         this.stoneCutter = (PhysicalBlock)this.jobSiteBlockExistsCondition.getJobSiteBlock().get();
         context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromBlock(this.stoneCutter)));
         this.currentRecipe = (CutStoneRecipe)RandomUtil.choice(RECIPES).orElseThrow();
         Direction direction = (Direction)this.stoneCutter.getBlockState().m_61143_(StonecutterBlock.f_57063_);
         Direction.Axis axis = direction.m_122434_();
         int axisDirection = direction.m_122421_().m_122540_();
         if (axis == Axis.Z) {
            this.initialMatrix = this.getMatrix((double)(-axisDirection) * 0.6, (double)0.0F);
            this.finalMatrix = this.getMatrix((double)axisDirection * 0.6, (double)0.0F);
         } else {
            if (axis != Axis.X) {
               log.error("Unexpected axis '{}' for stone-cutter block at location {}", axis, this.stoneCutter.getLocation(false));
               this.requestStop("Unexpected axis for stone-cutter block");
               return;
            }

            this.initialMatrix = this.getMatrix((double)0.0F, (double)(-axisDirection) * 0.6);
            this.finalMatrix = this.getMatrix((double)0.0F, (double)axisDirection * 0.6);
         }

         this.initialBlockDisplay = new TransformedBlockDisplay(this.currentRecipe.getInput(), this.initialMatrix);
         this.finalBlockDisplay = new TransformedBlockDisplay(this.currentRecipe.getOutput(), this.intermediateMatrix);
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      return this.stoneCutter != null && this.stoneCutter.is(Blocks.f_50679_);
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      this.stoneCutter = null;
      this.currentRecipe = null;
      this.initialBlockDisplay = null;
      this.finalBlockDisplay = null;
      this.initialDisplayHandle = null;
      this.initialMatrix = null;
      this.finalMatrix = null;
   }

   private BehaviorStep<BaseVillager> createCutStep() {
      TimeBasedStep<BaseVillager> setup = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.ONE.asTickable()).onEnd((ctx) -> {
         if (this.stoneCutter != null && this.initialBlockDisplay != null) {
            Location location = this.stoneCutter.getLocation(true).add((double)0.0F, (double)0.5F, (double)0.0F, false);
            this.initialBlockDisplay.spawn(location);
            this.initialDisplayHandle = ctx.getTeardownScope().track(new DiscardEntityObligation(this.initialBlockDisplay.getDisplayEntity().m_20148_(), location.toBlockPos()));
            this.initialBlockDisplay.setTransformation(this.intermediateMatrix, ANIMATION_HALF_DURATION);
            SoundRegistry.STONE_CUTTER_WORKING.playGlobally(location, SoundSource.BLOCKS);
            return StepResult.noOp();
         } else {
            return StepResult.complete();
         }
      }).build();
      TimeBasedStep<BaseVillager> initialCut = TimeBasedStep.<BaseVillager>builder().withTickable(ANIMATION_HALF_DURATION.asTickable()).everyTick((ctx) -> {
         if (this.stoneCutter != null && this.currentRecipe != null) {
            Location location = this.stoneCutter.getLocation(true).add((double)0.0F, (double)0.5F, (double)0.0F, false);
            ParticleRegistry.cutBlock(location, this.currentRecipe.getInput());
            SoundRegistry.STONE_CUTTER_WORKING.playGlobally(location, SoundSource.BLOCKS);
            return StepResult.noOp();
         } else {
            return StepResult.complete();
         }
      }).build();
      TimeBasedStep<BaseVillager> transition = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.ONE.asTickable()).onEnd((ctx) -> {
         if (this.stoneCutter != null && this.finalBlockDisplay != null && this.finalMatrix != null) {
            if (this.initialDisplayHandle != null) {
               this.initialDisplayHandle.dispose(ctx.getLevel());
               this.initialDisplayHandle = null;
            }

            Location location = this.stoneCutter.getLocation(true).add((double)0.0F, (double)0.5F, (double)0.0F, false);
            this.finalBlockDisplay.spawn(location);
            ctx.getTeardownScope().track(new DiscardEntityObligation(this.finalBlockDisplay.getDisplayEntity().m_20148_(), location.toBlockPos()));
            this.finalBlockDisplay.setTransformation(this.finalMatrix, ANIMATION_HALF_DURATION);
            SoundRegistry.STONE_CUTTER_WORKING.playGlobally(location, SoundSource.BLOCKS);
            return StepResult.noOp();
         } else {
            return StepResult.complete();
         }
      }).build();
      TimeBasedStep<BaseVillager> finalCut = TimeBasedStep.<BaseVillager>builder().withTickable(ANIMATION_HALF_DURATION.asTickable()).everyTick((ctx) -> {
         if (this.stoneCutter != null && this.currentRecipe != null) {
            Location location = this.stoneCutter.getLocation(true).add((double)0.0F, (double)0.5F, (double)0.0F, false);
            ParticleRegistry.cutBlock(location, this.currentRecipe.getOutput());
            SoundRegistry.STONE_CUTTER_WORKING.playGlobally(location, SoundSource.BLOCKS);
            return StepResult.noOp();
         } else {
            return StepResult.complete();
         }
      }).onEnd((ctx) -> {
         this.rewardExperience(((BaseVillager)ctx.getInitiator()).getMinecraftEntity());
         ctx.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.STONE_CUT, (String)null)).markSucceeded();
         return StepResult.complete();
      }).build();
      SequencedStep<BaseVillager> sequence = new SequencedStep<BaseVillager>("CutStoneBehavior.sequence", List.of(setup, initialCut, transition, finalCut));
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 1)).actionStep(sequence).build();
   }

   private TransformationMatrix getMatrix(double dx, double dz) {
      return new TransformationMatrix(0.6F, 0.0F, 0.0F, (float)((double)-0.3F + dx), 0.0F, 0.6F, 0.0F, 0.1F, 0.0F, 0.0F, 0.6F, (float)((double)-0.3F + dz), 0.0F, 0.0F, 0.0F, 1.0F);
   }

   static {
      RECIPES = List.of(CutStoneBehavior.CutStoneRecipe.builder().input(Blocks.f_50470_.m_49966_()).output((BlockState)Blocks.f_50405_.m_49966_().m_61124_(SlabBlock.f_56353_, SlabType.DOUBLE)).build());
   }

   private static enum CutStage implements StageKey {
      CUT_STONE,
      END;

      // $FF: synthetic method
      private static CutStage[] $values() {
         return new CutStage[]{CUT_STONE, END};
      }
   }

   private static class CutStoneRecipe {
      private final BlockState input;
      private final BlockState output;

      @Generated
      CutStoneRecipe(BlockState input, BlockState output) {
         this.input = input;
         this.output = output;
      }

      @Generated
      public static CutStoneRecipeBuilder builder() {
         return new CutStoneRecipeBuilder();
      }

      @Generated
      public BlockState getInput() {
         return this.input;
      }

      @Generated
      public BlockState getOutput() {
         return this.output;
      }

      @Generated
      public static class CutStoneRecipeBuilder {
         @Generated
         private BlockState input;
         @Generated
         private BlockState output;

         @Generated
         CutStoneRecipeBuilder() {
         }

         @Generated
         public CutStoneRecipeBuilder input(BlockState input) {
            this.input = input;
            return this;
         }

         @Generated
         public CutStoneRecipeBuilder output(BlockState output) {
            this.output = output;
            return this;
         }

         @Generated
         public CutStoneRecipe build() {
            return new CutStoneRecipe(this.input, this.output);
         }

         @Generated
         public String toString() {
            String var10000 = String.valueOf(this.input);
            return "CutStoneBehavior.CutStoneRecipe.CutStoneRecipeBuilder(input=" + var10000 + ", output=" + String.valueOf(this.output) + ")";
         }
      }
   }
}
