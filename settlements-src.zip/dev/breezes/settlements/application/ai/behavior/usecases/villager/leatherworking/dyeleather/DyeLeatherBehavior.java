package dev.breezes.settlements.application.ai.behavior.usecases.villager.leatherworking.dyeleather;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.teardown.DiscardEntityObligation;
import dev.breezes.settlements.application.ai.behavior.teardown.TemporaryArtifactHandle;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.look.LookState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.SequencedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.domain.ai.conditions.JobSiteBlockExistsCondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.compat.ColorParticleOption;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Plane;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.DyeableLeatherItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class DyeLeatherBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(DyeLeatherBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private static final int STAND_SEARCH_RADIUS = 4;
   private static final ClockTicks PLACE_STAND_DURATION = ClockTicks.seconds((double)1.0F);
   private static final ClockTicks EQUIP_PIECE_DURATION = ClockTicks.seconds(0.6);
   private static final ClockTicks DYE_DURATION = ClockTicks.seconds((double)1.0F);
   private static final ClockTicks DRY_DURATION = ClockTicks.seconds((double)5.0F);
   private static final ClockTicks UNEQUIP_PIECE_DURATION = ClockTicks.seconds((double)0.5F);
   private static final ClockTicks RETRIEVE_STAND_DURATION = ClockTicks.seconds((double)1.0F);
   private static final int DRY_PARTICLE_INTERVAL_TICKS = 5;
   private final JobSiteBlockExistsCondition<BaseVillager> jobSiteBlockExistsCondition = new JobSiteBlockExistsCondition<BaseVillager>((block) -> block != null && block.is(Blocks.f_50256_), 1);
   @Nullable
   private PhysicalBlock cauldron;
   @Nullable
   private BlockPos cauldronPos;
   @Nullable
   private Location standLocation;
   @Nullable
   private DyeColor chosenColor;
   @Nullable
   private ArmorStand armorStand;
   @Nullable
   private TemporaryArtifactHandle standHandle;

   public DyeLeatherBehavior(DyeLeatherConfig config, BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.preconditions.add(this.jobSiteBlockExistsCondition);
      this.cauldron = null;
      this.cauldronPos = null;
      this.standLocation = null;
      this.chosenColor = null;
      this.armorStand = null;
      this.standHandle = null;
      this.initializeStateMachine(this.createControlStep(), DyeLeatherBehavior.DyeStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("DyeLeatherArmorBehavior").initialStage(DyeLeatherBehavior.DyeStage.DYE_LEATHER).stageStepMap(Map.of(DyeLeatherBehavior.DyeStage.DYE_LEATHER, this.createDyeStep())).nextStage(DyeLeatherBehavior.DyeStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      if (this.jobSiteBlockExistsCondition.getJobSiteBlock().isEmpty()) {
         this.requestStop("No cauldron block found at job site");
      } else {
         this.cauldron = (PhysicalBlock)this.jobSiteBlockExistsCondition.getJobSiteBlock().get();
         this.cauldronPos = this.cauldron.getLocation(false).toBlockPos();
         Optional<StandPlacement> placement = this.resolveStandPlacement(world);
         if (placement.isEmpty()) {
            this.requestStop("No open spot near the cauldron to place an armor stand");
         } else {
            StandPlacement standPlacement = (StandPlacement)placement.get();
            this.standLocation = Location.of(standPlacement.standPos(), world).center(true);
            this.chosenColor = (DyeColor)RandomUtil.choice(DyeColor.values());
            Location approachCenter = Location.of(standPlacement.approachPos(), world).center(true);
            context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromLocation(approachCenter)));
         }
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      if (this.cauldronPos == null) {
         return false;
      } else {
         BlockState current = world.m_8055_(this.cauldronPos);
         return current.m_60713_(Blocks.f_50256_) || current.m_60713_(Blocks.f_152476_);
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.cauldron = null;
      this.cauldronPos = null;
      this.standLocation = null;
      this.chosenColor = null;
      this.armorStand = null;
      this.standHandle = null;
   }

   private BehaviorStep<BaseVillager> createDyeStep() {
      TimeBasedStep<BaseVillager> placeStand = TimeBasedStep.<BaseVillager>builder().withTickable(PLACE_STAND_DURATION.asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).setHeldItem(Items.f_42650_.m_7968_());
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).onEnd((ctx) -> {
         if (this.standLocation != null && this.cauldronPos != null) {
            BaseVillager villager = (BaseVillager)ctx.getInitiator();
            double dx = villager.m_20185_() - this.standLocation.getX();
            double dz = villager.m_20189_() - this.standLocation.getZ();
            float faceYaw = (float)(Mth.m_14136_(dz, dx) * (180D / Math.PI)) - 90.0F;
            float snappedYaw = (float)Mth.m_14143_((Mth.m_14177_(faceYaw) + 22.5F) / 45.0F) * 45.0F;
            this.standLocation.setYaw(snappedYaw);
            ArmorStand stand = new ArmorStand(ctx.getLevel(), this.standLocation.getX(), this.standLocation.getY(), this.standLocation.getZ());
            stand.m_20242_(true);
            stand.m_20331_(true);
            stand.m_31681_(true);
            this.standLocation.playSound(SoundEvents.f_11684_, 0.75F, 0.8F, SoundSource.BLOCKS);
            this.standLocation.spawnEntity(stand);
            this.armorStand = stand;
            this.standHandle = ctx.getTeardownScope().track(new DiscardEntityObligation(stand.m_20148_(), this.standLocation.toBlockPos()));
            ((BaseVillager)ctx.getInitiator()).clearHeldItem();
            ctx.setState(BehaviorStateType.LOOK_TARGET, LookState.ofLocation(this.standLocation.add((double)0.0F, 1.2, (double)0.0F, true)));
            return StepResult.noOp();
         } else {
            return StepResult.complete();
         }
      }).build();
      TimeBasedStep<BaseVillager> equipFeet = this.equipBeat(EquipmentSlot.FEET, Items.f_42463_);
      TimeBasedStep<BaseVillager> equipLegs = this.equipBeat(EquipmentSlot.LEGS, Items.f_42462_);
      TimeBasedStep<BaseVillager> equipChest = this.equipBeat(EquipmentSlot.CHEST, Items.f_42408_);
      TimeBasedStep<BaseVillager> equipHead = this.equipBeat(EquipmentSlot.HEAD, Items.f_42407_);
      TimeBasedStep<BaseVillager> dyeFeet = this.dyeBeat(EquipmentSlot.FEET, Items.f_42463_);
      TimeBasedStep<BaseVillager> dyeLegs = this.dyeBeat(EquipmentSlot.LEGS, Items.f_42462_);
      TimeBasedStep<BaseVillager> dyeChest = this.dyeBeat(EquipmentSlot.CHEST, Items.f_42408_);
      TimeBasedStep<BaseVillager> dyeHead = this.dyeBeat(EquipmentSlot.HEAD, Items.f_42407_);
      TimeBasedStep<BaseVillager> dry = TimeBasedStep.<BaseVillager>builder().withTickable(DRY_DURATION.asTickable()).addPeriodicStep(5, (ctx) -> {
         if (this.standLocation != null && this.chosenColor != null) {
            Location chestHeight = this.standLocation.add((double)0.0F, 1.2, (double)0.0F, true);
            int particleColor = this.chosenColor.m_41071_();
            ColorParticleOption dyeParticle = ColorParticleOption.create(ParticleTypes.f_123811_, particleColor);
            chestHeight.displayParticles(dyeParticle, 4, 0.2, 0.2, 0.2, (double)0.0F);
            return StepResult.noOp();
         } else {
            return StepResult.noOp();
         }
      }).onEnd((ctx) -> {
         if (this.standLocation != null && this.chosenColor != null) {
            Location chestHeight = this.standLocation.add((double)0.0F, (double)1.0F, (double)0.0F, true);
            chestHeight.displayParticles(ParticleTypes.f_175829_, 15, 0.4, (double)1.0F, 0.4, 0.1);
            chestHeight.playSound(SoundEvents.f_12546_, 0.4F, 1.3F, SoundSource.NEUTRAL);
            return StepResult.noOp();
         } else {
            return StepResult.noOp();
         }
      }).build();
      TimeBasedStep<BaseVillager> unequipHead = this.unequipBeat(EquipmentSlot.HEAD, Items.f_42407_);
      TimeBasedStep<BaseVillager> unequipChest = this.unequipBeat(EquipmentSlot.CHEST, Items.f_42408_);
      TimeBasedStep<BaseVillager> unequipLegs = this.unequipBeat(EquipmentSlot.LEGS, Items.f_42462_);
      TimeBasedStep<BaseVillager> unequipFeet = this.unequipBeat(EquipmentSlot.FEET, Items.f_42463_);
      TimeBasedStep<BaseVillager> retrieve = TimeBasedStep.<BaseVillager>builder().withTickable(RETRIEVE_STAND_DURATION.asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).setHeldItem(Items.f_42650_.m_7968_());
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).onEnd((ctx) -> {
         if (this.standHandle != null) {
            this.standHandle.dispose(ctx.getLevel());
            this.standHandle = null;
         }

         this.armorStand = null;
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         this.rewardExperience(((BaseVillager)ctx.getInitiator()).getMinecraftEntity());
         if (this.chosenColor != null) {
            BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.LEATHER_DYED, (String)null);
            outcome.recordDeedDetail(this.chosenColor.m_41065_());
            outcome.putDetailField("color", this.chosenColor.m_41065_());
            ctx.declarePrimaryDeed(outcome);
         }

         return StepResult.complete();
      }).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 1)).actionStep(new SequencedStep("DyeLeatherBehavior.sequence", List.of(placeStand, equipFeet, equipLegs, equipChest, equipHead, dyeFeet, dyeLegs, dyeChest, dyeHead, dry, unequipHead, unequipChest, unequipLegs, unequipFeet, retrieve))).build();
   }

   private TimeBasedStep<BaseVillager> equipBeat(EquipmentSlot slot, Item leatherItem) {
      return TimeBasedStep.<BaseVillager>builder().withTickable(EQUIP_PIECE_DURATION.asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).setHeldItem(new ItemStack(leatherItem));
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).onEnd((ctx) -> {
         if (this.armorStand != null) {
            this.armorStand.m_8061_(slot, new ItemStack(leatherItem));
         }

         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         if (this.standLocation != null) {
            this.standLocation.playSound(SoundEvents.f_11678_, 0.5F, 1.0F, SoundSource.PLAYERS);
         }

         return StepResult.noOp();
      }).build();
   }

   private TimeBasedStep<BaseVillager> dyeBeat(EquipmentSlot slot, Item leatherItem) {
      return TimeBasedStep.<BaseVillager>builder().withTickable(DYE_DURATION.asTickable()).onStart((ctx) -> {
         if (this.chosenColor != null) {
            ((BaseVillager)ctx.getInitiator()).setHeldItem(new ItemStack(DyeItem.m_41082_(this.chosenColor)));
         }

         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).onEnd((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         if (this.armorStand != null && this.chosenColor != null) {
            int armorRgb = this.chosenColor.m_41071_() & 16777215;
            this.applyDyeToSlot(slot, leatherItem, armorRgb);
            if (this.standLocation != null) {
               int particleColor = this.chosenColor.m_41071_();
               ColorParticleOption dyeParticle = ColorParticleOption.create(ParticleTypes.f_123811_, particleColor);
               this.standLocation.add((double)0.0F, 1.2, (double)0.0F, true).displayParticles(dyeParticle, 5, (double)0.25F, 0.3, (double)0.25F, (double)0.0F);
               this.standLocation.playSound(SoundEvents.f_12019_, 0.4F, 0.9F, SoundSource.BLOCKS);
            }

            return StepResult.noOp();
         } else {
            return StepResult.noOp();
         }
      }).build();
   }

   private TimeBasedStep<BaseVillager> unequipBeat(EquipmentSlot slot, Item leatherItem) {
      return TimeBasedStep.<BaseVillager>builder().withTickable(UNEQUIP_PIECE_DURATION.asTickable()).onStart((ctx) -> {
         if (this.chosenColor != null) {
            int armorRgb = this.chosenColor.m_41071_() & 16777215;
            ItemStack dyedStack = new ItemStack(leatherItem);
            if (dyedStack.m_41720_() instanceof DyeableLeatherItem) {
               ((DyeableLeatherItem)dyedStack.m_41720_()).m_41115_(dyedStack, armorRgb);
            }

            ((BaseVillager)ctx.getInitiator()).setHeldItem(dyedStack);
         } else {
            ((BaseVillager)ctx.getInitiator()).setHeldItem(new ItemStack(leatherItem));
         }

         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).onEnd((ctx) -> {
         if (this.armorStand != null) {
            this.armorStand.m_8061_(slot, ItemStack.f_41583_);
         }

         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         if (this.standLocation != null) {
            this.standLocation.playSound(SoundEvents.f_11678_, 0.5F, 1.0F, SoundSource.PLAYERS);
         }

         return StepResult.noOp();
      }).build();
   }

   private void applyDyeToSlot(EquipmentSlot slot, Item leatherItem, int armorRgb) {
      if (this.armorStand != null) {
         ItemStack stack = new ItemStack(leatherItem);
         if (stack.m_41720_() instanceof DyeableLeatherItem) {
            ((DyeableLeatherItem)stack.m_41720_()).m_41115_(stack, armorRgb);
         }

         this.armorStand.m_8061_(slot, stack);
      }
   }

   private Optional<StandPlacement> resolveStandPlacement(@Nonnull Level world) {
      if (this.cauldronPos == null) {
         return Optional.empty();
      } else {
         List<StandPlacement> placements = new ArrayList();

         for(int dx = -4; dx <= 4; ++dx) {
            for(int dz = -4; dz <= 4; ++dz) {
               BlockPos standPos = this.cauldronPos.m_7918_(dx, 0, dz);
               if (isOpenStandingColumn(world, standPos)) {
                  this.findApproach(world, standPos).ifPresent((approachPos) -> placements.add(new StandPlacement(standPos, approachPos)));
               }
            }
         }

         return RandomUtil.choice(placements);
      }
   }

   private Optional<BlockPos> findApproach(@Nonnull Level world, @Nonnull BlockPos standPos) {
      for(Direction direction : Plane.HORIZONTAL) {
         BlockPos approachPos = standPos.m_121945_(direction);
         if (isOpenStandingColumn(world, approachPos)) {
            return Optional.of(approachPos);
         }
      }

      return Optional.empty();
   }

   private static boolean isOpenStandingColumn(@Nonnull Level world, @Nonnull BlockPos pos) {
      return world.m_8055_(pos).m_60795_() && world.m_8055_(pos.m_7494_()).m_60795_() && !world.m_8055_(pos.m_7495_()).m_60795_();
   }

   private static enum DyeStage implements StageKey {
      DYE_LEATHER,
      END;

      // $FF: synthetic method
      private static DyeStage[] $values() {
         return new DyeStage[]{DYE_LEATHER, END};
      }
   }

   private static record StandPlacement(BlockPos standPos, BlockPos approachPos) {
   }
}
