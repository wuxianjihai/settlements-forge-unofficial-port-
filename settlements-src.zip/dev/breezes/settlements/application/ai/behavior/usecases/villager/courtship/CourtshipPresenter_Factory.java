package dev.breezes.settlements.application.ai.behavior.usecases.villager.courtship;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.courtship.CourtshipChoreographyLibrary;
import dev.breezes.settlements.application.ui.bubble.VillagerBubbleService;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class CourtshipPresenter_Factory implements Factory<CourtshipPresenter> {
   private final Provider<VillagerBubbleService> villagerBubbleServiceProvider;
   private final Provider<CourtshipChoreographyLibrary> choreographyLibraryProvider;

   private CourtshipPresenter_Factory(Provider<VillagerBubbleService> villagerBubbleServiceProvider, Provider<CourtshipChoreographyLibrary> choreographyLibraryProvider) {
      this.villagerBubbleServiceProvider = villagerBubbleServiceProvider;
      this.choreographyLibraryProvider = choreographyLibraryProvider;
   }

   public CourtshipPresenter get() {
      return newInstance((VillagerBubbleService)this.villagerBubbleServiceProvider.get(), (CourtshipChoreographyLibrary)this.choreographyLibraryProvider.get());
   }

   public static CourtshipPresenter_Factory create(Provider<VillagerBubbleService> villagerBubbleServiceProvider, Provider<CourtshipChoreographyLibrary> choreographyLibraryProvider) {
      return new CourtshipPresenter_Factory(villagerBubbleServiceProvider, choreographyLibraryProvider);
   }

   public static CourtshipPresenter newInstance(VillagerBubbleService villagerBubbleService, CourtshipChoreographyLibrary choreographyLibrary) {
      return new CourtshipPresenter(villagerBubbleService, choreographyLibrary);
   }
}
