package dev.breezes.settlements.application.ai.behavior.usecases.villager.nitwit;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.LoopBackStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.OneShotStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.cuccos.CuccoEntity;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public class ChaseChickensBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ChaseChickensBehavior.class.getName());
   private static final float STRIKE_DAMAGE = 0.01F;
   private static final double CHASE_SPAWN_RADIUS = (double)4.0F;
   private static final double CHASE_REACH_DISTANCE = (double)1.5F;
   private static final int SPAWN_HEIGHT = 4;
   private static final int NORMAL_STRIKES = 2;
   private static final int STRIKE_DURATION_TICKS = 10;
   private static final int STRIKE_IMPACT_TICK = 4;
   private static final int CHASE_TIMEOUT_TICKS = ClockTicks.seconds((double)8.0F).getTicksAsInt();
   private static final double REAL_CHICKEN_SCAN_RADIUS = (double)16.0F;
   private static final double SWARM_RADIUS = (double)2.0F;
   private static final int REVENGE_SPAWN_WINDOW = ClockTicks.seconds((double)5.0F).getTicksAsInt();
   private static final int REVENGE_FALL_SOUND_INTERVAL = ClockTicks.seconds((double)0.5F).getTicksAsInt();
   private static final int SWARM_SPAWN_INTERVAL = 4;
   private static final ClockTicks SWARM_CUCCO_LIFETIME = ClockTicks.seconds((double)2.0F);
   private final double revengeSwarmChance;
   @Nullable
   private Chicken targetChicken;
   private boolean targetChickenSpawned;
   private int normalStrikesLanded;

   public ChaseChickensBehavior(@Nonnull ChaseChickensConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.revengeSwarmChance = config.revengeSwarmChance();
      this.targetChicken = null;
      this.targetChickenSpawned = false;
      this.normalStrikesLanded = 0;
      this.initializeStateMachine(this.createControlStep(), ChaseChickensBehavior.Stage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("ChaseChickensBehavior").initialStage(ChaseChickensBehavior.Stage.SPAWN_TARGET).stageStepMap(Map.of(ChaseChickensBehavior.Stage.SPAWN_TARGET, this.createSpawnTargetStep(), ChaseChickensBehavior.Stage.CHASE_MOVE, this.createChaseMoveStep(), ChaseChickensBehavior.Stage.CHASE_LOOP, LoopBackStep.builder().name("ChickenChaseLoop").loopBackTo(ChaseChickensBehavior.Stage.CHASE_MOVE).completionTransition(ChaseChickensBehavior.Stage.REVENGE_ROLL).maxIterationsResolver((ctx) -> 2).build(), ChaseChickensBehavior.Stage.REVENGE_ROLL, this.createRevengeRollStep(), ChaseChickensBehavior.Stage.REVENGE_STRIKE, this.createRevengeStrikeStep(), ChaseChickensBehavior.Stage.REVENGE, this.createRevengeStep())).nextStage(ChaseChickensBehavior.Stage.END).build();
   }

   private BehaviorStep<BaseVillager> createSpawnTargetStep() {
      return OneShotStep.<BaseVillager>builder().name("ChickenSpawnTarget").action((ctx) -> {
         BaseVillager villager = (BaseVillager)ctx.getInitiator();
         this.normalStrikesLanded = 0;
         this.targetChicken = this.findOrSpawnTargetChicken(villager);
         if (this.targetChicken == null) {
            return StepResult.transition(ChaseChickensBehavior.Stage.END);
         } else {
            ctx.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.targetChicken)));
            return StepResult.transition(ChaseChickensBehavior.Stage.CHASE_MOVE);
         }
      }).build();
   }

   @Nullable
   private Chicken findOrSpawnTargetChicken(@Nonnull BaseVillager villager) {
      List<Chicken> realChickens = villager.m_9236_().m_6443_(Chicken.class, villager.m_20191_().m_82400_((double)16.0F), (candidate) -> candidate.m_6084_() && !(candidate instanceof CuccoEntity));
      Stream var10000 = realChickens.stream();
      Objects.requireNonNull(villager);
      Chicken nearest = (Chicken)var10000.min(Comparator.comparingDouble(villager::m_20280_)).orElse((Object)null);
      if (nearest != null) {
         this.targetChickenSpawned = false;
         return nearest;
      } else {
         Level var5 = villager.m_9236_();
         if (var5 instanceof ServerLevel) {
            ServerLevel serverLevel = (ServerLevel)var5;
            double var16 = RandomUtil.randomDouble((double)0.0F, (Math.PI * 2D));
            double radius = RandomUtil.randomDouble((double)0.0F, (double)4.0F);
            double sx = villager.m_20185_() + Math.cos(var16) * radius;
            double sy = villager.m_20186_() + (double)4.0F;
            double sz = villager.m_20189_() + Math.sin(var16) * radius;
            Chicken chicken = (Chicken)EntityType.f_20555_.m_20615_(serverLevel);
            if (chicken == null) {
               return null;
            } else {
               chicken.m_7678_(sx, sy, sz, villager.m_146908_(), 0.0F);
               chicken.m_6518_(serverLevel, serverLevel.m_6436_(BlockPos.m_274561_(sx, sy, sz)), MobSpawnType.TRIGGERED, (SpawnGroupData)null, (CompoundTag)null);
               serverLevel.m_7967_(chicken);
               this.targetChickenSpawned = true;
               return chicken;
            }
         } else {
            return null;
         }
      }
   }

   private BehaviorStep<BaseVillager> createChaseMoveStep() {
      return this.createStrikeStep("ChickenStrike", ChaseChickensBehavior.Stage.CHASE_LOOP, this::strikeTargetChicken);
   }

   private BehaviorStep<BaseVillager> createRevengeStrikeStep() {
      return this.createStrikeStep("ChickenRevengeStrike", ChaseChickensBehavior.Stage.REVENGE, this::strikeAndPoofTargetChicken);
   }

   private BehaviorStep<BaseVillager> createStrikeStep(@Nonnull String name, @Nonnull Stage nextStage, @Nonnull BehaviorStep<BaseVillager> impactStep) {
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)1.5F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.RUN).completionDistance(1).unreachableTransition(nextStage).build()).actionStep(TimeBasedStep.builder().name(name).withTickable(ClockTicks.of(10L).asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(4L), impactStep).onEnd((ctx) -> StepResult.transition(nextStage)).build()).timeoutTicks(CHASE_TIMEOUT_TICKS).timeoutTransition(nextStage).build();
   }

   private StepResult strikeTargetChicken(@Nonnull BehaviorContext<BaseVillager> context) {
      if (this.targetChicken != null && this.targetChicken.m_6084_() && !this.targetChicken.m_213877_()) {
         BaseVillager villager = context.getInitiator();
         this.targetChicken.m_6469_(villager.m_269291_().m_269333_(villager), 0.01F);
         Location targetLocation = Location.fromEntity(this.targetChicken, false);
         ParticleRegistry.featherPoof(targetLocation);
         ++this.normalStrikesLanded;
         if (this.normalStrikesLanded == 2) {
            this.targetChicken.m_19998_(Items.f_42521_);
            targetLocation.playSound(SoundEvents.f_11752_, 1.0F, 1.0F, SoundSource.NEUTRAL);
         }

         if (context.primaryDeed().isEmpty()) {
            BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.CHICKENS_CHASED, (String)null);
            outcome.markSucceeded();
            context.declarePrimaryDeed(outcome);
         }

         return StepResult.noOp();
      } else {
         return StepResult.transition(ChaseChickensBehavior.Stage.CHASE_LOOP);
      }
   }

   private StepResult strikeAndPoofTargetChicken(@Nonnull BehaviorContext<BaseVillager> context) {
      if (this.targetChicken != null && this.targetChicken.m_6084_() && !this.targetChicken.m_213877_()) {
         BaseVillager villager = context.getInitiator();
         this.targetChicken.m_6469_(villager.m_269291_().m_269333_(villager), 0.01F);
         Location targetLocation = Location.fromEntity(this.targetChicken, false);
         ParticleRegistry.featherPoof(targetLocation);
         if (this.targetChickenSpawned) {
            this.targetChicken.m_146870_();
         }

         this.targetChicken = null;
         return StepResult.noOp();
      } else {
         return StepResult.transition(ChaseChickensBehavior.Stage.REVENGE);
      }
   }

   private BehaviorStep<BaseVillager> createRevengeRollStep() {
      return OneShotStep.<BaseVillager>builder().name("ChickenRevengeRoll").action((ctx) -> RandomUtil.chance(this.revengeSwarmChance) ? StepResult.transition(ChaseChickensBehavior.Stage.REVENGE_STRIKE) : StepResult.transition(ChaseChickensBehavior.Stage.END)).build();
   }

   private BehaviorStep<BaseVillager> createRevengeStep() {
      return TimeBasedStep.<BaseVillager>builder().name("CuccoRevengeSwarm").withTickable(ClockTicks.of((long)REVENGE_SPAWN_WINDOW).asTickable()).onStart((ctx) -> {
         BaseVillager villager = (BaseVillager)ctx.getInitiator();
         Location villagerLocation = Location.fromEntity(villager, false);
         SoundRegistry.CUCCO_CALL.playGlobally(villagerLocation, SoundSource.NEUTRAL);
         villager.getNavigationManager().stop();
         ctx.addSecondaryDeed(BehaviorOutcome.forDeed(WorldEventType.CHICKENS_REVENGED, (String)null)).markSucceeded();
         return StepResult.noOp();
      }).addPeriodicStep(REVENGE_FALL_SOUND_INTERVAL, (ctx) -> {
         Location villagerLocation = Location.fromEntity((Entity)ctx.getInitiator(), false);
         SoundRegistry.CUCCO_FALL.playGlobally(villagerLocation, SoundSource.NEUTRAL);
         return StepResult.noOp();
      }).addPeriodicStep(4, (ctx) -> {
         BaseVillager villager = (BaseVillager)ctx.getInitiator();
         Location cuccoLocation = this.pickSpawnLocation(villager, (double)2.0F);
         CuccoEntity cucco = CuccoEntity.spawn(cuccoLocation, SWARM_CUCCO_LIFETIME);
         cucco.m_6710_(villager);
         ParticleRegistry.featherPoof(cuccoLocation);
         return StepResult.noOp();
      }).onEnd((ctx) -> StepResult.transition(ChaseChickensBehavior.Stage.END)).build();
   }

   private Location pickSpawnLocation(@Nonnull BaseVillager villager, double maxRadius) {
      double angle = RandomUtil.randomDouble((double)0.0F, (Math.PI * 2D));
      double radius = RandomUtil.randomDouble((double)0.0F, maxRadius);
      return Location.of(villager.m_20185_() + Math.cos(angle) * radius, villager.m_20186_() + (double)4.0F, villager.m_20189_() + Math.sin(angle) * radius, villager.m_9236_());
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      return villager.m_6084_() && !villager.m_213877_();
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.setMotion(AnimationArchetype.IDLE);
      if (this.targetChicken != null && this.targetChickenSpawned && !this.targetChicken.m_213877_()) {
         this.targetChicken.m_146870_();
      }

      this.targetChicken = null;
      this.targetChickenSpawned = false;
      this.normalStrikesLanded = 0;
   }

   private static enum Stage implements StageKey {
      SPAWN_TARGET,
      CHASE_MOVE,
      CHASE_LOOP,
      REVENGE_ROLL,
      REVENGE_STRIKE,
      REVENGE,
      END;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{SPAWN_TARGET, CHASE_MOVE, CHASE_LOOP, REVENGE_ROLL, REVENGE_STRIKE, REVENGE, END};
      }
   }
}
