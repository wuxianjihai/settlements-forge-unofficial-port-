package dev.breezes.settlements.application.ai.behavior.usecases.villager.trading;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.ai.trading.TradeSession;
import dev.breezes.settlements.application.ai.trading.TradeSessionPhase;
import dev.breezes.settlements.application.ai.trading.TradeSessionRegistry;
import dev.breezes.settlements.application.ai.trading.TradingConfig;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.RandomRangeTickable;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;

public final class TradeAcceptBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(TradeAcceptBehavior.class.getName());
   private static final double APPROACH_DISTANCE_SQUARED = (double)9.0F;
   private static final ClockTicks RESPONDER_PRESENTATION_DELAY = ClockTicks.seconds((double)2.0F);
   private static final double TRADE_CLOSE_ENOUGH_DISTANCE = (double)3.0F;
   private final TradeSessionRegistry sessionRegistry;
   private final TradeSessionPresenter tradeSessionPresenter;
   @Nullable
   private PresentationSignature lastObservedSignature;

   public TradeAcceptBehavior(@Nonnull TradingConfig config, @Nonnull BehaviorSupport support, @Nonnull TradeSessionRegistry sessionRegistry, @Nonnull TradeSessionPresenter tradeSessionPresenter) {
      super(log, ClockTicks.seconds((double)config.acceptPreconditionCooldownSeconds()).asTickable(), RandomRangeTickable.of(ClockTicks.seconds((double)config.acceptBehaviorCooldownSecondsMax()), ClockTicks.seconds((double)config.acceptBehaviorCooldownSecondsMin())), support);
      this.sessionRegistry = sessionRegistry;
      this.tradeSessionPresenter = tradeSessionPresenter;
      this.preconditions.add(this.hasTradeToMirror());
      this.initializeStateMachine(StagedStep.builder().name("TradeAcceptBehavior").initialStage(TradeAcceptBehavior.MirrorStage.MIRROR).stageStepMap(Map.of(TradeAcceptBehavior.MirrorStage.MIRROR, StayCloseStep.builder().closeEnoughDistance((double)3.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 2)).actionStep(this::mirror).build())).nextStage(TradeAcceptBehavior.MirrorStage.CLOSED).build(), TradeAcceptBehavior.MirrorStage.CLOSED);
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      long currentGameTime = world.m_46467_();
      if (this.sessionRegistry.hasInviteFor(villager.m_20148_())) {
         this.sessionRegistry.acceptInvite(villager.m_20148_(), currentGameTime);
      }

      this.lastObservedSignature = null;
      if (world instanceof ServerLevel serverLevel) {
         Optional.ofNullable(serverLevel.m_8791_(villager.m_20148_())).map(Targetable::fromEntity).ifPresent((target) -> context.setState(BehaviorStateType.TARGET, TargetState.of(target)));
      }

   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      this.lastObservedSignature = null;
   }

   private ICondition<BaseVillager> hasTradeToMirror() {
      return ICondition.<BaseVillager>named("HasTradeToMirror", (villager) -> this.sessionRegistry.hasInviteFor(villager.m_20148_()) || this.sessionRegistry.getActiveSession(villager.m_20148_()).isPresent());
   }

   private StepResult mirror(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager self = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      TradeSession session = (TradeSession)this.sessionRegistry.getActiveSession(self.m_20148_()).orElse((Object)null);
      if (session == null) {
         log.behaviorWarn("Trade session is null, stopping the behavior");
         return StepResult.fail("Trade session is null");
      } else {
         PresentationSignature signature = TradeAcceptBehavior.PresentationSignature.from(session);
         if (!Objects.equals(signature, this.lastObservedSignature) && this.isPresentationReady(session, self.m_9236_().m_46467_())) {
            this.presentPhase(session, self);
            this.lastObservedSignature = signature;
         }

         StepResult var10000;
         switch (session.getPhase()) {
            case EXTERNAL_CANCEL:
            case CLOSED:
               var10000 = StepResult.complete();
               break;
            default:
               var10000 = StepResult.noOp();
         }

         return var10000;
      }
   }

   private boolean isPresentationReady(@Nonnull TradeSession session, long now) {
      boolean var10000;
      switch (session.getPhase()) {
         case EXTERNAL_CANCEL:
         case CLOSED:
            var10000 = true;
            break;
         case DEAL:
         case WALK_AWAY:
            var10000 = false;
            break;
         default:
            var10000 = now - session.getPhaseEnteredGameTime() >= RESPONDER_PRESENTATION_DELAY.getTicks();
      }

      return var10000;
   }

   private void presentPhase(@Nonnull TradeSession session, @Nonnull BaseVillager self) {
      switch (session.getPhase()) {
         case DEAL -> this.tradeSessionPresenter.presentDeal(session, self);
         case WALK_AWAY -> this.tradeSessionPresenter.presentWalkAway(session, self);
         case OPENING_OFFER -> this.tradeSessionPresenter.presentOpeningOffer(session, self);
         case NEGOTIATING -> this.tradeSessionPresenter.presentNegotiationUpdate(session, self);
      }

   }

   private static enum MirrorStage implements StageKey {
      MIRROR,
      CLOSED;

      // $FF: synthetic method
      private static MirrorStage[] $values() {
         return new MirrorStage[]{MIRROR, CLOSED};
      }
   }

   private static record PresentationSignature(@Nonnull TradeSessionPhase phase, int buyerOffer, int sellerAsk) {
      private static PresentationSignature from(@Nonnull TradeSession session) {
         return new PresentationSignature(session.getPhase(), session.getBuyerOffer(), session.getSellerAsk());
      }
   }
}
