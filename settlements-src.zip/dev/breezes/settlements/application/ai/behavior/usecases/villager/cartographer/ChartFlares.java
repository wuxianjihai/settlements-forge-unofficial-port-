package dev.breezes.settlements.application.ai.behavior.usecases.villager.cartographer;

import dev.breezes.settlements.domain.entities.Expertise;
import dev.breezes.settlements.infrastructure.compat.NetworkHelper;
import dev.breezes.settlements.infrastructure.network.features.flare.packet.ClientBoundFlarePacket;
import dev.breezes.settlements.infrastructure.network.features.flare.packet.FlareExplosion;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;
import javax.annotation.Nonnull;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.entity.raid.Raid;
import net.minecraft.world.entity.raid.Raider;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.phys.Vec3;

final class ChartFlares {
   private static final double HIDE_WITHIN = (double)32.0F;
   private static final double MIN_APEX_RISE = (double)16.0F;
   private static final double MAX_APEX_RISE = (double)32.0F;
   private static final int MIN_SIGNAL_FLIGHT_DURATION = 3;
   private static final int MAX_SIGNAL_FLIGHT_DURATION = 5;
   private static final int[] RED;
   private static final FlareExplosion SMALL_BURST;
   private static final FlareExplosion LARGE_BURST;

   static void launchSignal(@Nonnull ServerLevel level, @Nonnull Entity cartographer, @Nonnull Expertise expertise, @Nonnull RandomSource random) {
      double x = cartographer.m_20185_();
      double z = cartographer.m_20189_();
      int surface = surfaceAt(level, x, z);

      for(int i = 0; i < flareCount(expertise); ++i) {
         ItemStack rocket = new ItemStack(Items.f_42688_);
         CompoundTag fireworks = new CompoundTag();
         fireworks.m_128344_("FlightDuration", (byte)Mth.m_216271_(random, 3, 5));
         fireworks.m_128365_("Explosions", new ListTag());
         rocket.m_41784_().m_128365_("Fireworks", fireworks);
         level.m_7967_(new FireworkRocketEntity(level, cartographer, x, (double)surface, z, rocket));
      }

   }

   static void send(@Nonnull ServerLevel level, @Nonnull Raid raid, @Nonnull List<Raider> charted, @Nonnull Expertise expertise, @Nonnull RandomSource random) {
      if (!charted.isEmpty()) {
         double spread = spread(expertise);
         List<FlareExplosion> burst = List.of(expertise.getLevel() >= Expertise.JOURNEYMAN.getLevel() ? LARGE_BURST : SMALL_BURST);
         List<ClientBoundFlarePacket.Flare> flares = IntStream.range(0, flareCount(expertise)).mapToObj((i) -> launchPoint(level, (Raider)charted.get(i % charted.size()), spread, random)).flatMap(Optional::stream).map((launch) -> new ClientBoundFlarePacket.Flare(launch, launch.f_82480_ + Mth.m_216263_(random, (double)16.0F, (double)32.0F), burst)).toList();
         if (!flares.isEmpty()) {
            ClientBoundFlarePacket packet = new ClientBoundFlarePacket((double)32.0F, flares);

            for(ServerPlayer recipient : level.m_8795_((player) -> player.m_6084_() && level.m_8832_(player.m_20183_()) == raid)) {
               NetworkHelper.sendToPlayer(recipient, packet);
            }

         }
      }
   }

   private static int flareCount(@Nonnull Expertise expertise) {
      byte var10000;
      switch (expertise) {
         case NOVICE:
         case APPRENTICE:
         case JOURNEYMAN:
            var10000 = 1;
            break;
         case EXPERT:
            var10000 = 2;
            break;
         case MASTER:
            var10000 = 3;
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   private static double spread(@Nonnull Expertise expertise) {
      double var10000;
      switch (expertise) {
         case NOVICE -> var10000 = (double)24.0F;
         case APPRENTICE -> var10000 = (double)18.0F;
         case JOURNEYMAN -> var10000 = (double)12.0F;
         case EXPERT -> var10000 = (double)6.0F;
         case MASTER -> var10000 = (double)0.0F;
         default -> throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   private static Optional<Vec3> launchPoint(@Nonnull ServerLevel level, @Nonnull Raider raider, double spread, @Nonnull RandomSource random) {
      double angle = random.m_188500_() * (double)((float)Math.PI * 2F);
      double distance = spread * Math.sqrt(random.m_188500_());
      double x = raider.m_20185_() + distance * Math.cos(angle);
      double z = raider.m_20189_() + distance * Math.sin(angle);
      int surface = surfaceAt(level, x, z);
      if (surface <= level.m_141937_()) {
         x = raider.m_20185_();
         z = raider.m_20189_();
         surface = surfaceAt(level, x, z);
      }

      return surface <= level.m_141937_() ? Optional.empty() : Optional.of(new Vec3(x, (double)surface, z));
   }

   private static int surfaceAt(@Nonnull ServerLevel level, double x, double z) {
      return level.m_6924_(Types.WORLD_SURFACE, Mth.m_14107_(x), Mth.m_14107_(z));
   }

   private ChartFlares() {
   }

   static {
      RED = new int[]{DyeColor.RED.m_41070_()};
      SMALL_BURST = new FlareExplosion((byte)4, RED, new int[0], true, true);
      LARGE_BURST = new FlareExplosion((byte)1, RED, new int[0], true, true);
   }
}
