package dev.breezes.settlements.application.ai.behavior.usecases.villager.farming;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.blocks.VisitedBlockSitesState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetQueries;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.AwardExperienceStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.LoopBackStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.OneShotStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.ai.targeting.BlockMemoryTargetResolver;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.conditions.KnownBlockSitesPrecondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.AabbBlockScan;
import dev.breezes.settlements.domain.world.blocks.BlockMatcher;
import dev.breezes.settlements.domain.world.blocks.BlockMatchers;
import dev.breezes.settlements.domain.world.blocks.BlockScanBox;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.data.farming.hive.CollectHoneyYieldDataManager;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BeehiveBlock;
import net.minecraft.world.level.block.state.BlockState;

public class CollectHoneyBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(CollectHoneyBehavior.class.getName());
   private static final ResourceLocation GLASS_BOTTLE_ID = new ResourceLocation("minecraft", "glass_bottle");
   private static final int APPROACH_TIMEOUT_TICKS = ClockTicks.seconds((double)20.0F).getTicksAsInt();
   private final BlockMatcher fullHiveMatcher;
   private final BlockScanBox confirmBox;
   private final int maxConfirms;
   private final CollectHoneyConfig config;
   private final CollectHoneyYieldDataManager yieldData;
   private final BlockMemoryTargetResolver targetResolver;

   public CollectHoneyBehavior(@Nonnull CollectHoneyConfig config, @Nonnull BehaviorSupport support, @Nonnull CollectHoneyYieldDataManager yieldData) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.yieldData = yieldData;
      this.targetResolver = support.getBlockMemoryTargetResolver();
      this.fullHiveMatcher = BlockMatchers.FULL_HIVE;
      this.confirmBox = BlockScanBox.confirm();
      this.maxConfirms = 8;
      this.preconditions.add(KnownBlockSitesPrecondition.builder().memoryType(MemoryTypeRegistry.FULL_HIVE_SITES).matcher(this.fullHiveMatcher).confirmBox(this.confirmBox).maxSitesToConfirm(this.maxConfirms).completionRange(2).description("Known full hive sites").build());
      this.preconditions.add(support.getDemandSignalService().requireItem(new ItemMatch.ItemRef(GLASS_BOTTLE_ID), 1, 50, this.getClass().getSimpleName()));
      this.initializeStateMachine(this.createControlStep(), CollectHoneyBehavior.CollectStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      Map<StageKey, BehaviorStep<BaseVillager>> stageMap = new HashMap();
      stageMap.put(CollectHoneyBehavior.CollectStage.PICK_TARGET, this.createPickTargetStep());
      stageMap.put(CollectHoneyBehavior.CollectStage.APPROACH, StayCloseStep.builder().closeEnoughDistance((double)2.0F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.WALK).completionDistance(2).unreachableTransition(CollectHoneyBehavior.CollectStage.PICK_TARGET).build()).actionStep(OneShotStep.builder().name("ArrivedAtHoneyHive").action((context) -> StepResult.transition(CollectHoneyBehavior.CollectStage.COLLECT_HONEY)).build()).timeoutTicks(APPROACH_TIMEOUT_TICKS).timeoutTransition(CollectHoneyBehavior.CollectStage.PICK_TARGET).build());
      stageMap.put(CollectHoneyBehavior.CollectStage.COLLECT_HONEY, this.createCollectStep());
      stageMap.put(CollectHoneyBehavior.CollectStage.LOOP, LoopBackStep.builder().name("CollectHoneyLoopBack").loopBackTo(CollectHoneyBehavior.CollectStage.PICK_TARGET).completionTransition(CollectHoneyBehavior.CollectStage.AWARD).maxIterationsResolver((context) -> (Integer)this.config.expertiseHarvestLimit().getOrDefault(((BaseVillager)context.getInitiator()).getExpertise().getConfigName(), 1)).build());
      stageMap.put(CollectHoneyBehavior.CollectStage.AWARD, AwardExperienceStep.builder().name("AwardCollectHoneyXp").experienceAmount(this.config.experienceReward()).nextStage(CollectHoneyBehavior.CollectStage.END).build());
      return StagedStep.<BaseVillager>builder().name("CollectHoneyBehavior").initialStage(CollectHoneyBehavior.CollectStage.PICK_TARGET).stageStepMap(stageMap).nextStage(CollectHoneyBehavior.CollectStage.END).build();
   }

   private BehaviorStep<BaseVillager> createPickTargetStep() {
      return OneShotStep.<BaseVillager>builder().name("PickHoneyHiveTarget").action((context) -> {
         BaseVillager villager = (BaseVillager)context.getInitiator();
         if (!this.canHarvest(villager)) {
            return StepResult.transition(CollectHoneyBehavior.CollectStage.AWARD);
         } else {
            boolean resolved = this.targetResolver.resolveBlockTarget(context, MemoryTypeRegistry.FULL_HIVE_SITES, this.fullHiveMatcher, this.confirmBox, this.maxConfirms, 2);
            if (!resolved) {
               log.behaviorStatus("No additional full hive targets found, ending honey collection");
               return StepResult.transition(CollectHoneyBehavior.CollectStage.AWARD);
            } else {
               return StepResult.transition(CollectHoneyBehavior.CollectStage.APPROACH);
            }
         }
      }).build();
   }

   private BehaviorStep<BaseVillager> createCollectStep() {
      TimeBasedStep<BaseVillager> collectStep = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.seconds((double)2.0F).asTickable()).onStart((context) -> {
         ((BaseVillager)context.getInitiator()).setHeldItem(Items.f_42590_.m_7968_());
         ((BaseVillager)context.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(12L), this::performHarvest).onEnd((context) -> {
         ((BaseVillager)context.getInitiator()).clearHeldItem();
         return StepResult.transition(CollectHoneyBehavior.CollectStage.LOOP);
      }).build();
      return collectStep;
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      context.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.RESOURCE_HARVESTED, "honey bottles"));
      context.setState(BehaviorStateType.VISITED_BLOCK_SITES, VisitedBlockSitesState.empty());
      if (!this.canHarvest(entity)) {
         this.requestStop("Precondition check at behavior start failed");
      }

   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      villager.getNavigationManager().stop();
   }

   private boolean canHarvest(@Nonnull BaseVillager villager) {
      VillagerInventory inventory = villager.getSettlementsInventory();
      return inventory.containsOrBypassed(Items.f_42590_, GeneralConfig.bypassInventoryRequirements);
   }

   private StepResult performHarvest(@Nonnull BehaviorContext<BaseVillager> context) {
      Optional<BlockPos> target = TargetQueries.firstBlockPos(context);
      if (target.isEmpty()) {
         return StepResult.noOp();
      } else {
         BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
         Level level = villager.m_9236_();
         BlockPos pos = (BlockPos)target.get();
         BlockState state = level.m_8055_(pos);
         if (AabbBlockScan.findFirst(pos, BlockScanBox.self(), this.fullHiveMatcher, level).isEmpty()) {
            return StepResult.noOp();
         } else {
            VillagerInventory inventory = villager.getSettlementsInventory();
            if (!inventory.containsOrBypassed(Items.f_42590_, GeneralConfig.bypassInventoryRequirements)) {
               return StepResult.noOp();
            } else if (!inventory.consumeIfRequired(Items.f_42590_, 1, GeneralConfig.bypassInventoryRequirements)) {
               return StepResult.noOp();
            } else {
               String harvestedBlockId = BuiltInRegistries.f_256975_.m_7981_(state.m_60734_()).toString();
               String expertiseName = villager.getExpertise().getConfigName();
               int collectedCount = 0;

               for(ItemStack drop : this.yieldData.rollDrops(expertiseName, harvestedBlockId)) {
                  if (!drop.m_41619_()) {
                     inventory.add(drop);
                     collectedCount += drop.m_41613_();
                  }
               }

               level.m_46597_(pos, (BlockState)state.m_61124_(BeehiveBlock.f_49564_, 0));
               SoundRegistry.COLLECT_HONEY.playGlobally(Location.of(pos, level), SoundSource.BLOCKS);
               context.getState(BehaviorStateType.VISITED_BLOCK_SITES, VisitedBlockSitesState.class).ifPresent((visitedSites) -> visitedSites.addSite(GlobalPos.m_122643_(level.m_46472_(), pos)));
               context.primaryDeed().ifPresent((outcome) -> outcome.recordYield(collectedCount));
               return StepResult.noOp();
            }
         }
      }
   }

   private static enum CollectStage implements StageKey {
      PICK_TARGET,
      APPROACH,
      COLLECT_HONEY,
      LOOP,
      AWARD,
      END;

      // $FF: synthetic method
      private static CollectStage[] $values() {
         return new CollectStage[]{PICK_TARGET, APPROACH, COLLECT_HONEY, LOOP, AWARD, END};
      }
   }
}
