package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals;

import lombok.Generated;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.item.Item;

public final class BreedSpecies {
   private final EntityType<? extends Animal> type;
   private final TagKey<Item> foodTag;
   private final Item canonicalFood;

   @Generated
   BreedSpecies(EntityType<? extends Animal> type, TagKey<Item> foodTag, Item canonicalFood) {
      this.type = type;
      this.foodTag = foodTag;
      this.canonicalFood = canonicalFood;
   }

   @Generated
   public static BreedSpeciesBuilder builder() {
      return new BreedSpeciesBuilder();
   }

   @Generated
   public EntityType<? extends Animal> getType() {
      return this.type;
   }

   @Generated
   public TagKey<Item> getFoodTag() {
      return this.foodTag;
   }

   @Generated
   public Item getCanonicalFood() {
      return this.canonicalFood;
   }

   @Generated
   public boolean equals(Object o) {
      if (o == this) {
         return true;
      } else if (!(o instanceof BreedSpecies)) {
         return false;
      } else {
         BreedSpecies other = (BreedSpecies)o;
         Object this$type = this.getType();
         Object other$type = other.getType();
         if (this$type == null) {
            if (other$type != null) {
               return false;
            }
         } else if (!this$type.equals(other$type)) {
            return false;
         }

         Object this$foodTag = this.getFoodTag();
         Object other$foodTag = other.getFoodTag();
         if (this$foodTag == null) {
            if (other$foodTag != null) {
               return false;
            }
         } else if (!this$foodTag.equals(other$foodTag)) {
            return false;
         }

         Object this$canonicalFood = this.getCanonicalFood();
         Object other$canonicalFood = other.getCanonicalFood();
         if (this$canonicalFood == null) {
            if (other$canonicalFood != null) {
               return false;
            }
         } else if (!this$canonicalFood.equals(other$canonicalFood)) {
            return false;
         }

         return true;
      }
   }

   @Generated
   public int hashCode() {
      int PRIME = 59;
      int result = 1;
      Object $type = this.getType();
      result = result * 59 + ($type == null ? 43 : $type.hashCode());
      Object $foodTag = this.getFoodTag();
      result = result * 59 + ($foodTag == null ? 43 : $foodTag.hashCode());
      Object $canonicalFood = this.getCanonicalFood();
      result = result * 59 + ($canonicalFood == null ? 43 : $canonicalFood.hashCode());
      return result;
   }

   @Generated
   public String toString() {
      String var10000 = String.valueOf(this.getType());
      return "BreedSpecies(type=" + var10000 + ", foodTag=" + String.valueOf(this.getFoodTag()) + ", canonicalFood=" + String.valueOf(this.getCanonicalFood()) + ")";
   }

   @Generated
   public static class BreedSpeciesBuilder {
      @Generated
      private EntityType<? extends Animal> type;
      @Generated
      private TagKey<Item> foodTag;
      @Generated
      private Item canonicalFood;

      @Generated
      BreedSpeciesBuilder() {
      }

      @Generated
      public BreedSpeciesBuilder type(EntityType<? extends Animal> type) {
         this.type = type;
         return this;
      }

      @Generated
      public BreedSpeciesBuilder foodTag(TagKey<Item> foodTag) {
         this.foodTag = foodTag;
         return this;
      }

      @Generated
      public BreedSpeciesBuilder canonicalFood(Item canonicalFood) {
         this.canonicalFood = canonicalFood;
         return this;
      }

      @Generated
      public BreedSpecies build() {
         return new BreedSpecies(this.type, this.foodTag, this.canonicalFood);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.type);
         return "BreedSpecies.BreedSpeciesBuilder(type=" + var10000 + ", foodTag=" + String.valueOf(this.foodTag) + ", canonicalFood=" + String.valueOf(this.canonicalFood) + ")";
      }
   }
}
