package dev.breezes.settlements.application.ai.behavior.usecases.villager.logistics;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.LoopBackStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.OneShotStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.infrastructure.minecraft.mixins.AbstractArrowInvoker;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;

public class RetrieveProjectilesBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(RetrieveProjectilesBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.5F;
   private static final int NAVIGATION_COMPLETION_DISTANCE = 1;
   private static final int COLLECT_TIMEOUT_TICKS = ClockTicks.seconds((double)20.0F).getTicksAsInt();
   private static final int MAX_PROJECTILES_PER_RUN = 5;
   private final Map<String, Integer> collectedByItem = new HashMap();
   @Nullable
   private AbstractArrow target;

   public RetrieveProjectilesBehavior(@Nonnull RetrieveProjectilesConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.preconditions.add(ICondition.named("RetrievableProjectilesRemembered", (villager) -> villager != null && villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.RETRIEVABLE_PROJECTILES).isPresent()));
      this.target = null;
      this.initializeStateMachine(this.createControlStep(), RetrieveProjectilesBehavior.Stage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      Map<StageKey, BehaviorStep<BaseVillager>> stageMap = new HashMap();
      stageMap.put(RetrieveProjectilesBehavior.Stage.RESOLVE, this.createResolveStep());
      stageMap.put(RetrieveProjectilesBehavior.Stage.COLLECT, this.createCollectStep());
      stageMap.put(RetrieveProjectilesBehavior.Stage.LOOP, LoopBackStep.builder().name("RetrieveProjectilesLoopBack").loopBackTo(RetrieveProjectilesBehavior.Stage.RESOLVE).completionTransition(RetrieveProjectilesBehavior.Stage.END).maxIterationsResolver((ctx) -> 5).build());
      return StagedStep.<BaseVillager>builder().name("RetrieveProjectilesBehavior").initialStage(RetrieveProjectilesBehavior.Stage.RESOLVE).stageStepMap(stageMap).nextStage(RetrieveProjectilesBehavior.Stage.END).build();
   }

   private BehaviorStep<BaseVillager> createResolveStep() {
      return OneShotStep.<BaseVillager>builder().name("ResolveProjectile").action((ctx) -> {
         this.target = takeNextRemembered((BaseVillager)ctx.getInitiator());
         if (this.target == null) {
            return StepResult.transition(RetrieveProjectilesBehavior.Stage.END);
         } else {
            ctx.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.target)));
            return StepResult.transition(RetrieveProjectilesBehavior.Stage.COLLECT);
         }
      }).build();
   }

   @Nullable
   private static AbstractArrow takeNextRemembered(@Nonnull BaseVillager villager) {
      List<AbstractArrow> remembered = new ArrayList((Collection)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.RETRIEVABLE_PROJECTILES).orElse(List.of()));
      AbstractArrow next = null;

      while(next == null && !remembered.isEmpty()) {
         AbstractArrow candidate = (AbstractArrow)remembered.remove(0);
         if (candidate.m_6084_()) {
            next = candidate;
         }
      }

      if (remembered.isEmpty()) {
         villager.getSettlementsBrain().clearMemory(MemoryTypeRegistry.RETRIEVABLE_PROJECTILES);
      } else {
         villager.getSettlementsBrain().setMemory(MemoryTypeRegistry.RETRIEVABLE_PROJECTILES, List.copyOf(remembered));
      }

      return next;
   }

   private BehaviorStep<BaseVillager> createCollectStep() {
      TimeBasedStep<BaseVillager> pickupStep = TimeBasedStep.<BaseVillager>builder().name("PickupProjectile").withTickable(ClockTicks.of(24L).asTickable()).onStart((ctx) -> {
         if (this.target != null && this.target.m_6084_()) {
            ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.PICK_UP);
            return StepResult.noOp();
         } else {
            return StepResult.transition(RetrieveProjectilesBehavior.Stage.LOOP);
         }
      }).addKeyFrame(ClockTicks.of(11L), (ctx) -> {
         if (this.target != null && this.target.m_6084_()) {
            this.pickUp(ctx, this.target);
            return StepResult.noOp();
         } else {
            return StepResult.transition(RetrieveProjectilesBehavior.Stage.LOOP);
         }
      }).onEnd((ctx) -> StepResult.transition(RetrieveProjectilesBehavior.Stage.LOOP)).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.5F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.WALK).completionDistance(1).unreachableTransition(RetrieveProjectilesBehavior.Stage.LOOP).build()).actionStep(pickupStep).timeoutTicks(COLLECT_TIMEOUT_TICKS).timeoutTransition(RetrieveProjectilesBehavior.Stage.END).build();
   }

   private void pickUp(@Nonnull BehaviorContext<BaseVillager> ctx, @Nonnull AbstractArrow projectile) {
      BaseVillager villager = ctx.getInitiator();
      ItemStack retrieved = ((AbstractArrowInvoker)projectile).accessGetPickupItem().m_41777_();
      int count = retrieved.m_41613_();
      villager.getSettlementsInventory().add(retrieved);
      villager.m_7938_(projectile, count);
      projectile.m_146870_();
      String itemId = BuiltInRegistries.f_257033_.m_7981_(retrieved.m_41720_()).m_135815_();
      this.collectedByItem.merge(itemId, count, Integer::sum);
      BehaviorOutcome outcome = (BehaviorOutcome)ctx.primaryDeed().orElseGet(() -> ctx.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.ITEM_COLLECTED, (String)null)));
      outcome.recordYield(count);
   }

   private static enum Stage implements StageKey {
      RESOLVE,
      COLLECT,
      LOOP,
      END;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{RESOLVE, COLLECT, LOOP, END};
      }
   }
}
