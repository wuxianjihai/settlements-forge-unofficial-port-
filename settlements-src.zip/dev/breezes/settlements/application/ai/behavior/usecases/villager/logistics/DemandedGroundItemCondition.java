package dev.breezes.settlements.application.ai.behavior.usecases.villager.logistics;

import dev.breezes.settlements.application.economy.demand.ActiveDemand;
import dev.breezes.settlements.application.economy.demand.DemandEvaluator;
import dev.breezes.settlements.domain.ai.conditions.IEntityCondition;
import dev.breezes.settlements.domain.economy.catalog.ItemMatches;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.phys.AABB;

public class DemandedGroundItemCondition implements IEntityCondition<BaseVillager> {
   private static final double SCAN_RANGE_HORIZONTAL = (double)8.0F;
   private static final double SCAN_RANGE_VERTICAL = (double)2.0F;
   private final DemandEvaluator demandEvaluator;
   private final int completionRange;
   @Nullable
   private Resolution resolution;

   public DemandedGroundItemCondition(@Nonnull DemandEvaluator demandEvaluator, int completionRange) {
      if (completionRange < 1) {
         throw new IllegalArgumentException("Completion range must be at least 1");
      } else {
         this.demandEvaluator = demandEvaluator;
         this.completionRange = completionRange;
      }
   }

   public boolean test(@Nullable BaseVillager villager) {
      this.resolution = null;
      if (villager == null) {
         return false;
      } else {
         List<ActiveDemand> demands = this.demandEvaluator.resolveForPickup(villager);
         if (demands.isEmpty()) {
            return false;
         } else {
            AABB box = villager.m_20191_().m_82377_((double)8.0F, (double)2.0F, (double)8.0F);
            List<ItemEntity> items = villager.m_9236_().m_6443_(ItemEntity.class, box, Entity::m_6084_);
            if (items.isEmpty()) {
               return false;
            } else {
               List<ItemEntity> sortedItems = new ArrayList(items);
               Objects.requireNonNull(villager);
               sortedItems.sort(Comparator.comparingDouble(villager::m_20280_));

               for(ActiveDemand demand : demands) {
                  for(ItemEntity item : sortedItems) {
                     if (ItemMatches.test(demand.match(), item.m_32055_()) && villager.getNavigationManager().canReach(Location.fromEntity(item, false), (double)this.completionRange)) {
                        this.resolution = new Resolution(item, demand);
                        return true;
                     }
                  }
               }

               return false;
            }
         }
      }
   }

   public Optional<Resolution> getResolution() {
      return Optional.ofNullable(this.resolution);
   }

   public static record Resolution(@Nonnull ItemEntity item, @Nonnull ActiveDemand demand) {
   }
}
