package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals;

import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.infrastructure.minecraft.entities.wolves.SettlementsWolf;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Predicate;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.world.phys.AABB;

public class OwnedWolfExistsCondition implements ICondition<BaseVillager> {
   private final int scanRangeHorizontal;
   private final int scanRangeVertical;
   private final Predicate<SettlementsWolf> wolfFilter;
   private List<SettlementsWolf> targets;

   public OwnedWolfExistsCondition(int scanRangeHorizontal, int scanRangeVertical, @Nonnull Predicate<SettlementsWolf> wolfFilter) {
      this.scanRangeHorizontal = scanRangeHorizontal;
      this.scanRangeVertical = scanRangeVertical;
      this.wolfFilter = wolfFilter;
      this.targets = Collections.emptyList();
   }

   public boolean test(@Nullable BaseVillager villager) {
      if (villager == null) {
         this.targets = Collections.emptyList();
         return false;
      } else {
         Optional<SettlementsWolf> target = villager.m_6274_().m_21952_(MemoryTypeRegistry.OWNED_WOLVES.getModuleType()).flatMap((ownedWolfIds) -> this.findFirstMatchingOwnedWolf(villager, ownedWolfIds));
         this.targets = (List)target.map(Collections::singletonList).orElse(Collections.emptyList());
         return target.isPresent();
      }
   }

   private Optional<SettlementsWolf> findFirstMatchingOwnedWolf(@Nonnull BaseVillager villager, @Nonnull List<UUID> ownedWolfIds) {
      if (ownedWolfIds.isEmpty()) {
         return Optional.empty();
      } else {
         AABB scanBox = villager.m_20191_().m_82377_((double)this.scanRangeHorizontal, (double)this.scanRangeVertical, (double)this.scanRangeHorizontal);
         List<SettlementsWolf> nearbyWolves = villager.m_9236_().m_45976_(SettlementsWolf.class, scanBox);

         for(UUID ownedWolfId : ownedWolfIds) {
            Optional<SettlementsWolf> match = nearbyWolves.stream().filter((wolf) -> this.isEligible(wolf, ownedWolfId, villager)).findFirst();
            if (match.isPresent()) {
               return match;
            }
         }

         return Optional.empty();
      }
   }

   private boolean isEligible(@Nonnull SettlementsWolf wolf, @Nonnull UUID ownedWolfId, @Nonnull BaseVillager villager) {
      return wolf.m_20148_().equals(ownedWolfId) && wolf.m_6084_() && !wolf.m_213877_() && villager.m_20148_().equals(wolf.m_21805_()) && this.wolfFilter.test(wolf);
   }

   @Generated
   public List<SettlementsWolf> getTargets() {
      return this.targets;
   }
}
