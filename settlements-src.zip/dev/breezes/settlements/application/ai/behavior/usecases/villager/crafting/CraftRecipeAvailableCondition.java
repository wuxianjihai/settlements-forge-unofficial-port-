package dev.breezes.settlements.application.ai.behavior.usecases.villager.crafting;

import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.crafting.catalog.CraftRecipe;
import dev.breezes.settlements.domain.crafting.catalog.ProfessionRecipeCatalog;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public class CraftRecipeAvailableCondition implements ICondition<BaseVillager> {
   private final ProfessionRecipeCatalog recipeCatalog;
   private final CraftBatchCalculator batchCalculator;
   private List<CraftRecipe> validRecipes;

   public CraftRecipeAvailableCondition(@Nonnull ProfessionRecipeCatalog recipeCatalog, @Nonnull CraftBatchCalculator batchCalculator) {
      this.recipeCatalog = recipeCatalog;
      this.batchCalculator = batchCalculator;
      this.validRecipes = List.of();
   }

   public boolean test(@Nullable BaseVillager villager) {
      this.validRecipes = List.of();
      if (villager == null) {
         return false;
      } else {
         this.validRecipes = this.recipeCatalog.recipesFor(villager.getProfession()).stream().filter((recipe) -> this.batchCalculator.computeBatch(villager, recipe) >= 1).toList();
         return !this.validRecipes.isEmpty();
      }
   }

   @Generated
   public List<CraftRecipe> getValidRecipes() {
      return this.validRecipes;
   }
}
