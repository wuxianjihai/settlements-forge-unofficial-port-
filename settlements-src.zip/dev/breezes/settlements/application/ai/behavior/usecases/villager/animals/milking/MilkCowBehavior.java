package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals.milking;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.conditions.PerceivedEntityExistsCondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.entities.Expertise;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public class MilkCowBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(MilkCowBehavior.class.getName());
   private static final ResourceLocation BUCKET_ID = new ResourceLocation("minecraft", "bucket");
   private final MilkCowConfig config;
   @Nullable
   private Cow target;
   private int milkCountRemaining;
   private boolean shouldRewardExperience;

   public MilkCowBehavior(@Nonnull MilkCowConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.preconditions.add(PerceivedEntityExistsCondition.builder().entityType(Cow.class).filter((villager, cow) -> isMilkable(cow)).completionRange(1).build());
      this.preconditions.add(support.getDemandSignalService().requireItem(new ItemMatch.ItemRef(BUCKET_ID), 1, 50, this.getClass().getSimpleName()));
      this.target = null;
      this.milkCountRemaining = 0;
      this.shouldRewardExperience = false;
      this.initializeStateMachine(this.createControlStep(), MilkCowBehavior.MilkStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("MilkCowBehavior").initialStage(MilkCowBehavior.MilkStage.MILK_COW).stageStepMap(Map.of(MilkCowBehavior.MilkStage.MILK_COW, this.createMilkCowStep())).nextStage(MilkCowBehavior.MilkStage.END).build();
   }

   private BehaviorStep<BaseVillager> createMilkCowStep() {
      TimeBasedStep<BaseVillager> milkStep = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.seconds((double)2.0F).asTickable()).onStart((context) -> {
         ((BaseVillager)context.getInitiator()).setHeldItem(Items.f_42446_.m_7968_());
         ((BaseVillager)context.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.seconds((double)1.0F), this::performMilk).onEnd((context) -> {
         ((BaseVillager)context.getInitiator()).clearHeldItem();
         if (this.milkCountRemaining <= 0) {
            return StepResult.complete();
         } else {
            VillagerInventory inventory = ((BaseVillager)context.getInitiator()).getMinecraftEntity().getSettlementsInventory();
            if (!inventory.containsOrBypassed(Items.f_42446_, GeneralConfig.bypassInventoryRequirements)) {
               return StepResult.complete();
            } else if (this.target != null && this.target.m_6084_() && !this.target.m_6162_()) {
               context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.target)));
               return StepResult.transition(MilkCowBehavior.MilkStage.MILK_COW);
            } else {
               return StepResult.complete();
            }
         }
      }).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 1)).actionStep(milkStep).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      Expertise expertise = villager.getExpertise();
      this.milkCountRemaining = (Integer)this.config.expertiseMilkLimit().getOrDefault(expertise.getConfigName(), 1);
      this.shouldRewardExperience = false;
      Optional<Cow> targetCandidate = this.findClosestMilkableCow(villager);
      if (targetCandidate.isEmpty()) {
         this.requestStop("No milkable cows found");
      } else if (!villager.getSettlementsInventory().containsOrBypassed(Items.f_42446_, GeneralConfig.bypassInventoryRequirements)) {
         this.requestStop("Not enough buckets in inventory");
      } else {
         this.target = (Cow)targetCandidate.get();
         context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.target)));
         context.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.COW_MILKED, "cows"));
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      return this.target != null && this.target.m_6084_();
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      if (this.shouldRewardExperience) {
         this.rewardExperience(villager);
      }

      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.target = null;
      this.milkCountRemaining = 0;
      this.shouldRewardExperience = false;
   }

   private StepResult performMilk(@Nonnull BehaviorContext<BaseVillager> context) {
      if (this.target != null && this.target.m_6084_() && !this.target.m_6162_()) {
         VillagerInventory inventory = ((BaseVillager)context.getInitiator()).getMinecraftEntity().getSettlementsInventory();
         ItemStack milkBucketStack = new ItemStack(Items.f_42455_);
         if (!inventory.consumeIfRequired(Items.f_42446_, 1, GeneralConfig.bypassInventoryRequirements)) {
            this.milkCountRemaining = 0;
            return StepResult.noOp();
         } else {
            SoundRegistry.MILK_COW.playGlobally(Location.fromEntity(this.target, false), SoundSource.NEUTRAL);
            ((BaseVillager)context.getInitiator()).setHeldItem(Items.f_42455_.m_7968_());
            inventory.add(milkBucketStack);
            --this.milkCountRemaining;
            this.shouldRewardExperience = true;
            context.primaryDeed().ifPresent((outcome) -> outcome.recordYield(1));
            return StepResult.noOp();
         }
      } else {
         this.milkCountRemaining = 0;
         return StepResult.noOp();
      }
   }

   private Optional<Cow> findClosestMilkableCow(@Nonnull BaseVillager villager) {
      return this.getPerceivedEntities(villager).<Cow>closest(Cow.class, (cow) -> isMilkable(cow) && villager.getNavigationManager().canReach(Location.fromEntity(cow, false), (double)1.0F), villager);
   }

   private PerceivedEntities getPerceivedEntities(@Nonnull BaseVillager villager) {
      return (PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_SENSED_ENTITIES).orElse(PerceivedEntities.empty());
   }

   private static boolean isMilkable(@Nonnull Cow cow) {
      return cow.m_6084_() && !cow.m_6162_();
   }

   private static enum MilkStage implements StageKey {
      MILK_COW,
      END;

      // $FF: synthetic method
      private static MilkStage[] $values() {
         return new MilkStage[]{MILK_COW, END};
      }
   }
}
