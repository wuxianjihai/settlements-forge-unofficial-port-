package dev.breezes.settlements.application.ai.behavior.usecases.villager.donation;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ui.bubble.VillagerBubbleService;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class DonationPresenter_Factory implements Factory<DonationPresenter> {
   private final Provider<VillagerBubbleService> villagerBubbleServiceProvider;

   private DonationPresenter_Factory(Provider<VillagerBubbleService> villagerBubbleServiceProvider) {
      this.villagerBubbleServiceProvider = villagerBubbleServiceProvider;
   }

   public DonationPresenter get() {
      return newInstance((VillagerBubbleService)this.villagerBubbleServiceProvider.get());
   }

   public static DonationPresenter_Factory create(Provider<VillagerBubbleService> villagerBubbleServiceProvider) {
      return new DonationPresenter_Factory(villagerBubbleServiceProvider);
   }

   public static DonationPresenter newInstance(VillagerBubbleService villagerBubbleService) {
      return new DonationPresenter(villagerBubbleService);
   }
}
