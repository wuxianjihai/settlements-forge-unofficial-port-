package dev.breezes.settlements.application.ai.behavior.usecases.villager.smelting.blastore;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.teardown.ResetBlockStateObligation;
import dev.breezes.settlements.application.ai.behavior.teardown.TemporaryArtifactHandle;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.SequencedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleTypeRegistry;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.conditions.JobSiteBlockExistsCondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.domain.smelting.catalog.BlastOreRecipe;
import dev.breezes.settlements.domain.smelting.catalog.BlastOreRecipeRegistry;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.BlockFlag;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class BlastOreBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(BlastOreBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private static final ClockTicks ITEM_INTERACTION_DURATION = ClockTicks.seconds((double)1.0F);
   private static final ClockTicks BLASTING_DURATION = ClockTicks.seconds((double)8.0F);
   private static final ClockTicks SOOT_DURATION = ClockTicks.seconds((double)20.0F);
   private static final int DAZE_STAR_EMIT_INTERVAL = 15;
   private static final int BATCH_SIZE = 8;
   private final BlastOreRecipeRegistry recipeRegistry;
   private final JobSiteBlockExistsCondition<BaseVillager> jobSiteBlockExistsCondition;
   private final BlastRecipeAvailableCondition blastRecipeAvailableCondition;
   private final float explosionChance;
   private final ClockTicks dazeDuration;
   @Nullable
   private PhysicalBlock blastFurnace;
   @Nullable
   private BlastOreRecipe currentRecipe;
   @Nullable
   private Item currentInputItem;
   @Nullable
   private Item currentOutputItem;
   @Nullable
   private TemporaryArtifactHandle litHandle;
   private int currentBatchCount;
   private boolean misfired;

   public BlastOreBehavior(BlastOreConfig config, BehaviorSupport support, BlastOreRecipeRegistry recipeRegistry) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.recipeRegistry = recipeRegistry;
      this.explosionChance = config.explosionChance();
      this.dazeDuration = ClockTicks.seconds((double)config.dazeDurationSeconds());
      this.jobSiteBlockExistsCondition = new JobSiteBlockExistsCondition<BaseVillager>((block) -> block != null && block.is(Blocks.f_50620_), 1);
      this.blastRecipeAvailableCondition = new BlastRecipeAvailableCondition(this.recipeRegistry);
      this.preconditions.add(this.jobSiteBlockExistsCondition);
      this.preconditions.add(this.blastRecipeAvailableCondition);
      this.blastFurnace = null;
      this.currentRecipe = null;
      this.currentInputItem = null;
      this.currentOutputItem = null;
      this.currentBatchCount = 0;
      this.litHandle = null;
      this.misfired = false;
      this.initializeStateMachine(this.createControlStep(), BlastOreBehavior.BlastStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("BlastOreBehavior").initialStage(BlastOreBehavior.BlastStage.BLAST_ORE).stageStepMap(Map.of(BlastOreBehavior.BlastStage.BLAST_ORE, this.createBlastStep())).nextStage(BlastOreBehavior.BlastStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      this.misfired = false;
      if (this.jobSiteBlockExistsCondition.getJobSiteBlock().isEmpty()) {
         this.requestStop("No blast furnace block found at job site");
      } else {
         this.blastFurnace = (PhysicalBlock)this.jobSiteBlockExistsCondition.getJobSiteBlock().get();
         List<BlastOreRecipe> validRecipes = this.blastRecipeAvailableCondition.getValidRecipes();
         if (validRecipes.isEmpty()) {
            this.requestStop("No valid blast-ore recipes available");
         } else {
            BlastOreRecipe recipe = (BlastOreRecipe)RandomUtil.choice(validRecipes).orElseThrow();
            Item inputItem = (Item)BuiltInRegistries.f_257033_.m_7745_(recipe.input());
            Item outputItem = (Item)BuiltInRegistries.f_257033_.m_7745_(recipe.output());
            if (inputItem != Items.f_41852_ && outputItem != Items.f_41852_) {
               int available = entity.getSettlementsInventory().count(inputItem);
               int batch = Math.min(8, available / recipe.inputCount());
               if (batch < 1) {
                  this.requestStop("Not enough ore in inventory to smelt a full batch");
               } else {
                  this.currentRecipe = recipe;
                  this.currentInputItem = inputItem;
                  this.currentOutputItem = outputItem;
                  this.currentBatchCount = batch;
                  if (!this.commitSmelt(entity, context)) {
                     this.requestStop("Blast-ore batch could not be consumed from inventory");
                  } else {
                     context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromBlock(this.blastFurnace)));
                  }
               }
            } else {
               this.requestStop("Blast-ore recipe references an item id that is not registered");
            }
         }
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      return this.blastFurnace != null && this.blastFurnace.is(Blocks.f_50620_);
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.misfired = false;
      this.litHandle = null;
      this.blastFurnace = null;
      this.currentRecipe = null;
      this.currentBatchCount = 0;
      this.currentInputItem = null;
      this.currentOutputItem = null;
   }

   private BehaviorStep<BaseVillager> createBlastStep() {
      TimeBasedStep<BaseVillager> setup = TimeBasedStep.<BaseVillager>builder().withTickable(ITEM_INTERACTION_DURATION.asTickable()).onStart((ctx) -> {
         if (this.currentInputItem != null && this.blastFurnace != null) {
            BaseVillager villager = ((BaseVillager)ctx.getInitiator()).getMinecraftEntity();
            ((BaseVillager)ctx.getInitiator()).setHeldItem(new ItemStack(this.currentInputItem, this.currentBatchCount));
            villager.triggerMotion(AnimationArchetype.INTERACT);
            return StepResult.noOp();
         } else {
            return StepResult.complete();
         }
      }).onEnd((ctx) -> {
         if (this.blastFurnace == null) {
            return StepResult.complete();
         } else {
            ((BaseVillager)ctx.getInitiator()).clearHeldItem();
            this.setFurnaceLitState(true);
            BlockPos furnacePos = this.blastFurnace.getLocation(false).toBlockPos();
            ResourceLocation furnaceBlockId = BuiltInRegistries.f_256975_.m_7981_(Blocks.f_50620_);
            this.litHandle = ctx.getTeardownScope().track(new ResetBlockStateObligation(furnacePos, furnaceBlockId, "lit", "false"));
            Location location = this.blastFurnace.getLocation(true).add((double)0.0F, (double)0.5F, (double)0.0F, false);
            location.displayParticles(ParticleTypes.f_123756_, 5, 0.3, 0.3, 0.3, 0.1);
            SoundRegistry.ITEM_POP_IN.playGlobally(location, SoundSource.BLOCKS);
            return StepResult.noOp();
         }
      }).build();
      TimeBasedStep<BaseVillager> blasting = TimeBasedStep.<BaseVillager>builder().withTickable(BLASTING_DURATION.asTickable()).onEnd((ctx) -> {
         if (this.blastFurnace != null && this.currentRecipe != null && this.currentOutputItem != null) {
            if (this.litHandle != null) {
               this.litHandle.dispose(ctx.getLevel());
               this.litHandle = null;
            }

            BaseVillager villager = ((BaseVillager)ctx.getInitiator()).getMinecraftEntity();
            Location furnaceTop = this.blastFurnace.getLocation(true).add((double)0.0F, (double)0.5F, (double)0.0F, false);
            if (this.misfired) {
               furnaceTop.displayParticles(ParticleTypes.f_123777_, 100, (double)3.0F, (double)1.5F, (double)3.0F, 0.1);
               furnaceTop.displayParticles(ParticleTypes.f_123755_, 20, 0.4, 0.4, 0.4, 0.02);
               furnaceTop.displayParticles(ParticleTypes.f_123813_, 4, 0.4, 0.4, 0.4, 0.1);
               Location face = Location.fromEntity(villager, true);
               face.displayParticles(ParticleTypes.f_123792_, 3, 0.1, 0.1, 0.1, 0.4);
               SoundRegistry.BLAST_MISFIRE.playGlobally(face, SoundSource.BLOCKS);
               villager.setSooty(SOOT_DURATION);
               ((BaseVillager)ctx.getInitiator()).clearHeldItem();
            } else {
               ((BaseVillager)ctx.getInitiator()).setHeldItem(new ItemStack(this.currentOutputItem));
               villager.triggerMotion(AnimationArchetype.INTERACT);
               SoundRegistry.ITEM_POP_OUT.playGlobally(furnaceTop, SoundSource.BLOCKS);
            }

            return StepResult.noOp();
         } else {
            return StepResult.complete();
         }
      }).build();
      TimeBasedStep<BaseVillager> takeOut = TimeBasedStep.<BaseVillager>builder().withTickable(ITEM_INTERACTION_DURATION.asTickable()).onEnd((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         return StepResult.complete();
      }).build();
      TimeBasedStep<BaseVillager> daze = TimeBasedStep.<BaseVillager>builder().withTickable(this.dazeDuration.asTickable()).onStart((ctx) -> {
         if (!this.misfired) {
            return StepResult.complete();
         } else {
            ((BaseVillager)ctx.getInitiator()).getMinecraftEntity().clearHeldItem();
            return StepResult.noOp();
         }
      }).addPeriodicStep(15, (ctx) -> {
         BaseVillager villager = ((BaseVillager)ctx.getInitiator()).getMinecraftEntity();
         Location starOrigin = Location.fromEntity(villager, true).add((double)0.0F, (double)0.5F, (double)0.0F, false);
         starOrigin.displayParticles((SimpleParticleType)ParticleTypeRegistry.STUNNED_STAR.get(), 2, (double)0.0F, 0.03, (double)0.0F, (double)0.0F);
         return StepResult.noOp();
      }).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 1)).actionStep(new SequencedStep("BlastOreBehavior.sequence", List.of(setup, blasting, takeOut, daze))).build();
   }

   private boolean commitSmelt(@Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      if (this.currentRecipe != null && this.currentInputItem != null && this.currentOutputItem != null) {
         if (!this.consumeRecipeInput(villager, this.currentRecipe)) {
            return false;
         } else {
            int outputTotal = this.currentRecipe.outputCount() * this.currentBatchCount;
            villager.getSettlementsInventory().add(new ItemStack(this.currentOutputItem, outputTotal));
            BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.ORE_SMELTED, (String)null);
            outcome.putDetailField("item", BuiltInRegistries.f_257033_.m_7981_(this.currentOutputItem).m_135815_());
            outcome.putDetailField("count", Integer.toString(outputTotal));
            outcome.markSucceeded();
            context.declarePrimaryDeed(outcome);
            this.misfired = RandomUtil.chance((double)this.explosionChance);
            if (this.misfired) {
               context.addSecondaryDeed(BehaviorOutcome.forDeed(WorldEventType.FURNACE_MISFIRED, (String)null)).markSucceeded();
            }

            this.rewardExperience(villager);
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean consumeRecipeInput(@Nonnull BaseVillager villager, @Nonnull BlastOreRecipe recipe) {
      if (this.currentInputItem == null) {
         return false;
      } else {
         int requested = recipe.inputCount() * this.currentBatchCount;
         VillagerInventory inventory = villager.getSettlementsInventory();
         if (inventory.count(this.currentInputItem) < requested) {
            return false;
         } else {
            return inventory.consume(this.currentInputItem, requested) == requested;
         }
      }
   }

   private void setFurnaceLitState(boolean lit) {
      if (this.blastFurnace != null) {
         Level level = this.blastFurnace.getLevel();
         BlockPos pos = this.blastFurnace.getLocation(false).toBlockPos();
         BlockState currentState = level.m_8055_(pos);
         if (!currentState.m_60713_(Blocks.f_50620_)) {
            log.behaviorTrace("Skipping furnace lit state update at {} because block is no longer a blast furnace", pos);
         } else if (!currentState.m_61138_(AbstractFurnaceBlock.f_48684_)) {
            log.behaviorTrace("Skipping furnace lit state update at {} because block state has no LIT property", pos);
         } else if ((Boolean)currentState.m_61143_(AbstractFurnaceBlock.f_48684_) != lit) {
            log.behaviorTrace("Setting furnace lit state to {}", lit);
            BlockState newState = (BlockState)currentState.m_61124_(AbstractFurnaceBlock.f_48684_, lit);
            level.m_7731_(pos, newState, BlockFlag.of(BlockFlag.SEND_BLOCK_UPDATE, BlockFlag.SEND_CLIENT_UPDATE));
         }
      }
   }

   private static enum BlastStage implements StageKey {
      BLAST_ORE,
      END;

      // $FF: synthetic method
      private static BlastStage[] $values() {
         return new BlastStage[]{BLAST_ORE, END};
      }
   }
}
