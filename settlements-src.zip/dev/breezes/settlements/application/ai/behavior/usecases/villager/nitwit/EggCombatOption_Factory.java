package dev.breezes.settlements.application.ai.behavior.usecases.villager.nitwit;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class EggCombatOption_Factory implements Factory<EggCombatOption> {
   private final Provider<BehaviorSupport> supportProvider;

   private EggCombatOption_Factory(Provider<BehaviorSupport> supportProvider) {
      this.supportProvider = supportProvider;
   }

   public EggCombatOption get() {
      return newInstance((BehaviorSupport)this.supportProvider.get());
   }

   public static EggCombatOption_Factory create(Provider<BehaviorSupport> supportProvider) {
      return new EggCombatOption_Factory(supportProvider);
   }

   public static EggCombatOption newInstance(BehaviorSupport support) {
      return new EggCombatOption(support);
   }
}
