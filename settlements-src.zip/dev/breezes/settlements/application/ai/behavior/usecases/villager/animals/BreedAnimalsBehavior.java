package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.teardown.DropLeashObligation;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.conditions.NearbyBreedableAnimalPairExistsCondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.tags.EntityTag;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

public class BreedAnimalsBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(BreedAnimalsBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private final BreedSpecies species;
   private final NearbyBreedableAnimalPairExistsCondition<BaseVillager> nearbyBreedableAnimalPairExistsCondition;
   @Nullable
   private ItemStack heldItem;
   @Nullable
   private Animal breedTarget1;
   @Nullable
   private Animal breedTarget2;
   private boolean shouldRewardExperience;

   public BreedAnimalsBehavior(BreedAnimalsConfig config, BehaviorSupport support, BreedSpecies species) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.species = species;
      this.nearbyBreedableAnimalPairExistsCondition = new NearbyBreedableAnimalPairExistsCondition<BaseVillager>((double)config.scanRangeHorizontal(), (double)config.scanRangeVertical(), species.getType());
      this.preconditions.add(this.nearbyBreedableAnimalPairExistsCondition);
      this.preconditions.add(support.getDemandSignalService().requireAny(List.of(new ItemMatch.TagRef(species.getFoodTag())), 1, 50, this.getClass().getSimpleName()));
      this.heldItem = null;
      this.breedTarget1 = null;
      this.breedTarget2 = null;
      this.shouldRewardExperience = false;
      this.initializeStateMachine(this.createControlStep(), BreedAnimalsBehavior.BreedStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("BreedAnimalsBehavior").initialStage(BreedAnimalsBehavior.BreedStage.FEED_FIRST).stageStepMap(Map.of(BreedAnimalsBehavior.BreedStage.FEED_FIRST, this.createFeedTargetStep("first", BreedAnimalsBehavior.BreedStage.FEED_SECOND, () -> this.breedTarget1, () -> this.breedTarget2), BreedAnimalsBehavior.BreedStage.FEED_SECOND, this.createFeedTargetStep("second", BreedAnimalsBehavior.BreedStage.WAITING_FOR_BREEDING, () -> this.breedTarget2, (Supplier)null), BreedAnimalsBehavior.BreedStage.WAITING_FOR_BREEDING, this.createWaitingStep())).nextStage(BreedAnimalsBehavior.BreedStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      Optional<NearbyBreedableAnimalPairExistsCondition.BreedablePair<?>> breedablePair = this.nearbyBreedableAnimalPairExistsCondition.getBreedablePair();
      if (breedablePair.isEmpty()) {
         this.requestStop("No breedable pair found, stopping behavior");
      } else {
         this.breedTarget1 = ((NearbyBreedableAnimalPairExistsCondition.BreedablePair)breedablePair.get()).getFirst();
         this.breedTarget2 = ((NearbyBreedableAnimalPairExistsCondition.BreedablePair)breedablePair.get()).getSecond();
         this.shouldRewardExperience = false;
         Optional<ItemStack> foundFood = this.findFirstMatchingFood(villager);
         if (foundFood.isPresent()) {
            this.heldItem = ((ItemStack)foundFood.get()).m_255036_(1);
         } else {
            if (!GeneralConfig.bypassInventoryRequirements) {
               this.requestStop("No food available for breeding at behavior start");
               return;
            }

            this.heldItem = new ItemStack(this.species.getCanonicalFood());
         }

         context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.breedTarget1)));
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      return this.breedTarget1 != null && this.breedTarget2 != null && this.breedTarget1.m_6084_() && this.breedTarget2.m_6084_();
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      if (this.breedTarget1 != null) {
         this.claimNearbyBabyAnimals(villager);
      }

      for(Animal target : new Animal[]{this.breedTarget1, this.breedTarget2}) {
         if (target != null) {
            target.m_146762_(6000);
         }
      }

      this.heldItem = null;
      this.breedTarget1 = null;
      this.breedTarget2 = null;
      this.shouldRewardExperience = false;
   }

   private BehaviorStep<BaseVillager> createFeedTargetStep(@Nonnull String label, @Nonnull BreedStage nextStage, @Nonnull Supplier<Animal> targetSupplier, @Nullable Supplier<Animal> nextTargetSupplier) {
      TimeBasedStep<BaseVillager> feedStep = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.ONE.asTickable()).onStart((ctx) -> {
         Animal target = (Animal)targetSupplier.get();
         if (target != null && this.heldItem != null) {
            ((BaseVillager)ctx.getInitiator()).setHeldItem(this.heldItem);
            ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
            return StepResult.noOp();
         } else {
            return StepResult.complete();
         }
      }).onEnd((ctx) -> {
         Animal target = (Animal)targetSupplier.get();
         StepResult result = this.feedAnimal(((BaseVillager)ctx.getInitiator()).getMinecraftEntity(), ctx, target, label);
         if (!(result instanceof StepResult.NoOp)) {
            return result;
         } else {
            target.m_27595_((Player)null);
            if (nextTargetSupplier != null) {
               Animal nextTarget = (Animal)nextTargetSupplier.get();
               if (nextTarget != null) {
                  ctx.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(nextTarget)));
               }
            }

            return StepResult.transition(nextStage);
         }
      }).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 1)).actionStep(feedStep).build();
   }

   private BehaviorStep<BaseVillager> createWaitingStep() {
      return TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.seconds((double)3.0F).asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         return StepResult.noOp();
      }).everyTick((ctx) -> {
         if (this.breedTarget1 != null && this.breedTarget2 != null) {
            if (this.breedTarget1.m_21573_().m_26571_()) {
               this.breedTarget1.m_21573_().m_5624_(this.breedTarget2, (double)1.0F);
            }

            if (this.breedTarget2.m_21573_().m_26571_()) {
               this.breedTarget2.m_21573_().m_5624_(this.breedTarget1, (double)1.0F);
            }

            if (((BaseVillager)ctx.getInitiator()).getNavigationManager().isNavigating()) {
               ((BaseVillager)ctx.getInitiator()).getNavigationManager().stop();
            }

            return StepResult.noOp();
         } else {
            return StepResult.complete();
         }
      }).onEnd((ctx) -> {
         if (this.shouldRewardExperience) {
            this.rewardExperience(((BaseVillager)ctx.getInitiator()).getMinecraftEntity());
         }

         return StepResult.complete();
      }).build();
   }

   private StepResult feedAnimal(@Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context, @Nullable Animal target, @Nonnull String label) {
      if (target != null && this.heldItem != null) {
         log.behaviorStatus("Feeding {} animal: '{}'", label, target);
         if (!villager.getSettlementsInventory().consumeIfRequired(this.heldItem.m_41720_(), 1, GeneralConfig.bypassInventoryRequirements)) {
            return StepResult.complete();
         } else {
            target.m_21463_(villager, true);
            context.getTeardownScope().track(new DropLeashObligation(target.m_20148_(), villager.m_20148_(), target.m_20183_()));
            Location targetLocation = Location.fromEntity(target, false);
            ParticleRegistry.breedHearts(targetLocation);
            ParticleRegistry.breedItemConsume(targetLocation, this.heldItem);
            SoundRegistry.FEED_ANIMAL.playGlobally(targetLocation, SoundSource.NEUTRAL);
            log.behaviorStatus("Fed {} animal", label);
            this.shouldRewardExperience = true;
            String speciesNoun = resolveSpeciesNoun(this.species);
            BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.ANIMAL_BRED, (String)null);
            outcome.recordDeedDetail(speciesNoun);
            outcome.putDetailField("species", speciesNoun);
            context.declarePrimaryDeed(outcome);
            return StepResult.noOp();
         }
      } else {
         return StepResult.complete();
      }
   }

   private Optional<ItemStack> findFirstMatchingFood(@Nonnull BaseVillager villager) {
      return villager.getSettlementsInventory().findFirst((stack) -> stack.m_204117_(this.species.getFoodTag()));
   }

   private static String resolveSpeciesNoun(@Nonnull BreedSpecies species) {
      if (species.getType() == EntityType.f_20557_) {
         return "cows";
      } else if (species.getType() == EntityType.f_20510_) {
         return "pigs";
      } else if (species.getType() == EntityType.f_20520_) {
         return "sheep";
      } else {
         return species.getType() == EntityType.f_20555_ ? "chickens" : species.getType().m_20675_();
      }
   }

   private void claimNearbyBabyAnimals(@Nonnull BaseVillager villager) {
      AABB scanBoundary = villager.m_20191_().m_82377_((double)6.0F, (double)3.0F, (double)6.0F);
      Predicate<Entity> isBabyOfRightType = (targetEntity) -> targetEntity.m_6095_() == this.species.getType() && ((Animal)targetEntity).m_6162_();

      for(Entity nearbyEntity : villager.m_9236_().m_6249_(villager, scanBoundary, isBabyOfRightType)) {
         log.behaviorStatus("Claiming baby animal '{}' as village-owned", nearbyEntity);
         nearbyEntity.m_20049_(EntityTag.VILLAGE_OWNED_ANIMAL.getTag());
      }

   }

   private static enum BreedStage implements StageKey {
      FEED_FIRST,
      FEED_SECOND,
      WAITING_FOR_BREEDING,
      END;

      // $FF: synthetic method
      private static BreedStage[] $values() {
         return new BreedStage[]{FEED_FIRST, FEED_SECOND, WAITING_FOR_BREEDING, END};
      }
   }
}
