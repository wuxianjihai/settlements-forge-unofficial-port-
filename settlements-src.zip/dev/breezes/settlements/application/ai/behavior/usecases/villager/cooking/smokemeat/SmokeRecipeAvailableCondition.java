package dev.breezes.settlements.application.ai.behavior.usecases.villager.cooking.smokemeat;

import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public class SmokeRecipeAvailableCondition implements ICondition<BaseVillager> {
   private final List<SmokeMeatRecipe> recipes;
   private List<SmokeMeatRecipe> validRecipes;

   public SmokeRecipeAvailableCondition(@Nonnull List<SmokeMeatRecipe> recipes) {
      this.recipes = recipes;
      this.validRecipes = List.of();
   }

   public boolean test(@Nullable BaseVillager villager) {
      this.validRecipes = List.of();
      if (villager == null) {
         return false;
      } else {
         VillagerInventory inventory = villager.getSettlementsInventory();
         this.validRecipes = this.recipes.stream().filter((recipe) -> inventory.count(recipe.getInput()) >= recipe.getInputCount()).toList();
         return !this.validRecipes.isEmpty();
      }
   }

   @Generated
   public List<SmokeMeatRecipe> getValidRecipes() {
      return this.validRecipes;
   }
}
