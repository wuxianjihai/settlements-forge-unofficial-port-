package dev.breezes.settlements.application.ai.behavior.usecases.villager.trading;

import dev.breezes.settlements.application.ai.trading.TradeSession;
import dev.breezes.settlements.application.ui.bubble.BubbleChannel;
import dev.breezes.settlements.application.ui.bubble.BubbleCommand;
import dev.breezes.settlements.application.ui.bubble.BubbleMessage;
import dev.breezes.settlements.application.ui.bubble.BubbleSegment;
import dev.breezes.settlements.application.ui.bubble.TradeMarker;
import dev.breezes.settlements.application.ui.bubble.VillagerBubbleService;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Items;

@ServerScope
public final class TradeSessionPresenter {
   private static final ClockTicks BUBBLE_TTL = ClockTicks.seconds((double)2.0F);
   private static final String TRADE_SOURCE = "trade";
   private final VillagerBubbleService villagerBubbleService;

   public void presentOpeningOffer(@Nonnull TradeSession session, @Nonnull BaseVillager self) {
      TradeRole role = this.roleOf(session, self);
      TradeMarker marker = role == TradeSessionPresenter.TradeRole.SELLER ? TradeMarker.UP : null;
      this.upsert(self, session, this.createMessage(session, role, marker));
      Location.fromEntity(self, true).playSound(SoundEvents.f_12508_, 0.8F, 1.0F, SoundSource.NEUTRAL);
   }

   public void presentNegotiationUpdate(@Nonnull TradeSession session, @Nonnull BaseVillager self) {
      TradeRole role = this.roleOf(session, self);
      TradeMarker var10000;
      switch (role) {
         case BUYER -> var10000 = TradeMarker.UP;
         case SELLER -> var10000 = TradeMarker.DOWN;
         default -> throw new IncompatibleClassChangeError();
      }

      TradeMarker marker = var10000;
      this.upsert(self, session, this.createMessage(session, role, marker));
      Location.fromEntity(self, true).playSound(SoundEvents.f_12508_, 0.8F, 1.0F, SoundSource.NEUTRAL);
   }

   public void presentDeal(@Nonnull TradeSession session, @Nonnull BaseVillager self) {
      List<BubbleSegment> segments = this.createBaseSegments(session, session.getBuyerOffer());
      segments.add(TradeMarker.CHECK.asSegment());
      this.upsert(self, session, this.createMessage(segments));
      Location selfHead = Location.fromEntity(self, true);
      selfHead.displayParticles(ParticleTypes.f_123748_, 6, 0.2, 0.2, 0.2, 0.01);
      selfHead.playSound(SoundEvents.f_12504_, 0.8F, 1.0F, SoundSource.NEUTRAL);
   }

   public void presentWalkAway(@Nonnull TradeSession session, @Nonnull BaseVillager self) {
      TradeRole role = this.roleOf(session, self);
      this.upsert(self, session, this.createMessage(session, role, TradeMarker.CROSS));
      Location selfHead = Location.fromEntity(self, true);
      selfHead.displayParticles(ParticleTypes.f_123792_, 6, 0.2, 0.2, 0.2, 0.01);
      selfHead.playSound(SoundEvents.f_12507_, 0.8F, 1.0F, SoundSource.NEUTRAL);
   }

   private void upsert(@Nonnull BaseVillager self, @Nonnull TradeSession session, @Nonnull BubbleMessage message) {
      this.villagerBubbleService.applyCommand(self, new BubbleCommand.Upsert(BubbleChannel.BEHAVIOR, ownerKey(session), message), self.m_9236_().m_46467_());
   }

   private BubbleMessage createMessage(@Nonnull TradeSession session, @Nonnull TradeRole role, @Nullable TradeMarker marker) {
      int var10000;
      switch (role) {
         case BUYER -> var10000 = session.getBuyerOffer();
         case SELLER -> var10000 = session.getSellerAsk();
         default -> throw new IncompatibleClassChangeError();
      }

      int emeraldCount = var10000;
      List<BubbleSegment> segments = this.createBaseSegments(session, emeraldCount);
      if (marker != null) {
         segments.add(marker.asSegment());
      }

      return this.createMessage(segments);
   }

   private List<BubbleSegment> createBaseSegments(@Nonnull TradeSession session, int emeraldCount) {
      List<BubbleSegment> segments = new ArrayList();
      segments.add(BubbleSegment.Item.builder().itemId(BuiltInRegistries.f_257033_.m_7981_(session.getMatchedItem())).count(session.getBundleSize()).build());
      segments.add(BubbleSegment.Item.builder().itemId(BuiltInRegistries.f_257033_.m_7981_(Items.f_42616_)).count(emeraldCount).build());
      return segments;
   }

   private BubbleMessage createMessage(@Nonnull List<BubbleSegment> segments) {
      return BubbleMessage.builder().priority(10).ttl(BUBBLE_TTL).sourceType("trade").segments(segments).build();
   }

   private TradeRole roleOf(@Nonnull TradeSession session, @Nonnull BaseVillager self) {
      if (self.m_20148_().equals(session.getBuyerId())) {
         return TradeSessionPresenter.TradeRole.BUYER;
      } else if (self.m_20148_().equals(session.getSellerId())) {
         return TradeSessionPresenter.TradeRole.SELLER;
      } else {
         throw new IllegalArgumentException("Villager is not a participant in trade session " + String.valueOf(session.getSessionId()));
      }
   }

   private static String ownerKey(@Nonnull TradeSession session) {
      return "trade-session-" + String.valueOf(session.getSessionId());
   }

   @Inject
   @Generated
   TradeSessionPresenter(VillagerBubbleService villagerBubbleService) {
      this.villagerBubbleService = villagerBubbleService;
   }

   private static enum TradeRole {
      BUYER,
      SELLER;

      // $FF: synthetic method
      private static TradeRole[] $values() {
         return new TradeRole[]{BUYER, SELLER};
      }
   }
}
