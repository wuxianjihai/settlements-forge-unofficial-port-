package dev.breezes.settlements.application.ai.behavior.usecases.villager.logistics;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.LoopBackStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.OneShotStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.Level;

public class CollectDemandedItemBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(CollectDemandedItemBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)1.5F;
   private static final int NAVIGATION_COMPLETION_DISTANCE = 1;
   private static final int COLLECT_TIMEOUT_TICKS = ClockTicks.seconds((double)20.0F).getTicksAsInt();
   private static final int MAX_ITEMS_PER_RUN = 5;
   private final DemandedGroundItemCondition itemCondition;
   private final Map<String, Integer> collectedByItem = new HashMap();
   @Nullable
   private DemandedGroundItemCondition.Resolution resolution;

   public CollectDemandedItemBehavior(@Nonnull CollectDemandedItemConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.itemCondition = new DemandedGroundItemCondition(support.getDemandEvaluator(), 1);
      this.preconditions.add(this.itemCondition);
      this.resolution = null;
      this.initializeStateMachine(this.createControlStep(), CollectDemandedItemBehavior.Stage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      Map<StageKey, BehaviorStep<BaseVillager>> stageMap = new HashMap();
      stageMap.put(CollectDemandedItemBehavior.Stage.RESOLVE, this.createResolveStep());
      stageMap.put(CollectDemandedItemBehavior.Stage.COLLECT, this.createCollectStep());
      stageMap.put(CollectDemandedItemBehavior.Stage.LOOP, LoopBackStep.builder().name("CollectDemandedItemLoopBack").loopBackTo(CollectDemandedItemBehavior.Stage.RESOLVE).completionTransition(CollectDemandedItemBehavior.Stage.END).maxIterationsResolver((ctx) -> 5).build());
      return StagedStep.<BaseVillager>builder().name("CollectDemandedItemBehavior").initialStage(CollectDemandedItemBehavior.Stage.RESOLVE).stageStepMap(stageMap).nextStage(CollectDemandedItemBehavior.Stage.END).build();
   }

   private BehaviorStep<BaseVillager> createResolveStep() {
      return OneShotStep.<BaseVillager>builder().name("ResolveDemandedItem").action((ctx) -> {
         if (!this.itemCondition.test((BaseVillager)ctx.getInitiator())) {
            return StepResult.transition(CollectDemandedItemBehavior.Stage.END);
         } else {
            this.resolution = (DemandedGroundItemCondition.Resolution)this.itemCondition.getResolution().orElse((Object)null);
            if (this.resolution == null) {
               return StepResult.transition(CollectDemandedItemBehavior.Stage.END);
            } else {
               ctx.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.resolution.item())));
               return StepResult.transition(CollectDemandedItemBehavior.Stage.COLLECT);
            }
         }
      }).build();
   }

   private BehaviorStep<BaseVillager> createCollectStep() {
      TimeBasedStep<BaseVillager> pickupStep = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.of(24L).asTickable()).onStart((ctx) -> {
         if (this.resolution != null && this.resolution.item().m_6084_()) {
            ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.PICK_UP);
            return StepResult.noOp();
         } else {
            return StepResult.transition(CollectDemandedItemBehavior.Stage.LOOP);
         }
      }).addKeyFrame(ClockTicks.of(11L), (ctx) -> {
         if (this.resolution != null && this.resolution.item().m_6084_()) {
            ItemEntity item = this.resolution.item();
            ((BaseVillager)ctx.getInitiator()).pickUp(item);
            this.recordPickup(ctx, item);
            return StepResult.noOp();
         } else {
            return StepResult.transition(CollectDemandedItemBehavior.Stage.LOOP);
         }
      }).onEnd((ctx) -> StepResult.transition(CollectDemandedItemBehavior.Stage.LOOP)).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)1.5F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.WALK).completionDistance(1).unreachableTransition(CollectDemandedItemBehavior.Stage.END).build()).actionStep(pickupStep).timeoutTicks(COLLECT_TIMEOUT_TICKS).timeoutTransition(CollectDemandedItemBehavior.Stage.END).build();
   }

   private void recordPickup(@Nonnull BehaviorContext<BaseVillager> ctx, @Nonnull ItemEntity item) {
      String itemId = BuiltInRegistries.f_257033_.m_7981_(item.m_32055_().m_41720_()).m_135815_();
      int count = item.m_32055_().m_41613_();
      this.collectedByItem.merge(itemId, count, Integer::sum);
      BehaviorOutcome outcome = (BehaviorOutcome)ctx.primaryDeed().orElseGet(() -> ctx.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.ITEM_COLLECTED, (String)null)));
      outcome.putDetailField("items", formatItemList(this.collectedByItem));
      outcome.recordYield(count);
   }

   private static String formatItemList(@Nonnull Map<String, Integer> byItem) {
      return (String)byItem.entrySet().stream().sorted(Entry.comparingByValue().reversed()).map((entry) -> {
         String var10000 = String.valueOf(entry.getValue());
         return var10000 + " " + (String)entry.getKey();
      }).collect(Collectors.joining("; "));
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      villager.getNavigationManager().stop();
      this.resolution = null;
      this.collectedByItem.clear();
   }

   private static enum Stage implements StageKey {
      RESOLVE,
      COLLECT,
      LOOP,
      END;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{RESOLVE, COLLECT, LOOP, END};
      }
   }
}
