package dev.breezes.settlements.application.ai.behavior.usecases.villager.leatherworking.washleather;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.teardown.DiscardEntityObligation;
import dev.breezes.settlements.application.ai.behavior.teardown.RestoreBlockObligation;
import dev.breezes.settlements.application.ai.behavior.teardown.TemporaryArtifactHandle;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.SequencedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.domain.ai.conditions.JobSiteBlockExistsCondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.BlockFlag;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.compat.ColorParticleOption;
import dev.breezes.settlements.infrastructure.minecraft.entities.displays.TransformedItemDisplay;
import dev.breezes.settlements.infrastructure.minecraft.entities.displays.models.TransformationMatrix;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LayeredCauldronBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.joml.Matrix4f;

public class WashLeatherBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(WashLeatherBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private static final ClockTicks FILL_DURATION = ClockTicks.seconds((double)0.5F);
   private static final ClockTicks HOLD_LEATHER_DURATION = ClockTicks.seconds((double)1.0F);
   private static final ClockTicks WASH_DURATION = ClockTicks.seconds((double)5.0F);
   private static final ClockTicks REMOVE_LEATHER_DURATION = ClockTicks.seconds((double)1.0F);
   private static final ClockTicks DRAIN_DURATION = ClockTicks.seconds((double)0.5F);
   private static final int DIRTY_WATER_COLOR = -9479619;
   private static final int WASH_EFFECT_INTERVAL_TICKS = 5;
   private static final int INTERACT_RETRIGGER_INTERVAL_TICKS = 20;
   private final JobSiteBlockExistsCondition<BaseVillager> jobSiteBlockExistsCondition = new JobSiteBlockExistsCondition<BaseVillager>((block) -> block != null && block.is(Blocks.f_50256_), 1);
   @Nullable
   private PhysicalBlock cauldron;
   @Nullable
   private BlockPos cauldronPos;
   @Nullable
   private Location cauldronCenter;
   @Nullable
   private TransformedItemDisplay leatherDisplay;
   @Nullable
   private TemporaryArtifactHandle restoreHandle;
   @Nullable
   private TemporaryArtifactHandle leatherDisplayHandle;

   public WashLeatherBehavior(WashLeatherConfig config, BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.preconditions.add(this.jobSiteBlockExistsCondition);
      this.cauldron = null;
      this.cauldronPos = null;
      this.cauldronCenter = null;
      this.leatherDisplay = null;
      this.restoreHandle = null;
      this.leatherDisplayHandle = null;
      this.initializeStateMachine(this.createControlStep(), WashLeatherBehavior.WashStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("WashLeatherBehavior").initialStage(WashLeatherBehavior.WashStage.WASH_LEATHER).stageStepMap(Map.of(WashLeatherBehavior.WashStage.WASH_LEATHER, this.createWashStep())).nextStage(WashLeatherBehavior.WashStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      if (this.jobSiteBlockExistsCondition.getJobSiteBlock().isEmpty()) {
         this.requestStop("No cauldron block found at job site");
      } else {
         this.cauldron = (PhysicalBlock)this.jobSiteBlockExistsCondition.getJobSiteBlock().get();
         this.cauldronPos = this.cauldron.getLocation(false).toBlockPos();
         this.cauldronCenter = this.cauldron.getLocation(true).add((double)0.0F, (double)0.5F, (double)0.0F, false);
         context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromBlock(this.cauldron)));
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      if (this.cauldronPos == null) {
         return false;
      } else {
         BlockState current = world.m_8055_(this.cauldronPos);
         return current.m_60713_(Blocks.f_50256_) || current.m_60713_(Blocks.f_152476_);
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.cauldron = null;
      this.cauldronPos = null;
      this.cauldronCenter = null;
      this.leatherDisplay = null;
      this.restoreHandle = null;
      this.leatherDisplayHandle = null;
   }

   private BehaviorStep<BaseVillager> createWashStep() {
      TimeBasedStep<BaseVillager> fill = TimeBasedStep.<BaseVillager>builder().withTickable(FILL_DURATION.asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).setHeldItem(Items.f_42447_.m_7968_());
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         this.setCauldronWaterLevel(ctx.getLevel(), 3);
         this.restoreHandle = ctx.getTeardownScope().track(new RestoreBlockObligation(this.cauldronPos, BuiltInRegistries.f_256975_.m_7981_(Blocks.f_50256_), BuiltInRegistries.f_256975_.m_7981_(Blocks.f_152476_)));
         if (this.cauldronCenter != null) {
            this.cauldronCenter.displayParticles(ParticleTypes.f_123769_, 6, 0.2, 0.1, 0.2, 0.02);
            this.cauldronCenter.playSound(SoundEvents.f_11778_, 0.5F, 1.0F, SoundSource.BLOCKS);
         }

         return StepResult.noOp();
      }).onEnd((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         return StepResult.noOp();
      }).build();
      TimeBasedStep<BaseVillager> holdLeather = TimeBasedStep.<BaseVillager>builder().withTickable(HOLD_LEATHER_DURATION.asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).setHeldItem(Items.f_42454_.m_7968_());
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).onEnd((ctx) -> {
         if (this.cauldron != null && this.cauldronPos != null) {
            Location displayLocation = this.cauldron.getLocation(false);
            TransformationMatrix matrix = this.getAnimatedLeatherMatrix((float)ctx.getLevel().m_46467_());
            this.leatherDisplay = TransformedItemDisplay.builder().itemStack(Items.f_42454_.m_7968_()).transform(matrix).build();
            this.leatherDisplay.spawn(displayLocation);
            this.leatherDisplayHandle = ctx.getTeardownScope().track(new DiscardEntityObligation(this.leatherDisplay.getDisplayEntity().m_20148_(), this.cauldronPos));
            ((BaseVillager)ctx.getInitiator()).clearHeldItem();
            if (this.cauldronCenter != null) {
               this.cauldronCenter.displayParticles(ParticleTypes.f_123769_, 4, 0.15, 0.05, 0.15, 0.01);
               this.cauldronCenter.playSound(SoundEvents.f_12019_, 0.3F, 0.8F, SoundSource.BLOCKS);
            }

            return StepResult.noOp();
         } else {
            return StepResult.complete();
         }
      }).build();
      TimeBasedStep<BaseVillager> wash = TimeBasedStep.<BaseVillager>builder().withTickable(WASH_DURATION.asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).setHeldItem(Items.f_271356_.m_7968_());
         return StepResult.noOp();
      }).everyTick((ctx) -> {
         if (this.leatherDisplay != null) {
            TransformationMatrix matrix = this.getAnimatedLeatherMatrix((float)ctx.getLevel().m_46467_());
            this.leatherDisplay.setTransformation(matrix, ClockTicks.ONE);
         }

         return StepResult.noOp();
      }).addPeriodicStep(20, (ctx) -> {
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).addPeriodicStep(5, (ctx) -> {
         if (this.cauldronCenter == null) {
            return StepResult.noOp();
         } else {
            this.cauldronCenter.displayParticles(ParticleTypes.f_123769_, 8, 0.3, 0.1, 0.3, 0.02);
            this.cauldronCenter.playSound(SoundEvents.f_11917_, 0.25F, 1.2F, SoundSource.BLOCKS);
            ColorParticleOption dirtySwirl = ColorParticleOption.create(ParticleTypes.f_123811_, -9479619);
            this.cauldronCenter.displayParticles(dirtySwirl, 5, 0.2, 0.1, 0.2, (double)0.0F);
            return StepResult.noOp();
         }
      }).onEnd((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         return StepResult.noOp();
      }).build();
      TimeBasedStep<BaseVillager> removeLeather = TimeBasedStep.<BaseVillager>builder().withTickable(REMOVE_LEATHER_DURATION.asTickable()).onStart((ctx) -> {
         if (this.leatherDisplayHandle != null) {
            this.leatherDisplayHandle.dispose(ctx.getLevel());
            this.leatherDisplayHandle = null;
         }

         this.leatherDisplay = null;
         ((BaseVillager)ctx.getInitiator()).setHeldItem(Items.f_42454_.m_7968_());
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         if (this.cauldronCenter != null) {
            this.cauldronCenter.displayParticles(ParticleTypes.f_175829_, 6, 0.2, 0.3, 0.2, 0.1);
            this.cauldronCenter.playSound(SoundEvents.f_12019_, 0.3F, 1.2F, SoundSource.BLOCKS);
         }

         return StepResult.noOp();
      }).onEnd((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         return StepResult.noOp();
      }).build();
      TimeBasedStep<BaseVillager> drain = TimeBasedStep.<BaseVillager>builder().withTickable(DRAIN_DURATION.asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).setHeldItem(Items.f_42446_.m_7968_());
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         if (this.cauldronCenter != null) {
            this.cauldronCenter.displayParticles(ParticleTypes.f_123769_, 5, 0.2, 0.1, 0.2, 0.02);
            this.cauldronCenter.playSound(SoundEvents.f_11781_, 0.5F, 1.0F, SoundSource.BLOCKS);
         }

         return StepResult.noOp();
      }).onEnd((ctx) -> {
         this.setCauldronWaterLevel(ctx.getLevel(), 0);
         if (this.restoreHandle != null) {
            this.restoreHandle.dispose(ctx.getLevel());
            this.restoreHandle = null;
         }

         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         this.rewardExperience(((BaseVillager)ctx.getInitiator()).getMinecraftEntity());
         BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.LEATHER_WASHED, (String)null);
         outcome.markSucceeded();
         ctx.declarePrimaryDeed(outcome);
         return StepResult.complete();
      }).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 1)).actionStep(new SequencedStep("WashLeatherBehavior.sequence", List.of(fill, holdLeather, wash, removeLeather, drain))).build();
   }

   private void setCauldronWaterLevel(@Nonnull Level level, int waterLevel) {
      if (this.cauldronPos != null) {
         BlockState current = level.m_8055_(this.cauldronPos);
         if (!current.m_60713_(Blocks.f_50256_) && !current.m_60713_(Blocks.f_152476_)) {
            log.behaviorTrace("Skipping cauldron water level update at {} — block is no longer a cauldron", this.cauldronPos);
         } else {
            BlockState newState;
            if (waterLevel <= 0) {
               newState = Blocks.f_50256_.m_49966_();
            } else {
               newState = (BlockState)Blocks.f_152476_.m_49966_().m_61124_(LayeredCauldronBlock.f_153514_, waterLevel);
            }

            level.m_7731_(this.cauldronPos, newState, BlockFlag.of(BlockFlag.SEND_BLOCK_UPDATE, BlockFlag.SEND_CLIENT_UPDATE));
         }
      }
   }

   private TransformationMatrix getAnimatedLeatherMatrix(float gameTime) {
      float spinAngleRadians = gameTime % 100.0F / 100.0F * ((float)Math.PI * 2F);
      return new TransformationMatrix((new Matrix4f()).translate(0.5F, 0.875F, 0.5F).rotateY(spinAngleRadians).rotateX(((float)Math.PI / 6F)).scale(0.8F));
   }

   private static enum WashStage implements StageKey {
      WASH_LEATHER,
      END;

      // $FF: synthetic method
      private static WashStage[] $values() {
         return new WashStage[]{WASH_LEATHER, END};
      }
   }
}
