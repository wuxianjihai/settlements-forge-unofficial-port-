package dev.breezes.settlements.application.ai.behavior.usecases.villager.cartographer;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.raid.Raid;
import net.minecraft.world.entity.raid.Raider;
import net.minecraft.world.level.Level;

public class ChartRaidersBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ChartRaidersBehavior.class.getName());
   private static final ClockTicks EMPTY_PULSE_RETRY = ClockTicks.seconds((double)15.0F);
   private final ChartRaidersConfig config;
   private boolean shouldRewardExperience;

   public ChartRaidersBehavior(@Nonnull ChartRaidersConfig config, @Nonnull BehaviorSupport support) {
      super(log, ClockTicks.ZERO.asTickable(), ClockTicks.ZERO.asTickable(), support, config.experienceReward());
      this.config = config;
      this.shouldRewardExperience = false;
      this.initializeStateMachine(StagedStep.builder().name("ChartRaidersBehavior").initialStage(ChartRaidersBehavior.ChartStage.SKETCH).stageStepMap(Map.of(ChartRaidersBehavior.ChartStage.SKETCH, MapSketch.step(this::chartRaiders))).nextStage(ChartRaidersBehavior.ChartStage.END).build(), ChartRaidersBehavior.ChartStage.END);
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      this.shouldRewardExperience = false;
      ChartFlares.launchSignal(context.getLevel(), villager, villager.getExpertise(), villager.m_217043_());
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      if (this.shouldRewardExperience) {
         this.rewardExperience(villager);
      }

      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
   }

   private StepResult chartRaiders(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager villager = context.getInitiator();
      ServerLevel level = context.getLevel();
      Optional<Raid> raid = RaidCharting.raidInWave(level, villager);
      if (raid.isEmpty()) {
         return StepResult.transition(ChartRaidersBehavior.ChartStage.END);
      } else {
         int raidersPerPulse = (Integer)this.config.expertiseRaidersPerPulse().getOrDefault(villager.getExpertise().getConfigName(), 2);
         List<Raider> candidates = ((Raid)raid.get()).m_150221_().stream().filter((raiderx) -> RaidCharting.isChartable(raiderx, level)).limit((long)raidersPerPulse).toList();
         List<Raider> charted = new ArrayList();

         for(Raider raider : candidates) {
            if (raider.m_147207_(new MobEffectInstance(MobEffects.f_19619_, RaidCharting.GLOW_DURATION.getTicksAsInt()), villager)) {
               charted.add(raider);
            }
         }

         ClockTicks cadence = this.config.cadence();
         if (charted.isEmpty()) {
            ClockTicks retry = ClockTicks.of(Math.min(EMPTY_PULSE_RETRY.getTicks(), cadence.getTicks()));
            villager.getSettlementsBrain().setMemory(MemoryTypeRegistry.CHART_RAIDERS_COOLDOWN, true, retry);
            return StepResult.transition(ChartRaidersBehavior.ChartStage.END);
         } else {
            villager.getSettlementsBrain().setMemory(MemoryTypeRegistry.CHART_RAIDERS_COOLDOWN, true, cadence);
            Location.fromEntity(villager, false).playSound(SoundEvents.f_11700_, 1.0F, 1.0F, SoundSource.NEUTRAL);
            ChartFlares.send(level, (Raid)raid.get(), charted, villager.getExpertise(), villager.m_217043_());
            this.shouldRewardExperience = true;
            context.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.RAIDERS_CHARTED, "raiders")).recordYield(charted.size());
            return StepResult.transition(ChartRaidersBehavior.ChartStage.END);
         }
      }
   }

   private static enum ChartStage implements StageKey {
      SKETCH,
      END;

      // $FF: synthetic method
      private static ChartStage[] $values() {
         return new ChartStage[]{SKETCH, END};
      }
   }
}
