package dev.breezes.settlements.application.ai.behavior.usecases.villager.donation;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.economy.VillagerWallet;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class DonationScanner_Factory implements Factory<DonationScanner> {
   private final Provider<VillagerWallet> villagerWalletProvider;

   private DonationScanner_Factory(Provider<VillagerWallet> villagerWalletProvider) {
      this.villagerWalletProvider = villagerWalletProvider;
   }

   public DonationScanner get() {
      return newInstance((VillagerWallet)this.villagerWalletProvider.get());
   }

   public static DonationScanner_Factory create(Provider<VillagerWallet> villagerWalletProvider) {
      return new DonationScanner_Factory(villagerWalletProvider);
   }

   public static DonationScanner newInstance(VillagerWallet villagerWallet) {
      return new DonationScanner(villagerWallet);
   }
}
