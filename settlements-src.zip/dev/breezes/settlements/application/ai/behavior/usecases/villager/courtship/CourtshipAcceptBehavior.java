package dev.breezes.settlements.application.ai.behavior.usecases.villager.courtship;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.ai.courtship.ChoreographyTimeline;
import dev.breezes.settlements.application.ai.courtship.CourtshipChoreographyLibrary;
import dev.breezes.settlements.application.ai.courtship.CourtshipCloseReason;
import dev.breezes.settlements.application.ai.courtship.CourtshipInvite;
import dev.breezes.settlements.application.ai.courtship.CourtshipPhase;
import dev.breezes.settlements.application.ai.courtship.CourtshipSession;
import dev.breezes.settlements.application.ai.courtship.CourtshipSessionRegistry;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.EventOutcome;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.genetics.GeneType;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.RandomRangeTickable;
import dev.breezes.settlements.infrastructure.compat.CompatMath;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;

public final class CourtshipAcceptBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(CourtshipAcceptBehavior.class.getName());
   private final CourtshipSessionRegistry sessionRegistry;
   private final CourtshipPresenter courtshipPresenter;
   private final CourtshipChoreographyLibrary choreographyLibrary;
   private static final double BASE_ACCEPTANCE_CHANCE = 0.65;
   private static final double CHARISMA_DIFFERENCE_WEIGHT = 0.35;
   private static final double MIN_ACCEPTANCE_CHANCE = 0.15;
   private static final double MAX_ACCEPTANCE_CHANCE = 0.95;
   @Nullable
   private UUID activeSessionId;
   private int lastObservedBeat;

   public CourtshipAcceptBehavior(@Nonnull BehaviorSupport support, @Nonnull CourtshipSessionRegistry sessionRegistry, @Nonnull CourtshipPresenter courtshipPresenter, @Nonnull CourtshipChoreographyLibrary choreographyLibrary) {
      super(log, ClockTicks.seconds((double)2.0F).asTickable(), RandomRangeTickable.of(ClockTicks.seconds((double)30.0F), ClockTicks.seconds((double)15.0F)), support);
      this.sessionRegistry = sessionRegistry;
      this.courtshipPresenter = courtshipPresenter;
      this.choreographyLibrary = choreographyLibrary;
      this.preconditions.add(this.hasCourtshipInviteOrSession());
      this.initializeStateMachine(StagedStep.builder().name("CourtshipAcceptBehavior").initialStage(CourtshipAcceptBehavior.Stage.MIRROR).stageStepMap(Map.of(CourtshipAcceptBehavior.Stage.MIRROR, StayCloseStep.builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 2)).actionStep(this::mirror).build())).nextStage(CourtshipAcceptBehavior.Stage.CLOSED).build(), CourtshipAcceptBehavior.Stage.CLOSED);
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      this.lastObservedBeat = -1;
      long now = world.m_46467_();
      if (this.sessionRegistry.hasInviteFor(villager.m_20148_())) {
         CourtshipInvite invite = (CourtshipInvite)this.sessionRegistry.getInvite(villager.m_20148_()).orElse((Object)null);
         if (invite == null) {
            return;
         }

         CourtshipSession pendingSession = (CourtshipSession)this.sessionRegistry.getActiveSession(villager.m_20148_()).orElse((Object)null);
         if (pendingSession == null) {
            return;
         }

         if (!(world instanceof ServerLevel)) {
            this.sessionRegistry.closeSession(pendingSession.getSessionId(), CourtshipCloseReason.EXTERNAL_CANCEL);
            return;
         }

         ServerLevel serverLevel = (ServerLevel)world;
         BaseVillager presenter = (BaseVillager)resolveParticipant(serverLevel, invite.presenterId()).orElse((Object)null);
         if (presenter == null) {
            this.sessionRegistry.closeSession(pendingSession.getSessionId(), CourtshipCloseReason.ABORTED_PARTNER_GONE);
            return;
         }

         if (!RandomUtil.chance(charismaAcceptanceChance(presenter, villager))) {
            this.courtshipPresenter.presentAbort(pendingSession, villager, CourtshipCloseReason.REJECTED_CHARISMA);
            this.sessionRegistry.closeSession(pendingSession.getSessionId(), CourtshipCloseReason.REJECTED_CHARISMA);
            UUID presenterId = invite.presenterId();
            UUID sessionId = pendingSession.getSessionId();
            BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.COURTSHIP_REJECTED, (String)null);
            outcome.recordSocialOutcome(presenterId, sessionId, EventOutcome.FAILURE, (String)null, "their charm fell short");
            context.declarePrimaryDeed(outcome);
            return;
         }

         this.sessionRegistry.acceptInvite(villager.m_20148_(), now);
      }

      CourtshipSession session = (CourtshipSession)this.sessionRegistry.getActiveSession(villager.m_20148_()).orElse((Object)null);
      if (session != null) {
         this.activeSessionId = session.getSessionId();
         this.courtshipPresenter.presentApproach(session, villager);
         if (world instanceof ServerLevel) {
            ServerLevel serverLevel = (ServerLevel)world;
            resolveParticipant(serverLevel, session.getPresenterId()).map(Targetable::fromEntity).ifPresent((target) -> context.setState(BehaviorStateType.TARGET, TargetState.of(target)));
         }
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      if (this.activeSessionId != null) {
         this.courtshipPresenter.presentEnd(villager, this.activeSessionId, world.m_46467_());
      }

      this.activeSessionId = null;
      this.lastObservedBeat = -1;
   }

   private ICondition<BaseVillager> hasCourtshipInviteOrSession() {
      return ICondition.<BaseVillager>named("has courtship invite or session", (villager) -> this.sessionRegistry.hasInviteFor(villager.m_20148_()) || this.sessionRegistry.getActiveSession(villager.m_20148_()).isPresent());
   }

   private StepResult mirror(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager self = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      CourtshipSession session = (CourtshipSession)this.currentSession(self).orElse((Object)null);
      if (session == null) {
         return StepResult.complete();
      } else {
         CourtshipPhase phase = session.getPhase();
         if (phase != CourtshipPhase.COMPLETED && phase != CourtshipPhase.ABORTED) {
            int presenterBeat = session.getCurrentBeatIndex();
            long now = self.m_9236_().m_46467_();
            if (presenterBeat != this.lastObservedBeat && this.isReactionReady(session, presenterBeat, now)) {
               this.courtshipPresenter.presentBeat(session, self, presenterBeat);
               this.lastObservedBeat = presenterBeat;
            }

            return StepResult.noOp();
         } else {
            return StepResult.complete();
         }
      }
   }

   private static double charismaAcceptanceChance(@Nonnull BaseVillager presenter, @Nonnull BaseVillager receiver) {
      double presenterCharisma = presenter.getGenetics().getGeneValue(GeneType.CHARISMA);
      double receiverCharisma = receiver.getGenetics().getGeneValue(GeneType.CHARISMA);
      double socialFit = 0.65 + (presenterCharisma - receiverCharisma) * 0.35;
      return CompatMath.clamp(socialFit, 0.15, 0.95);
   }

   private boolean isReactionReady(@Nonnull CourtshipSession session, int beat, long now) {
      if (session.getCourtshipStartGameTime() < 0L) {
         return false;
      } else {
         ChoreographyTimeline timeline = this.choreographyLibrary.get(session.getChoreographyId());
         long beatStartTick = timeline.beatStartTick(beat, session.getCourtshipStartGameTime());
         return now - beatStartTick >= 8L;
      }
   }

   private Optional<CourtshipSession> currentSession(@Nonnull BaseVillager villager) {
      return this.sessionRegistry.getActiveSession(villager.m_20148_()).filter((s) -> this.activeSessionId == null || this.activeSessionId.equals(s.getSessionId()));
   }

   private static Optional<BaseVillager> resolveParticipant(@Nonnull ServerLevel level, @Nonnull UUID id) {
      Optional var10000 = Optional.ofNullable(level.m_8791_(id));
      Objects.requireNonNull(BaseVillager.class);
      var10000 = var10000.filter(BaseVillager.class::isInstance);
      Objects.requireNonNull(BaseVillager.class);
      return var10000.map(BaseVillager.class::cast);
   }

   public static enum Stage implements StageKey {
      MIRROR,
      CLOSED;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{MIRROR, CLOSED};
      }
   }
}
