package dev.breezes.settlements.application.ai.behavior.usecases.villager.enchanting;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.enchanting.engine.EnchantmentEngine;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.domain.ai.conditions.IBlockCondition;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.conditions.NearbyBlockExistsCondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.enchanting.SpecializationProfile;
import dev.breezes.settlements.domain.entities.Expertise;
import dev.breezes.settlements.domain.genetics.GeneType;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.ITickable;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.infrastructure.rendering.particles.EnchantTier;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EnchantmentTableBlock;

public class EnchantItemBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(EnchantItemBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private static final int MAX_BOOKSHELF_COUNT = 15;
   private static final int ORB_EMISSION_GRANULARITY_TICKS = 2;
   private final EnchantItemConfig config;
   private final NearbyBlockExistsCondition<BaseVillager> nearbyEnchantingTableCondition;
   private final EnchantmentEngine enchantmentEngine;
   @Nullable
   private BlockPos enchantingTablePos;
   @Nullable
   private ItemStack targetRepresentative;
   @Nullable
   private EnchantTier enchantTier;

   public EnchantItemBehavior(@Nonnull EnchantItemConfig config, @Nonnull BehaviorSupport support, @Nonnull EnchantmentEngine enchantmentEngine) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.nearbyEnchantingTableCondition = new NearbyBlockExistsCondition<BaseVillager>((double)config.scanRangeHorizontal(), (double)config.scanRangeVertical(), Blocks.f_50201_, (IBlockCondition)null, 1);
      this.preconditions.add(ICondition.named("HasEnchantableNonEnchantedItem", this::hasEnchantableNonEnchantedItem));
      this.preconditions.add(this.nearbyEnchantingTableCondition);
      this.enchantmentEngine = enchantmentEngine;
      this.enchantingTablePos = null;
      this.targetRepresentative = null;
      this.enchantTier = null;
      this.initializeStateMachine(this.createControlStep(), EnchantItemBehavior.EnchantStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("EnchantItemBehavior").initialStage(EnchantItemBehavior.EnchantStage.ENCHANT_ITEM).stageStepMap(Map.of(EnchantItemBehavior.EnchantStage.ENCHANT_ITEM, this.createEnchantStep())).nextStage(EnchantItemBehavior.EnchantStage.END).build();
   }

   private BehaviorStep<BaseVillager> createEnchantStep() {
      ITickable actionTickable = ClockTicks.seconds((double)10.0F).asTickable();
      TimeBasedStep<BaseVillager> actionStep = TimeBasedStep.<BaseVillager>builder().withTickable(actionTickable).addPeriodicStep(ClockTicks.of(10L).getTicksAsInt(), this::emitAmbianceParticles).addPeriodicStep(2, (context) -> this.emitTierOrbPulse(context, actionTickable)).addKeyFrame(ClockTicks.seconds((double)8.0F), this::playRevealSound).onEnd((context) -> StepResult.complete()).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 1)).actionStep(actionStep).build();
   }

   private StepResult emitAmbianceParticles(@Nonnull BehaviorContext<BaseVillager> context) {
      if (this.enchantingTablePos == null) {
         return StepResult.noOp();
      } else {
         Location targetLocation = Location.of(this.enchantingTablePos, ((BaseVillager)context.getInitiator()).getMinecraftEntity().m_9236_()).center(false);
         targetLocation.displayParticles(ParticleTypes.f_123809_, 50, (double)2.0F, (double)1.0F, (double)2.0F, (double)1.0F);
         targetLocation.displayParticles(ParticleTypes.f_123760_, 3, (double)2.0F, (double)1.0F, (double)2.0F, (double)1.0F);
         ParticleRegistry.displayCircle(ParticleTypes.f_123810_, targetLocation.add((double)0.0F, -0.2, (double)0.0F, true), (double)1.25F, 16);
         return StepResult.noOp();
      }
   }

   private StepResult emitTierOrbPulse(@Nonnull BehaviorContext<BaseVillager> context, @Nonnull ITickable actionTickable) {
      if (this.enchantTier != null && this.enchantingTablePos != null) {
         if (actionTickable.getTicksElapsedRounded() % (long)this.enchantTier.getEmitIntervalTicks() != 0L) {
            return StepResult.noOp();
         } else {
            Location targetLocation = Location.of(this.enchantingTablePos, ((BaseVillager)context.getInitiator()).getMinecraftEntity().m_9236_()).center(false);
            ParticleRegistry.enchantTierOrbs(targetLocation, this.enchantTier);
            return StepResult.noOp();
         }
      } else {
         return StepResult.noOp();
      }
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      this.enchantingTablePos = (BlockPos)this.nearbyEnchantingTableCondition.getTargets().get(0);
      if (this.enchantingTablePos == null) {
         log.behaviorError("Unable to find enchanting table position");
         this.requestStop("Unable to find enchanting table position");
      } else {
         this.targetRepresentative = (ItemStack)this.findFirstEnchantableNonEnchantedRepresentative(entity.getSettlementsInventory()).orElse((Object)null);
         if (this.targetRepresentative == null) {
            log.behaviorError("No enchantable non-enchanted item found");
            this.requestStop("No enchantable non-enchanted item found");
         } else if (this.transactEnchant(world, entity, context)) {
            context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromBlock(PhysicalBlock.of(Location.of(this.enchantingTablePos, world), world.m_8055_(this.enchantingTablePos)))));
         }
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      if (this.enchantingTablePos != null && world.m_8055_(this.enchantingTablePos).m_60713_(Blocks.f_50201_)) {
         return true;
      } else {
         log.behaviorError("Invalid enchanting table position: {}", this.enchantingTablePos);
         return false;
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager entity) {
      entity.getNavigationManager().stop();
      entity.clearHeldItem();
      this.enchantingTablePos = null;
      this.targetRepresentative = null;
      this.enchantTier = null;
   }

   private boolean transactEnchant(@Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      if (this.enchantingTablePos != null && this.targetRepresentative != null) {
         VillagerInventory inventory = entity.getSettlementsInventory();
         Expertise expertise = entity.getExpertise();
         double intelligence = entity.getGenetics().getGeneValue(GeneType.INTELLIGENCE);
         int bookshelfCount = this.countNearbyBookshelves(world, this.enchantingTablePos);
         SpecializationProfile specialization = null;
         ItemStack enchantedItem = this.enchantmentEngine.enchant(this.targetRepresentative, expertise, intelligence, bookshelfCount, specialization, world.m_9598_());
         if (inventory.consume((ItemStack)this.targetRepresentative, 1) != 1) {
            log.behaviorError("Failed to enchant item because item cannot be consumed");
            this.requestStop("Failed to enchant item because item cannot be consumed");
            return false;
         } else {
            inventory.add(enchantedItem);
            this.enchantTier = EnchantTier.classify(enchantedItem);
            log.behaviorStatus("Enchanted item from {} to {} (tier {})", this.targetRepresentative, enchantedItem, this.enchantTier);
            BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.ITEM_ENCHANTED, (String)null);
            outcome.markSucceeded();
            outcome.recordDeedDetail(enchantedItem.m_41720_().toString());
            outcome.putDetailField("item", BuiltInRegistries.f_257033_.m_7981_(enchantedItem.m_41720_()).m_135815_());
            context.declarePrimaryDeed(outcome);
            this.rewardExperience(entity);
            return true;
         }
      } else {
         log.behaviorError("Failed to enchant item: enchanting setup or target is invalid");
         this.requestStop("Enchanting setup or target is invalid");
         return false;
      }
   }

   private StepResult playRevealSound(@Nonnull BehaviorContext<BaseVillager> context) {
      if (this.enchantingTablePos != null && this.enchantTier != null) {
         Level world = ((BaseVillager)context.getInitiator()).getMinecraftEntity().m_9236_();
         world.m_5594_((Player)null, this.enchantingTablePos, SoundEvents.f_11887_, SoundSource.BLOCKS, 1.0F, 1.0F);
         return StepResult.noOp();
      } else {
         return StepResult.noOp();
      }
   }

   private boolean hasEnchantableNonEnchantedItem(@Nullable BaseVillager villager) {
      return villager == null ? false : this.findFirstEnchantableNonEnchantedRepresentative(villager.getSettlementsInventory()).isPresent();
   }

   private Optional<ItemStack> findFirstEnchantableNonEnchantedRepresentative(@Nonnull VillagerInventory inventory) {
      return inventory.findFirst((stack) -> stack.m_41792_() || stack.m_150930_(Items.f_42517_));
   }

   private int countNearbyBookshelves(@Nonnull Level world, @Nonnull BlockPos enchantingTablePosition) {
      int count = 0;

      for(BlockPos offset : EnchantmentTableBlock.f_207902_) {
         if (count >= 15) {
            return 15;
         }

         BlockPos bookshelfPos = enchantingTablePosition.m_121955_(offset);
         if (world.m_8055_(bookshelfPos).m_60713_(Blocks.f_50078_)) {
            BlockPos middlePos = enchantingTablePosition.m_7918_(offset.m_123341_() / 2, offset.m_123342_(), offset.m_123343_() / 2);
            if (world.m_8055_(middlePos).m_60795_()) {
               ++count;
            }
         }
      }

      return count;
   }

   private static enum EnchantStage implements StageKey {
      ENCHANT_ITEM,
      END;

      // $FF: synthetic method
      private static EnchantStage[] $values() {
         return new EnchantStage[]{ENCHANT_ITEM, END};
      }
   }
}
