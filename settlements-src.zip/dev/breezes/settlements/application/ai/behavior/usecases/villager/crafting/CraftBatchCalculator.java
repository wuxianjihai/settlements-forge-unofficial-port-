package dev.breezes.settlements.application.ai.behavior.usecases.villager.crafting;

import dev.breezes.settlements.domain.crafting.catalog.CraftIngredient;
import dev.breezes.settlements.domain.crafting.catalog.CraftRecipe;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.economy.catalog.ItemMatches;
import dev.breezes.settlements.domain.economy.catalog.OfferEntry;
import dev.breezes.settlements.domain.economy.catalog.SupplyEntry;
import dev.breezes.settlements.domain.economy.catalog.TradeCatalogRegistry;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.Comparator;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;

public class CraftBatchCalculator {
   private final TradeCatalogRegistry tradeCatalog;

   public int computeBatch(@Nonnull BaseVillager villager, @Nonnull CraftRecipe recipe) {
      Item outputItem = (Item)BuiltInRegistries.f_257033_.m_7745_(recipe.output().itemId());
      VillagerProfessionKey profession = villager.getProfession();
      Integer ceiling = this.dumpAbove(profession, outputItem);
      if (ceiling == null) {
         return 0;
      } else {
         VillagerInventory inventory = villager.getSettlementsInventory();
         List<CraftIngredient> inputs = recipe.inputs();
         int[] inputHeadrooms = new int[inputs.size()];
         int[] inputCounts = new int[inputs.size()];

         for(int i = 0; i < inputs.size(); ++i) {
            CraftIngredient input = (CraftIngredient)inputs.get(i);
            inputHeadrooms[i] = inventory.countMatching(input.match()) - this.reserveFor(profession, input.match());
            inputCounts[i] = input.count();
         }

         return clampBatch(villager.getExpertise().getLevel(), ceiling - inventory.count(outputItem), recipe.output().count(), inputHeadrooms, inputCounts);
      }
   }

   static int clampBatch(int expertiseLevel, int outputHeadroom, int outputCount, @Nonnull int[] inputHeadrooms, @Nonnull int[] inputCounts) {
      int batch = Math.min(expertiseLevel, outputHeadroom / outputCount);

      for(int i = 0; i < inputHeadrooms.length; ++i) {
         batch = Math.min(batch, inputHeadrooms[i] / inputCounts[i]);
      }

      return Math.max(batch, 0);
   }

   public int ceilingHeadroom(@Nonnull BaseVillager villager, @Nonnull CraftRecipe recipe) {
      Item outputItem = (Item)BuiltInRegistries.f_257033_.m_7745_(recipe.output().itemId());
      Integer ceiling = this.dumpAbove(villager.getProfession(), outputItem);
      return ceiling == null ? Integer.MIN_VALUE : ceiling - villager.getSettlementsInventory().count(outputItem);
   }

   public CraftRecipe selectPreferred(@Nonnull BaseVillager villager, @Nonnull List<CraftRecipe> craftableRecipes) {
      return (CraftRecipe)craftableRecipes.stream().max(Comparator.comparingInt((recipe) -> this.ceilingHeadroom(villager, recipe)).thenComparingInt(CraftRecipe::priority)).orElseThrow();
   }

   @Nullable
   private Integer dumpAbove(@Nonnull VillagerProfessionKey profession, @Nonnull Item outputItem) {
      ItemStack outputStack = new ItemStack(outputItem);
      Integer ceiling = null;

      for(SupplyEntry entry : this.tradeCatalog.supplyFor(profession)) {
         if (ItemMatches.test(entry.match(), outputStack)) {
            ceiling = ceiling == null ? entry.dumpAbove() : Math.max(ceiling, entry.dumpAbove());
         }
      }

      return ceiling;
   }

   private int reserveFor(@Nonnull VillagerProfessionKey profession, @Nonnull ItemMatch inputMatch) {
      return this.tradeCatalog.findOffers(profession, inputMatch).stream().filter((entry) -> coversInput(entry.match(), inputMatch)).mapToInt(OfferEntry::surplusThreshold).max().orElse(0);
   }

   private static boolean coversInput(@Nonnull ItemMatch rungMatch, @Nonnull ItemMatch inputMatch) {
      if (rungMatch.equals(inputMatch)) {
         return true;
      } else {
         if (rungMatch instanceof ItemMatch.TagRef) {
            ItemMatch.TagRef tagRef = (ItemMatch.TagRef)rungMatch;
            if (inputMatch instanceof ItemMatch.ItemRef) {
               ItemMatch.ItemRef itemRef = (ItemMatch.ItemRef)inputMatch;
               return itemInTag(itemRef, tagRef);
            }
         }

         if (rungMatch instanceof ItemMatch.ItemRef) {
            ItemMatch.ItemRef itemRef = (ItemMatch.ItemRef)rungMatch;
            if (inputMatch instanceof ItemMatch.TagRef) {
               ItemMatch.TagRef tagRef = (ItemMatch.TagRef)inputMatch;
               return itemInTag(itemRef, tagRef);
            }
         }

         return false;
      }
   }

   private static boolean itemInTag(@Nonnull ItemMatch.ItemRef itemRef, @Nonnull ItemMatch.TagRef tagRef) {
      return (new ItemStack((ItemLike)BuiltInRegistries.f_257033_.m_7745_(itemRef.id()))).m_204117_(tagRef.tag());
   }

   @Inject
   @Generated
   public CraftBatchCalculator(TradeCatalogRegistry tradeCatalog) {
      this.tradeCatalog = tradeCatalog;
   }
}
