package dev.breezes.settlements.application.ai.behavior.usecases.villager.ballista;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class BallistaCombatOption_Factory implements Factory<BallistaCombatOption> {
   private final Provider<BehaviorSupport> supportProvider;
   private final Provider<BallistaOperationConfig> configProvider;

   private BallistaCombatOption_Factory(Provider<BehaviorSupport> supportProvider, Provider<BallistaOperationConfig> configProvider) {
      this.supportProvider = supportProvider;
      this.configProvider = configProvider;
   }

   public BallistaCombatOption get() {
      return newInstance((BehaviorSupport)this.supportProvider.get(), (BallistaOperationConfig)this.configProvider.get());
   }

   public static BallistaCombatOption_Factory create(Provider<BehaviorSupport> supportProvider, Provider<BallistaOperationConfig> configProvider) {
      return new BallistaCombatOption_Factory(supportProvider, configProvider);
   }

   public static BallistaCombatOption newInstance(BehaviorSupport support, BallistaOperationConfig config) {
      return new BallistaCombatOption(support, config);
   }
}
