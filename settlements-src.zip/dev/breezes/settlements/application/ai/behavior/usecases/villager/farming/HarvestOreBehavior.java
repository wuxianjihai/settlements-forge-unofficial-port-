package dev.breezes.settlements.application.ai.behavior.usecases.villager.farming;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.blocks.VisitedBlockSitesState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.items.ItemState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetQueries;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.AwardExperienceStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.LoopBackStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.OneShotStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.PickupItemsStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.WaitStep;
import dev.breezes.settlements.application.ai.targeting.BlockMemoryTargetResolver;
import dev.breezes.settlements.bootstrap.registry.blocks.BlockRegistry;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.domain.ai.conditions.KnownBlockSitesPrecondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.AabbBlockScan;
import dev.breezes.settlements.domain.world.blocks.BlockMatcher;
import dev.breezes.settlements.domain.world.blocks.BlockMatchers;
import dev.breezes.settlements.domain.world.blocks.BlockScanBox;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.config.factory.ConfigFactory;
import dev.breezes.settlements.infrastructure.minecraft.blocks.DormantOreBlock;
import dev.breezes.settlements.infrastructure.minecraft.blocks.OreRegenConfig;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.Tags.Blocks;

public class HarvestOreBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(HarvestOreBehavior.class.getName());
   private static final ClockTicks SETTLE_DURATION = ClockTicks.seconds((double)1.0F);
   private static final int APPROACH_TIMEOUT_TICKS = ClockTicks.seconds((double)20.0F).getTicksAsInt();
   private static final ResourceLocation IRON_PICKAXE_ID = new ResourceLocation("minecraft", "iron_pickaxe");
   private final BlockMatcher oreMatcher;
   private final BlockScanBox confirmBox;
   private final int maxConfirms;
   private final HarvestOreConfig config;
   private final BlockMemoryTargetResolver targetResolver;

   public HarvestOreBehavior(@Nonnull HarvestOreConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.targetResolver = support.getBlockMemoryTargetResolver();
      this.oreMatcher = BlockMatchers.HARVESTABLE_ORE;
      this.confirmBox = BlockScanBox.confirm();
      this.maxConfirms = 8;
      this.preconditions.add(KnownBlockSitesPrecondition.builder().memoryType(MemoryTypeRegistry.ORE_SITES).matcher(this.oreMatcher).confirmBox(this.confirmBox).maxSitesToConfirm(this.maxConfirms).completionRange(2).description("Known ore sites").build());
      this.preconditions.add(support.getDemandSignalService().requireItem(new ItemMatch.ItemRef(IRON_PICKAXE_ID), 1, 50, this.getClass().getSimpleName()));
      this.initializeStateMachine(this.createControlStep(), HarvestOreBehavior.Stage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      Map<StageKey, BehaviorStep<BaseVillager>> stageMap = new HashMap();
      stageMap.put(HarvestOreBehavior.Stage.PICK_TARGET, this.createPickTargetStep());
      stageMap.put(HarvestOreBehavior.Stage.APPROACH, StayCloseStep.builder().closeEnoughDistance((double)2.5F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.WALK).completionDistance(2).unreachableTransition(HarvestOreBehavior.Stage.PICK_TARGET).build()).actionStep(OneShotStep.builder().name("ArrivedAtOre").action((ctx) -> StepResult.transition(HarvestOreBehavior.Stage.HARVEST)).build()).timeoutTicks(APPROACH_TIMEOUT_TICKS).timeoutTransition(HarvestOreBehavior.Stage.PICK_TARGET).build());
      stageMap.put(HarvestOreBehavior.Stage.HARVEST, this.createHarvestStep());
      stageMap.put(HarvestOreBehavior.Stage.SETTLE, WaitStep.builder().waitTime(SETTLE_DURATION.asTickable()).nextStage(HarvestOreBehavior.Stage.PICKUP).build());
      stageMap.put(HarvestOreBehavior.Stage.PICKUP, PickupItemsStep.builder().name("PickupOreDrops").nextStage(HarvestOreBehavior.Stage.LOOP).build());
      stageMap.put(HarvestOreBehavior.Stage.LOOP, LoopBackStep.builder().name("OreLoopBack").loopBackTo(HarvestOreBehavior.Stage.PICK_TARGET).completionTransition(HarvestOreBehavior.Stage.AWARD).maxIterationsResolver((ctx) -> (Integer)this.config.expertiseHarvestLimit().getOrDefault(((BaseVillager)ctx.getInitiator()).getExpertise().getConfigName(), 1)).build());
      stageMap.put(HarvestOreBehavior.Stage.AWARD, AwardExperienceStep.builder().name("AwardOreXp").experienceAmount(this.config.experienceReward()).nextStage(HarvestOreBehavior.Stage.END).build());
      return StagedStep.<BaseVillager>builder().name("HarvestOreBehavior").initialStage(HarvestOreBehavior.Stage.PICK_TARGET).stageStepMap(stageMap).nextStage(HarvestOreBehavior.Stage.END).build();
   }

   private BehaviorStep<BaseVillager> createPickTargetStep() {
      return OneShotStep.<BaseVillager>builder().name("PickOreTarget").action((ctx) -> {
         boolean resolved = this.targetResolver.resolveBlockTarget(ctx, MemoryTypeRegistry.ORE_SITES, this.oreMatcher, this.confirmBox, this.maxConfirms, 2);
         if (!resolved) {
            log.behaviorStatus("No additional ore targets found, ending behavior");
            return StepResult.transition(HarvestOreBehavior.Stage.AWARD);
         } else {
            return StepResult.transition(HarvestOreBehavior.Stage.APPROACH);
         }
      }).build();
   }

   private BehaviorStep<BaseVillager> createHarvestStep() {
      return TimeBasedStep.<BaseVillager>builder().name("HarvestOre").withTickable(ClockTicks.of(30L).asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).setHeldItem(Items.f_42385_.m_7968_());
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.SWING_HEAVY);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(14L), this::replaceOre).onEnd((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         ((BaseVillager)ctx.getInitiator()).setMotion(AnimationArchetype.IDLE);
         return StepResult.transition(HarvestOreBehavior.Stage.SETTLE);
      }).build();
   }

   private StepResult replaceOre(@Nonnull BehaviorContext<BaseVillager> context) {
      Optional<BlockPos> target = TargetQueries.firstBlockPos(context);
      if (target.isEmpty()) {
         return StepResult.noOp();
      } else {
         BaseVillager villager = context.getInitiator();
         Level world = villager.m_9236_();
         BlockPos pos = (BlockPos)target.get();
         BlockState oreState = world.m_8055_(pos);
         if (world instanceof ServerLevel) {
            ServerLevel server = (ServerLevel)world;
            if (AabbBlockScan.findFirst(pos, BlockScanBox.self(), this.oreMatcher, world).isEmpty()) {
               return StepResult.noOp();
            } else {
               Location effectLocation = Location.of(pos, world).center(true).add((double)0.0F, (double)0.5F, (double)0.0F, true);
               ParticleRegistry.harvestBlock(effectLocation, oreState);
               effectLocation.playSound(oreState.getSoundType(world, pos, villager).m_56775_(), 0.8F, 1.0F, SoundSource.BLOCKS);
               List<ItemStack> drops = Block.m_49874_(oreState, server, pos, (BlockEntity)null, villager, ItemStack.f_41583_);
               List<ItemEntity> spawned = Location.of(pos, world).center(true).dropItems(drops, true);
               spawned.forEach((itemEntity) -> itemEntity.m_32010_(ClockTicks.seconds((double)5.0F).getTicksAsInt()));
               BlockState replacement = this.createReplacementState(oreState);
               world.m_46597_(pos, replacement);
               context.getState(BehaviorStateType.VISITED_BLOCK_SITES, VisitedBlockSitesState.class).ifPresent((visitedSites) -> visitedSites.addSite(GlobalPos.m_122643_(world.m_46472_(), pos)));
               context.setState(BehaviorStateType.ITEMS_TO_PICK_UP, ItemState.of(spawned));
               context.primaryDeed().ifPresent((outcome) -> outcome.recordYield(totalItemCount(drops)));
               return StepResult.noOp();
            }
         } else {
            return StepResult.noOp();
         }
      }
   }

   private BlockState createReplacementState(@Nonnull BlockState oreState) {
      boolean isStone = oreState.m_204336_(Blocks.ORES_IN_GROUND_STONE);
      if (!((OreRegenConfig)ConfigFactory.create(OreRegenConfig.class)).enabled()) {
         return isStone ? net.minecraft.world.level.block.Blocks.f_50652_.m_49966_() : net.minecraft.world.level.block.Blocks.f_152551_.m_49966_();
      } else {
         return isStone ? ((DormantOreBlock)BlockRegistry.DORMANT_ORE.get()).m_49966_() : ((DormantOreBlock)BlockRegistry.DORMANT_DEEPSLATE_ORE.get()).m_49966_();
      }
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      context.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.RESOURCE_HARVESTED, "ore"));
      context.setState(BehaviorStateType.VISITED_BLOCK_SITES, VisitedBlockSitesState.empty());
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
   }

   private static int totalItemCount(@Nonnull List<ItemStack> drops) {
      return drops.stream().mapToInt(ItemStack::m_41613_).sum();
   }

   private static enum Stage implements StageKey {
      PICK_TARGET,
      APPROACH,
      HARVEST,
      SETTLE,
      PICKUP,
      LOOP,
      AWARD,
      END;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{PICK_TARGET, APPROACH, HARVEST, SETTLE, PICKUP, LOOP, AWARD, END};
      }
   }
}
