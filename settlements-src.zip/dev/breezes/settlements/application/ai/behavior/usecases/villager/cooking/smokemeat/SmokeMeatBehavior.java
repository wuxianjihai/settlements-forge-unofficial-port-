package dev.breezes.settlements.application.ai.behavior.usecases.villager.cooking.smokemeat;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.teardown.ResetBlockStateObligation;
import dev.breezes.settlements.application.ai.behavior.teardown.TemporaryArtifactHandle;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.SequencedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.conditions.JobSiteBlockExistsCondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.BlockFlag;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class SmokeMeatBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(SmokeMeatBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private static final ClockTicks ITEM_INTERACTION_DURATION = ClockTicks.seconds((double)1.0F);
   private static final ClockTicks SMOKING_DURATION = ClockTicks.seconds((double)6.0F);
   private static final List<SmokeMeatRecipe> RECIPES;
   private final JobSiteBlockExistsCondition<BaseVillager> jobSiteBlockExistsCondition = new JobSiteBlockExistsCondition<BaseVillager>((block) -> block != null && block.is(Blocks.f_50619_), 1);
   private final SmokeRecipeAvailableCondition smokeRecipeAvailableCondition;
   @Nullable
   private PhysicalBlock smoker;
   @Nullable
   private SmokeMeatRecipe currentRecipe;
   @Nullable
   private TemporaryArtifactHandle litHandle;

   public SmokeMeatBehavior(SmokeMeatConfig config, BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.smokeRecipeAvailableCondition = new SmokeRecipeAvailableCondition(RECIPES);
      this.preconditions.add(this.jobSiteBlockExistsCondition);
      this.preconditions.add(this.smokeRecipeAvailableCondition);
      this.smoker = null;
      this.currentRecipe = null;
      this.litHandle = null;
      this.initializeStateMachine(this.createControlStep(), SmokeMeatBehavior.SmokeStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("SmokeMeatBehavior").initialStage(SmokeMeatBehavior.SmokeStage.SMOKE_MEAT).stageStepMap(Map.of(SmokeMeatBehavior.SmokeStage.SMOKE_MEAT, this.createSmokeStep())).nextStage(SmokeMeatBehavior.SmokeStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      if (this.jobSiteBlockExistsCondition.getJobSiteBlock().isEmpty()) {
         this.requestStop("No smoker block found at job site");
      } else {
         this.smoker = (PhysicalBlock)this.jobSiteBlockExistsCondition.getJobSiteBlock().get();
         List<SmokeMeatRecipe> validRecipes = this.smokeRecipeAvailableCondition.getValidRecipes();
         if (validRecipes.isEmpty()) {
            this.requestStop("No valid smoke recipes available");
         } else {
            this.currentRecipe = (SmokeMeatRecipe)RandomUtil.choice(validRecipes).orElseThrow();
            context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromBlock(this.smoker)));
         }
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      return this.smoker != null && this.smoker.is(Blocks.f_50619_);
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.litHandle = null;
      this.smoker = null;
      this.currentRecipe = null;
   }

   private BehaviorStep<BaseVillager> createSmokeStep() {
      TimeBasedStep<BaseVillager> setup = TimeBasedStep.<BaseVillager>builder().withTickable(ITEM_INTERACTION_DURATION.asTickable()).onStart((ctx) -> {
         if (this.currentRecipe != null && this.smoker != null) {
            BaseVillager villager = ((BaseVillager)ctx.getInitiator()).getMinecraftEntity();
            if (!this.consumeRecipeInput(villager, this.currentRecipe)) {
               return StepResult.fail("SMOKE_MEAT_INPUT_CONSUME_FAILED");
            } else {
               ((BaseVillager)ctx.getInitiator()).setHeldItem(this.currentRecipe.createInputStack());
               villager.triggerMotion(AnimationArchetype.INTERACT);
               return StepResult.noOp();
            }
         } else {
            return StepResult.complete();
         }
      }).onEnd((ctx) -> {
         if (this.smoker == null) {
            return StepResult.complete();
         } else {
            ((BaseVillager)ctx.getInitiator()).clearHeldItem();
            this.setSmokerLitState(true);
            BlockPos smokerPos = this.smoker.getLocation(false).toBlockPos();
            ResourceLocation smokerBlockId = BuiltInRegistries.f_256975_.m_7981_(Blocks.f_50619_);
            this.litHandle = ctx.getTeardownScope().track(new ResetBlockStateObligation(smokerPos, smokerBlockId, "lit", "false"));
            Location location = this.smoker.getLocation(true).add((double)0.0F, (double)0.5F, (double)0.0F, false);
            location.displayParticles(ParticleTypes.f_123762_, 6, 0.3, 0.3, 0.3, 0.02);
            SoundRegistry.ITEM_POP_IN.playGlobally(location, SoundSource.BLOCKS);
            return StepResult.noOp();
         }
      }).build();
      TimeBasedStep<BaseVillager> smoking = TimeBasedStep.<BaseVillager>builder().withTickable(SMOKING_DURATION.asTickable()).onEnd((ctx) -> {
         if (this.smoker != null && this.currentRecipe != null) {
            if (this.litHandle != null) {
               this.litHandle.dispose(ctx.getLevel());
               this.litHandle = null;
            }

            BaseVillager villager = ((BaseVillager)ctx.getInitiator()).getMinecraftEntity();
            ItemStack outputStack = this.currentRecipe.createOutputStack();
            villager.getSettlementsInventory().add(outputStack);
            BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.MEAT_SMOKED, (String)null);
            outcome.recordDeedDetail(outputStack.m_41720_().toString());
            outcome.putDetailField("item", BuiltInRegistries.f_257033_.m_7981_(outputStack.m_41720_()).m_135815_());
            outcome.markSucceeded();
            ctx.declarePrimaryDeed(outcome);
            ((BaseVillager)ctx.getInitiator()).setHeldItem(outputStack);
            villager.triggerMotion(AnimationArchetype.INTERACT);
            SoundRegistry.ITEM_POP_OUT.playGlobally(this.smoker.getLocation(true).add((double)0.0F, (double)0.5F, (double)0.0F, false), SoundSource.BLOCKS);
            return StepResult.noOp();
         } else {
            return StepResult.complete();
         }
      }).build();
      TimeBasedStep<BaseVillager> takeOut = TimeBasedStep.<BaseVillager>builder().withTickable(ITEM_INTERACTION_DURATION.asTickable()).onEnd((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         this.rewardExperience(((BaseVillager)ctx.getInitiator()).getMinecraftEntity());
         return StepResult.complete();
      }).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 1)).actionStep(new SequencedStep("SmokeMeatBehavior.sequence", List.of(setup, smoking, takeOut))).build();
   }

   private boolean consumeRecipeInput(@Nonnull BaseVillager villager, @Nonnull SmokeMeatRecipe recipe) {
      return villager.getSettlementsInventory().consume(recipe.getInput(), recipe.getInputCount()) == recipe.getInputCount();
   }

   private void setSmokerLitState(boolean lit) {
      if (this.smoker != null) {
         Level level = this.smoker.getLevel();
         BlockPos pos = this.smoker.getLocation(false).toBlockPos();
         BlockState currentState = level.m_8055_(pos);
         if (!currentState.m_60713_(Blocks.f_50619_)) {
            log.behaviorTrace("Skipping smoker lit state update at {} because block is no longer a smoker", pos);
         } else if (!currentState.m_61138_(AbstractFurnaceBlock.f_48684_)) {
            log.behaviorTrace("Skipping smoker lit state update at {} because block state has no LIT property", pos);
         } else if ((Boolean)currentState.m_61143_(AbstractFurnaceBlock.f_48684_) != lit) {
            log.behaviorTrace("Setting smoker lit state to {}", lit);
            BlockState newState = (BlockState)currentState.m_61124_(AbstractFurnaceBlock.f_48684_, lit);
            level.m_7731_(pos, newState, BlockFlag.of(BlockFlag.SEND_BLOCK_UPDATE, BlockFlag.SEND_CLIENT_UPDATE));
         }
      }
   }

   static {
      RECIPES = List.of(SmokeMeatRecipe.builder().input(Items.f_42579_).output(Items.f_42580_).build(), SmokeMeatRecipe.builder().input(Items.f_42485_).output(Items.f_42486_).build(), SmokeMeatRecipe.builder().input(Items.f_42581_).output(Items.f_42582_).build(), SmokeMeatRecipe.builder().input(Items.f_42658_).output(Items.f_42659_).build(), SmokeMeatRecipe.builder().input(Items.f_42697_).output(Items.f_42698_).build(), SmokeMeatRecipe.builder().input(Items.f_42526_).output(Items.f_42530_).build(), SmokeMeatRecipe.builder().input(Items.f_42527_).output(Items.f_42531_).build());
   }

   private static enum SmokeStage implements StageKey {
      SMOKE_MEAT,
      END;

      // $FF: synthetic method
      private static SmokeStage[] $values() {
         return new SmokeStage[]{SMOKE_MEAT, END};
      }
   }
}
