package dev.breezes.settlements.application.ai.behavior.usecases.villager.support;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.conditions.NearbyFriendlyNeedsPotionCondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.domain.world.location.Vector;
import dev.breezes.settlements.infrastructure.compat.PotionContents;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.level.Level;

public class ThrowPotionsBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ThrowPotionsBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)4.0F;
   private final NearbyFriendlyNeedsPotionCondition<BaseVillager> nearbyFriendlyNeedsPotionCondition;
   @Nullable
   private LivingEntity targetToThrow;
   @Nullable
   private ItemStack potionToThrow;
   @Nullable
   private Potion potionHolder;

   public ThrowPotionsBehavior(ThrowPotionsConfig config, BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.nearbyFriendlyNeedsPotionCondition = new NearbyFriendlyNeedsPotionCondition<BaseVillager>(config.minimumPlayerReputation());
      this.preconditions.add(this.nearbyFriendlyNeedsPotionCondition);
      this.targetToThrow = null;
      this.potionToThrow = null;
      this.potionHolder = null;
      this.initializeStateMachine(this.createControlStep(), ThrowPotionsBehavior.ThrowStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("ThrowPotionsBehavior").initialStage(ThrowPotionsBehavior.ThrowStage.THROW_POTION).stageStepMap(Map.of(ThrowPotionsBehavior.ThrowStage.THROW_POTION, this.createThrowStep())).nextStage(ThrowPotionsBehavior.ThrowStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   private BehaviorStep<BaseVillager> createThrowStep() {
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)4.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 3)).actionStep((ctx) -> {
         if (this.targetToThrow != null && this.potionToThrow != null) {
            BaseVillager villager = ((BaseVillager)ctx.getInitiator()).getMinecraftEntity();
            Location location = Location.fromEntity(villager, true);
            SoundRegistry.THROW_POTION.playGlobally(location, SoundSource.NEUTRAL);
            ThrownPotion potionEntity = new ThrownPotion(villager.m_9236_(), villager);
            potionEntity.m_37446_(this.potionToThrow);
            potionEntity.m_146926_(potionEntity.m_146909_() + 20.0F);
            Vector direction = villager.getLocation().getDirectionTo(Location.fromEntity(this.targetToThrow, true));
            potionEntity.m_6686_(direction.getX(), direction.getY(), direction.getZ(), 1.0F, 4.0F);
            villager.m_9236_().m_7967_(potionEntity);
            if (!GeneralConfig.bypassInventoryRequirements && this.potionHolder != null) {
               consumeMatchingSplashPotion(villager, this.potionHolder);
            }

            villager.clearHeldItem();
            this.rewardExperience(villager);
            BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.POTION_THROWN, (String)null);
            if (!(this.targetToThrow instanceof BaseVillager) && !(this.targetToThrow instanceof Villager)) {
               outcome.markSucceeded();
            } else {
               outcome.recordTargetedDeed(this.targetToThrow.m_20148_());
            }

            ctx.declarePrimaryDeed(outcome);
            return StepResult.complete();
         } else {
            return StepResult.fail("Target or potion is null");
         }
      }).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      double currentHpPercentage = Double.MAX_VALUE;
      Map<Entity, NearbyFriendlyNeedsPotionCondition.PotionType> friendlyNeedsPotionMap = this.nearbyFriendlyNeedsPotionCondition.findFriendlyNeedsPotionMap(villager);

      for(Entity entity : friendlyNeedsPotionMap.keySet()) {
         if (entity instanceof LivingEntity livingEntity) {
            double hp = (double)(livingEntity.m_21223_() / livingEntity.m_21233_());
            if (hp < currentHpPercentage) {
               this.targetToThrow = livingEntity;
               currentHpPercentage = hp;
            }
         }
      }

      if (this.targetToThrow == null) {
         log.behaviorStatus("No target found to throw potion at");
         this.requestStop("No target found to throw potion at");
      } else {
         Potion potionNeeded = ((NearbyFriendlyNeedsPotionCondition.PotionType)friendlyNeedsPotionMap.get(this.targetToThrow)).getPotion();
         Optional<ItemStack> foundPotion = findMatchingSplashPotionInInventory(villager, potionNeeded);
         if (GeneralConfig.bypassInventoryRequirements) {
            this.potionToThrow = (ItemStack)foundPotion.orElseGet(() -> PotionContents.createItemStack(Items.f_42736_, potionNeeded));
         } else {
            if (foundPotion.isEmpty()) {
               this.requestStop("No matching splash potion in inventory");
               return;
            }

            this.potionToThrow = ((ItemStack)foundPotion.get()).m_255036_(1);
         }

         this.potionHolder = potionNeeded;
         context.setState(BehaviorStateType.TARGET, TargetState.of(List.of(Targetable.fromEntity(this.targetToThrow))));
         villager.setHeldItem(this.potionToThrow);
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      return this.targetToThrow != null && this.targetToThrow.m_6084_();
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      this.targetToThrow = null;
      this.potionToThrow = null;
      this.potionHolder = null;
   }

   private static Optional<ItemStack> findMatchingSplashPotionInInventory(@Nonnull BaseVillager villager, @Nonnull Potion needed) {
      return villager.getSettlementsInventory().findFirst((stack) -> isMatchingSplashPotion(stack, needed));
   }

   private static void consumeMatchingSplashPotion(@Nonnull BaseVillager villager, @Nonnull Potion needed) {
      villager.getSettlementsInventory().findFirst((stack) -> isMatchingSplashPotion(stack, needed)).ifPresent((stack) -> villager.getSettlementsInventory().consume((ItemStack)stack, 1));
   }

   private static boolean isMatchingSplashPotion(@Nonnull ItemStack stack, @Nonnull Potion needed) {
      if (!stack.m_150930_(Items.f_42736_)) {
         return false;
      } else {
         Potion contents = PotionContents.getPotion(stack);
         return contents != null && contents == needed;
      }
   }

   private static enum ThrowStage implements StageKey {
      THROW_POTION,
      END;

      // $FF: synthetic method
      private static ThrowStage[] $values() {
         return new ThrowStage[]{THROW_POTION, END};
      }
   }
}
