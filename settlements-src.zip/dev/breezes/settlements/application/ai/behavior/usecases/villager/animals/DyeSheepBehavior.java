package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetQueries;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.behavior.model.BehaviorStatus;
import dev.breezes.settlements.domain.ai.conditions.PerceivedEntityExistsCondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.entities.Expertise;
import dev.breezes.settlements.domain.tags.EntityTag;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.compat.ColorParticleOption;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.Tags.Items;

public class DyeSheepBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(DyeSheepBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private static final int DEFAULT_DYE_LIMIT = 1;
   private static final double WHITE_WEIGHT = (double)50.0F;
   private static final double BLACK_WEIGHT = (double)10.0F;
   private static final double GRAY_WEIGHT = (double)10.0F;
   private static final double OTHER_COLOR_WEIGHT = 2.3076923076923075;
   private static final DyeColor WOLOLO_TRIGGER_COLOR;
   private static final DyeColor WOLOLO_RESULT_COLOR;
   private final DyeSheepConfig config;
   private final AtomicInteger dyeCount;
   private final Set<UUID> dyedSheepIds;
   @Nullable
   private DyeColor selectedDyeColor;
   private boolean shouldRewardExperience;

   public DyeSheepBehavior(@Nonnull DyeSheepConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.dyeCount = new AtomicInteger(0);
      this.dyedSheepIds = new HashSet();
      this.selectedDyeColor = null;
      this.shouldRewardExperience = false;
      this.preconditions.add(PerceivedEntityExistsCondition.builder().entityType(Sheep.class).filter(this::isEligibleSheep).completionRange(1).build());
      this.preconditions.add(support.getDemandSignalService().requireItem(new ItemMatch.TagRef(Items.DYES), 1, 50, this.getClass().getSimpleName()));
      this.initializeStateMachine(this.createControlStep(), DyeSheepBehavior.DyeStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("DyeSheepBehavior").initialStage(DyeSheepBehavior.DyeStage.DYE_SHEEP).stageStepMap(Map.of(DyeSheepBehavior.DyeStage.DYE_SHEEP, this.createDyeSheepStep())).nextStage(DyeSheepBehavior.DyeStage.END).onEnd((context) -> StepResult.noOp()).build();
   }

   private BehaviorStep<BaseVillager> createDyeSheepStep() {
      TimeBasedStep<BaseVillager> dyeStep = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.seconds((double)1.0F).asTickable()).onStart((context) -> {
         this.dyeCount.decrementAndGet();
         ((BaseVillager)context.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         this.setHeldDyePreview(context);
         this.getTargetSheep(context).ifPresent((sheep) -> {
            if (isWololoTrigger(sheep)) {
               Location location = Location.fromEntity((Entity)context.getInitiator(), true);
               SoundRegistry.WOLOLO.playGlobally(location, SoundSource.NEUTRAL);
            }

         });
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(12L), (context) -> {
         Optional<Sheep> sheepOptional = this.getTargetSheep(context);
         if (sheepOptional.isEmpty()) {
            return StepResult.complete();
         } else {
            if (this.dyeSheep(((BaseVillager)context.getInitiator()).getMinecraftEntity(), (Sheep)sheepOptional.get())) {
               context.primaryDeed().ifPresent((outcome) -> outcome.recordYield(1));
               this.shouldRewardExperience = true;
            }

            return StepResult.noOp();
         }
      }).onEnd((context) -> {
         ((BaseVillager)context.getInitiator()).clearHeldItem();
         if (this.dyeCount.get() > 0) {
            List<Targetable> nearbySheep = this.findEligibleSheepTargets(((BaseVillager)context.getInitiator()).getMinecraftEntity());
            if (!nearbySheep.isEmpty()) {
               context.setState(BehaviorStateType.TARGET, TargetState.of(nearbySheep));
               return StepResult.transition(DyeSheepBehavior.DyeStage.DYE_SHEEP);
            }
         }

         return StepResult.complete();
      }).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 1)).actionStep(dyeStep).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      Expertise expertise = ((BaseVillager)context.getInitiator()).getMinecraftEntity().getExpertise();
      int limit = (Integer)this.config.expertiseDyeLimit().getOrDefault(expertise.getConfigName(), 1);
      this.dyeCount.set(limit);
      this.dyedSheepIds.clear();
      this.selectedDyeColor = (DyeColor)this.chooseBehaviorDyeColor(villager).orElse((Object)null);
      this.shouldRewardExperience = false;
      log.behaviorStatus("Villager is '{}' level, maximum dye count is {}", expertise.toString(), limit);
      List<Targetable> targets = this.findEligibleSheepTargets(villager);
      if (targets.isEmpty()) {
         this.requestStop("No eligible sheep available");
      } else {
         context.setState(BehaviorStateType.TARGET, TargetState.of(targets));
         DyeColor headlineColor = this.selectedDyeColor != null ? this.selectedDyeColor : WOLOLO_RESULT_COLOR;
         context.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.SHEEP_DYED, "sheep", describeColor(headlineColor)));
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      if (this.shouldRewardExperience) {
         this.rewardExperience(villager);
      }

      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.dyedSheepIds.clear();
      this.selectedDyeColor = null;
      this.shouldRewardExperience = false;
   }

   private void setHeldDyePreview(@Nonnull BehaviorContext<BaseVillager> context) {
      Optional var10000 = this.getTargetSheep(context).flatMap((sheep) -> this.resolveDyeColor(((BaseVillager)context.getInitiator()).getMinecraftEntity(), sheep)).map(DyeItem::m_41082_).map(Item::m_7968_);
      BaseVillager var10001 = context.getInitiator();
      Objects.requireNonNull(var10001);
      var10000.ifPresent(var10001::setHeldItem);
   }

   private boolean dyeSheep(@Nonnull BaseVillager villager, @Nonnull Sheep sheep) {
      Optional<DyeColor> colorOptional = this.resolveDyeColor(villager, sheep);
      if (colorOptional.isEmpty()) {
         return false;
      } else {
         DyeColor color = (DyeColor)colorOptional.get();
         if (!isWololoTrigger(sheep) && !villager.getSettlementsInventory().consumeIfRequired(DyeItem.m_41082_(color), 1, GeneralConfig.bypassInventoryRequirements)) {
            return false;
         } else {
            sheep.m_29855_(color);
            this.emitDyeEffects(sheep, color);
            this.dyedSheepIds.add(sheep.m_20148_());
            return true;
         }
      }
   }

   private void emitDyeEffects(@Nonnull Sheep sheep, @Nonnull DyeColor color) {
      Location particleLocation = Location.fromEntity(sheep, false).add((double)0.0F, 0.8, (double)0.0F, true);
      ColorParticleOption dyeParticle = ColorParticleOption.create(ParticleTypes.f_123811_, color.m_41071_());
      particleLocation.displayParticles(dyeParticle, 8, 0.4, 0.4, 0.4, (double)0.0F);
      particleLocation.playSound(SoundEvents.f_12019_, 0.4F, 0.9F, SoundSource.NEUTRAL);
   }

   private Optional<Sheep> getTargetSheep(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      return TargetQueries.firstEntity(context, EntityType.f_20520_, Sheep.class).filter((sheep) -> this.isEligibleSheep(villager, sheep));
   }

   private List<Targetable> findEligibleSheepTargets(@Nonnull BaseVillager villager) {
      return this.findEligibleSheep(villager).stream().map(Targetable::fromEntity).toList();
   }

   private List<Sheep> findEligibleSheep(@Nonnull BaseVillager villager) {
      return this.getPerceivedEntities(villager).ofType(Sheep.class, (sheep) -> this.isEligibleSheep(villager, sheep) && villager.getNavigationManager().canReach(Location.fromEntity(sheep, false), (double)1.0F)).toList();
   }

   private boolean isEligibleSheep(@Nonnull BaseVillager villager, @Nonnull Sheep sheep) {
      return this.isUndyedVillageSheep(sheep) && !sheep.m_29875_() && (isWololoTrigger(sheep) || this.canDyeWithBehaviorColor(villager, sheep));
   }

   private boolean isUndyedVillageSheep(@Nonnull Sheep sheep) {
      return isVillageOwned(sheep) && !this.dyedSheepIds.contains(sheep.m_20148_());
   }

   private boolean canDyeWithBehaviorColor(@Nonnull BaseVillager villager, @Nonnull Sheep sheep) {
      if (this.selectedDyeColor != null) {
         return this.resolveDyeColor(villager, sheep).isPresent();
      } else {
         return this.status != BehaviorStatus.STOPPED ? false : this.canChooseDyeColorForSheep(villager, sheep);
      }
   }

   private Optional<DyeColor> resolveDyeColor(@Nonnull BaseVillager villager, @Nonnull Sheep sheep) {
      if (isWololoTrigger(sheep)) {
         return Optional.of(WOLOLO_RESULT_COLOR);
      } else if (this.selectedDyeColor != null && this.selectedDyeColor != sheep.m_29874_()) {
         return !villager.getSettlementsInventory().containsOrBypassed(DyeItem.m_41082_(this.selectedDyeColor), GeneralConfig.bypassInventoryRequirements) ? Optional.empty() : Optional.of(this.selectedDyeColor);
      } else {
         return Optional.empty();
      }
   }

   private Optional<DyeColor> chooseBehaviorDyeColor(@Nonnull BaseVillager villager) {
      Map<DyeColor, Double> weightedChoices = (Map)Arrays.stream(DyeColor.values()).filter((color) -> villager.getSettlementsInventory().containsOrBypassed(DyeItem.m_41082_(color), GeneralConfig.bypassInventoryRequirements)).filter((color) -> this.hasEligibleSheepForColor(villager, color)).collect(Collectors.toMap((color) -> color, DyeSheepBehavior::weightFor, (left, right) -> left, LinkedHashMap::new));
      return weightedChoices.isEmpty() ? Optional.empty() : Optional.of((DyeColor)RandomUtil.weightedChoice(weightedChoices));
   }

   private boolean canChooseDyeColorForSheep(@Nonnull BaseVillager villager, @Nonnull Sheep sheep) {
      return GeneralConfig.bypassInventoryRequirements ? true : villager.getSettlementsInventory().anyMatch((stack) -> {
         Item patt15888$temp = stack.m_41720_();
         boolean var10000;
         if (patt15888$temp instanceof DyeItem dye) {
            if (dye.m_41089_() != sheep.m_29874_()) {
               var10000 = true;
               return var10000;
            }
         }

         var10000 = false;
         return var10000;
      });
   }

   private boolean hasEligibleSheepForColor(@Nonnull BaseVillager villager, @Nonnull DyeColor color) {
      return this.getPerceivedEntities(villager).ofType(Sheep.class, (sheep) -> this.isUndyedVillageSheep(sheep) && !isWololoTrigger(sheep) && sheep.m_29874_() != color).findAny().isPresent();
   }

   private PerceivedEntities getPerceivedEntities(@Nonnull BaseVillager villager) {
      return (PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_SENSED_ENTITIES).orElse(PerceivedEntities.empty());
   }

   private static boolean isVillageOwned(@Nonnull Sheep sheep) {
      return sheep.m_19880_().contains(EntityTag.VILLAGE_OWNED_ANIMAL.getTag());
   }

   private static boolean isWololoTrigger(@Nonnull Sheep sheep) {
      return sheep.m_29874_() == WOLOLO_TRIGGER_COLOR;
   }

   private static String describeColor(@Nonnull DyeColor color) {
      return color.m_7912_().replace('_', ' ');
   }

   private static double weightFor(@Nonnull DyeColor color) {
      double var10000;
      switch (color) {
         case WHITE -> var10000 = (double)50.0F;
         case BLACK -> var10000 = (double)10.0F;
         case GRAY -> var10000 = (double)10.0F;
         default -> var10000 = 2.3076923076923075;
      }

      return var10000;
   }

   static {
      WOLOLO_TRIGGER_COLOR = DyeColor.RED;
      WOLOLO_RESULT_COLOR = DyeColor.BLUE;
   }

   private static enum DyeStage implements StageKey {
      DYE_SHEEP,
      END;

      // $FF: synthetic method
      private static DyeStage[] $values() {
         return new DyeStage[]{DYE_SHEEP, END};
      }
   }
}
