package dev.breezes.settlements.application.ai.behavior.usecases.villager.cartographer;

import dev.breezes.settlements.application.ai.brain.ActivityArbiter;
import dev.breezes.settlements.domain.time.ClockTicks;
import java.util.Optional;
import javax.annotation.Nonnull;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.raid.Raid;
import net.minecraft.world.entity.raid.Raider;
import net.minecraft.world.level.Level;

public final class RaidCharting {
   static final ClockTicks GLOW_DURATION = ClockTicks.seconds((double)60.0F);
   private static final ClockTicks RENEWAL_THRESHOLD = ClockTicks.seconds((double)10.0F);

   public static Optional<Raid> raidInWave(@Nonnull ServerLevel level, @Nonnull Entity cartographer) {
      Raid raid = level.m_8832_(cartographer.m_20183_());
      return ActivityArbiter.isRaidWaveLive(raid) ? Optional.of(raid) : Optional.empty();
   }

   public static boolean isChartable(@Nonnull Raider raider, @Nonnull Level level) {
      if (raider.m_6084_() && raider.m_9236_() == level && !raider.m_146886_()) {
         MobEffectInstance glow = raider.m_21124_(MobEffects.f_19619_);
         return glow == null || !glow.m_267577_() && (long)glow.m_19557_() < RENEWAL_THRESHOLD.getTicks();
      } else {
         return false;
      }
   }

   private RaidCharting() {
   }
}
