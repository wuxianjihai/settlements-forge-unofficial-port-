package dev.breezes.settlements.application.ai.behavior.usecases.villager.librarian;

import dev.breezes.settlements.bootstrap.registry.effects.MobEffectRegistry;
import dev.breezes.settlements.domain.tags.SettlementsEntityTypeTags;
import javax.annotation.Nonnull;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

public final class VexBinding {
   public static boolean isBindable(@Nonnull LivingEntity entity, @Nonnull Level level) {
      return entity.m_6084_() && entity.m_9236_() == level && entity.m_6095_().m_204039_(SettlementsEntityTypeTags.BINDABLE) && !entity.m_21023_((MobEffect)MobEffectRegistry.BOUND.get());
   }

   private VexBinding() {
   }
}
