package dev.breezes.settlements.application.ai.behavior.usecases.villager.librarian;

import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.config.annotations.BehaviorConfig;
import dev.breezes.settlements.infrastructure.config.annotations.ConfigurationType;
import dev.breezes.settlements.infrastructure.config.annotations.integers.IntegerConfig;
import org.apache.commons.lang3.Validate;

@BehaviorConfig(
   name = "bind_vexes",
   type = ConfigurationType.BEHAVIOR
)
public record BindVexesConfig(@IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "cadence_seconds",description = "Seconds a librarian waits after binding vexes before it binds again",defaultValue = 30,min = 1,max = 600) int cadenceSeconds, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "bind_duration_seconds",description = "Seconds a bound vex stays immobilized",defaultValue = 8,min = 1,max = 60) int bindDurationSeconds, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "channel_seconds",description = "Seconds the librarian channels the binding spell",defaultValue = 2,min = 1,max = 10) int channelSeconds, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "experience_reward",description = "Villager experience awarded when the behavior completes successfully",defaultValue = 1,min = 0) int experienceReward) {
   public BindVexesConfig {
      Validate.isTrue(bindDurationSeconds >= 1, "bind_duration_seconds must be at least 1", new Object[0]);
      Validate.isTrue(channelSeconds >= 1, "channel_seconds must be at least 1", new Object[0]);
   }

   public ClockTicks cadence() {
      return ClockTicks.seconds((double)this.cadenceSeconds);
   }

   public ClockTicks bindDuration() {
      return ClockTicks.seconds((double)this.bindDurationSeconds);
   }

   public ClockTicks channelDuration() {
      return ClockTicks.seconds((double)this.channelSeconds);
   }
}
