package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals.petting;

import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.infrastructure.minecraft.entities.pet.Pettable;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

public class NearbyPettableExistsCondition implements ICondition<BaseVillager> {
   private final int scanRangeHorizontal;
   private final int scanRangeVertical;
   private List<LivingEntity> targets;

   public NearbyPettableExistsCondition(int scanRangeHorizontal, int scanRangeVertical) {
      this.scanRangeHorizontal = scanRangeHorizontal;
      this.scanRangeVertical = scanRangeVertical;
      this.targets = Collections.emptyList();
   }

   public boolean test(@Nullable BaseVillager villager) {
      if (villager == null) {
         this.targets = Collections.emptyList();
         return false;
      } else {
         Optional<LivingEntity> nearest = this.findNearestPettable(villager);
         this.targets = (List)nearest.map(Collections::singletonList).orElse(Collections.emptyList());
         return nearest.isPresent();
      }
   }

   private Optional<LivingEntity> findNearestPettable(@Nonnull BaseVillager villager) {
      AABB scanBox = villager.m_20191_().m_82377_((double)this.scanRangeHorizontal, (double)this.scanRangeVertical, (double)this.scanRangeHorizontal);
      List<LivingEntity> candidates = villager.m_9236_().m_6443_(LivingEntity.class, scanBox, (entity) -> entity instanceof Pettable && entity.m_6084_() && !entity.m_213877_());
      return candidates.stream().min(Comparator.comparingDouble((candidate) -> candidate.m_20280_(villager)));
   }

   @Generated
   public List<LivingEntity> getTargets() {
      return this.targets;
   }
}
