package dev.breezes.settlements.application.ai.behavior.usecases.villager.farming;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.blocks.VisitedBlockSitesState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.items.ItemState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetQueries;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.AwardExperienceStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.LoopBackStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.OneShotStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.PickupItemsStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.WaitStep;
import dev.breezes.settlements.application.ai.targeting.BlockMemoryTargetResolver;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.domain.ai.conditions.KnownBlockSitesPrecondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.AabbBlockScan;
import dev.breezes.settlements.domain.world.blocks.BlockMatcher;
import dev.breezes.settlements.domain.world.blocks.BlockMatchers;
import dev.breezes.settlements.domain.world.blocks.BlockScanBox;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class HarvestSugarCaneBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(HarvestSugarCaneBehavior.class.getName());
   private static final ClockTicks SETTLE_DURATION = ClockTicks.seconds((double)1.0F);
   private static final int APPROACH_TIMEOUT_TICKS = ClockTicks.seconds((double)20.0F).getTicksAsInt();
   private final BlockMatcher sugarCaneMatcher;
   private final BlockScanBox confirmBox;
   private final int maxConfirms;
   private final HarvestSugarCaneConfig config;
   private final BlockMemoryTargetResolver targetResolver;

   public HarvestSugarCaneBehavior(@Nonnull HarvestSugarCaneConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.targetResolver = support.getBlockMemoryTargetResolver();
      this.sugarCaneMatcher = BlockMatchers.HARVESTABLE_SUGARCANE;
      this.confirmBox = BlockScanBox.confirm();
      this.maxConfirms = 8;
      this.preconditions.add(KnownBlockSitesPrecondition.builder().memoryType(MemoryTypeRegistry.HARVESTABLE_SUGARCANE_SITES).matcher(this.sugarCaneMatcher).confirmBox(this.confirmBox).maxSitesToConfirm(this.maxConfirms).completionRange(2).description("Known harvestable sugar cane sites").build());
      this.initializeStateMachine(this.createControlStep(), HarvestSugarCaneBehavior.Stage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      Map<StageKey, BehaviorStep<BaseVillager>> stageMap = new HashMap();
      stageMap.put(HarvestSugarCaneBehavior.Stage.PICK_TARGET, this.createPickTargetStep());
      stageMap.put(HarvestSugarCaneBehavior.Stage.APPROACH, StayCloseStep.builder().closeEnoughDistance((double)2.5F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.WALK).completionDistance(2).unreachableTransition(HarvestSugarCaneBehavior.Stage.PICK_TARGET).build()).actionStep(OneShotStep.builder().name("ArrivedAtSugarCane").action((ctx) -> StepResult.transition(HarvestSugarCaneBehavior.Stage.HARVEST)).build()).timeoutTicks(APPROACH_TIMEOUT_TICKS).timeoutTransition(HarvestSugarCaneBehavior.Stage.PICK_TARGET).build());
      stageMap.put(HarvestSugarCaneBehavior.Stage.HARVEST, this.createHarvestStep());
      stageMap.put(HarvestSugarCaneBehavior.Stage.SETTLE, WaitStep.builder().waitTime(SETTLE_DURATION.asTickable()).nextStage(HarvestSugarCaneBehavior.Stage.PICKUP).build());
      stageMap.put(HarvestSugarCaneBehavior.Stage.PICKUP, PickupItemsStep.builder().name("PickupSugarCaneDrops").nextStage(HarvestSugarCaneBehavior.Stage.LOOP).build());
      stageMap.put(HarvestSugarCaneBehavior.Stage.LOOP, LoopBackStep.builder().name("SugarCaneLoopBack").loopBackTo(HarvestSugarCaneBehavior.Stage.PICK_TARGET).completionTransition(HarvestSugarCaneBehavior.Stage.AWARD).maxIterationsResolver((ctx) -> 4 * ((BaseVillager)ctx.getInitiator()).getExpertise().getLevel()).build());
      stageMap.put(HarvestSugarCaneBehavior.Stage.AWARD, AwardExperienceStep.builder().name("AwardSugarCaneXp").experienceAmount(this.config.experienceReward()).nextStage(HarvestSugarCaneBehavior.Stage.END).build());
      return StagedStep.<BaseVillager>builder().name("HarvestSugarCaneBehavior").initialStage(HarvestSugarCaneBehavior.Stage.PICK_TARGET).stageStepMap(stageMap).nextStage(HarvestSugarCaneBehavior.Stage.END).build();
   }

   private BehaviorStep<BaseVillager> createPickTargetStep() {
      return OneShotStep.<BaseVillager>builder().name("PickSugarCaneTarget").action((ctx) -> {
         boolean resolved = this.targetResolver.resolveBlockTarget(ctx, MemoryTypeRegistry.HARVESTABLE_SUGARCANE_SITES, this.sugarCaneMatcher, this.confirmBox, this.maxConfirms, 2);
         if (!resolved) {
            log.behaviorStatus("No additional sugar cane targets found, ending behavior");
            return StepResult.transition(HarvestSugarCaneBehavior.Stage.AWARD);
         } else {
            return StepResult.transition(HarvestSugarCaneBehavior.Stage.APPROACH);
         }
      }).build();
   }

   private BehaviorStep<BaseVillager> createHarvestStep() {
      return TimeBasedStep.<BaseVillager>builder().name("HarvestSugarCane").withTickable(ClockTicks.of(12L).asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(5L), (ctx) -> {
         Optional<BlockPos> target = TargetQueries.firstBlockPos(ctx);
         if (target.isEmpty()) {
            return StepResult.noOp();
         } else {
            BaseVillager villager = (BaseVillager)ctx.getInitiator();
            Level world = villager.m_9236_();
            BlockPos pos = (BlockPos)target.get();
            BlockState state = world.m_8055_(pos);
            if (!(world instanceof ServerLevel)) {
               return StepResult.noOp();
            } else if (AabbBlockScan.findFirst(pos, BlockScanBox.self(), this.sugarCaneMatcher, world).isEmpty()) {
               return StepResult.noOp();
            } else {
               List<BlockPos> harvestedPositions = this.collectSugarCaneBlocksToHarvest(world, pos);
               if (harvestedPositions.isEmpty()) {
                  return StepResult.noOp();
               } else {
                  Location effectLocation = Location.of(pos, world).center(true).add((double)0.0F, (double)0.5F, (double)0.0F, true);
                  ParticleRegistry.harvestBlock(effectLocation, state);
                  effectLocation.playSound(SoundEvents.f_11988_, 0.8F, 1.0F, SoundSource.BLOCKS);
                  List<ItemStack> drops = this.createSugarCaneDropStacks(harvestedPositions.size());
                  List<ItemEntity> spawned = Location.of(pos, world).center(true).dropItems(drops, true);
                  spawned.forEach((itemEntity) -> itemEntity.m_32010_(ClockTicks.seconds((double)5.0F).getTicksAsInt()));
                  harvestedPositions.forEach((harvestedPos) -> world.m_7471_(harvestedPos, false));
                  ctx.getState(BehaviorStateType.VISITED_BLOCK_SITES, VisitedBlockSitesState.class).ifPresent((visitedSites) -> visitedSites.addSite(GlobalPos.m_122643_(world.m_46472_(), pos)));
                  ctx.setState(BehaviorStateType.ITEMS_TO_PICK_UP, ItemState.of(spawned));
                  ctx.primaryDeed().ifPresent((outcome) -> outcome.recordYield(harvestedPositions.size()));
                  return StepResult.noOp();
               }
            }
         }
      }).onEnd((ctx) -> StepResult.transition(HarvestSugarCaneBehavior.Stage.SETTLE)).build();
   }

   private List<BlockPos> collectSugarCaneBlocksToHarvest(@Nonnull Level world, @Nonnull BlockPos start) {
      List<BlockPos> positions = new ArrayList();
      BlockPos current = start;

      for(int scanned = 0; scanned < this.config.maxHarvestBlocks() && world.m_8055_(current).m_60713_(Blocks.f_50130_); ++scanned) {
         positions.add(current);
         current = current.m_7494_();
      }

      return positions;
   }

   private List<ItemStack> createSugarCaneDropStacks(int harvestedBlockCount) {
      List<ItemStack> drops = new ArrayList();
      int remaining = harvestedBlockCount;

      int stackSize;
      for(int maxStackSize = Items.f_41909_.m_7968_().m_41741_(); remaining > 0; remaining -= stackSize) {
         stackSize = Math.min(remaining, maxStackSize);
         drops.add(new ItemStack(Items.f_41909_, stackSize));
      }

      return drops;
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      context.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.RESOURCE_HARVESTED, "sugarcane"));
      context.setState(BehaviorStateType.VISITED_BLOCK_SITES, VisitedBlockSitesState.empty());
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.setMotion(AnimationArchetype.IDLE);
   }

   private static enum Stage implements StageKey {
      PICK_TARGET,
      APPROACH,
      HARVEST,
      SETTLE,
      PICKUP,
      LOOP,
      AWARD,
      END;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{PICK_TARGET, APPROACH, HARVEST, SETTLE, PICKUP, LOOP, AWARD, END};
      }
   }
}
