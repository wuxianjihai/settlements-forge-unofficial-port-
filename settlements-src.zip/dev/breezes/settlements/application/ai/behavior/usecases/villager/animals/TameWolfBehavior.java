package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetQueries;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetableType;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.conditions.PerceivedEntityExistsCondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.entities.Expertise;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.infrastructure.minecraft.entities.wolves.SettlementsWolf;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public class TameWolfBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(TameWolfBehavior.class.getName());
   private static final ResourceLocation BONE_ID = new ResourceLocation("minecraft", "bone");
   private static final double TAME_SUCCESS_CHANCE = 0.33;
   private static final int MAX_TAME_ATTEMPTS = 5;
   private final TameWolfConfig config;
   private int attemptsRemaining;
   private boolean shouldRewardExperience;

   public TameWolfBehavior(TameWolfConfig config, BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.attemptsRemaining = 0;
      this.shouldRewardExperience = false;
      this.preconditions.add(PerceivedEntityExistsCondition.builder().entityType(Wolf.class).filter((villager, wolf) -> !wolf.m_21824_()).completionRange(2).build());
      this.preconditions.add(support.getDemandSignalService().requireItem(new ItemMatch.ItemRef(BONE_ID), 1, 50, this.getClass().getSimpleName()));
      this.preconditions.add(ICondition.named("OwnershipBelowLimit", (villager) -> {
         Expertise expertise = villager.getExpertise();
         int limit = (Integer)this.config.expertiseWolfLimit().getOrDefault(expertise.getConfigName(), 1);
         int owned = villager.m_9236_().m_6443_(Wolf.class, villager.m_20191_().m_82377_((double)48.0F, (double)16.0F, (double)48.0F), (wolf) -> wolf.m_21824_() && ownerMatches(villager, wolf)).size();
         if (owned >= limit) {
            log.behaviorStatus("Owned wolves {} >= limit {}, aborting tame (precondition)", owned, limit);
            return false;
         } else {
            return true;
         }
      }));
      this.initializeStateMachine(this.createControlStep(), TameWolfBehavior.TameStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("TameWolfBehavior").initialStage(TameWolfBehavior.TameStage.TAME_WOLF).stageStepMap(Map.of(TameWolfBehavior.TameStage.TAME_WOLF, this.createTameWolfStep())).nextStage(TameWolfBehavior.TameStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   private BehaviorStep<BaseVillager> createTameWolfStep() {
      TimeBasedStep<BaseVillager> attemptStep = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.seconds((double)1.0F).asTickable()).onStart((ctx) -> {
         this.attemptsRemaining = Math.max(0, this.attemptsRemaining - 1);
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         ((BaseVillager)ctx.getInitiator()).setHeldItem(Items.f_42500_.m_7968_());
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(12L), (ctx) -> {
         Optional<Wolf> wolfOptional = this.getTargetWolf(ctx);
         if (wolfOptional.isEmpty()) {
            return StepResult.complete();
         } else {
            Wolf wolf = (Wolf)wolfOptional.get();
            if (wolf.m_21824_()) {
               return StepResult.complete();
            } else if (!((BaseVillager)ctx.getInitiator()).getMinecraftEntity().getSettlementsInventory().consumeIfRequired(Items.f_42500_, 1, GeneralConfig.bypassInventoryRequirements)) {
               return StepResult.complete();
            } else {
               log.behaviorStatus("Attempting to tame wolf {}", wolf.m_20148_());
               if (RandomUtil.chance(0.33)) {
                  Location wolfLoc = Location.fromEntity(wolf, false);
                  wolfLoc.displayParticles(ParticleTypes.f_123750_, 7, 0.4, (double)0.5F, 0.4, 0.01);
                  Location villagerHead = Location.fromEntity(((BaseVillager)ctx.getInitiator()).getMinecraftEntity(), true);
                  villagerHead.displayParticles(ParticleTypes.f_123748_, 8, 0.3, 0.2, 0.3, 0.01);
                  wolfLoc.playSound(SoundEvents.f_12617_, 0.6F, 1.5F, SoundSource.NEUTRAL);
                  wolfLoc.playSound(SoundEvents.f_12617_, 0.6F, 1.7F, SoundSource.NEUTRAL);
                  SettlementsWolf settlementsWolf;
                  if (wolf instanceof SettlementsWolf) {
                     SettlementsWolf alreadySettlementsWolf = (SettlementsWolf)wolf;
                     alreadySettlementsWolf.m_7105_(true);
                     alreadySettlementsWolf.m_21816_(((BaseVillager)ctx.getInitiator()).getMinecraftEntity().m_20148_());
                     alreadySettlementsWolf.applyCollarColor(DyeColor.LIME);
                     settlementsWolf = alreadySettlementsWolf;
                     log.behaviorStatus("Tamed existing SettlementsWolf {} in-place", alreadySettlementsWolf.m_20148_());
                  } else {
                     boolean wasBaby = wolf.m_6162_();
                     wolf.m_146870_();
                     settlementsWolf = SettlementsWolf.spawn(wolfLoc);
                     if (wasBaby) {
                        settlementsWolf.m_6863_(true);
                     }

                     settlementsWolf.m_7105_(true);
                     settlementsWolf.m_21816_(((BaseVillager)ctx.getInitiator()).getMinecraftEntity().m_20148_());
                     settlementsWolf.applyCollarColor(DyeColor.LIME);
                     log.behaviorStatus("Replaced vanilla Wolf with SettlementsWolf {}", settlementsWolf.m_20148_());
                  }

                  this.rememberOwnedWolf(((BaseVillager)ctx.getInitiator()).getMinecraftEntity(), settlementsWolf);
                  this.shouldRewardExperience = true;
                  BehaviorOutcome tameOutcome = BehaviorOutcome.forDeed(WorldEventType.ANIMAL_TAMED, (String)null);
                  tameOutcome.recordDeedDetail("a dog");
                  tameOutcome.putDetailField("animal", "dog");
                  ctx.declarePrimaryDeed(tameOutcome);
                  return StepResult.complete();
               } else {
                  Location wolfLoc = Location.fromEntity(wolf, false);
                  wolfLoc.displayParticles(ParticleTypes.f_123762_, 6, 0.35, (double)0.5F, 0.35, 0.01);
                  log.behaviorStatus("Failed to tame wolf");
                  return StepResult.noOp();
               }
            }
         }
      }).onEnd((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         if (this.attemptsRemaining > 0) {
            Optional<Wolf> target = this.getTargetWolf(ctx);
            if (target.isPresent() && ((Wolf)target.get()).m_6084_() && !((Wolf)target.get()).m_21824_()) {
               return StepResult.transition(TameWolfBehavior.TameStage.TAME_WOLF);
            }
         }

         return StepResult.complete();
      }).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.5F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 2)).actionStep(attemptStep).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      Expertise expertise = villager.getExpertise();
      int limit = (Integer)this.config.expertiseWolfLimit().getOrDefault(expertise.getConfigName(), 1);
      int owned = villager.m_9236_().m_6443_(Wolf.class, villager.m_20191_().m_82377_((double)48.0F, (double)16.0F, (double)48.0F), (wolf) -> wolf.m_21824_() && ownerMatches(villager, wolf)).size();
      if (owned >= limit) {
         log.behaviorStatus("Owned wolves {} >= limit {}, aborting tame", owned, limit);
         this.requestStop("Owned wolves greater than taming limit");
      } else {
         Optional<Wolf> chosenWolf = this.findClosestReachableUntamedWolf(villager);
         if (chosenWolf.isEmpty()) {
            this.requestStop("No reachable untamed wolves found");
         } else {
            context.setState(BehaviorStateType.TARGET, TargetState.of(List.of(Targetable.fromEntity((Entity)chosenWolf.get()))));
            int bonesAvailable = villager.getSettlementsInventory().count(Items.f_42500_);
            this.attemptsRemaining = GeneralConfig.bypassInventoryRequirements ? 5 : Math.min(5, bonesAvailable);
            if (this.attemptsRemaining <= 0) {
               this.requestStop("No bones available at behavior start");
            } else {
               this.shouldRewardExperience = false;
            }
         }
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      if (this.shouldRewardExperience) {
         this.rewardExperience(villager);
      }

      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.shouldRewardExperience = false;
   }

   private Optional<Wolf> getTargetWolf(@Nonnull BehaviorContext<BaseVillager> context) {
      return TargetQueries.firstMatching(context, (target) -> target != null && target.getType() == TargetableType.ENTITY && target.getAsEntity() instanceof Wolf).map((target) -> (Wolf)target.getAsEntity());
   }

   private Optional<Wolf> findClosestReachableUntamedWolf(@Nonnull BaseVillager villager) {
      return ((PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_SENSED_ENTITIES).orElse(PerceivedEntities.empty())).<Wolf>closest(Wolf.class, (wolf) -> !wolf.m_21824_() && villager.getNavigationManager().canReach(Location.fromEntity(wolf, false), (double)2.0F), villager);
   }

   private static boolean ownerMatches(@Nonnull BaseVillager villager, @Nonnull Wolf wolf) {
      try {
         return villager.m_20148_().equals(wolf.m_21805_());
      } catch (Throwable var3) {
         return wolf.m_269323_() != null && wolf.m_269323_().m_20148_().equals(villager.m_20148_());
      }
   }

   private void rememberOwnedWolf(@Nonnull BaseVillager villager, @Nonnull SettlementsWolf wolf) {
      List<UUID> ownedWolfIds = (List)villager.m_6274_().m_21952_(MemoryTypeRegistry.OWNED_WOLVES.getModuleType()).orElse(List.of());
      log.behaviorStatus("Remembering tamed wolf {}", wolf.m_20148_());
      List<UUID> updatedOwnedWolfIds = new ArrayList(ownedWolfIds);
      updatedOwnedWolfIds.add(wolf.m_20148_());
      villager.m_6274_().m_21879_(MemoryTypeRegistry.OWNED_WOLVES.getModuleType(), List.copyOf(updatedOwnedWolfIds));
   }

   private static enum TameStage implements StageKey {
      TAME_WOLF,
      END;

      // $FF: synthetic method
      private static TameStage[] $values() {
         return new TameStage[]{TAME_WOLF, END};
      }
   }
}
