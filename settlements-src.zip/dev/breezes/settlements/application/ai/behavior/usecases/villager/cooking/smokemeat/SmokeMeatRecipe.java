package dev.breezes.settlements.application.ai.behavior.usecases.villager.cooking.smokemeat;

import lombok.Generated;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class SmokeMeatRecipe {
   private final Item input;
   private final Item output;
   private final int inputCount;
   private final int outputCount;

   public ItemStack createInputStack() {
      return new ItemStack(this.input, this.inputCount);
   }

   public ItemStack createOutputStack() {
      return new ItemStack(this.output, this.outputCount);
   }

   @Generated
   private static int $default$inputCount() {
      return 1;
   }

   @Generated
   private static int $default$outputCount() {
      return 1;
   }

   @Generated
   SmokeMeatRecipe(Item input, Item output, int inputCount, int outputCount) {
      this.input = input;
      this.output = output;
      this.inputCount = inputCount;
      this.outputCount = outputCount;
   }

   @Generated
   public static SmokeMeatRecipeBuilder builder() {
      return new SmokeMeatRecipeBuilder();
   }

   @Generated
   public Item getInput() {
      return this.input;
   }

   @Generated
   public Item getOutput() {
      return this.output;
   }

   @Generated
   public int getInputCount() {
      return this.inputCount;
   }

   @Generated
   public int getOutputCount() {
      return this.outputCount;
   }

   @Generated
   public static class SmokeMeatRecipeBuilder {
      @Generated
      private Item input;
      @Generated
      private Item output;
      @Generated
      private boolean inputCount$set;
      @Generated
      private int inputCount$value;
      @Generated
      private boolean outputCount$set;
      @Generated
      private int outputCount$value;

      @Generated
      SmokeMeatRecipeBuilder() {
      }

      @Generated
      public SmokeMeatRecipeBuilder input(Item input) {
         this.input = input;
         return this;
      }

      @Generated
      public SmokeMeatRecipeBuilder output(Item output) {
         this.output = output;
         return this;
      }

      @Generated
      public SmokeMeatRecipeBuilder inputCount(int inputCount) {
         this.inputCount$value = inputCount;
         this.inputCount$set = true;
         return this;
      }

      @Generated
      public SmokeMeatRecipeBuilder outputCount(int outputCount) {
         this.outputCount$value = outputCount;
         this.outputCount$set = true;
         return this;
      }

      @Generated
      public SmokeMeatRecipe build() {
         int inputCount$value = this.inputCount$value;
         if (!this.inputCount$set) {
            inputCount$value = SmokeMeatRecipe.$default$inputCount();
         }

         int outputCount$value = this.outputCount$value;
         if (!this.outputCount$set) {
            outputCount$value = SmokeMeatRecipe.$default$outputCount();
         }

         return new SmokeMeatRecipe(this.input, this.output, inputCount$value, outputCount$value);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.input);
         return "SmokeMeatRecipe.SmokeMeatRecipeBuilder(input=" + var10000 + ", output=" + String.valueOf(this.output) + ", inputCount$value=" + this.inputCount$value + ", outputCount$value=" + this.outputCount$value + ")";
      }
   }
}
