package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals.washing;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.infrastructure.minecraft.entities.wolves.SettlementsWolf;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.Map;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public class WashWolfBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(WashWolfBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.5F;
   private static final int NAVIGATION_COMPLETION_DISTANCE = 2;
   private static final ClockTicks WASH_DURATION = ClockTicks.seconds((double)5.0F);
   private static final ClockTicks DRY_DURATION = ClockTicks.seconds((double)1.0F);
   private static final int WASH_EFFECT_INTERVAL_TICKS = 5;
   private static final int INTERACT_RETRIGGER_INTERVAL_TICKS = 20;
   private final WashWolfConfig config;
   private final OwnedDirtyWolfExistsCondition ownedDirtyWolfExistsCondition;
   private SettlementsWolf targetWolf;

   public WashWolfBehavior(@Nonnull WashWolfConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.config = config;
      this.ownedDirtyWolfExistsCondition = new OwnedDirtyWolfExistsCondition(config.scanRangeHorizontal(), config.scanRangeVertical());
      this.targetWolf = null;
      this.preconditions.add(this.ownedDirtyWolfExistsCondition);
      this.initializeStateMachine(this.createControlStep(), WashWolfBehavior.WashStage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("WashWolfBehavior").initialStage(WashWolfBehavior.WashStage.WASH_WOLF).stageStepMap(Map.of(WashWolfBehavior.WashStage.WASH_WOLF, this.createWashWolfStep(), WashWolfBehavior.WashStage.DRY_WOLF, this.createDryWolfStep())).nextStage(WashWolfBehavior.WashStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   private BehaviorStep<BaseVillager> createWashWolfStep() {
      TimeBasedStep<BaseVillager> washStep = TimeBasedStep.<BaseVillager>builder().withTickable(WASH_DURATION.asTickable()).onStart((context) -> {
         ((BaseVillager)context.getInitiator()).setHeldItem(Items.f_42447_.m_7968_());
         return StepResult.noOp();
      }).addPeriodicStep(5, this::playWashEffects).addPeriodicStep(20, (context) -> {
         ((BaseVillager)context.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).onEnd((context) -> StepResult.transition(WashWolfBehavior.WashStage.DRY_WOLF)).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.5F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 2)).actionStep(washStep).build();
   }

   private BehaviorStep<BaseVillager> createDryWolfStep() {
      TimeBasedStep<BaseVillager> dryStep = TimeBasedStep.<BaseVillager>builder().withTickable(DRY_DURATION.asTickable()).onStart((context) -> {
         ((BaseVillager)context.getInitiator()).setHeldItem(Items.f_41902_.m_7968_());
         ((BaseVillager)context.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).onEnd(this::completeWash).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.5F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 2)).actionStep(dryStep).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      this.targetWolf = null;
      if (!this.ownedDirtyWolfExistsCondition.test(villager)) {
         this.requestStop("No owned dirty wolves found within range");
      } else {
         this.targetWolf = (SettlementsWolf)this.ownedDirtyWolfExistsCondition.getTargets().stream().findFirst().orElse((Object)null);
         if (this.targetWolf == null) {
            this.requestStop("Chosen dirty wolf is null");
         } else {
            context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.targetWolf)));
            this.targetWolf.m_21839_(false);
         }
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      villager.getNavigationManager().stop();
      this.targetWolf = null;
   }

   private StepResult playWashEffects(@Nonnull BehaviorContext<BaseVillager> context) {
      if (this.targetWolf != null && this.targetWolf.m_6084_()) {
         Location wolfLocation = Location.fromEntity(this.targetWolf, false);
         wolfLocation.displayParticles(ParticleTypes.f_123769_, 8, 0.35, (double)0.5F, 0.35, 0.02);
         wolfLocation.playSound(SoundEvents.f_11917_, 0.35F, 1.2F, SoundSource.NEUTRAL);
         this.targetWolf.f_30363_ = true;
         return StepResult.noOp();
      } else {
         return StepResult.complete();
      }
   }

   private StepResult completeWash(@Nonnull BehaviorContext<BaseVillager> context) {
      if (this.targetWolf != null && this.targetWolf.m_6084_()) {
         Location wolfLocation = Location.fromEntity(this.targetWolf, false);
         wolfLocation.displayParticles(ParticleTypes.f_123796_, 10, 0.4, (double)0.5F, 0.4, 0.02);
         wolfLocation.playSound(SoundEvents.f_11937_, 0.45F, 1.4F, SoundSource.NEUTRAL);
         this.targetWolf.setDirty(false);
         BehaviorOutcome washOutcome = BehaviorOutcome.forDeed(WorldEventType.WOLF_WASHED, (String)null);
         washOutcome.markSucceeded();
         context.declarePrimaryDeed(washOutcome);
         return StepResult.complete();
      } else {
         return StepResult.complete();
      }
   }

   private static enum WashStage implements StageKey {
      WASH_WOLF,
      DRY_WOLF,
      END;

      // $FF: synthetic method
      private static WashStage[] $values() {
         return new WashStage[]{WASH_WOLF, DRY_WOLF, END};
      }
   }
}
