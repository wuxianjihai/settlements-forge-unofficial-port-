package dev.breezes.settlements.application.ai.behavior.usecases.villager.logistics;

import dev.breezes.settlements.application.economy.demand.ActiveDemand;
import dev.breezes.settlements.application.economy.demand.DemandEvaluator;
import dev.breezes.settlements.application.economy.supply.ActiveSupply;
import dev.breezes.settlements.application.economy.supply.SupplyEvaluator;
import dev.breezes.settlements.domain.ai.conditions.IEntityCondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.economy.catalog.ItemMatches;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.compat.Capabilities;
import dev.breezes.settlements.infrastructure.minecraft.chest.ChestWaxService;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemHandlerHelper;

public class ChestInteractionCondition implements IEntityCondition<BaseVillager> {
   private final DemandEvaluator demandEvaluator;
   private final SupplyEvaluator supplyEvaluator;
   private final int completionRange;
   private List<BlockPos> reachableChests;

   public ChestInteractionCondition(@Nonnull DemandEvaluator demandEvaluator, @Nonnull SupplyEvaluator supplyEvaluator, int completionRange) {
      if (completionRange < 1) {
         throw new IllegalArgumentException("Completion range must be at least 1");
      } else {
         this.demandEvaluator = demandEvaluator;
         this.supplyEvaluator = supplyEvaluator;
         this.completionRange = completionRange;
         this.reachableChests = List.of();
      }
   }

   public boolean test(@Nullable BaseVillager villager) {
      this.reachableChests = List.of();
      if (villager == null) {
         return false;
      } else {
         List<ActiveDemand> demands = this.demandEvaluator.resolve(villager);
         List<ActiveSupply> supplies = this.supplyEvaluator.resolve(villager);
         if (demands.isEmpty() && supplies.isEmpty()) {
            return false;
         } else {
            Level level = villager.m_9236_();
            List<GlobalPos> chests = ((List)villager.m_6274_().m_21952_(MemoryTypeRegistry.VILLAGE_CHESTS.getModuleType()).orElse(List.of())).stream().filter((chest) -> chest.m_122640_().equals(level.m_46472_())).sorted(Comparator.comparingDouble((chest) -> chest.m_122646_().m_123331_(villager.m_20183_()))).toList();
            if (chests.isEmpty()) {
               return false;
            } else {
               List<BlockPos> reachable = new ArrayList();

               for(GlobalPos chestPos : chests) {
                  BlockPos pos = chestPos.m_122646_();
                  if (!ChestWaxService.isWaxed(level, pos) && villager.getNavigationManager().canReach(Location.of(pos, level), (double)this.completionRange)) {
                     IItemHandler handler = Capabilities.ItemHandler.getLevelCapability(level, pos, (Direction)null);
                     if (handler != null && chestHasWork(handler, demands, supplies)) {
                        reachable.add(pos);
                     }
                  }
               }

               this.reachableChests = reachable;
               return !reachable.isEmpty();
            }
         }
      }
   }

   public static boolean chestHasWork(@Nonnull IItemHandler handler, @Nonnull List<ActiveDemand> demands, @Nonnull List<ActiveSupply> supplies) {
      for(ActiveDemand demand : demands) {
         if (findMatchingSlot(handler, demand.match()) >= 0) {
            return true;
         }
      }

      for(ActiveSupply supply : supplies) {
         int targetCount = computeDepositTargetCount(supply);
         if (targetCount > 0 && simulateAcceptedCount(handler, supply.representative().m_255036_(targetCount)) > 0) {
            return true;
         }
      }

      return false;
   }

   private static int findMatchingSlot(@Nonnull IItemHandler handler, @Nonnull ItemMatch match) {
      int size = handler.getSlots();

      for(int i = 0; i < size; ++i) {
         ItemStack stack = handler.getStackInSlot(i);
         if (ItemMatches.test(match, stack)) {
            return i;
         }
      }

      return -1;
   }

   public static int computeDepositTargetCount(@Nonnull ActiveSupply supply) {
      return Math.min(supply.dumpableCount(), supply.representative().m_41741_());
   }

   public static int simulateAcceptedCount(@Nonnull IItemHandler handler, @Nonnull ItemStack stack) {
      if (stack.m_41619_()) {
         return 0;
      } else {
         ItemStack remainder = ItemHandlerHelper.insertItemStacked(handler, stack.m_41777_(), true);
         return stack.m_41613_() - remainder.m_41613_();
      }
   }

   @Generated
   public List<BlockPos> getReachableChests() {
      return this.reachableChests;
   }
}
