package dev.breezes.settlements.application.ai.behavior.usecases.villager.trading;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.ai.trading.CloseReason;
import dev.breezes.settlements.application.ai.trading.NegotiationEngine;
import dev.breezes.settlements.application.ai.trading.TradeExecutor;
import dev.breezes.settlements.application.ai.trading.TradeSession;
import dev.breezes.settlements.application.ai.trading.TradeSessionPhase;
import dev.breezes.settlements.application.ai.trading.TradeSessionRegistry;
import dev.breezes.settlements.application.ai.trading.TradingConfig;
import dev.breezes.settlements.application.economy.VillagerWallet;
import dev.breezes.settlements.application.economy.catalog.TradePriceResolver;
import dev.breezes.settlements.application.economy.demand.ActiveDemand;
import dev.breezes.settlements.application.economy.demand.DemandEvaluator;
import dev.breezes.settlements.application.economy.demand.DemandSignalService;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.EventOutcome;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventEmitter;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.economy.catalog.TradeCatalogRegistry;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.RandomRangeTickable;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.behavior.EntityTracker;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.level.Level;

public final class TradeInitiateBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(TradeInitiateBehavior.class.getName());
   private static final int DEAL_PRICE_EPSILON = 1;
   private static final double APPROACH_DISTANCE_SQUARED = (double)9.0F;
   private static final double TRADE_CLOSE_ENOUGH_DISTANCE = (double)3.0F;
   private final TradingConfig config;
   private final TradeSessionRegistry sessionRegistry;
   private final TradeCatalogRegistry tradeCatalogRegistry;
   private final TradePriceResolver tradePriceResolver;
   private final DemandSignalService demandSignalService;
   private final VillagerWallet villagerWallet;
   private final TradeExecutor tradeExecutor;
   private final TradeSessionPresenter tradeSessionPresenter;
   private final DemandEvaluator demandEvaluator;
   private final PartnerScanner partnerScanner;
   private final NegotiationEngine negotiationEngine;
   private final WorldEventEmitter worldEventEmitter;
   @Nullable
   private PartnerScanner.TradeCandidate pendingCandidate;
   @Nullable
   private ActiveDemand activeDemand;
   @Nullable
   private UUID activeSessionId;
   private boolean tradeExecuted;

   public TradeInitiateBehavior(@Nonnull TradingConfig config, @Nonnull BehaviorSupport support, @Nonnull TradeSessionRegistry sessionRegistry, @Nonnull TradeCatalogRegistry tradeCatalogRegistry, @Nonnull TradePriceResolver tradePriceResolver, @Nonnull VillagerWallet villagerWallet, @Nonnull TradeExecutor tradeExecutor, @Nonnull TradeSessionPresenter tradeSessionPresenter, @Nonnull PartnerScanner partnerScanner, @Nonnull NegotiationEngine negotiationEngine) {
      super(log, ClockTicks.seconds((double)config.initiatePreconditionCooldownSeconds()).asTickable(), RandomRangeTickable.of(ClockTicks.seconds((double)config.initiateBehaviorCooldownSecondsMax()), ClockTicks.seconds((double)config.initiateBehaviorCooldownSecondsMin())), support);
      this.config = config;
      this.sessionRegistry = sessionRegistry;
      this.tradeCatalogRegistry = tradeCatalogRegistry;
      this.tradePriceResolver = tradePriceResolver;
      this.demandSignalService = support.getDemandSignalService();
      this.villagerWallet = villagerWallet;
      this.tradeExecutor = tradeExecutor;
      this.tradeSessionPresenter = tradeSessionPresenter;
      this.demandEvaluator = support.getDemandEvaluator();
      this.partnerScanner = partnerScanner;
      this.negotiationEngine = negotiationEngine;
      this.worldEventEmitter = support.getWorldEventEmitter();
      this.preconditions.add(this.canInitiateTrade());
      this.initializeStateMachine(this.createControlStep(), TradeInitiateBehavior.Stage.CLOSED);
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      context.declarePrimaryDeed(BehaviorOutcome.silent());
      this.activeDemand = null;
      this.activeSessionId = null;
      this.tradeExecuted = false;
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      this.sessionRegistry.getActiveSession(villager.m_20148_()).ifPresent((session) -> {
         TradeSessionPhase phase = session.getPhase();
         if (phase != TradeSessionPhase.DEAL && phase != TradeSessionPhase.WALK_AWAY) {
            log.warn("Closing trade session after external interruption: sessionId={}, phase={}", session.getSessionId(), phase);
            this.sessionRegistry.closeSession(session.getSessionId(), CloseReason.EXTERNAL_CANCEL);
         }

      });
      this.pendingCandidate = null;
      this.activeDemand = null;
      this.activeSessionId = null;
      this.tradeExecuted = false;
   }

   private ICondition<BaseVillager> canInitiateTrade() {
      return ICondition.<BaseVillager>named("can initiate villager trade", (villager) -> {
         this.pendingCandidate = null;
         if (this.sessionRegistry.getActiveSession(villager.m_20148_()).isPresent()) {
            log.behaviorTrace("Trade initiation blocked: villager {} already has an active session", villager.m_20148_());
            return false;
         } else if (this.villagerWallet.getBalance(villager) <= 0) {
            log.behaviorTrace("Trade initiation blocked: villager {} has no emerald balance", villager.m_20148_());
            return false;
         } else {
            List<ActiveDemand> activeDemands = this.demandEvaluator.resolve(villager);
            if (activeDemands.isEmpty()) {
               log.behaviorTrace("Trade initiation blocked: villager {} has no active demands", villager.m_20148_());
               return false;
            } else {
               log.behaviorTrace("Trade initiation evaluating {} active demands for villager {}: {}", activeDemands.size(), villager.m_20148_(), activeDemands.stream().map((demand) -> demand.match().asDebugString()).toList());
               this.pendingCandidate = (PartnerScanner.TradeCandidate)this.partnerScanner.findPartner(villager, activeDemands).orElse((Object)null);
               if (this.pendingCandidate == null) {
                  log.behaviorTrace("Trade initiation blocked: villager {} found no partner candidate", villager.m_20148_());
                  return false;
               } else {
                  log.behaviorStatus("Trade initiation selected partner {} for villager {} with item {}", this.pendingCandidate.partner().m_20148_(), villager.m_20148_(), this.pendingCandidate.matchedItem());
                  return true;
               }
            }
         }
      });
   }

   private StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("TradeInitiateBehavior").initialStage(TradeInitiateBehavior.Stage.SCAN_AND_INVITE).stageStepMap(Map.of(TradeInitiateBehavior.Stage.SCAN_AND_INVITE, this::scanAndInvite, TradeInitiateBehavior.Stage.WAIT_FOR_ACCEPT, this::waitForAccept, TradeInitiateBehavior.Stage.APPROACH, this::approach, TradeInitiateBehavior.Stage.OPENING_OFFER, this::openingOffer, TradeInitiateBehavior.Stage.NEGOTIATE, StayCloseStep.builder().closeEnoughDistance((double)3.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 2)).actionStep(this::negotiate).build(), TradeInitiateBehavior.Stage.DEAL, this::deal, TradeInitiateBehavior.Stage.WALK_AWAY, this::walkAway)).nextStage(TradeInitiateBehavior.Stage.CLOSED).build();
   }

   private StepResult scanAndInvite(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager buyer = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      if (this.pendingCandidate == null) {
         return StepResult.complete();
      } else {
         this.activeDemand = this.pendingCandidate.activeDemand();
         int priceJitter = this.pendingCandidate.offerEntry().priceJitter();
         long currentGameTime = buyer.m_9236_().m_46467_();
         TradeSession session = this.sessionRegistry.sendInvite(buyer, this.pendingCandidate.partner(), buyer.m_20148_(), this.pendingCandidate.partner().m_20148_(), this.pendingCandidate.matchedItem(), this.pendingCandidate.offerEntry().bundleSize(), priceJitter, this.pendingCandidate.buyerOffer(), this.pendingCandidate.sellerAsk(), this.config.maxNegotiationRounds(), currentGameTime);
         this.pendingCandidate = null;
         this.activeSessionId = session.getSessionId();
         this.worldEventEmitter.emitTradeInviteSent(buyer, session.getResponderId(), session.getSessionId());
         return StepResult.transition(TradeInitiateBehavior.Stage.WAIT_FOR_ACCEPT);
      }
   }

   private StepResult waitForAccept(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager buyer = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      Optional<TradeSession> session = this.currentSession(buyer);
      if (session.isEmpty()) {
         return StepResult.complete();
      } else if (((TradeSession)session.get()).getPhase() != TradeSessionPhase.ESTABLISHED) {
         return StepResult.noOp();
      } else {
         ((TradeSession)session.get()).transitionTo(TradeSessionPhase.APPROACH, buyer.m_9236_().m_46467_());
         return StepResult.transition(TradeInitiateBehavior.Stage.APPROACH);
      }
   }

   private StepResult approach(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager buyer = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      TradeSession session = (TradeSession)this.currentSession(buyer).orElse((Object)null);
      if (session == null) {
         return StepResult.fail("Trade failed due to missing session");
      } else {
         BaseVillager seller = (BaseVillager)this.resolveParticipant(buyer.m_9236_(), session.getSellerId()).orElse((Object)null);
         if (seller == null) {
            this.sessionRegistry.closeSession(session.getSessionId(), CloseReason.EXTERNAL_CANCEL);
            return StepResult.fail("Trade failed due to missing seller");
         } else {
            context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(seller)));
            buyer.getNavigationManager().stop();
            session.transitionTo(TradeSessionPhase.OPENING_OFFER, buyer.m_9236_().m_46467_());
            this.tradeSessionPresenter.presentOpeningOffer(session, buyer);
            return StepResult.transition(TradeInitiateBehavior.Stage.OPENING_OFFER);
         }
      }
   }

   private StepResult openingOffer(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager buyer = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      TradeSession session = (TradeSession)this.currentSession(buyer).orElse((Object)null);
      if (session == null) {
         return StepResult.complete();
      } else if (!this.phaseElapsed(session, buyer.m_9236_().m_46467_(), this.config.openingOfferDuration().getTicksAsInt())) {
         return StepResult.noOp();
      } else if (this.hasDeal(session)) {
         return this.enterDeal(buyer, session);
      } else {
         session.transitionTo(TradeSessionPhase.NEGOTIATING, buyer.m_9236_().m_46467_());
         return StepResult.transition(TradeInitiateBehavior.Stage.NEGOTIATE);
      }
   }

   private StepResult negotiate(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager buyer = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      TradeSession session = (TradeSession)this.currentSession(buyer).orElse((Object)null);
      if (session == null) {
         return StepResult.complete();
      } else {
         BaseVillager seller = (BaseVillager)this.resolveParticipant(buyer.m_9236_(), session.getSellerId()).orElse((Object)null);
         if (seller == null) {
            this.sessionRegistry.closeSession(session.getSessionId(), CloseReason.EXTERNAL_CANCEL);
            return StepResult.fail("seller-disappeared-during-negotiation");
         } else {
            this.lockMutualAttention(buyer, seller);
            if (!this.phaseElapsed(session, buyer.m_9236_().m_46467_(), this.config.negotiationRoundDuration().getTicksAsInt())) {
               return StepResult.noOp();
            } else if (this.hasDeal(session)) {
               return this.enterDeal(buyer, session);
            } else if (session.getNegotiationRoundsRemaining() <= 0) {
               session.transitionTo(TradeSessionPhase.WALK_AWAY, buyer.m_9236_().m_46467_());
               this.presentWalkAwayToBoth(session, buyer, seller);
               return StepResult.transition(TradeInitiateBehavior.Stage.WALK_AWAY);
            } else if (session.getBuyerOffer() >= session.getSellerAsk()) {
               return this.enterDeal(buyer, session);
            } else {
               NegotiationEngine.NegotiationRoundResult result = this.negotiationEngine.advanceRound(session.getBuyerOffer(), session.getSellerAsk(), session.getPriceJitter());
               session.setBuyerOffer(result.buyerOffer());
               session.setSellerAsk(result.sellerAsk());
               session.setNegotiationRoundsRemaining(session.getNegotiationRoundsRemaining() - 1);
               session.transitionTo(TradeSessionPhase.NEGOTIATING, buyer.m_9236_().m_46467_());
               this.tradeSessionPresenter.presentNegotiationUpdate(session, buyer);
               return this.hasDeal(session) ? this.enterDeal(buyer, session) : StepResult.noOp();
            }
         }
      }
   }

   private StepResult deal(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager buyer = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      TradeSession session = (TradeSession)this.currentSession(buyer).orElse((Object)null);
      if (session == null) {
         return StepResult.complete();
      } else if (!this.phaseElapsed(session, buyer.m_9236_().m_46467_(), this.config.dealDuration().getTicksAsInt())) {
         return StepResult.noOp();
      } else {
         this.sessionRegistry.closeSession(session.getSessionId(), CloseReason.DEAL);
         BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.TRADE_COMPLETED, (String)null);
         outcome.recordSocialOutcome(session.getResponderId(), session.getSessionId(), EventOutcome.SUCCESS, buildTradeDetail(session), (String)null);
         recordTradeDetailFields(outcome, session);
         context.declarePrimaryDeed(outcome);
         return StepResult.complete();
      }
   }

   private StepResult walkAway(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager buyer = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      TradeSession session = (TradeSession)this.currentSession(buyer).orElse((Object)null);
      if (session == null) {
         return StepResult.complete();
      } else if (!this.phaseElapsed(session, buyer.m_9236_().m_46467_(), this.config.walkawayDuration().getTicksAsInt())) {
         return StepResult.noOp();
      } else {
         this.sessionRegistry.closeSession(session.getSessionId(), CloseReason.WALK_AWAY);
         BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.TRADE_COMPLETED, (String)null);
         outcome.recordSocialOutcome(session.getResponderId(), session.getSessionId(), EventOutcome.FAILURE, (String)null, "negotiations fell through");
         context.declarePrimaryDeed(outcome);
         return StepResult.complete();
      }
   }

   private StepResult enterDeal(@Nonnull BaseVillager buyer, @Nonnull TradeSession session) {
      BaseVillager seller = (BaseVillager)this.resolveParticipant(buyer.m_9236_(), session.getSellerId()).orElse((Object)null);
      if (seller == null) {
         this.sessionRegistry.closeSession(session.getSessionId(), CloseReason.EXTERNAL_CANCEL);
         return StepResult.fail("seller-disappeared-before-deal");
      } else {
         if (!this.tradeExecuted) {
            if (!this.villagerWallet.canAfford(buyer, session.getBuyerOffer())) {
               log.behaviorStatus("Buyer cannot afford this deal, walking away");
               session.transitionTo(TradeSessionPhase.WALK_AWAY, buyer.m_9236_().m_46467_());
               this.presentWalkAwayToBoth(session, buyer, seller);
               return StepResult.transition(TradeInitiateBehavior.Stage.WALK_AWAY);
            }

            try {
               this.tradeExecutor.execute(session, buyer, seller);
            } catch (RuntimeException exception) {
               log.warn("Trade execution failed, converting to walk-away: sessionId={}, buyer={}, seller={}", session.getSessionId(), buyer.m_20148_(), seller.m_20148_(), exception);
               session.transitionTo(TradeSessionPhase.WALK_AWAY, buyer.m_9236_().m_46467_());
               this.presentWalkAwayToBoth(session, buyer, seller);
               return StepResult.transition(TradeInitiateBehavior.Stage.WALK_AWAY);
            }

            if (this.activeDemand != null && this.activeDemand.origin() != ActiveDemand.Origin.STATIC_SHORTFALL) {
               this.demandSignalService.remove(buyer, this.activeDemand.match());
            }

            this.tradeExecuted = true;
         }

         session.transitionTo(TradeSessionPhase.DEAL, buyer.m_9236_().m_46467_());
         this.presentDealToBoth(session, buyer, seller);
         return StepResult.transition(TradeInitiateBehavior.Stage.DEAL);
      }
   }

   private Optional<TradeSession> currentSession(@Nonnull BaseVillager villager) {
      return this.sessionRegistry.getActiveSession(villager.m_20148_()).filter((session) -> this.activeSessionId == null || this.activeSessionId.equals(session.getSessionId()));
   }

   private Optional<BaseVillager> resolveParticipant(@Nonnull Level level, @Nonnull UUID participantId) {
      if (level instanceof ServerLevel serverLevel) {
         Optional var10000 = Optional.ofNullable(serverLevel.m_8791_(participantId));
         Objects.requireNonNull(BaseVillager.class);
         var10000 = var10000.filter(BaseVillager.class::isInstance);
         Objects.requireNonNull(BaseVillager.class);
         return var10000.map(BaseVillager.class::cast);
      } else {
         return Optional.empty();
      }
   }

   private void presentDealToBoth(@Nonnull TradeSession session, @Nonnull BaseVillager buyer, @Nonnull BaseVillager seller) {
      this.tradeSessionPresenter.presentDeal(session, buyer);
      this.tradeSessionPresenter.presentDeal(session, seller);
   }

   private void presentWalkAwayToBoth(@Nonnull TradeSession session, @Nonnull BaseVillager buyer, @Nonnull BaseVillager seller) {
      this.tradeSessionPresenter.presentWalkAway(session, buyer);
      this.tradeSessionPresenter.presentWalkAway(session, seller);
   }

   protected boolean shouldLookAtActiveTarget() {
      return false;
   }

   private void lockMutualAttention(@Nonnull BaseVillager buyer, @Nonnull BaseVillager seller) {
      buyer.m_6274_().m_21879_(MemoryModuleType.f_26371_, new EntityTracker(seller, true));
      seller.m_6274_().m_21879_(MemoryModuleType.f_26371_, new EntityTracker(buyer, true));
   }

   private boolean hasDeal(@Nonnull TradeSession session) {
      int spread = session.getSellerAsk() - session.getBuyerOffer();
      return spread <= 1;
   }

   private boolean phaseElapsed(@Nonnull TradeSession session, long currentGameTime, int durationTicks) {
      return currentGameTime - session.getPhaseEnteredGameTime() >= (long)durationTicks;
   }

   private static String buildTradeDetail(@Nonnull TradeSession session) {
      String itemPath = BuiltInRegistries.f_257033_.m_7981_(session.getMatchedItem()).m_135815_();
      int quantity = session.getBundleSize();
      int price = session.getBuyerOffer();
      String emeraldLabel = price == 1 ? "1 emerald" : price + " emeralds";
      return quantity + " " + itemPath + " for " + emeraldLabel;
   }

   private static void recordTradeDetailFields(@Nonnull BehaviorOutcome outcome, @Nonnull TradeSession session) {
      String itemPath = BuiltInRegistries.f_257033_.m_7981_(session.getMatchedItem()).m_135815_();
      int price = session.getBuyerOffer();
      String emeraldLabel = price == 1 ? "1 emerald" : price + " emeralds";
      outcome.putDetailField("item", itemPath);
      outcome.putDetailField("count", String.valueOf(session.getBundleSize()));
      outcome.putDetailField("price", emeraldLabel);
   }

   public static enum Stage implements StageKey {
      SCAN_AND_INVITE,
      WAIT_FOR_ACCEPT,
      APPROACH,
      OPENING_OFFER,
      NEGOTIATE,
      DEAL,
      WALK_AWAY,
      CLOSED;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{SCAN_AND_INVITE, WAIT_FOR_ACCEPT, APPROACH, OPENING_OFFER, NEGOTIATE, DEAL, WALK_AWAY, CLOSED};
      }
   }
}
