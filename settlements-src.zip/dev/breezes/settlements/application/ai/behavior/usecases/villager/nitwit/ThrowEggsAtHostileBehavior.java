package dev.breezes.settlements.application.ai.behavior.usecases.villager.nitwit;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.domain.world.location.Vector;
import dev.breezes.settlements.infrastructure.minecraft.entities.projectiles.SettlementsEgg;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.Map;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class ThrowEggsAtHostileBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ThrowEggsAtHostileBehavior.class.getName());
   private static final ClockTicks BURST_DURATION = ClockTicks.of(30L);
   private static final ClockTicks THROW_INTERVAL = ClockTicks.of(3L);
   private static final float EGG_VELOCITY = 1.5F;
   private static final float EGG_INACCURACY = 4.0F;
   private static final double HAND_LATERAL_OFFSET = 0.4;
   private static final double HAND_FORWARD_OFFSET = 0.1;
   private static final double HAND_RAISED_ABOVE_HEAD = 0.15;
   private final LivingEntity target;
   private final double reachSquared;
   private int eggsThrown;

   ThrowEggsAtHostileBehavior(@Nonnull BehaviorSupport support, @Nonnull LivingEntity target, double reachBlocks) {
      super(log, ClockTicks.ZERO.asTickable(), ClockTicks.ZERO.asTickable(), support);
      this.target = target;
      this.reachSquared = reachBlocks * reachBlocks;
      this.eggsThrown = 0;
      this.initializeStateMachine(this.createControlStep(), ThrowEggsAtHostileBehavior.Stage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("ThrowEggsAtHostileBehavior").initialStage(ThrowEggsAtHostileBehavior.Stage.BURST).stageStepMap(Map.of(ThrowEggsAtHostileBehavior.Stage.BURST, this.createBurstStep())).nextStage(ThrowEggsAtHostileBehavior.Stage.END).build();
   }

   private BehaviorStep<BaseVillager> createBurstStep() {
      return TimeBasedStep.<BaseVillager>builder().name("EggCombatBurst").withTickable(BURST_DURATION.asTickable()).onStart((ctx) -> {
         BaseVillager villager = (BaseVillager)ctx.getInitiator();
         villager.getNavigationManager().stop();
         ctx.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.target)));
         villager.setMotion(AnimationArchetype.THROW);
         return StepResult.noOp();
      }).addPeriodicStep(THROW_INTERVAL.getTicksAsInt(), this::throwEggAtTarget).onEnd((ctx) -> StepResult.transition(ThrowEggsAtHostileBehavior.Stage.END)).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      this.eggsThrown = 0;
      villager.setHeldItem(new ItemStack(Items.f_42521_));
      villager.setOffhandItem(new ItemStack(Items.f_42521_));
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      return this.target.m_6084_() && !this.target.m_213877_() && villager.m_20280_(this.target) <= this.reachSquared;
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.setMotion(AnimationArchetype.IDLE);
      villager.clearHeldItem();
      villager.clearOffhandItem();
   }

   private StepResult throwEggAtTarget(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager villager = context.getInitiator();
      Level world = villager.m_9236_();
      boolean rightHand = this.eggsThrown % 2 == 0;
      ++this.eggsThrown;
      Vec3 handPosition = computeRaisedHandPosition(villager, rightHand);
      Location handLocation = Location.of(handPosition.f_82479_, handPosition.f_82480_, handPosition.f_82481_, world);
      Vector direction = handLocation.getDirectionTo(Location.fromEntity(this.target, true));
      SettlementsEgg egg = new SettlementsEgg((ServerLevel)world, villager, true);
      egg.m_6034_(handPosition.f_82479_, handPosition.f_82480_, handPosition.f_82481_);
      egg.m_6686_(direction.getX(), direction.getY(), direction.getZ(), 1.5F, 4.0F);
      world.m_7967_(egg);
      SoundRegistry.THROW_EGG.playGlobally(handLocation, SoundSource.NEUTRAL);
      return StepResult.noOp();
   }

   private static Vec3 computeRaisedHandPosition(@Nonnull BaseVillager villager, boolean rightHand) {
      Vec3 look = villager.m_20154_();
      Vec3 forward = new Vec3(look.f_82479_, (double)0.0F, look.f_82481_);
      forward = forward.m_82556_() < 1.0E-4 ? villager.m_20156_() : forward.m_82541_();
      Vec3 right = new Vec3(-forward.f_82481_, (double)0.0F, forward.f_82479_);
      double lateral = rightHand ? 0.4 : -0.4;
      return new Vec3(villager.m_20185_() + right.f_82479_ * lateral + forward.f_82479_ * 0.1, villager.m_20186_() + (double)villager.m_20206_() + 0.15, villager.m_20189_() + right.f_82481_ * lateral + forward.f_82481_ * 0.1);
   }

   private static enum Stage implements StageKey {
      BURST,
      END;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{BURST, END};
      }
   }
}
