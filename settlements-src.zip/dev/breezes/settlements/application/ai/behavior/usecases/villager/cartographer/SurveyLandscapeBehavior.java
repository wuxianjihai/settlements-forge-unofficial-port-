package dev.breezes.settlements.application.ai.behavior.usecases.villager.cartographer;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.ConditionalStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Queue;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap.Types;

public class SurveyLandscapeBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(SurveyLandscapeBehavior.class.getName());
   private static final int SURVEY_POINT_HORIZONTAL_REACH = 5;
   private static final int NAVIGATION_COMPLETION_DISTANCE = 1;
   private static final int MAX_SAMPLING_RETRIES = 20;
   private static final int MAX_SURVEY_POINT_Y_DIFFERENCE = 10;
   private final SurveyLandscapeConfig config;
   private final Queue<Location> remainingPoints = new ArrayDeque();
   private boolean shouldRewardExperience;

   public SurveyLandscapeBehavior(@Nonnull SurveyLandscapeConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.shouldRewardExperience = false;
      this.initializeStateMachine(this.createControlStep(), SurveyLandscapeBehavior.SurveyStage.END);
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      this.sampleSurveyPoints(villager, world);
      if (!this.remainingPoints.isEmpty()) {
         this.shouldRewardExperience = false;
         Location firstPoint = (Location)this.remainingPoints.poll();
         context.setState(BehaviorStateType.TARGET, TargetState.of(this.toTargetable(firstPoint)));
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      if (this.shouldRewardExperience) {
         this.rewardExperience(villager);
      }

      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.remainingPoints.clear();
   }

   private StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("SurveyLandscapeBehavior").initialStage(SurveyLandscapeBehavior.SurveyStage.NAVIGATE_TO_POINT).stageStepMap(Map.of(SurveyLandscapeBehavior.SurveyStage.NAVIGATE_TO_POINT, this.createNavigateToPointStep(), SurveyLandscapeBehavior.SurveyStage.SURVEY, this.createSurveyStep(), SurveyLandscapeBehavior.SurveyStage.MARK_MAP, this.createMarkMapStep())).nextStage(SurveyLandscapeBehavior.SurveyStage.END).build();
   }

   private BehaviorStep<BaseVillager> createNavigateToPointStep() {
      TimeBasedStep<BaseVillager> arrivedStep = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.seconds((double)0.5F).asTickable()).onEnd((context) -> StepResult.transition(SurveyLandscapeBehavior.SurveyStage.SURVEY)).build();
      NavigateToTargetStep<BaseVillager> navigateStep = NavigateToTargetStep.<BaseVillager>builder().navigationType(NavigationType.WALK).completionDistance(1).reachabilityGated(false).build();
      ICondition<BehaviorContext<BaseVillager>> closeEnoughHorizontally = ICondition.<BehaviorContext<BaseVillager>>named("closeEnoughHorizontally", (context) -> {
         if (context == null) {
            return false;
         } else {
            BaseVillager villager = (BaseVillager)context.getInitiator();
            return (Boolean)context.getState(BehaviorStateType.TARGET, TargetState.class).flatMap(TargetState::getFirst).map(Targetable::getLocation).map((target) -> Math.abs(target.getBlockX() - villager.getMinecraftEntity().m_146903_()) + Math.abs(target.getBlockZ() - villager.getMinecraftEntity().m_146907_()) <= 5).orElse(false);
         }
      });
      return ConditionalStep.<BaseVillager>builder().name("SurveyArrivedOrNavigate").condition(closeEnoughHorizontally).trueStep(arrivedStep).falseStep(navigateStep).build();
   }

   private BehaviorStep<BaseVillager> createSurveyStep() {
      return TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.of(160L).asTickable()).onStart((context) -> {
         BaseVillager villager = (BaseVillager)context.getInitiator();
         villager.getNavigationManager().stop();
         villager.setHeldItem(Items.f_151059_.m_7968_());
         villager.triggerMotion(AnimationArchetype.SURVEY_WITH_SPYGLASS);
         return StepResult.noOp();
      }).onEnd((context) -> {
         ((BaseVillager)context.getInitiator()).clearHeldItem();
         return StepResult.transition(SurveyLandscapeBehavior.SurveyStage.MARK_MAP);
      }).build();
   }

   private BehaviorStep<BaseVillager> createMarkMapStep() {
      return TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.of(40L).asTickable()).onStart((context) -> {
         BaseVillager villager = (BaseVillager)context.getInitiator();
         villager.getNavigationManager().stop();
         villager.setHeldItem(Items.f_42676_.m_7968_());
         SoundRegistry.MAP_FLAP.playGlobally(Location.fromEntity((Entity)context.getInitiator(), false), SoundSource.NEUTRAL);
         villager.triggerMotion(AnimationArchetype.WRITE_TO_MAP);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(20L), (context) -> {
         ((BaseVillager)context.getInitiator()).setHeldItem(Items.f_42573_.m_7968_());
         SoundRegistry.MAP_SCRIBBLE.playGlobally(Location.fromEntity((Entity)context.getInitiator(), false), SoundSource.NEUTRAL);
         return StepResult.noOp();
      }).onEnd((context) -> {
         ((BaseVillager)context.getInitiator()).clearHeldItem();
         this.shouldRewardExperience = true;
         if (context.primaryDeed().isEmpty()) {
            BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.LANDSCAPE_SURVEYED, (String)null);
            outcome.markSucceeded();
            context.declarePrimaryDeed(outcome);
         }

         if (this.remainingPoints.isEmpty()) {
            return StepResult.transition(SurveyLandscapeBehavior.SurveyStage.END);
         } else {
            Location nextPoint = (Location)this.remainingPoints.poll();
            context.setState(BehaviorStateType.TARGET, TargetState.of(this.toTargetable(nextPoint)));
            return StepResult.transition(SurveyLandscapeBehavior.SurveyStage.NAVIGATE_TO_POINT);
         }
      }).build();
   }

   private void sampleSurveyPoints(@Nonnull BaseVillager villager, @Nonnull Level world) {
      int pointCount = (Integer)this.config.expertiseSurveyPointCount().getOrDefault(villager.getExpertise().getConfigName(), 2);
      Location origin = Location.fromEntity(villager, false);
      List<Location> sampled = new ArrayList();

      for(int i = 0; i < pointCount; ++i) {
         Optional<Location> candidate = this.trySamplePoint(origin, sampled, villager, world);
         Objects.requireNonNull(sampled);
         candidate.ifPresent(sampled::add);
      }

      if (sampled.isEmpty()) {
         log.behaviorWarn("No reachable survey points found; stopping behavior");
         this.requestStop("no_reachable_survey_points");
      } else {
         this.remainingPoints.addAll(sampled);
      }
   }

   private Optional<Location> trySamplePoint(@Nonnull Location origin, @Nonnull List<Location> existing, @Nonnull BaseVillager villager, @Nonnull Level world) {
      ServerLevel serverLevel = (ServerLevel)world;
      double minSeparationSquared = (double)this.config.minPointSeparation() * (double)this.config.minPointSeparation();

      for(int attempt = 0; attempt < 20; ++attempt) {
         double yaw = RandomUtil.randomDouble((double)0.0F, (Math.PI * 2D));
         double distance = RandomUtil.randomDouble((double)this.config.minPointDistance(), (double)this.config.maxPointDistance());
         int x = origin.getBlockX() + (int)(Math.cos(yaw) * distance);
         int z = origin.getBlockZ() + (int)(Math.sin(yaw) * distance);
         int y = serverLevel.m_6924_(Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
         if (Math.abs(y - origin.getBlockY()) <= 10) {
            BlockPos targetPos = new BlockPos(x, y, z);
            BlockState surfaceState = serverLevel.m_8055_(targetPos);
            if (!surfaceState.m_60812_(serverLevel, targetPos).m_83281_()) {
               Location candidate = Location.of((double)x + (double)0.5F, (double)y, (double)z + (double)0.5F, world);
               boolean tooClose = existing.stream().anyMatch((p) -> p.distanceSquared(candidate) < minSeparationSquared);
               if (!tooClose && villager.getNavigationManager().canReach(candidate, (double)this.config.maxPointDistance())) {
                  return Optional.of(candidate);
               }
            }
         }
      }

      return Optional.empty();
   }

   private Targetable toTargetable(@Nonnull Location location) {
      Level level = (Level)location.getLevel().orElseThrow(() -> new IllegalStateException("Survey point location has no level reference"));
      return Targetable.fromBlock(PhysicalBlock.of(location, level.m_8055_(location.toBlockPos())));
   }

   private static enum SurveyStage implements StageKey {
      NAVIGATE_TO_POINT,
      SURVEY,
      MARK_MAP,
      END;

      // $FF: synthetic method
      private static SurveyStage[] $values() {
         return new SurveyStage[]{NAVIGATE_TO_POINT, SURVEY, MARK_MAP, END};
      }
   }
}
