package dev.breezes.settlements.application.ai.behavior.usecases.villager.donation;

import dev.breezes.settlements.application.ui.bubble.BubbleChannel;
import dev.breezes.settlements.application.ui.bubble.BubbleCommand;
import dev.breezes.settlements.application.ui.bubble.BubbleMessage;
import dev.breezes.settlements.application.ui.bubble.BubbleSegment;
import dev.breezes.settlements.application.ui.bubble.VillagerBubbleService;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.List;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Items;

@ServerScope
public final class DonationPresenter {
   private static final ClockTicks DONOR_BUBBLE_TTL = ClockTicks.seconds((double)6.0F);
   private static final ClockTicks HEART_BUBBLE_TTL = ClockTicks.seconds((double)4.0F);
   private static final String DONATION_SOURCE = "donation";
   private static final BubbleSegment HEART_GLYPH;
   private final VillagerBubbleService villagerBubbleService;

   public void presentGift(@Nonnull BaseVillager donor, @Nonnull BaseVillager recipient, int amount, long gameTime) {
      BubbleSegment emeraldWithCount = BubbleSegment.Item.builder().itemId(BuiltInRegistries.f_257033_.m_7981_(Items.f_42616_)).count(amount).build();
      this.villagerBubbleService.applyCommand(donor, new BubbleCommand.Upsert(BubbleChannel.BEHAVIOR, ownerKey(donor), BubbleMessage.builder().priority(10).ttl(DONOR_BUBBLE_TTL).sourceType("donation").segments(List.of(emeraldWithCount)).build()), gameTime);
      this.villagerBubbleService.applyCommand(recipient, new BubbleCommand.Upsert(BubbleChannel.FLAVOR, ownerKey(donor), BubbleMessage.builder().priority(10).ttl(HEART_BUBBLE_TTL).sourceType("donation").segments(List.of(HEART_GLYPH)).build()), gameTime);
      Location recipientLocation = Location.fromEntity(recipient, true);
      recipientLocation.displayParticles(ParticleTypes.f_123750_, 12, (double)0.5F, (double)0.5F, (double)0.5F, 0.02);
      recipientLocation.displayParticles(ParticleTypes.f_123748_, 8, (double)0.5F, (double)0.5F, (double)0.5F, 0.01);
      recipientLocation.playSound(SoundEvents.f_12509_, 1.0F, 1.0F, SoundSource.NEUTRAL);
   }

   private static String ownerKey(@Nonnull BaseVillager donor) {
      return "donation-" + String.valueOf(donor.m_20148_());
   }

   @Inject
   @Generated
   DonationPresenter(VillagerBubbleService villagerBubbleService) {
      this.villagerBubbleService = villagerBubbleService;
   }

   static {
      HEART_GLYPH = BubbleSegment.Text.builder().literal("❤").color(ChatFormatting.RED).bold(true).scale(0.9F).build();
   }
}
