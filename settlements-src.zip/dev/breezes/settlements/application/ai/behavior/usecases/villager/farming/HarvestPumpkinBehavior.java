package dev.breezes.settlements.application.ai.behavior.usecases.villager.farming;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.blocks.VisitedBlockSitesState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.items.ItemState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetQueries;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.AwardExperienceStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.LoopBackStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.OneShotStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.PickupItemsStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.WaitStep;
import dev.breezes.settlements.application.ai.targeting.BlockMemoryTargetResolver;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.domain.ai.conditions.KnownBlockSitesPrecondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.AabbBlockScan;
import dev.breezes.settlements.domain.world.blocks.BlockMatcher;
import dev.breezes.settlements.domain.world.blocks.BlockMatchers;
import dev.breezes.settlements.domain.world.blocks.BlockScanBox;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class HarvestPumpkinBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(HarvestPumpkinBehavior.class.getName());
   private static final ClockTicks SETTLE_DURATION = ClockTicks.seconds((double)1.0F);
   private static final int APPROACH_TIMEOUT_TICKS = ClockTicks.seconds((double)20.0F).getTicksAsInt();
   private final BlockMatcher ripePumpkinMatcher;
   private final BlockScanBox confirmBox;
   private final int maxConfirms;
   private final HarvestPumpkinConfig config;
   private final BlockMemoryTargetResolver targetResolver;

   public HarvestPumpkinBehavior(@Nonnull HarvestPumpkinConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.targetResolver = support.getBlockMemoryTargetResolver();
      this.ripePumpkinMatcher = BlockMatchers.HARVESTABLE_PUMPKIN;
      this.confirmBox = BlockScanBox.confirm();
      this.maxConfirms = 8;
      this.preconditions.add(KnownBlockSitesPrecondition.builder().memoryType(MemoryTypeRegistry.RIPE_PUMPKIN_SITES).matcher(this.ripePumpkinMatcher).confirmBox(this.confirmBox).maxSitesToConfirm(this.maxConfirms).completionRange(1).description("Known ripe pumpkin sites").build());
      this.initializeStateMachine(this.createControlStep(), HarvestPumpkinBehavior.Stage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      Map<StageKey, BehaviorStep<BaseVillager>> stageMap = new HashMap();
      stageMap.put(HarvestPumpkinBehavior.Stage.PICK_TARGET, this.createPickTargetStep());
      stageMap.put(HarvestPumpkinBehavior.Stage.APPROACH, StayCloseStep.builder().closeEnoughDistance((double)1.5F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.WALK).completionDistance(1).unreachableTransition(HarvestPumpkinBehavior.Stage.PICK_TARGET).build()).actionStep(OneShotStep.builder().name("ArrivedAtPumpkin").action((ctx) -> StepResult.transition(HarvestPumpkinBehavior.Stage.CHOP)).build()).timeoutTicks(APPROACH_TIMEOUT_TICKS).timeoutTransition(HarvestPumpkinBehavior.Stage.PICK_TARGET).build());
      stageMap.put(HarvestPumpkinBehavior.Stage.CHOP, this.createChopStep());
      stageMap.put(HarvestPumpkinBehavior.Stage.SETTLE, WaitStep.builder().waitTime(SETTLE_DURATION.asTickable()).nextStage(HarvestPumpkinBehavior.Stage.PICKUP).build());
      stageMap.put(HarvestPumpkinBehavior.Stage.PICKUP, PickupItemsStep.builder().name("PickupPumpkinDrops").nextStage(HarvestPumpkinBehavior.Stage.LOOP).build());
      stageMap.put(HarvestPumpkinBehavior.Stage.LOOP, LoopBackStep.builder().name("PumpkinLoopBack").loopBackTo(HarvestPumpkinBehavior.Stage.PICK_TARGET).completionTransition(HarvestPumpkinBehavior.Stage.AWARD).maxIterationsResolver((ctx) -> 4 * ((BaseVillager)ctx.getInitiator()).getExpertise().getLevel()).build());
      stageMap.put(HarvestPumpkinBehavior.Stage.AWARD, AwardExperienceStep.builder().name("AwardPumpkinXp").experienceAmount(this.config.experienceReward()).nextStage(HarvestPumpkinBehavior.Stage.END).build());
      return StagedStep.<BaseVillager>builder().name("HarvestPumpkinBehavior").initialStage(HarvestPumpkinBehavior.Stage.PICK_TARGET).stageStepMap(stageMap).nextStage(HarvestPumpkinBehavior.Stage.END).build();
   }

   private BehaviorStep<BaseVillager> createPickTargetStep() {
      return OneShotStep.<BaseVillager>builder().name("PickPumpkinTarget").action((ctx) -> {
         boolean resolved = this.targetResolver.resolveBlockTarget(ctx, MemoryTypeRegistry.RIPE_PUMPKIN_SITES, this.ripePumpkinMatcher, this.confirmBox, this.maxConfirms, 1);
         if (!resolved) {
            log.behaviorStatus("No additional pumpkin targets found, ending behavior");
            return StepResult.transition(HarvestPumpkinBehavior.Stage.AWARD);
         } else {
            return StepResult.transition(HarvestPumpkinBehavior.Stage.APPROACH);
         }
      }).build();
   }

   private BehaviorStep<BaseVillager> createChopStep() {
      return TimeBasedStep.<BaseVillager>builder().name("ChopPumpkin").withTickable(ClockTicks.of(30L).asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).setHeldItem(Items.f_42386_.m_7968_());
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.SWING_HEAVY);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(14L), (ctx) -> {
         Optional<BlockPos> target = TargetQueries.firstBlockPos(ctx);
         if (target.isEmpty()) {
            return StepResult.noOp();
         } else {
            BaseVillager villager = (BaseVillager)ctx.getInitiator();
            Level world = villager.m_9236_();
            BlockPos pos = (BlockPos)target.get();
            BlockState state = world.m_8055_(pos);
            if (world instanceof ServerLevel) {
               ServerLevel server = (ServerLevel)world;
               if (AabbBlockScan.findFirst(pos, BlockScanBox.self(), this.ripePumpkinMatcher, world).isEmpty()) {
                  return StepResult.noOp();
               } else {
                  Location effectLocation = Location.of(pos, world).center(true).add((double)0.0F, (double)0.5F, (double)0.0F, true);
                  ParticleRegistry.harvestBlock(effectLocation, state);
                  effectLocation.playSound(state.getSoundType(world, pos, villager).m_56775_(), 0.8F, 1.0F, SoundSource.BLOCKS);
                  List<ItemStack> drops = Block.m_49874_(state, server, pos, (BlockEntity)null, villager, ItemStack.f_41583_);
                  List<ItemEntity> spawned = Location.of(pos, world).center(true).dropItems(drops, true);
                  spawned.forEach((itemEntity) -> itemEntity.m_32010_(ClockTicks.seconds((double)5.0F).getTicksAsInt()));
                  world.m_7471_(pos, false);
                  ctx.getState(BehaviorStateType.VISITED_BLOCK_SITES, VisitedBlockSitesState.class).ifPresent((visitedSites) -> visitedSites.addSite(GlobalPos.m_122643_(world.m_46472_(), pos)));
                  ctx.setState(BehaviorStateType.ITEMS_TO_PICK_UP, ItemState.of(spawned));
                  ctx.primaryDeed().ifPresent((outcome) -> outcome.recordYield(totalItemCount(drops)));
                  return StepResult.noOp();
               }
            } else {
               return StepResult.noOp();
            }
         }
      }).onEnd((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         return StepResult.transition(HarvestPumpkinBehavior.Stage.SETTLE);
      }).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      context.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.RESOURCE_HARVESTED, "pumpkins"));
      context.setState(BehaviorStateType.VISITED_BLOCK_SITES, VisitedBlockSitesState.empty());
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
   }

   private static int totalItemCount(@Nonnull List<ItemStack> drops) {
      return drops.stream().mapToInt(ItemStack::m_41613_).sum();
   }

   private static enum Stage implements StageKey {
      PICK_TARGET,
      APPROACH,
      CHOP,
      SETTLE,
      PICKUP,
      LOOP,
      AWARD,
      END;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{PICK_TARGET, APPROACH, CHOP, SETTLE, PICKUP, LOOP, AWARD, END};
      }
   }
}
