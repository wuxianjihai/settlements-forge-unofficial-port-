package dev.breezes.settlements.application.ai.behavior.usecases.villager.support;

import dev.breezes.settlements.application.ai.behavior.runtime.timing.BehaviorTimingConfig;
import dev.breezes.settlements.application.config.validation.BehaviorCooldownValidator;
import dev.breezes.settlements.infrastructure.config.annotations.BehaviorConfig;
import dev.breezes.settlements.infrastructure.config.annotations.ConfigurationType;
import dev.breezes.settlements.infrastructure.config.annotations.doubles.DoubleConfig;
import dev.breezes.settlements.infrastructure.config.annotations.integers.IntegerConfig;
import dev.breezes.settlements.infrastructure.config.annotations.maps.MapConfig;
import dev.breezes.settlements.infrastructure.config.annotations.maps.MapEntry;
import java.util.Map;

@BehaviorConfig(
   name = "repair_iron_golem",
   type = ConfigurationType.BEHAVIOR
)
public record RepairIronGolemConfig(@IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "precondition_check_cooldown_min",description = "Minimum interval (in seconds) between precondition checks",defaultValue = 10,min = 1) int preconditionCheckCooldownMin, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "precondition_check_cooldown_max",description = "Maximum interval (in seconds) between precondition checks",defaultValue = 20,min = 1) int preconditionCheckCooldownMax, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "behavior_cooldown_min",description = "Minimum behavior cooldown time (in seconds)",defaultValue = 30,min = 1) int behaviorCooldownMin, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "behavior_cooldown_max",description = "Maximum behavior cooldown time (in seconds)",defaultValue = 60,min = 1) int behaviorCooldownMax, @MapConfig(type = ConfigurationType.BEHAVIOR,identifier = "expertise_repair_limit",description = "Map of villager expertise level to the maximum number of iron golem repair attempts in one session.",deserializer = "StringToInteger",defaultValue = {@MapEntry(
   key = "novice",
   value = "1"
), @MapEntry(
   key = "apprentice",
   value = "2"
), @MapEntry(
   key = "journeyman",
   value = "2"
), @MapEntry(
   key = "expert",
   value = "3"
), @MapEntry(
   key = "master",
   value = "5"
)}) Map<String, Integer> expertiseRepairLimit, @DoubleConfig(type = ConfigurationType.BEHAVIOR,identifier = "repair_hp_percentage",description = "Health percentage threshold to consider the iron golem as damaged",defaultValue = 0.9,min = (double)0.0F,max = (double)1.0F) double repairHpPercentage, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "experience_reward",description = "Villager experience awarded when the behavior completes successfully",defaultValue = 3,min = 0) int experienceReward) implements BehaviorTimingConfig {
   public RepairIronGolemConfig {
      BehaviorCooldownValidator.validateRanges(preconditionCheckCooldownMin, preconditionCheckCooldownMax, behaviorCooldownMin, behaviorCooldownMax);
   }
}
