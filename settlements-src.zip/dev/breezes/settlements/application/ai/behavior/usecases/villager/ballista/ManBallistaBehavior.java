package dev.breezes.settlements.application.ai.behavior.usecases.villager.ballista;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.look.LookState;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.AbstractStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.bootstrap.registry.items.ItemRegistry;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.navigation.INavigationManager;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.threat.ThreatResponseRules;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.ballista.BallistaFiringSolution;
import dev.breezes.settlements.domain.ballista.BallistaLaunchPoint;
import dev.breezes.settlements.domain.ballista.BallistaLease;
import dev.breezes.settlements.domain.ballista.BallistaOperatorSkill;
import dev.breezes.settlements.domain.ballista.BallistaStateMachine;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.ITickable;
import dev.breezes.settlements.domain.time.Tickable;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.blocks.ballista.BallistaBlockEntity;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class ManBallistaBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ManBallistaBehavior.class.getName());
   private static final ClockTicks APPROACH_TIMEOUT = ClockTicks.seconds((double)12.0F);
   private static final ClockTicks AIM_TIMEOUT = ClockTicks.seconds((double)8.0F);
   private static final ClockTicks NO_SOLUTION_GRACE = ClockTicks.seconds((double)1.0F);
   private static final ClockTicks SIGHT_CHECK_INTERVAL = ClockTicks.of(5L);
   private static final double LOCK_RANGE_SQUARED = (double)16384.0F;
   private static final int DEPARTURE_DELAY_TICKS = 3;
   private static final AnimationArchetype WIND_MOTION;
   private static final AnimationArchetype LOAD_MOTION;
   private static final AnimationArchetype FIRE_MOTION;
   private final BallistaCombatOption option;
   private final BallistaOperationConfig config;
   private final BallistaShotChecks shotChecks;
   private final LivingEntity target;
   private final ITickable leaseRenewal;
   private final ITickable sightCheck;
   @Nullable
   private BlockPos machinePos;
   @Nullable
   private BallistaBlockEntity machine;
   @Nullable
   private BallistaOperatorSkill skill;
   private boolean targetInSight;
   private int ticksOutOfSight;
   private final Set<BlockPos> reachableBallistas = new HashSet();
   @Nullable
   private BlockPos walkTarget;

   ManBallistaBehavior(@Nonnull BehaviorSupport support, @Nonnull BallistaCombatOption option, @Nonnull BallistaOperationConfig config, @Nonnull BallistaShotChecks shotChecks, @Nonnull LivingEntity target) {
      super(log, ClockTicks.ZERO.asTickable(), ClockTicks.ZERO.asTickable(), support);
      this.option = option;
      this.config = config;
      this.shotChecks = shotChecks;
      this.target = target;
      this.leaseRenewal = Tickable.staggered(BallistaLease.RENEWAL_INTERVAL);
      this.sightCheck = Tickable.staggered(SIGHT_CHECK_INTERVAL);
      this.preconditions.add(ICondition.named("a ballista the villager can take up", this::chooseMachine));
      this.initializeStateMachine(this.createControlStep(), ManBallistaBehavior.Stage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("ManBallistaBehavior").initialStage(ManBallistaBehavior.Stage.APPROACH).stageStepMap(Map.of(ManBallistaBehavior.Stage.APPROACH, new ApproachStep(), ManBallistaBehavior.Stage.WIND, new WindStep(), ManBallistaBehavior.Stage.LOAD, new LoadStep(), ManBallistaBehavior.Stage.AIM, new AimStep(), ManBallistaBehavior.Stage.FIRE, new FireStep())).nextStage(ManBallistaBehavior.Stage.END).build();
   }

   private boolean chooseMachine(@Nullable BaseVillager villager) {
      this.machinePos = null;
      this.reachableBallistas.clear();
      if (villager == null) {
         return false;
      } else {
         BallistaCombatOption.Readiness readiness = this.option.prepare(villager);
         BallistaBlockEntity candidate = readiness == null ? null : readiness.machineFor(this.target, true);
         if (candidate == null) {
            return false;
         } else {
            BlockPos station = BlockPos.m_274446_(stationOf(candidate.m_58899_(), candidate.getAim().getIntentYaw()));
            if (!villager.getNavigationManager().canReach(Location.of(station, villager.m_9236_()), (double)1.0F)) {
               this.option.rememberRefusal(villager, candidate.m_58899_());
               return false;
            } else {
               this.machinePos = candidate.m_58899_();
               this.reachableBallistas.add(station);
               return true;
            }
         }
      }
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      BallistaBlockEntity chosen = this.machinePos == null ? null : BallistaBlockEntity.inLoadedChunk(context.getLevel(), this.machinePos);
      if (chosen != null && chosen.acquireLease(villager.m_20148_())) {
         this.machine = chosen;
         this.skill = BallistaOperatorSkill.of(villager.getGenetics(), villager.getExpertise(), this.config.maxScatterDegrees());
         this.targetInSight = true;
         this.ticksOutOfSight = 0;
         this.walkTarget = null;
         context.setState(BehaviorStateType.LOOK_TARGET, LookState.ofLocation(Location.of(this.machinePos, world)));
         if (BallistaCombatOption.hasBoltInInventory(villager)) {
            villager.setHeldItem(new ItemStack((ItemLike)ItemRegistry.BALLISTA_BOLT.get()));
         }
      } else {
         if (this.machinePos != null) {
            this.option.rememberRefusal(villager, this.machinePos);
         }

         this.requestStop("No ballista could be taken up");
      }

   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      if (this.machinePos != null && this.target.m_6084_() && !this.target.m_213877_() && this.target.m_9236_() == world) {
         this.machine = BallistaBlockEntity.inLoadedChunk(context.getLevel(), this.machinePos);
         if (this.machine != null && !(this.target.m_20182_().m_82557_(BallistaCombatOption.floorCenterOf(this.machinePos)) > (double)16384.0F)) {
            if (this.sightCheck.tickCheckAndReset((double)delta)) {
               this.targetInSight = this.shotChecks.refreshLineOfSight(context.getLevel(), this.machinePos, this.target);
            }

            this.ticksOutOfSight = this.targetInSight ? 0 : this.ticksOutOfSight + delta;
            if (this.ticksOutOfSight > ThreatResponseRules.TARGETLESS_COMBAT_LIMIT.getTicksAsInt()) {
               return false;
            } else {
               return !this.leaseRenewal.tickCheckAndReset((double)delta) || this.machine.renewLease(villager.m_20148_());
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.setMotion(AnimationArchetype.IDLE);
      villager.clearHeldItem();
      villager.m_6274_().m_21936_(MemoryModuleType.f_26371_);
      if (this.machine != null) {
         this.machine.releaseLease(villager.m_20148_());
      }

      this.machine = null;
      this.walkTarget = null;
   }

   private StepResult resumeFromMachineState(@Nonnull BaseVillager villager) {
      boolean seated = this.machine.hasSeatedAmmunition();
      if (!seated && !BallistaCombatOption.hasBoltInInventory(villager)) {
         return StepResult.transition(ManBallistaBehavior.Stage.END);
      } else {
         StepResult var10000;
         switch (this.machine.settledStage()) {
            case WINDING:
            case FIRING:
               var10000 = StepResult.noOp();
               break;
            case UNWOUND:
               var10000 = StepResult.transition(ManBallistaBehavior.Stage.WIND);
               break;
            case COCKED:
               var10000 = StepResult.transition(seated ? ManBallistaBehavior.Stage.AIM : ManBallistaBehavior.Stage.LOAD);
               break;
            default:
               throw new IncompatibleClassChangeError();
         }

         return var10000;
      }
   }

   private StationApproach approachStation(@Nonnull BaseVillager villager) {
      BlockPos station = BlockPos.m_274446_(stationOf(this.machinePos, this.machine.getAim().getIntentYaw()));
      INavigationManager<BaseVillager> navigation = villager.getNavigationManager();
      if (villager.m_20183_().m_123333_(station) <= 1) {
         if (this.walkTarget != null) {
            navigation.stop();
            this.walkTarget = null;
         }

         return ManBallistaBehavior.StationApproach.ARRIVED;
      } else {
         boolean walkEndedShort = station.equals(this.walkTarget) && navigation.getNavigationTarget().isEmpty();
         if (walkEndedShort) {
            this.reachableBallistas.remove(station);
         }

         if (!this.canReachStation(villager, station)) {
            return ManBallistaBehavior.StationApproach.UNREACHABLE;
         } else {
            if (walkEndedShort || !station.equals(this.walkTarget)) {
               navigation.navigateTo(Location.of(station, villager.m_9236_()), NavigationType.RUN, 1);
               this.walkTarget = station;
            }

            return ManBallistaBehavior.StationApproach.WALKING;
         }
      }
   }

   private boolean canReachStation(@Nonnull BaseVillager villager, @Nonnull BlockPos station) {
      if (this.reachableBallistas.contains(station)) {
         return true;
      } else if (!villager.getNavigationManager().canReach(Location.of(station, villager.m_9236_()), (double)1.0F)) {
         return false;
      } else {
         this.reachableBallistas.add(station);
         return true;
      }
   }

   private StepResult failUnreachableStation(@Nonnull BaseVillager villager) {
      this.option.rememberRefusal(villager, this.machinePos);
      return StepResult.fail("station_unreachable");
   }

   private Optional<BallistaFiringSolution> solveForTarget() {
      Vec3 aimPoint = BallistaCombatOption.aimPointOf(this.target);
      Vec3 velocity = new Vec3(this.target.m_20185_() - this.target.f_19854_, this.target.m_20186_() - this.target.f_19855_, this.target.m_20189_() - this.target.f_19856_);
      Vec3 judgedVelocity = velocity.m_82490_(this.skill.getLeadQuality());
      Vec3 atDeparture = aimPoint.m_82549_(judgedVelocity.m_82490_((double)3.0F)).m_82546_(BallistaCombatOption.floorCenterOf(this.machinePos));
      return BallistaFiringSolution.solve(atDeparture, judgedVelocity, (double)3.9F);
   }

   private static Vec3 stationOf(@Nonnull BlockPos ballistaPos, float yaw) {
      return BallistaCombatOption.floorCenterOf(ballistaPos).m_82549_(BallistaLaunchPoint.stationOffset(yaw));
   }

   private static ItemStack boltToLoad(@Nonnull BaseVillager villager) {
      Item bolt = (Item)ItemRegistry.BALLISTA_BOLT.get();
      VillagerInventory inventory = villager.getSettlementsInventory();
      return (ItemStack)inventory.findFirst((stack) -> stack.m_150930_(bolt)).orElseGet(() -> GeneralConfig.bypassInventoryRequirements ? new ItemStack(bolt) : ItemStack.f_41583_);
   }

   static {
      WIND_MOTION = AnimationArchetype.FORGE;
      LOAD_MOTION = AnimationArchetype.INTERACT;
      FIRE_MOTION = AnimationArchetype.SWING_HEAVY;
   }

   private final class AimStep extends AbstractStep<BaseVillager> {
      private boolean aimed;
      private int ticksWithoutSolution;
      private double scatterDirectionDraw;
      private double scatterDistanceDraw;

      private AimStep() {
         super("BallistaAim", ManBallistaBehavior.AIM_TIMEOUT.getTicksAsInt(), (StageKey)null);
      }

      protected void doOnEnter() {
         this.aimed = false;
         this.ticksWithoutSolution = 0;
         this.scatterDirectionDraw = RandomUtil.RANDOM.nextDouble();
         this.scatterDistanceDraw = RandomUtil.RANDOM.nextDouble();
      }

      protected StepResult doTick(@Nonnull BehaviorContext<BaseVillager> context) {
         BaseVillager villager = context.getInitiator();
         StationApproach approach = ManBallistaBehavior.this.approachStation(villager);
         if (approach == ManBallistaBehavior.StationApproach.UNREACHABLE) {
            return ManBallistaBehavior.this.failUnreachableStation(villager);
         } else if (this.aimed && ManBallistaBehavior.this.machine.getAim().isAtRest() && approach == ManBallistaBehavior.StationApproach.ARRIVED && ManBallistaBehavior.this.targetInSight) {
            if (!ManBallistaBehavior.this.machine.fire(villager)) {
               return ManBallistaBehavior.this.resumeFromMachineState(villager);
            } else {
               villager.triggerMotion(ManBallistaBehavior.FIRE_MOTION);
               return StepResult.transition(ManBallistaBehavior.Stage.FIRE);
            }
         } else {
            Optional<BallistaFiringSolution> solution = ManBallistaBehavior.this.solveForTarget();
            if (solution.isEmpty()) {
               return ++this.ticksWithoutSolution > ManBallistaBehavior.NO_SOLUTION_GRACE.getTicksAsInt() ? StepResult.fail("no_firing_solution") : StepResult.noOp();
            } else {
               this.ticksWithoutSolution = 0;
               BallistaFiringSolution intended = ManBallistaBehavior.this.skill.scatter((BallistaFiringSolution)solution.get(), this.scatterDirectionDraw, this.scatterDistanceDraw);
               if (!ManBallistaBehavior.this.canReachStation(villager, BlockPos.m_274446_(ManBallistaBehavior.stationOf(ManBallistaBehavior.this.machinePos, intended.getYaw())))) {
                  return ManBallistaBehavior.this.failUnreachableStation(villager);
               } else {
                  ManBallistaBehavior.this.machine.aimAt(intended.getYaw(), intended.getPitch());
                  this.aimed = true;
                  return StepResult.noOp();
               }
            }
         }
      }
   }

   private final class ApproachStep extends AbstractStep<BaseVillager> {
      private ApproachStep() {
         super("BallistaApproach", ManBallistaBehavior.APPROACH_TIMEOUT.getTicksAsInt(), (StageKey)null);
      }

      protected StepResult doTick(@Nonnull BehaviorContext<BaseVillager> context) {
         BaseVillager villager = context.getInitiator();
         StepResult var10000;
         switch (ManBallistaBehavior.this.approachStation(villager)) {
            case ARRIVED -> var10000 = ManBallistaBehavior.this.resumeFromMachineState(villager);
            case WALKING -> var10000 = StepResult.noOp();
            case UNREACHABLE -> var10000 = ManBallistaBehavior.this.failUnreachableStation(villager);
            default -> throw new IncompatibleClassChangeError();
         }

         return var10000;
      }
   }

   private final class FireStep extends AbstractStep<BaseVillager> {
      private FireStep() {
         super("BallistaFire");
      }

      protected StepResult doTick(@Nonnull BehaviorContext<BaseVillager> context) {
         if (ManBallistaBehavior.this.machine.settledStage() == BallistaStateMachine.Stage.FIRING) {
            return StepResult.noOp();
         } else {
            ManBallistaBehavior.this.reachableBallistas.clear();
            return StepResult.transition(ManBallistaBehavior.Stage.APPROACH);
         }
      }
   }

   private final class LoadStep extends AbstractStep<BaseVillager> {
      private int ticksLoading;

      private LoadStep() {
         super("BallistaLoad");
      }

      protected void doOnEnter() {
         this.ticksLoading = 0;
      }

      protected StepResult doTick(@Nonnull BehaviorContext<BaseVillager> context) {
         BaseVillager villager = context.getInitiator();
         if (this.ticksLoading == 0) {
            villager.triggerMotion(ManBallistaBehavior.LOAD_MOTION);
         }

         if (++this.ticksLoading < ManBallistaBehavior.this.skill.getLoadDuration().getTicksAsInt()) {
            return StepResult.noOp();
         } else {
            ItemStack bolt = ManBallistaBehavior.boltToLoad(villager);
            if (ManBallistaBehavior.this.machine.load(villager, bolt)) {
               villager.getSettlementsInventory().consumeIfRequired(bolt.m_41720_(), 1, GeneralConfig.bypassInventoryRequirements);
               if (!BallistaCombatOption.hasBoltInInventory(villager)) {
                  villager.clearHeldItem();
               }
            }

            return ManBallistaBehavior.this.resumeFromMachineState(villager);
         }
      }
   }

   private static enum Stage implements StageKey {
      APPROACH,
      WIND,
      LOAD,
      AIM,
      FIRE,
      END;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{APPROACH, WIND, LOAD, AIM, FIRE, END};
      }
   }

   private static enum StationApproach {
      ARRIVED,
      WALKING,
      UNREACHABLE;

      // $FF: synthetic method
      private static StationApproach[] $values() {
         return new StationApproach[]{ARRIVED, WALKING, UNREACHABLE};
      }
   }

   private final class WindStep extends AbstractStep<BaseVillager> {
      private boolean winding;

      private WindStep() {
         super("BallistaWind");
      }

      protected void doOnEnter() {
         this.winding = false;
      }

      protected StepResult doTick(@Nonnull BehaviorContext<BaseVillager> context) {
         BaseVillager villager = context.getInitiator();
         if (!this.winding) {
            if (!ManBallistaBehavior.this.machine.wind()) {
               return ManBallistaBehavior.this.resumeFromMachineState(villager);
            } else {
               this.winding = true;
               villager.setMotion(ManBallistaBehavior.WIND_MOTION);
               return StepResult.noOp();
            }
         } else if (ManBallistaBehavior.this.machine.settledStage() == BallistaStateMachine.Stage.WINDING) {
            return StepResult.noOp();
         } else {
            villager.setMotion(AnimationArchetype.IDLE);
            return ManBallistaBehavior.this.resumeFromMachineState(villager);
         }
      }
   }
}
