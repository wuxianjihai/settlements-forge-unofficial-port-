package dev.breezes.settlements.application.ai.behavior.usecases.villager.fishing;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.look.LookState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.items.ItemRegistry;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.conditions.NearbyWaterExistsCondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.entities.Expertise;
import dev.breezes.settlements.domain.entities.ISettlementsVillager;
import dev.breezes.settlements.domain.fishing.FishCatchEntry;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.projectiles.VillagerFishingHook;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public class FishingBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(FishingBehavior.class.getName());
   private static final ResourceLocation FISHING_ROD_ID = new ResourceLocation("minecraft", "fishing_rod");
   private static final double NAVIGATION_CLOSE_ENOUGH_DISTANCE = (double)5.0F;
   private static final int NAVIGATION_COMPLETION_DISTANCE = 3;
   private static final int HOOK_MAX_LIFETIME_BUFFER_SECONDS = 15;
   private static final double COLLECT_DISTANCE_SQUARED = (double)9.0F;
   private static final int MAX_CAST_RETRIES = 5;
   private static final int FIGHT_FISH_CYCLES = 2;
   private static final double DEFAULT_CATCH_RATE = 0.3;
   private final FishingConfig config;
   private final NearbyWaterExistsCondition<BaseVillager> nearbyWaterExistsCondition;
   @Nullable
   private BlockPos waterTarget;
   @Nullable
   private VillagerFishingHook activeHook;
   @Nullable
   private Entity fishedEntity;
   @Nullable
   private FishCatchEntry caughtFishEntry;
   @Nullable
   private ItemStack caughtItem;
   @Nullable
   private String caughtFishSize;
   private int castRetryCount;

   public FishingBehavior(@Nonnull FishingConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.nearbyWaterExistsCondition = NearbyWaterExistsCondition.<BaseVillager>builder().rangeHorizontal(config.scanRangeHorizontal()).rangeVertical(config.scanRangeVertical()).completionRange(3).minPondDepth(config.minPondDepth()).minPondRingWaterCount(config.minPondRingWaterCount()).build();
      this.preconditions.add(this.nearbyWaterExistsCondition);
      this.preconditions.add(support.getDemandSignalService().requireItem(new ItemMatch.ItemRef(FISHING_ROD_ID), 1, 50, this.getClass().getSimpleName()));
      this.initializeStateMachine(this.createControlStep(), FishingBehavior.FishingStage.END);
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      this.waterTarget = (BlockPos)this.nearbyWaterExistsCondition.getWaterTarget().orElse((Object)null);
      if (this.waterTarget == null) {
         log.behaviorWarn("Fishing behavior started without a water target; stopping");
         this.requestStop("Fishing behavior started without a water target");
      } else {
         Optional<BlockPos> shorePosition = this.nearbyWaterExistsCondition.getShorePosition();
         if (shorePosition.isEmpty()) {
            log.behaviorWarn("Fishing behavior started without a shore position for water target {}; stopping", this.waterTarget);
            this.requestStop("Fishing behavior started without a shore position");
         } else {
            PhysicalBlock shoreBlock = PhysicalBlock.of(Location.of((BlockPos)shorePosition.get(), villager.m_9236_()), villager.m_9236_().m_8055_((BlockPos)shorePosition.get()));
            context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromBlock(shoreBlock)));
            context.setState(BehaviorStateType.LOOK_TARGET, LookState.ofLocation(Location.of(this.waterTarget, villager.m_9236_())));
            log.behaviorStatus("Starting fishing behavior at shore position {} and water position {}", shorePosition, this.waterTarget);
            this.castRetryCount = 0;
         }
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      if (this.activeHook != null && !this.activeHook.m_213877_()) {
         this.activeHook.m_146870_();
      }

      if (this.fishedEntity != null && !this.fishedEntity.m_213877_()) {
         this.fishedEntity.m_146870_();
      }

      villager.setMotion(AnimationArchetype.IDLE);
      villager.clearHeldItem();
      villager.setBobberDeployed(false);
      this.waterTarget = null;
      this.activeHook = null;
      this.fishedEntity = null;
      this.caughtFishEntry = null;
      this.caughtItem = null;
      this.caughtFishSize = null;
      this.castRetryCount = 0;
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      if (this.activeHook == null) {
         return true;
      } else if (!this.activeHook.m_213877_()) {
         return true;
      } else {
         return this.activeHook.isMissedWater() && this.castRetryCount < 5;
      }
   }

   private StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("FishingBehavior").initialStage(FishingBehavior.FishingStage.NAVIGATE_TO_WATER).stageStepMap(Map.of(FishingBehavior.FishingStage.NAVIGATE_TO_WATER, this.createNavigateStep(), FishingBehavior.FishingStage.CAST_LINE, this.createCastLineStep(), FishingBehavior.FishingStage.WAIT_FOR_BITE, this.createWaitForBiteStep(), FishingBehavior.FishingStage.FIGHT_FISH, this.createFightFishStep(), FishingBehavior.FishingStage.REEL_IN, this.createReelInStep(), FishingBehavior.FishingStage.COLLECT_FISH, this.createCollectFishStep())).nextStage(FishingBehavior.FishingStage.END).build();
   }

   private BehaviorStep<BaseVillager> createNavigateStep() {
      TimeBasedStep<BaseVillager> arrivedStep = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.seconds((double)0.5F).asTickable()).onEnd((context) -> StepResult.transition(FishingBehavior.FishingStage.CAST_LINE)).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)5.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 3)).actionStep(arrivedStep).build();
   }

   private BehaviorStep<BaseVillager> createCastLineStep() {
      return TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.of(30L).asTickable()).onStart((context) -> {
         ISettlementsVillager villager = (ISettlementsVillager)context.getInitiator();
         ((BaseVillager)context.getInitiator()).triggerMotion(AnimationArchetype.CAST);
         villager.setHeldItem(((Item)ItemRegistry.VILLAGER_FISHING_ROD.get()).m_7968_());
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(17L), (context) -> {
         if (this.waterTarget == null) {
            log.behaviorWarn("No water target set during cast — stopping");
            return StepResult.fail("NO_WATER_TARGET");
         } else {
            BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
            return this.castHook(villager);
         }
      }).onEnd((context) -> StepResult.transition(FishingBehavior.FishingStage.WAIT_FOR_BITE)).build();
   }

   private BehaviorStep<BaseVillager> createWaitForBiteStep() {
      return TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.seconds((double)this.config.maxWaitTimeSeconds()).asTickable()).onStart((context) -> {
         ((BaseVillager)context.getInitiator()).getMinecraftEntity().setMotion(AnimationArchetype.FISHING_WAIT);
         return StepResult.noOp();
      }).addPeriodicStep(5, (context) -> {
         if (this.activeHook != null && this.activeHook.m_213877_() && this.activeHook.isMissedWater()) {
            if (this.castRetryCount < 5) {
               ++this.castRetryCount;
               log.behaviorStatus("Hook missed water (attempt {}/{}), retrying", this.castRetryCount, 5);
               this.activeHook = null;
               ((BaseVillager)context.getInitiator()).getMinecraftEntity().setBobberDeployed(false);
               return StepResult.transition(FishingBehavior.FishingStage.CAST_LINE);
            } else {
               log.behaviorWarn("Hook missed water, no retries left");
               ((BaseVillager)context.getInitiator()).getMinecraftEntity().setBobberDeployed(false);
               return StepResult.complete();
            }
         } else if (this.activeHook != null && this.activeHook.hasBitten()) {
            SoundRegistry.FISHING_SPLASH.playGlobally(Location.fromEntity(this.activeHook, false), SoundSource.NEUTRAL);
            log.behaviorStatus("Fish has bitten the hook!");
            return StepResult.transition(FishingBehavior.FishingStage.FIGHT_FISH);
         } else {
            return StepResult.noOp();
         }
      }).addPeriodicStep(ClockTicks.of(20L).getTicksAsInt(), (context) -> {
         ((BaseVillager)context.getInitiator()).setHeldItem(((Item)ItemRegistry.VILLAGER_FISHING_ROD.get()).m_7968_());
         return StepResult.noOp();
      }).onEnd((context) -> {
         if (this.activeHook != null && !this.activeHook.m_213877_()) {
            this.activeHook.m_146870_();
            this.activeHook = null;
         }

         ((BaseVillager)context.getInitiator()).getMinecraftEntity().setBobberDeployed(false);
         return StepResult.complete();
      }).build();
   }

   private BehaviorStep<BaseVillager> createFightFishStep() {
      return TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.of(48L).asTickable()).onStart((context) -> {
         BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
         Location villagerHead = Location.fromEntity(villager, true);
         villagerHead.displayParticles(ParticleTypes.f_123748_, 8, 0.3, 0.2, 0.3, 0.01);
         villagerHead.playSound(SoundEvents.f_12509_, 0.8F, 1.0F, SoundSource.NEUTRAL);
         villager.setMotion(AnimationArchetype.REEL_OUT);
         return StepResult.noOp();
      }).onEnd((context) -> StepResult.transition(FishingBehavior.FishingStage.REEL_IN)).build();
   }

   private BehaviorStep<BaseVillager> createReelInStep() {
      return TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.of(10L).asTickable()).onStart((context) -> {
         BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
         villager.triggerMotion(AnimationArchetype.REEL_IN);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(3L), (context) -> {
         if (this.activeHook != null && !this.activeHook.m_213877_()) {
            Location hookLocation = Location.fromEntity(this.activeHook, false);
            BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
            if (this.isEmptyCatch(villager)) {
               this.activeHook.m_146870_();
               this.fishedEntity = null;
               this.caughtFishEntry = null;
               this.caughtItem = null;
               this.caughtFishSize = null;
               this.showEmptyCatchSadness(villager);
            } else {
               this.fishedEntity = (Entity)this.activeHook.reelIn().orElse((Object)null);
               this.caughtFishEntry = this.activeHook.getSelectedCatchEntry();
               this.caughtItem = (ItemStack)this.fishToItem(this.caughtFishEntry).orElse((Object)null);
               this.caughtFishSize = this.activeHook.getSelectedCatchSize();
            }

            this.activeHook = null;
            ((BaseVillager)context.getInitiator()).getMinecraftEntity().setBobberDeployed(false);
            SoundRegistry.FISHING_SPLASH.playGlobally(hookLocation, SoundSource.NEUTRAL);
            SoundRegistry.FISHING_REEL.playGlobally(Location.fromEntity(villager, false), SoundSource.NEUTRAL);
            return StepResult.noOp();
         } else {
            ((BaseVillager)context.getInitiator()).getMinecraftEntity().setBobberDeployed(false);
            return StepResult.noOp();
         }
      }).onEnd((context) -> {
         ((BaseVillager)context.getInitiator()).getMinecraftEntity().setBobberDeployed(false);
         ((BaseVillager)context.getInitiator()).clearHeldItem();
         ((BaseVillager)context.getInitiator()).m_7292_(new MobEffectInstance(MobEffects.f_19617_, ClockTicks.seconds((double)30.0F).getTicksAsInt(), 9, true, true));
         return StepResult.transition(FishingBehavior.FishingStage.COLLECT_FISH);
      }).build();
   }

   private BehaviorStep<BaseVillager> createCollectFishStep() {
      return TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.seconds((double)3.0F).asTickable()).addPeriodicStep(5, (context) -> {
         if (this.fishedEntity != null && !this.fishedEntity.m_213877_()) {
            BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
            if (this.fishedEntity.m_20280_(villager) <= (double)9.0F) {
               Location.fromEntity(this.fishedEntity, false).displayParticles(ParticleTypes.f_123796_, 3, 0.1, 0.1, 0.1, 0.1);
               this.fishedEntity.m_146870_();
               return this.collectAndComplete(context);
            } else {
               return StepResult.noOp();
            }
         } else {
            return this.collectAndComplete(context);
         }
      }).onEnd((context) -> {
         if (this.fishedEntity != null && !this.fishedEntity.m_213877_()) {
            Location.fromEntity(this.fishedEntity, false).displayParticles(ParticleTypes.f_123796_, 3, 0.1, 0.1, 0.1, 0.1);
            this.fishedEntity.m_146870_();
         }

         return this.collectAndComplete(context);
      }).build();
   }

   private StepResult castHook(@Nonnull BaseVillager villager) {
      if (this.waterTarget == null) {
         log.behaviorWarn("No water target set during cast, stopping behavior");
         return StepResult.fail("NO_WATER_TARGET");
      } else {
         int baseMinBiteTicks = ClockTicks.seconds((double)this.config.minWaitTimeSeconds()).getTicksAsInt();
         int baseMaxBiteTicks = ClockTicks.seconds((double)this.config.maxWaitTimeSeconds()).getTicksAsInt();
         Expertise expertise = villager.getExpertise();
         double fishingTimeShortenScale = (Double)this.config.expertiseWaitTimeScale().getOrDefault(expertise.getConfigName(), (double)1.0F);
         int minBiteTicks = Math.max(1, (int)Math.round((double)baseMinBiteTicks * fishingTimeShortenScale));
         int maxBiteTicks = Math.max(minBiteTicks, (int)Math.round((double)baseMaxBiteTicks * fishingTimeShortenScale));
         int biteTimeTicks = RandomUtil.randomInt(minBiteTicks, maxBiteTicks, true);
         int maxLifetimeTicks = baseMaxBiteTicks + ClockTicks.seconds((double)15.0F).getTicksAsInt();
         double retryProgress = (double)(this.castRetryCount - 1) / (double)4.0F;
         double extraHorizontalRandomness = this.castRetryCount <= 0 ? (double)0.0F : 0.05 + 0.2 * retryProgress;
         double extraVerticalVelocity = (double)this.castRetryCount * 0.05;
         this.activeHook = new VillagerFishingHook(villager, this.waterTarget, biteTimeTicks, maxLifetimeTicks, extraHorizontalRandomness, extraVerticalVelocity);
         this.activeHook.castIntoWorld();
         villager.setBobberDeployed(true);
         SoundRegistry.FISHING_CAST.playGlobally(Location.fromEntity(villager, true), SoundSource.NEUTRAL);
         log.behaviorStatus("Casted fishing hook, fish will appear in {} ticks", biteTimeTicks);
         return StepResult.noOp();
      }
   }

   private boolean isEmptyCatch(@Nonnull BaseVillager villager) {
      Expertise expertise = villager.getExpertise();
      double catchRate = (Double)this.config.expertiseCatchRate().getOrDefault(expertise.getConfigName(), 0.3);
      return !RandomUtil.chance(RandomUtil.clamp(catchRate, (double)0.0F, (double)1.0F));
   }

   private void showEmptyCatchSadness(@Nonnull BaseVillager villager) {
      Location villagerHead = Location.fromEntity(villager, true);
      villagerHead.displayParticles(ParticleTypes.f_123792_, 6, 0.3, 0.2, 0.3, 0.01);
      villagerHead.playSound(SoundEvents.f_12507_, 0.8F, 1.0F, SoundSource.NEUTRAL);
      log.behaviorStatus("Villager reeled in nothing while fishing");
   }

   private StepResult collectAndComplete(@Nonnull BehaviorContext<BaseVillager> context) {
      if (this.caughtItem != null && !this.caughtItem.m_41619_()) {
         VillagerInventory inventory = ((BaseVillager)context.getInitiator()).getSettlementsInventory();
         inventory.add(this.caughtItem);
         this.rewardExperience(((BaseVillager)context.getInitiator()).getMinecraftEntity());
         SoundRegistry.ITEM_POP_IN.playGlobally(Location.fromEntity(((BaseVillager)context.getInitiator()).getMinecraftEntity(), false), SoundSource.NEUTRAL);
         log.behaviorStatus("Collected fish: {}", this.caughtItem);
         BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.FISH_CAUGHT, (String)null);
         outcome.markSucceeded();
         outcome.recordDeedDetail(this.describeCaughtFish());
         if (this.caughtItem != null) {
            outcome.putDetailField("item", BuiltInRegistries.f_257033_.m_7981_(this.caughtItem.m_41720_()).m_135815_());
         }

         if (this.caughtFishSize != null && !this.caughtFishSize.isBlank()) {
            outcome.putDetailField("size", this.caughtFishSize);
         }

         context.declarePrimaryDeed(outcome);
      }

      this.caughtItem = null;
      this.fishedEntity = null;
      this.caughtFishEntry = null;
      this.caughtFishSize = null;
      return StepResult.complete();
   }

   private String describeCaughtFish() {
      String itemId = this.caughtItem == null ? "fish" : this.caughtItem.m_41720_().toString();
      return this.caughtFishSize != null && !this.caughtFishSize.isBlank() ? this.caughtFishSize + " " + itemId : itemId;
   }

   private Optional<ItemStack> fishToItem(@Nullable FishCatchEntry catchEntry) {
      return catchEntry == null ? Optional.empty() : BuiltInRegistries.f_257033_.m_6612_(catchEntry.getItemId()).filter((item) -> item != Items.f_41852_).map(ItemStack::new);
   }

   private static enum FishingStage implements StageKey {
      NAVIGATE_TO_WATER,
      CAST_LINE,
      WAIT_FOR_BITE,
      FIGHT_FISH,
      REEL_IN,
      COLLECT_FISH,
      END;

      // $FF: synthetic method
      private static FishingStage[] $values() {
         return new FishingStage[]{NAVIGATE_TO_WATER, CAST_LINE, WAIT_FOR_BITE, FIGHT_FISH, REEL_IN, COLLECT_FISH, END};
      }
   }
}
