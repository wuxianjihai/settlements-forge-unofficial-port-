package dev.breezes.settlements.application.ai.behavior.usecases.wolf.walkdog;

import dev.breezes.settlements.application.ai.behavior.runtime.StateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.usecases.villager.idle.WalkDogBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetableType;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.RandomRangeTickable;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.infrastructure.minecraft.entities.wolves.SettlementsWolf;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class WolfWalkBehavior extends StateMachineBehavior<SettlementsWolf> {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(WolfWalkBehavior.class.getName());
   private static final double TARGET_CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private static final int NAVIGATION_COMPLETION_DISTANCE = 1;
   private static final double ENTITY_TARGET_CHANCE = 0.65;
   private static final double DIG_CHANCE = 0.35;
   private static final int DIG_EFFECT_INTERVAL_TICKS = 5;
   private final WolfWalkConfig config;
   private int elapsedTicks;

   public WolfWalkBehavior(@Nonnull WolfWalkConfig config) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable());
      this.config = config;
      this.elapsedTicks = 0;
      this.preconditions.add((ICondition)(wolf) -> wolf.isFollowOwnerLockedBy(WalkDogBehavior.class) && !wolf.m_21827_());
      this.continueConditions.add((ICondition)(wolf) -> wolf.isFollowOwnerLockedBy(WalkDogBehavior.class));
      this.continueConditions.add((ICondition)(wolf) -> Optional.ofNullable(wolf.getOwner()).filter(LivingEntity::m_6084_).filter((owner) -> !owner.m_213877_()).isPresent());
      this.initializeStateMachine(this.createControlStep(), WolfWalkBehavior.WolfWalkStage.END);
   }

   private StagedStep<SettlementsWolf> createControlStep() {
      return StagedStep.<SettlementsWolf>builder().name("WolfWalkBehavior").initialStage(WolfWalkBehavior.WolfWalkStage.PICK_TARGET).stageStepMap(Map.of(WolfWalkBehavior.WolfWalkStage.PICK_TARGET, this.createPickTargetStep(), WolfWalkBehavior.WolfWalkStage.WALK_TO_TARGET, this.createWalkToTargetStep(), WolfWalkBehavior.WolfWalkStage.SNIFF, this.createSniffStep(), WolfWalkBehavior.WolfWalkStage.DIG, this.createDigStep())).nextStage(WolfWalkBehavior.WolfWalkStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   private BehaviorStep<SettlementsWolf> createPickTargetStep() {
      return (context) -> {
         if ((long)this.elapsedTicks >= ClockTicks.seconds((double)this.config.walkDurationSeconds()).getTicks()) {
            log.behaviorTrace("Walk duration elapsed ({} ticks), ending", this.elapsedTicks);
            return StepResult.transition(WolfWalkBehavior.WolfWalkStage.END);
         } else {
            SettlementsWolf wolf = (SettlementsWolf)context.getInitiator();
            log.behaviorTrace("Picking target for wolf {} | pos={}", wolf.m_20148_(), wolf.m_20183_());
            Optional<Targetable> target = RandomUtil.chance(0.65) ? this.pickEntityTarget(wolf).or(() -> this.pickBlockTarget(wolf)) : this.pickBlockTarget(wolf).or(() -> this.pickEntityTarget(wolf));
            if (target.isEmpty()) {
               log.behaviorTrace("No target found, ending behavior");
               return StepResult.transition(WolfWalkBehavior.WolfWalkStage.END);
            } else {
               log.behaviorTrace("Picked target: type={} | loc={}", ((Targetable)target.get()).getType(), ((Targetable)target.get()).getLocation());
               context.setState(BehaviorStateType.TARGET, TargetState.of((Targetable)target.get()));
               return StepResult.transition(WolfWalkBehavior.WolfWalkStage.WALK_TO_TARGET);
            }
         }
      };
   }

   private BehaviorStep<SettlementsWolf> createWalkToTargetStep() {
      return StayCloseStep.<SettlementsWolf>builder().closeEnoughDistance((double)2.0F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.RUN).completionDistance(1).reachabilityGated(false).build()).actionStep((ctx) -> StepResult.transition(WolfWalkBehavior.WolfWalkStage.SNIFF)).build();
   }

   private BehaviorStep<SettlementsWolf> createSniffStep() {
      return TimeBasedStep.<SettlementsWolf>builder().withTickable(RandomRangeTickable.of(ClockTicks.seconds((double)this.config.sniffDurationMinSeconds()), ClockTicks.seconds((double)this.config.sniffDurationMaxSeconds()))).everyTick(this::lookAtTarget).everyTick(this::followMovingEntityTarget).onEnd((context) -> this.shouldDig(context) ? StepResult.transition(WolfWalkBehavior.WolfWalkStage.DIG) : StepResult.transition(WolfWalkBehavior.WolfWalkStage.PICK_TARGET)).build();
   }

   private BehaviorStep<SettlementsWolf> createDigStep() {
      return TimeBasedStep.<SettlementsWolf>builder().withTickable(RandomRangeTickable.of(ClockTicks.seconds((double)this.config.digDurationMinSeconds()), ClockTicks.seconds((double)this.config.digDurationMaxSeconds()))).addPeriodicStep(5, this::playDigEffects).onEnd((ctx) -> StepResult.transition(WolfWalkBehavior.WolfWalkStage.PICK_TARGET)).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull SettlementsWolf entity, @Nonnull BehaviorContext<SettlementsWolf> context) {
      this.elapsedTicks = 0;
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull SettlementsWolf entity) {
      entity.getNavigationManager().stop();
      entity.unlockFollowOwner(WalkDogBehavior.class);
      this.elapsedTicks = 0;
   }

   public boolean tickContinueConditions(int delta, @Nonnull Level world, @Nonnull SettlementsWolf entity) {
      this.elapsedTicks += delta;
      return super.tickContinueConditions(delta, world, entity);
   }

   private Optional<Targetable> pickEntityTarget(@Nonnull SettlementsWolf wolf) {
      BaseVillager owner = wolf.getOwner();
      AABB scanBox = wolf.m_20191_().m_82400_((double)this.config.entityTargetScanRange());
      List<Entity> targets = wolf.m_9236_().m_6249_(wolf, scanBox, (entity) -> isSniffableEntity(wolf, owner, entity));
      log.behaviorTrace("Entity scan found {} candidates (range={})", targets.size(), this.config.entityTargetScanRange());
      return targets.isEmpty() ? Optional.empty() : Optional.of(Targetable.fromEntity((Entity)RandomUtil.choice(targets).orElseThrow()));
   }

   private Optional<Targetable> pickBlockTarget(@Nonnull SettlementsWolf wolf) {
      Vec3 randomTarget = DefaultRandomPos.m_148403_(wolf, this.config.blockTargetHorizontalRange(), this.config.blockTargetVerticalRange());
      if (randomTarget == null) {
         return Optional.empty();
      } else {
         BlockPos blockPos = BlockPos.m_274446_(randomTarget).m_7495_();
         BlockState blockState = wolf.m_9236_().m_8055_(blockPos);
         if (blockState.m_60795_()) {
            log.behaviorTrace("Block target pos {} is air, skipping", blockPos);
            return Optional.empty();
         } else {
            log.behaviorTrace("Block target: {}", blockPos);
            return Optional.of(Targetable.fromBlock(PhysicalBlock.of(Location.of(blockPos, wolf.m_9236_()), blockState)));
         }
      }
   }

   private static boolean isSniffableEntity(@Nonnull SettlementsWolf wolf, @Nullable BaseVillager owner, @Nonnull Entity entity) {
      if (entity.m_6084_() && !entity.m_213877_() && entity != owner) {
         return entity.m_6095_() == EntityType.f_20532_ || entity.m_6095_() == EntityType.f_20461_ || entity instanceof AbstractVillager;
      } else {
         return false;
      }
   }

   protected boolean shouldLookAtActiveTarget() {
      return false;
   }

   private StepResult lookAtTarget(@Nonnull BehaviorContext<SettlementsWolf> context) {
      SettlementsWolf wolf = context.getInitiator();
      context.getState(BehaviorStateType.TARGET, TargetState.class).flatMap(TargetState::getFirst).map(Targetable::getLocation).ifPresent((location) -> wolf.m_21563_().m_24964_(location.toVec3()));
      return StepResult.noOp();
   }

   private StepResult followMovingEntityTarget(@Nonnull BehaviorContext<SettlementsWolf> context) {
      SettlementsWolf wolf = context.getInitiator();
      context.getState(BehaviorStateType.TARGET, TargetState.class).flatMap(TargetState::getFirst).filter((target) -> target.getType() == TargetableType.ENTITY).map(Targetable::getAsEntity).filter(Entity::m_6084_).map((entity) -> Location.fromEntity(entity, false)).ifPresent((location) -> {
         if (location.distanceSquared((Entity)wolf) > (double)4.0F) {
            wolf.getNavigationManager().navigateTo(location, NavigationType.RUN, 1);
         } else {
            wolf.getNavigationManager().stop();
         }

      });
      return StepResult.noOp();
   }

   private boolean shouldDig(@Nonnull BehaviorContext<SettlementsWolf> context) {
      return RandomUtil.chance(0.35) && (Boolean)context.getState(BehaviorStateType.TARGET, TargetState.class).flatMap(TargetState::getFirst).map((target) -> target.getType() == TargetableType.BLOCK).orElse(false);
   }

   private StepResult playDigEffects(@Nonnull BehaviorContext<SettlementsWolf> context) {
      SettlementsWolf wolf = context.getInitiator();
      BlockPos blockPosBelow = wolf.m_20183_().m_7495_();
      BlockState blockStateBelow = wolf.m_9236_().m_8055_(blockPosBelow);
      if (blockStateBelow.m_60795_()) {
         return StepResult.noOp();
      } else {
         Location effectLocation = Location.of(blockPosBelow, wolf.m_9236_()).center(true);
         ParticleRegistry.digBlockCrack(effectLocation.add((double)0.0F, 0.9, (double)0.0F, true), blockStateBelow);
         effectLocation.playSound(blockStateBelow.getSoundType(wolf.m_9236_(), blockPosBelow, (Entity)null).m_56775_(), 0.3F, 1.4F, SoundSource.NEUTRAL);
         return StepResult.noOp();
      }
   }

   private static enum WolfWalkStage implements StageKey {
      PICK_TARGET,
      WALK_TO_TARGET,
      SNIFF,
      DIG,
      END;

      // $FF: synthetic method
      private static WolfWalkStage[] $values() {
         return new WolfWalkStage[]{PICK_TARGET, WALK_TO_TARGET, SNIFF, DIG, END};
      }
   }
}
