package dev.breezes.settlements.application.ai.behavior.usecases.villager.logistics;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.LoopBackStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.OneShotStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.economy.demand.ActiveDemand;
import dev.breezes.settlements.application.economy.demand.DemandEvaluator;
import dev.breezes.settlements.application.economy.supply.ActiveSupply;
import dev.breezes.settlements.application.economy.supply.SupplyEvaluator;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatches;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.compat.Capabilities;
import dev.breezes.settlements.infrastructure.minecraft.chest.ChestWaxService;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemHandlerHelper;

public class ManageChestsBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ManageChestsBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private static final int NAVIGATION_COMPLETION_DISTANCE = 1;
   private static final int APPROACH_TIMEOUT_TICKS = ClockTicks.seconds((double)20.0F).getTicksAsInt();
   private static final int TAKE_AT_LEAST_COUNT = 8;
   private static final int MAX_CHESTS_PER_RUN = 4;
   private final ChestInteractionCondition chestCondition;
   private final DemandEvaluator demandEvaluator;
   private final SupplyEvaluator supplyEvaluator;
   private final List<BlockPos> reachableChests = new ArrayList();
   private final Set<BlockPos> visited = new HashSet();
   @Nullable
   private BlockPos currentChestPos;
   private final Map<String, Integer> takenByItem = new HashMap();
   private final Map<String, Integer> storedByItem = new HashMap();
   private int takenTotal;
   private int storedTotal;

   public ManageChestsBehavior(@Nonnull ManageChestsConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.demandEvaluator = support.getDemandEvaluator();
      this.supplyEvaluator = support.getSupplyEvaluator();
      this.chestCondition = new ChestInteractionCondition(this.demandEvaluator, this.supplyEvaluator, 1);
      this.preconditions.add(this.chestCondition);
      this.initializeStateMachine(this.createControlStep(), ManageChestsBehavior.Stage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      Map<StageKey, BehaviorStep<BaseVillager>> stageMap = new HashMap();
      stageMap.put(ManageChestsBehavior.Stage.PICK_CHEST, this.createPickChestStep());
      stageMap.put(ManageChestsBehavior.Stage.APPROACH_CHEST, StayCloseStep.builder().closeEnoughDistance((double)2.0F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.WALK).completionDistance(1).unreachableTransition(ManageChestsBehavior.Stage.PICK_CHEST).build()).actionStep(OneShotStep.builder().name("ArrivedAtChest").action((ctx) -> this.onArrivedAtChest()).build()).timeoutTicks(APPROACH_TIMEOUT_TICKS).timeoutTransition(ManageChestsBehavior.Stage.PICK_CHEST).build());
      stageMap.put(ManageChestsBehavior.Stage.INTERACT, this.createInteractStep());
      stageMap.put(ManageChestsBehavior.Stage.LOOP, LoopBackStep.builder().name("ManageChestsLoopBack").loopBackTo(ManageChestsBehavior.Stage.PICK_CHEST).completionTransition(ManageChestsBehavior.Stage.END).maxIterationsResolver((ctx) -> 4).build());
      return StagedStep.<BaseVillager>builder().name("ManageChestsBehavior").initialStage(ManageChestsBehavior.Stage.PICK_CHEST).stageStepMap(stageMap).nextStage(ManageChestsBehavior.Stage.END).build();
   }

   private BehaviorStep<BaseVillager> createPickChestStep() {
      return OneShotStep.<BaseVillager>builder().name("PickNextChest").action((ctx) -> {
         BaseVillager villager = (BaseVillager)ctx.getInitiator();
         Level level = villager.m_9236_();
         List<ActiveDemand> demands = this.demandEvaluator.resolve(villager);
         List<ActiveSupply> supplies = this.supplyEvaluator.resolve(villager);

         for(BlockPos chestPos : this.reachableChests) {
            if (!this.visited.contains(chestPos)) {
               if (ChestWaxService.isWaxed(level, chestPos)) {
                  this.visited.add(chestPos);
               } else {
                  IItemHandler handler = Capabilities.ItemHandler.getLevelCapability(level, chestPos, (Direction)null);
                  if (handler == null) {
                     this.visited.add(chestPos);
                  } else if (ChestInteractionCondition.chestHasWork(handler, demands, supplies)) {
                     this.visited.add(chestPos);
                     this.currentChestPos = chestPos;
                     PhysicalBlock block = PhysicalBlock.of(Location.of(chestPos, level), level.m_8055_(chestPos));
                     ctx.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromBlock(block)));
                     return StepResult.transition(ManageChestsBehavior.Stage.APPROACH_CHEST);
                  }
               }
            }
         }

         return StepResult.transition(ManageChestsBehavior.Stage.END);
      }).build();
   }

   private StepResult onArrivedAtChest() {
      return this.currentChestPos == null ? StepResult.transition(ManageChestsBehavior.Stage.PICK_CHEST) : StepResult.transition(ManageChestsBehavior.Stage.INTERACT);
   }

   private BehaviorStep<BaseVillager> createInteractStep() {
      return TimeBasedStep.<BaseVillager>builder().name("ManageChestInteract").withTickable(ClockTicks.seconds((double)1.0F).asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(5L), (ctx) -> {
         BlockPos chestPos = this.currentChestPos;
         if (chestPos == null) {
            return StepResult.noOp();
         } else {
            BaseVillager villager = (BaseVillager)ctx.getInitiator();
            Level level = villager.m_9236_();
            if (ChestWaxService.isWaxed(level, chestPos)) {
               return StepResult.noOp();
            } else {
               IItemHandler handler = Capabilities.ItemHandler.getLevelCapability(level, chestPos, (Direction)null);
               if (handler == null) {
                  return StepResult.noOp();
               } else {
                  int taken = this.takeDemandedItems(villager, handler, chestPos);
                  int stored = this.depositSurplus(villager, handler, chestPos);
                  int moved = taken + stored;
                  if (moved > 0) {
                     this.recordMove(ctx, moved);
                     SoundRegistry.MANAGE_CHEST.playGlobally(Location.of(chestPos, villager.m_9236_()), SoundSource.BLOCKS);
                  }

                  return StepResult.noOp();
               }
            }
         }
      }).onEnd((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         ((BaseVillager)ctx.getInitiator()).setMotion(AnimationArchetype.IDLE);
         return StepResult.transition(ManageChestsBehavior.Stage.LOOP);
      }).build();
   }

   private int takeDemandedItems(@Nonnull BaseVillager villager, @Nonnull IItemHandler handler, @Nonnull BlockPos chestPos) {
      List<ActiveDemand> demands = this.demandEvaluator.resolve(villager);
      int takenHere = 0;

      for(ActiveDemand demand : demands) {
         int extractedForDemand = 0;

         for(int slot = 0; slot < handler.getSlots(); ++slot) {
            ItemStack stackInSlot = handler.getStackInSlot(slot);
            if (!stackInSlot.m_41619_() && ItemMatches.test(demand.match(), stackInSlot)) {
               int targetTakeCount = calculateTargetTakeCount(stackInSlot, demand.desiredCount());
               int needed = targetTakeCount - extractedForDemand;
               if (needed <= 0) {
                  break;
               }

               ItemStack extracted = handler.extractItem(slot, needed, false);
               if (!extracted.m_41619_()) {
                  extractedForDemand += extracted.m_41613_();
                  takenHere += extracted.m_41613_();
                  villager.getSettlementsInventory().add(extracted);
                  villager.setHeldItem(extracted.m_255036_(1));
                  this.recordTaken(extracted.m_41720_().toString(), extracted.m_41613_());
                  if (extractedForDemand >= targetTakeCount) {
                     break;
                  }
               }
            }
         }
      }

      return takenHere;
   }

   private int depositSurplus(@Nonnull BaseVillager villager, @Nonnull IItemHandler handler, @Nonnull BlockPos chestPos) {
      List<ActiveSupply> supplies = this.supplyEvaluator.resolve(villager);
      int storedHere = 0;

      for(ActiveSupply supply : supplies) {
         int targetCount = ChestInteractionCondition.computeDepositTargetCount(supply);
         if (targetCount > 0) {
            ItemStack candidate = supply.representative().m_255036_(targetCount);
            int acceptedCount = ChestInteractionCondition.simulateAcceptedCount(handler, candidate);
            if (acceptedCount > 0) {
               ItemStack consumedStack = supply.representative().m_255036_(acceptedCount);
               int consumed = villager.getSettlementsInventory().consume(consumedStack, acceptedCount);
               if (consumed > 0) {
                  ItemStack toInsert = supply.representative().m_255036_(consumed);
                  ItemStack remainder = ItemHandlerHelper.insertItemStacked(handler, toInsert, false);
                  if (!remainder.m_41619_()) {
                     villager.getSettlementsInventory().add(remainder);
                  }

                  int inserted = consumed - remainder.m_41613_();
                  if (inserted > 0) {
                     storedHere += inserted;
                     villager.setHeldItem(toInsert.m_255036_(1));
                     this.recordStored(toInsert.m_41720_().toString(), inserted);
                  }
               }
            }
         }
      }

      return storedHere;
   }

   private void recordTaken(@Nonnull String itemDescription, int count) {
      this.takenByItem.merge(itemDescription, count, Integer::sum);
      this.takenTotal += count;
   }

   private void recordStored(@Nonnull String itemDescription, int count) {
      this.storedByItem.merge(itemDescription, count, Integer::sum);
      this.storedTotal += count;
   }

   private void recordMove(@Nonnull BehaviorContext<BaseVillager> ctx, int movedThisLeg) {
      BehaviorOutcome outcome = (BehaviorOutcome)ctx.primaryDeed().orElseGet(() -> ctx.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.CHEST_MANAGED, (String)null)));
      this.writeDetailFields(outcome);
      outcome.recordYield(movedThisLeg);
   }

   private void writeDetailFields(@Nonnull BehaviorOutcome outcome) {
      if (this.takenTotal > 0) {
         outcome.putDetailField("takenItems", formatItemList(this.takenByItem));
      }

      if (this.storedTotal > 0) {
         outcome.putDetailField("storedItems", formatItemList(this.storedByItem));
      }

   }

   private static String formatItemList(@Nonnull Map<String, Integer> byItem) {
      return (String)byItem.entrySet().stream().sorted(Entry.comparingByValue().reversed()).map((entry) -> {
         String var10000 = String.valueOf(entry.getValue());
         return var10000 + " " + (String)entry.getKey();
      }).collect(Collectors.joining("; "));
   }

   private static int calculateTargetTakeCount(@Nonnull ItemStack stack, int desiredCount) {
      int itemAwareMinimum = Math.min(8, stack.m_41741_());
      return Math.max(desiredCount, itemAwareMinimum);
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      List<BlockPos> reachable = this.chestCondition.getReachableChests();
      if (reachable.isEmpty()) {
         this.requestStop("No reachable village chests with logistics work found");
      } else {
         this.reachableChests.clear();
         this.reachableChests.addAll(reachable);
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.reachableChests.clear();
      this.visited.clear();
      this.currentChestPos = null;
      this.takenByItem.clear();
      this.storedByItem.clear();
      this.takenTotal = 0;
      this.storedTotal = 0;
   }

   private static enum Stage implements StageKey {
      PICK_CHEST,
      APPROACH_CHEST,
      INTERACT,
      LOOP,
      END;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{PICK_CHEST, APPROACH_CHEST, INTERACT, LOOP, END};
      }
   }
}
