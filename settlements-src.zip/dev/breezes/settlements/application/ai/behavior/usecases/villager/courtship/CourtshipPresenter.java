package dev.breezes.settlements.application.ai.behavior.usecases.villager.courtship;

import dev.breezes.settlements.application.ai.courtship.ChoreographyTimeline;
import dev.breezes.settlements.application.ai.courtship.CourtshipBeat;
import dev.breezes.settlements.application.ai.courtship.CourtshipChoreographyLibrary;
import dev.breezes.settlements.application.ai.courtship.CourtshipCloseReason;
import dev.breezes.settlements.application.ai.courtship.CourtshipRole;
import dev.breezes.settlements.application.ai.courtship.CourtshipSession;
import dev.breezes.settlements.application.ui.bubble.BubbleChannel;
import dev.breezes.settlements.application.ui.bubble.BubbleCommand;
import dev.breezes.settlements.application.ui.bubble.BubbleMessage;
import dev.breezes.settlements.application.ui.bubble.BubbleSegment;
import dev.breezes.settlements.application.ui.bubble.VillagerBubbleService;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

@ServerScope
public final class CourtshipPresenter {
   private static final ClockTicks APPROACH_BUBBLE_TTL = ClockTicks.seconds((double)10.0F);
   private static final ClockTicks BEAT_BUBBLE_TTL = ClockTicks.seconds((double)4.0F);
   private static final ClockTicks BIRTH_BUBBLE_TTL = ClockTicks.seconds((double)3.0F);
   private static final ClockTicks DATE_BUBBLE_TTL = ClockTicks.seconds((double)3.0F);
   private static final ClockTicks FAILURE_BUBBLE_TTL = ClockTicks.seconds((double)4.0F);
   private static final String COURTSHIP_SOURCE = "courtship";
   private static final BubbleSegment POPPY_ICON;
   private static final BubbleSegment BED_ICON;
   private static final BubbleSegment CLOCK_ICON;
   private static final BubbleSegment BREAD_ICON;
   private static final BubbleSegment FAILURE_CROSS;
   private static final BubbleSegment PARTNER_GONE_MARK;
   private final VillagerBubbleService villagerBubbleService;
   private final CourtshipChoreographyLibrary choreographyLibrary;

   public void presentApproach(@Nonnull CourtshipSession session, @Nonnull BaseVillager self) {
      self.setHeldItem(new ItemStack(Items.f_41940_));
      this.upsert(self, session, BubbleMessage.builder().priority(10).ttl(APPROACH_BUBBLE_TTL).sourceType("courtship").segments(List.of(POPPY_ICON)).build());
   }

   public void presentBeat(@Nonnull CourtshipSession session, @Nonnull BaseVillager self, int beatIndex) {
      CourtshipRole role = CourtshipRole.of(self.m_20148_(), session.partnerOf(self.m_20148_()));
      ChoreographyTimeline timeline = this.choreographyLibrary.get(session.getChoreographyId());
      CourtshipBeat beat = timeline.beatAt(beatIndex);
      self.triggerMotion(beat.motionFor(role));
      Location.fromEntity(self, true).displayParticles(ParticleTypes.f_123750_, 3, 0.3, 0.3, 0.3, 0.01);
      Optional.ofNullable(beat.sound()).ifPresent((soundEvent) -> Location.fromEntity(self, true).playSound(soundEvent, 0.5F, 1.1F, SoundSource.NEUTRAL));
      this.upsert(self, session, BubbleMessage.builder().priority(10).ttl(BEAT_BUBBLE_TTL).sourceType("courtship").segments(List.of(POPPY_ICON)).build());
   }

   public void presentBirth(@Nonnull CourtshipSession session, @Nonnull BaseVillager presenter, @Nonnull BaseVillager receiver) {
      Location midpoint = Location.of((presenter.m_20185_() + receiver.m_20185_()) / (double)2.0F, (presenter.m_20188_() + receiver.m_20188_()) / (double)2.0F, (presenter.m_20189_() + receiver.m_20189_()) / (double)2.0F, presenter.m_9236_());
      midpoint.displayParticles(ParticleTypes.f_123750_, 12, (double)0.5F, (double)0.5F, (double)0.5F, 0.02);
      midpoint.displayParticles(ParticleTypes.f_123748_, 8, (double)0.5F, (double)0.5F, (double)0.5F, 0.01);
      midpoint.playSound(SoundEvents.f_12504_, 1.0F, 1.0F, SoundSource.NEUTRAL);
      this.upsertResult(presenter, session, BubbleMessage.builder().priority(15).ttl(BIRTH_BUBBLE_TTL).sourceType("courtship").segments(List.of(POPPY_ICON)).build());
      this.upsertResult(receiver, session, BubbleMessage.builder().priority(15).ttl(BIRTH_BUBBLE_TTL).sourceType("courtship").segments(List.of(POPPY_ICON)).build());
   }

   public void presentDate(@Nonnull CourtshipSession session, @Nonnull BaseVillager presenter, @Nonnull BaseVillager receiver) {
      Location midpoint = Location.of((presenter.m_20185_() + receiver.m_20185_()) / (double)2.0F, (presenter.m_20188_() + receiver.m_20188_()) / (double)2.0F, (presenter.m_20189_() + receiver.m_20189_()) / (double)2.0F, presenter.m_9236_());
      midpoint.displayParticles(ParticleTypes.f_123750_, 5, (double)0.5F, (double)0.5F, (double)0.5F, 0.02);
      midpoint.playSound(SoundEvents.f_12509_, 1.0F, 1.0F, SoundSource.NEUTRAL);
      this.upsertResult(presenter, session, BubbleMessage.builder().priority(15).ttl(DATE_BUBBLE_TTL).sourceType("courtship").segments(List.of(POPPY_ICON)).build());
      this.upsertResult(receiver, session, BubbleMessage.builder().priority(15).ttl(DATE_BUBBLE_TTL).sourceType("courtship").segments(List.of(POPPY_ICON)).build());
   }

   public void presentAbort(@Nonnull CourtshipSession session, @Nonnull BaseVillager self, @Nonnull CourtshipCloseReason reason) {
      Location location = Location.fromEntity(self, true);
      location.displayParticles(ParticleTypes.f_123792_, 3, 0.2, 0.2, 0.2, 0.1);
      location.playSound(SoundEvents.f_12507_, 0.8F, 1.0F, SoundSource.NEUTRAL);
      List<BubbleSegment> reasonSegments = failureSegments(reason);
      if (reasonSegments.isEmpty()) {
         this.removeByOwner(self, session, self.m_9236_().m_46467_());
      } else {
         this.upsertResult(self, session, BubbleMessage.builder().priority(15).ttl(FAILURE_BUBBLE_TTL).sourceType("courtship").segments(reasonSegments).build());
      }
   }

   private static List<BubbleSegment> failureSegments(@Nonnull CourtshipCloseReason reason) {
      List var10000;
      switch (reason) {
         case REJECTED_CHARISMA:
            var10000 = List.of(POPPY_ICON, FAILURE_CROSS);
            break;
         case ABORTED_NO_BED:
            var10000 = List.of(BED_ICON, FAILURE_CROSS);
            break;
         case TIMEOUT:
            var10000 = List.of(CLOCK_ICON, FAILURE_CROSS);
            break;
         case ABORTED_WILLINGNESS:
            var10000 = List.of(BREAD_ICON, FAILURE_CROSS);
            break;
         case ABORTED_PARTNER_GONE:
            var10000 = List.of(PARTNER_GONE_MARK, FAILURE_CROSS);
            break;
         case ABORTED_SPAWN_FAILED:
            var10000 = List.of(FAILURE_CROSS);
            break;
         case COMPLETED:
         case EXTERNAL_CANCEL:
            var10000 = List.of();
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   public void presentEnd(@Nonnull BaseVillager self, @Nonnull UUID sessionId, long gameTime) {
      self.clearHeldItem();
      self.setMotion(AnimationArchetype.IDLE);
      this.villagerBubbleService.applyCommand(self, new BubbleCommand.RemoveByOwner(BubbleChannel.BEHAVIOR, ownerKey(sessionId)), gameTime);
   }

   private void upsert(@Nonnull BaseVillager self, @Nonnull CourtshipSession session, @Nonnull BubbleMessage message) {
      this.villagerBubbleService.applyCommand(self, new BubbleCommand.Upsert(BubbleChannel.BEHAVIOR, ownerKey(session.getSessionId()), message), self.m_9236_().m_46467_());
   }

   private void upsertResult(@Nonnull BaseVillager self, @Nonnull CourtshipSession session, @Nonnull BubbleMessage message) {
      this.villagerBubbleService.applyCommand(self, new BubbleCommand.Upsert(BubbleChannel.BEHAVIOR, resultOwnerKey(session.getSessionId()), message), self.m_9236_().m_46467_());
   }

   private void removeByOwner(@Nonnull BaseVillager self, @Nonnull CourtshipSession session, long gameTime) {
      this.villagerBubbleService.applyCommand(self, new BubbleCommand.RemoveByOwner(BubbleChannel.BEHAVIOR, ownerKey(session.getSessionId())), gameTime);
   }

   private static String ownerKey(@Nonnull UUID sessionId) {
      return "courtship-" + String.valueOf(sessionId);
   }

   private static String resultOwnerKey(@Nonnull UUID sessionId) {
      return "courtship-result-" + String.valueOf(sessionId);
   }

   @Inject
   @Generated
   CourtshipPresenter(VillagerBubbleService villagerBubbleService, CourtshipChoreographyLibrary choreographyLibrary) {
      this.villagerBubbleService = villagerBubbleService;
      this.choreographyLibrary = choreographyLibrary;
   }

   static {
      POPPY_ICON = BubbleSegment.Item.iconOnly(BuiltInRegistries.f_257033_.m_7981_(Items.f_41940_));
      BED_ICON = BubbleSegment.Item.iconOnly(BuiltInRegistries.f_257033_.m_7981_(Items.f_42570_));
      CLOCK_ICON = BubbleSegment.Item.iconOnly(BuiltInRegistries.f_257033_.m_7981_(Items.f_42524_));
      BREAD_ICON = BubbleSegment.Item.iconOnly(BuiltInRegistries.f_257033_.m_7981_(Items.f_42406_));
      FAILURE_CROSS = BubbleSegment.Text.builder().literal("✖").color(ChatFormatting.RED).bold(true).scale(0.9F).build();
      PARTNER_GONE_MARK = BubbleSegment.Text.builder().literal("?").color(ChatFormatting.BLACK).bold(true).scale(1.0F).build();
   }
}
