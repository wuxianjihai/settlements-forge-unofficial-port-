package dev.breezes.settlements.application.ai.behavior.usecases.villager.ballista;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.threat.CombatOption;
import dev.breezes.settlements.application.ai.threat.CombatReadiness;
import dev.breezes.settlements.bootstrap.registry.items.ItemRegistry;
import dev.breezes.settlements.domain.ai.behavior.contracts.IBehavior;
import dev.breezes.settlements.domain.ai.catalog.BehaviorDisplayMetadata;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.domain.genetics.GeneType;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.blocks.ballista.BallistaBlockEntity;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.ResourceLocationUtil;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.raid.Raid;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public final class BallistaCombatOption implements CombatOption {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(BallistaCombatOption.class.getName());
   private static final double APPROACH_RANGE_BLOCKS = (double)24.0F;
   private static final double ENGAGEMENT_RANGE_BLOCKS = (double)48.0F;
   static final double LOCK_RANGE_BLOCKS = (double)128.0F;
   private static final double RAID_INTELLIGENCE_RELIEF = 0.2;
   private static final ClockTicks REFUSAL_MEMORY = ClockTicks.seconds((double)20.0F);
   private static final String PREPARE_DIAG_KEY = "settlements_ballista_prepare_diag";
   private static final BehaviorDisplayMetadata DISPLAY_INFO = BehaviorDisplayMetadata.builder().displayNameKey("ui.settlements.behavior.combat.man_ballista").iconItemId(ResourceLocationUtil.mod("ballista")).build();
   private final BehaviorSupport support;
   private final BallistaOperationConfig config;
   private final BallistaShotChecks shotChecks = new BallistaShotChecks();

   @Inject
   BallistaCombatOption(BehaviorSupport support, BallistaOperationConfig config) {
      this.support = support;
      this.config = config;
   }

   public double nerveContribution() {
      return (double)8.0F;
   }

   public double reachBlocks() {
      return (double)152.0F;
   }

   @Nullable
   public Readiness prepare(@Nonnull BaseVillager villager) {
      Level var3 = villager.m_9236_();
      if (var3 instanceof ServerLevel level) {
         if (this.isEligible(level, villager)) {
            boolean holdsBolt = hasBoltInInventory(villager);
            Set<GlobalPos> refused = refusedMachines(villager);
            List<BlockPos> usableMachines = new ArrayList();
            List<GlobalPos> known = knownMachines(villager);

            for(GlobalPos site : known) {
               if (isAvailable(level, villager, site, refused, holdsBolt)) {
                  usableMachines.add(site.m_122646_());
               }
            }

            if (usableMachines.isEmpty()) {
               this.logPrepareReject(villager, level, known, refused, holdsBolt);
               return null;
            }

            usableMachines.sort(Comparator.comparingDouble((pos) -> villager.m_20275_((double)pos.m_123341_() + (double)0.5F, (double)pos.m_123342_(), (double)pos.m_123343_() + (double)0.5F)));
            return new Readiness(level, this.shotChecks, usableMachines, engagementRangeBlocks(isRaidActive(level, villager)));
         }
      }

      return null;
   }

   private void logPrepareReject(@Nonnull BaseVillager villager, @Nonnull ServerLevel level, @Nonnull List<GlobalPos> known, @Nonnull Set<GlobalPos> refused, boolean holdsBolt) {
      long now = level.m_46467_();
      CompoundTag persistent = villager.getPersistentData();
      if (persistent.m_128454_("settlements_ballista_prepare_diag") <= now) {
         persistent.m_128356_("settlements_ballista_prepare_diag", now + 400L);
         if (known.isEmpty()) {
            log.info("[ballista-prepare] villager {} ({}): no usable machine — BALLISTA_SITES empty (known=0 refused={} holdsBolt={})", villager.m_20148_(), villager.getProfession(), refused.size(), holdsBolt);
         } else {
            StringBuilder detail = new StringBuilder();

            for(GlobalPos site : known) {
               if (detail.length() > 0) {
                  detail.append("; ");
               }

               detail.append(describeSite(level, villager, site, refused, holdsBolt));
            }

            log.info("[ballista-prepare] villager {} ({}): no usable machine (known={} refused={} holdsBolt={}) — [{}]", villager.m_20148_(), villager.getProfession(), known.size(), refused.size(), holdsBolt, detail);
         }
      }
   }

   private static String describeSite(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull GlobalPos site, @Nonnull Set<GlobalPos> refused, boolean holdsBolt) {
      if (!site.m_122640_().equals(level.m_46472_())) {
         return site.m_122646_().m_123344_() + "@other-dim";
      } else {
         double distance = villager.m_20182_().m_82554_(floorCenterOf(site.m_122646_()));
         if (distance > (double)24.0F) {
            String var10000 = site.m_122646_().m_123344_();
            return var10000 + ": 距离" + String.format(Locale.ROOT, "%.0f", distance) + "格超接近范围24";
         } else {
            BallistaBlockEntity machine = BallistaBlockEntity.inLoadedChunk(level, site.m_122646_());
            if (machine == null) {
               return site.m_122646_().m_123344_() + ": 区块未加载或无弩炮方块实体";
            } else if (!machine.isLeaseFreeFor(villager.m_20148_())) {
               return site.m_122646_().m_123344_() + ": 租约被占";
            } else if (refused.contains(site)) {
               return site.m_122646_().m_123344_() + ": 在拒绝记忆中";
            } else {
               return !holdsBolt && !machine.hasSeatedAmmunition() ? site.m_122646_().m_123344_() + ": 无弹药" : site.m_122646_().m_123344_() + ": 判定可用(需复查)";
            }
         }
      }
   }

   public IBehavior<BaseVillager> createBehavior(@Nonnull LivingEntity target) {
      return new ManBallistaBehavior(this.support, this, this.config, this.shotChecks, target);
   }

   public BehaviorDisplayMetadata displayInfo() {
      return DISPLAY_INFO;
   }

   void rememberRefusal(@Nonnull BaseVillager villager, @Nonnull BlockPos machinePos) {
      Set<GlobalPos> refused = new HashSet(refusedMachines(villager));
      refused.add(GlobalPos.m_122643_(villager.m_9236_().m_46472_(), machinePos));
      villager.getSettlementsBrain().setMemory(MemoryTypeRegistry.REFUSED_BALLISTAS, Set.copyOf(refused), REFUSAL_MEMORY);
   }

   static Vec3 aimPointOf(@Nonnull LivingEntity target) {
      return target.m_20191_().m_82399_();
   }

   static boolean hasBoltInInventory(@Nonnull BaseVillager villager) {
      return villager.getSettlementsInventory().containsOrBypassed((Item)ItemRegistry.BALLISTA_BOLT.get(), GeneralConfig.bypassInventoryRequirements);
   }

   static Vec3 floorCenterOf(@Nonnull BlockPos machinePos) {
      return new Vec3((double)machinePos.m_123341_() + (double)0.5F, (double)machinePos.m_123342_(), (double)machinePos.m_123343_() + (double)0.5F);
   }

   private boolean isEligible(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      if (VillagerProfessionKey.FLETCHER.equals(villager.getProfession())) {
         return true;
      } else {
         double intelligence = villager.getGenetics().getGeneValue(GeneType.INTELLIGENCE);
         double threshold = this.config.operatorIntelligenceThreshold();
         return intelligence >= threshold || threshold <= (double)1.0F && intelligence >= threshold - 0.2 && isRaidActive(level, villager);
      }
   }

   private static double engagementRangeBlocks(boolean duringRaid) {
      return duringRaid ? (double)56.0F : (double)48.0F;
   }

   private static boolean isRaidActive(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      Raid raid = level.m_8832_(villager.m_20183_());
      return raid != null && raid.m_37782_() && !raid.m_37706_();
   }

   private static List<GlobalPos> knownMachines(@Nonnull BaseVillager villager) {
      return (List)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.BALLISTA_SITES).orElse(List.of());
   }

   private static Set<GlobalPos> refusedMachines(@Nonnull BaseVillager villager) {
      return (Set)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.REFUSED_BALLISTAS).orElse(Set.of());
   }

   private static boolean isAvailable(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull GlobalPos site, @Nonnull Set<GlobalPos> refused, boolean holdsBolt) {
      if (site.m_122640_().equals(level.m_46472_()) && !(villager.m_20182_().m_82557_(floorCenterOf(site.m_122646_())) > (double)576.0F)) {
         BallistaBlockEntity machine = BallistaBlockEntity.inLoadedChunk(level, site.m_122646_());
         if (machine == null) {
            return false;
         } else if (!machine.isLeaseFreeFor(villager.m_20148_())) {
            return false;
         } else {
            return !refused.contains(site) && (holdsBolt || machine.hasSeatedAmmunition());
         }
      } else {
         return false;
      }
   }

   public static final class Readiness implements CombatReadiness {
      private final ServerLevel level;
      private final BallistaShotChecks shotChecks;
      private final List<BlockPos> usableMachines;
      private final double engagementRangeBlocks;

      private Readiness(ServerLevel level, BallistaShotChecks shotChecks, List<BlockPos> usableMachines, double engagementRangeBlocks) {
         this.level = level;
         this.shotChecks = shotChecks;
         this.usableMachines = usableMachines;
         this.engagementRangeBlocks = engagementRangeBlocks;
      }

      public boolean canEngage(@Nonnull LivingEntity hostile) {
         return this.machineFor(hostile, false) != null;
      }

      public boolean canStayLockedOn(@Nonnull LivingEntity target) {
         return this.machineFor(target, true) != null;
      }

      @Nullable
      BallistaBlockEntity machineFor(@Nonnull LivingEntity hostile, boolean held) {
         double range = held ? (double)128.0F : this.engagementRangeBlocks;

         for(BlockPos machinePos : this.usableMachines) {
            if (hostile.m_20182_().m_82557_(BallistaCombatOption.floorCenterOf(machinePos)) <= range * range && this.shotChecks.canHit(this.level, machinePos, hostile)) {
               return BallistaBlockEntity.inLoadedChunk(this.level, machinePos);
            }
         }

         return null;
      }
   }
}
