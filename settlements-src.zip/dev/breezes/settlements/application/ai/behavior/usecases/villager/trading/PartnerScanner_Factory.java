package dev.breezes.settlements.application.ai.behavior.usecases.villager.trading;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.economy.VillagerWallet;
import dev.breezes.settlements.application.economy.catalog.TradePriceResolver;
import dev.breezes.settlements.domain.economy.catalog.TradeCatalogRegistry;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class PartnerScanner_Factory implements Factory<PartnerScanner> {
   private final Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider;
   private final Provider<TradePriceResolver> tradePriceResolverProvider;
   private final Provider<VillagerWallet> villagerWalletProvider;

   private PartnerScanner_Factory(Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider, Provider<TradePriceResolver> tradePriceResolverProvider, Provider<VillagerWallet> villagerWalletProvider) {
      this.tradeCatalogRegistryProvider = tradeCatalogRegistryProvider;
      this.tradePriceResolverProvider = tradePriceResolverProvider;
      this.villagerWalletProvider = villagerWalletProvider;
   }

   public PartnerScanner get() {
      return newInstance((TradeCatalogRegistry)this.tradeCatalogRegistryProvider.get(), (TradePriceResolver)this.tradePriceResolverProvider.get(), (VillagerWallet)this.villagerWalletProvider.get());
   }

   public static PartnerScanner_Factory create(Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider, Provider<TradePriceResolver> tradePriceResolverProvider, Provider<VillagerWallet> villagerWalletProvider) {
      return new PartnerScanner_Factory(tradeCatalogRegistryProvider, tradePriceResolverProvider, villagerWalletProvider);
   }

   public static PartnerScanner newInstance(TradeCatalogRegistry tradeCatalogRegistry, TradePriceResolver tradePriceResolver, VillagerWallet villagerWallet) {
      return new PartnerScanner(tradeCatalogRegistry, tradePriceResolver, villagerWallet);
   }
}
