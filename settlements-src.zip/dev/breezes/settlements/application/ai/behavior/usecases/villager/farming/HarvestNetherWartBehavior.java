package dev.breezes.settlements.application.ai.behavior.usecases.villager.farming;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.blocks.VisitedBlockSitesState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.items.ItemState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetQueries;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.AwardExperienceStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.LoopBackStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.OneShotStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.PickupItemsStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.WaitStep;
import dev.breezes.settlements.application.ai.targeting.BlockMemoryTargetResolver;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.domain.ai.conditions.KnownBlockSitesPrecondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.AabbBlockScan;
import dev.breezes.settlements.domain.world.blocks.BlockMatcher;
import dev.breezes.settlements.domain.world.blocks.BlockMatchers;
import dev.breezes.settlements.domain.world.blocks.BlockScanBox;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.NetherWartBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class HarvestNetherWartBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(HarvestNetherWartBehavior.class.getName());
   private static final ClockTicks SETTLE_DURATION = ClockTicks.seconds((double)1.0F);
   private static final int APPROACH_TIMEOUT_TICKS = ClockTicks.seconds((double)20.0F).getTicksAsInt();
   private final BlockMatcher netherWartMatcher;
   private final BlockScanBox confirmBox;
   private final int maxConfirms;
   private final HarvestNetherWartConfig config;
   private final BlockMemoryTargetResolver targetResolver;

   public HarvestNetherWartBehavior(@Nonnull HarvestNetherWartConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.targetResolver = support.getBlockMemoryTargetResolver();
      this.netherWartMatcher = BlockMatchers.HARVESTABLE_NETHER_WART;
      this.confirmBox = BlockScanBox.confirm();
      this.maxConfirms = 8;
      this.preconditions.add(KnownBlockSitesPrecondition.builder().memoryType(MemoryTypeRegistry.NETHER_WART_FARM_SITES).matcher(this.netherWartMatcher).confirmBox(this.confirmBox).maxSitesToConfirm(this.maxConfirms).completionRange(1).description("Known nether wart farm sites").build());
      this.initializeStateMachine(this.createControlStep(), HarvestNetherWartBehavior.Stage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      Map<StageKey, BehaviorStep<BaseVillager>> stageMap = new HashMap();
      stageMap.put(HarvestNetherWartBehavior.Stage.PICK_TARGET, this.createPickTargetStep());
      stageMap.put(HarvestNetherWartBehavior.Stage.APPROACH, StayCloseStep.builder().closeEnoughDistance((double)1.5F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.WALK).completionDistance(1).unreachableTransition(HarvestNetherWartBehavior.Stage.PICK_TARGET).build()).actionStep(OneShotStep.builder().name("ArrivedAtNetherWart").action((ctx) -> StepResult.transition(HarvestNetherWartBehavior.Stage.HARVEST)).build()).timeoutTicks(APPROACH_TIMEOUT_TICKS).timeoutTransition(HarvestNetherWartBehavior.Stage.PICK_TARGET).build());
      stageMap.put(HarvestNetherWartBehavior.Stage.HARVEST, this.createHarvestStep());
      stageMap.put(HarvestNetherWartBehavior.Stage.SETTLE, WaitStep.builder().waitTime(SETTLE_DURATION.asTickable()).nextStage(HarvestNetherWartBehavior.Stage.PICKUP).build());
      stageMap.put(HarvestNetherWartBehavior.Stage.PICKUP, PickupItemsStep.builder().name("PickupNetherWartDrops").nextStage(HarvestNetherWartBehavior.Stage.LOOP).build());
      stageMap.put(HarvestNetherWartBehavior.Stage.LOOP, LoopBackStep.builder().name("NetherWartLoopBack").loopBackTo(HarvestNetherWartBehavior.Stage.PICK_TARGET).completionTransition(HarvestNetherWartBehavior.Stage.AWARD).maxIterationsResolver((ctx) -> 4 * ((BaseVillager)ctx.getInitiator()).getExpertise().getLevel()).build());
      stageMap.put(HarvestNetherWartBehavior.Stage.AWARD, AwardExperienceStep.builder().name("AwardNetherWartXp").experienceAmount(this.config.experienceReward()).nextStage(HarvestNetherWartBehavior.Stage.END).build());
      return StagedStep.<BaseVillager>builder().name("HarvestNetherWartBehavior").initialStage(HarvestNetherWartBehavior.Stage.PICK_TARGET).stageStepMap(stageMap).nextStage(HarvestNetherWartBehavior.Stage.END).build();
   }

   private BehaviorStep<BaseVillager> createPickTargetStep() {
      return OneShotStep.<BaseVillager>builder().name("PickNetherWartTarget").action((ctx) -> {
         boolean resolved = this.targetResolver.resolveBlockTarget(ctx, MemoryTypeRegistry.NETHER_WART_FARM_SITES, this.netherWartMatcher, this.confirmBox, this.maxConfirms, 1);
         if (!resolved) {
            log.behaviorStatus("No additional nether wart targets found, ending behavior");
            return StepResult.transition(HarvestNetherWartBehavior.Stage.AWARD);
         } else {
            return StepResult.transition(HarvestNetherWartBehavior.Stage.APPROACH);
         }
      }).build();
   }

   private BehaviorStep<BaseVillager> createHarvestStep() {
      return TimeBasedStep.<BaseVillager>builder().name("HarvestNetherWart").withTickable(ClockTicks.of(30L).asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.HARVEST);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(14L), (ctx) -> {
         Optional<BlockPos> target = TargetQueries.firstBlockPos(ctx);
         if (target.isEmpty()) {
            return StepResult.noOp();
         } else {
            BaseVillager villager = (BaseVillager)ctx.getInitiator();
            Level world = villager.m_9236_();
            BlockPos pos = (BlockPos)target.get();
            BlockState state = world.m_8055_(pos);
            if (world instanceof ServerLevel) {
               ServerLevel server = (ServerLevel)world;
               if (AabbBlockScan.findFirst(pos, BlockScanBox.self(), this.netherWartMatcher, world).isEmpty()) {
                  return StepResult.noOp();
               } else {
                  Location effectLocation = Location.of(pos, world).center(true).add((double)0.0F, (double)0.5F, (double)0.0F, true);
                  ParticleRegistry.harvestBlock(effectLocation, state);
                  effectLocation.playSound(SoundEvents.f_12394_, 0.8F, 1.0F, SoundSource.BLOCKS);
                  List<ItemStack> drops = Block.m_49874_(state, server, pos, (BlockEntity)null, villager, ItemStack.f_41583_);
                  List<ItemEntity> spawned = Location.of(pos, world).center(true).dropItems(drops, true);
                  spawned.forEach((itemEntity) -> itemEntity.m_32010_(ClockTicks.seconds((double)5.0F).getTicksAsInt()));
                  world.m_46597_(pos, (BlockState)state.m_61124_(NetherWartBlock.f_54967_, 0));
                  ctx.getState(BehaviorStateType.VISITED_BLOCK_SITES, VisitedBlockSitesState.class).ifPresent((visitedSites) -> visitedSites.addSite(GlobalPos.m_122643_(world.m_46472_(), pos)));
                  ctx.setState(BehaviorStateType.ITEMS_TO_PICK_UP, ItemState.of(spawned));
                  ctx.primaryDeed().ifPresent((outcome) -> outcome.recordYield(totalItemCount(drops)));
                  return StepResult.noOp();
               }
            } else {
               return StepResult.noOp();
            }
         }
      }).onEnd((ctx) -> StepResult.transition(HarvestNetherWartBehavior.Stage.SETTLE)).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      context.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.RESOURCE_HARVESTED, "nether wart"));
      context.setState(BehaviorStateType.VISITED_BLOCK_SITES, VisitedBlockSitesState.empty());
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.setMotion(AnimationArchetype.IDLE);
   }

   private static int totalItemCount(@Nonnull List<ItemStack> drops) {
      return drops.stream().mapToInt(ItemStack::m_41613_).sum();
   }

   private static enum Stage implements StageKey {
      PICK_TARGET,
      APPROACH,
      HARVEST,
      SETTLE,
      PICKUP,
      LOOP,
      AWARD,
      END;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{PICK_TARGET, APPROACH, HARVEST, SETTLE, PICKUP, LOOP, AWARD, END};
      }
   }
}
