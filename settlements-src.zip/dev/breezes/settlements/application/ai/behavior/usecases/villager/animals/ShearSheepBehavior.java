package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.items.ItemState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetQueries;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.conditions.PerceivedEntityExistsCondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.entities.Expertise;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;

public class ShearSheepBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ShearSheepBehavior.class.getName());
   private static final String BUBBLE_OWNER_KEY = "behavior:shear_sheep";
   private static final ClockTicks BUBBLE_TTL = ClockTicks.seconds((double)30.0F);
   private static final ResourceLocation SHEARS_ITEM_ID = new ResourceLocation("minecraft", "shears");
   private static final int DEFAULT_SHEAR_LIMIT = 1;
   private static final Map<DyeColor, ItemLike> WOOL_COLOR_MAP;
   private final ShearSheepConfig config;
   private final AtomicInteger shearCount;
   private boolean shouldRewardExperience;

   public ShearSheepBehavior(@Nonnull ShearSheepConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.shearCount = new AtomicInteger(0);
      this.shouldRewardExperience = false;
      this.preconditions.add(PerceivedEntityExistsCondition.builder().entityType(Sheep.class).filter((villager, sheep) -> isShearable(sheep)).completionRange(1).build());
      this.preconditions.add(support.getDemandSignalService().requireItem(new ItemMatch.ItemRef(SHEARS_ITEM_ID), 1, 50, this.getClass().getSimpleName()));
      this.initializeStateMachine(this.createControlStep(), ShearSheepBehavior.ShearStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("ShearSheepBehavior").initialStage(ShearSheepBehavior.ShearStage.SHEAR_SHEEP).stageStepMap(Map.of(ShearSheepBehavior.ShearStage.SHEAR_SHEEP, this.createShearSheepStep(), ShearSheepBehavior.ShearStage.PICKUP_WOOL, this.createPickupWoolStep())).nextStage(ShearSheepBehavior.ShearStage.END).build();
   }

   private BehaviorStep<BaseVillager> createShearSheepStep() {
      TimeBasedStep<BaseVillager> shearStep = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.seconds((double)1.0F).asTickable()).onStart((context) -> {
         this.shearCount.decrementAndGet();
         ((BaseVillager)context.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         ((BaseVillager)context.getInitiator()).setHeldItem(Items.f_42574_.m_7968_());
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(12L), (context) -> {
         Optional<Sheep> sheepOptional = this.getTargetSheep(context);
         if (sheepOptional.isEmpty()) {
            return StepResult.complete();
         } else {
            Sheep sheep = (Sheep)sheepOptional.get();
            sheep.m_29878_(true);
            SoundRegistry.SHEAR_SHEEP.playGlobally(Location.fromEntity(sheep, false), SoundSource.NEUTRAL);
            int dropCount = RandomUtil.randomInt(1, 3, true);
            List<ItemEntity> woolItems = new ArrayList();

            for(int i = 0; i < dropCount; ++i) {
               ItemEntity woolItem = sheep.m_20000_((ItemLike)WOOL_COLOR_MAP.get(sheep.m_29874_()), 1);
               if (woolItem != null) {
                  woolItem.m_32010_(ClockTicks.seconds((double)3.0F).getTicksAsInt());
                  woolItem.m_20256_(woolItem.m_20184_().m_82520_(RandomUtil.randomDouble((double)-0.05F, (double)0.05F), RandomUtil.randomDouble((double)0.0F, (double)0.05F), RandomUtil.randomDouble((double)-0.05F, (double)0.05F)));
                  woolItems.add(woolItem);
               }
            }

            context.setState(BehaviorStateType.ITEMS_TO_PICK_UP, ItemState.of(woolItems));
            context.primaryDeed().ifPresent((outcome) -> outcome.recordYield(woolItems.size()));
            this.shouldRewardExperience = true;
            return StepResult.noOp();
         }
      }).onEnd((context) -> {
         ((BaseVillager)context.getInitiator()).clearHeldItem();
         return StepResult.transition(ShearSheepBehavior.ShearStage.PICKUP_WOOL);
      }).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 1)).actionStep(shearStep).build();
   }

   private BehaviorStep<BaseVillager> createPickupWoolStep() {
      return TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.of(24L).asTickable()).onStart((context) -> {
         ((BaseVillager)context.getInitiator()).triggerMotion(AnimationArchetype.PICK_UP);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(11L), (context) -> {
         context.getState(BehaviorStateType.ITEMS_TO_PICK_UP, ItemState.class).ifPresent((itemState) -> itemState.getItems().stream().filter(Entity::m_6084_).forEach((itemEntity) -> ((BaseVillager)context.getInitiator()).pickUp(itemEntity)));
         return StepResult.noOp();
      }).onEnd((context) -> {
         if (this.shearCount.get() > 0) {
            List<Targetable> nearbySheep = this.findShearableSheep(((BaseVillager)context.getInitiator()).getMinecraftEntity()).stream().map(Targetable::fromEntity).toList();
            if (!nearbySheep.isEmpty()) {
               context.setState(BehaviorStateType.TARGET, TargetState.of(nearbySheep));
               log.behaviorStatus("Found {} nearby sheep to shear, remaining {}", nearbySheep.size(), this.shearCount.get());
               return StepResult.transition(ShearSheepBehavior.ShearStage.SHEAR_SHEEP);
            }
         }

         return StepResult.complete();
      }).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      context.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.SHEEP_SHEARED, "wool"));
      Expertise expertise = ((BaseVillager)context.getInitiator()).getMinecraftEntity().getExpertise();
      int limit = (Integer)this.config.expertiseShearLimit().getOrDefault(expertise.getConfigName(), 1);
      this.shearCount.set(limit);
      this.shouldRewardExperience = false;
      log.behaviorStatus("Villager is '{}' level, maximum shear count is {}", expertise.toString(), limit);
      if (!villager.getSettlementsInventory().containsOrBypassed(Items.f_42574_, GeneralConfig.bypassInventoryRequirements)) {
         this.requestStop("No shears available");
      } else {
         List<Targetable> targets = this.findShearableSheep(villager).stream().map(Targetable::fromEntity).toList();
         context.setState(BehaviorStateType.TARGET, TargetState.of(targets));
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      if (this.shouldRewardExperience) {
         this.rewardExperience(villager);
      }

      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.shouldRewardExperience = false;
   }

   private Optional<Sheep> getTargetSheep(@Nonnull BehaviorContext<BaseVillager> context) {
      return TargetQueries.firstEntity(context, EntityType.f_20520_, Sheep.class).filter(ShearSheepBehavior::isShearable);
   }

   private List<Sheep> findShearableSheep(@Nonnull BaseVillager villager) {
      return this.getPerceivedEntities(villager).ofType(Sheep.class, (sheep) -> isShearable(sheep) && villager.getNavigationManager().canReach(Location.fromEntity(sheep, false), (double)1.0F)).toList();
   }

   private PerceivedEntities getPerceivedEntities(@Nonnull BaseVillager villager) {
      return (PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_SENSED_ENTITIES).orElse(PerceivedEntities.empty());
   }

   private static boolean isShearable(@Nonnull Sheep sheep) {
      return sheep.m_6220_();
   }

   static {
      WOOL_COLOR_MAP = Map.ofEntries(Map.entry(DyeColor.WHITE, Items.f_41870_), Map.entry(DyeColor.ORANGE, Items.f_41871_), Map.entry(DyeColor.MAGENTA, Items.f_41872_), Map.entry(DyeColor.LIGHT_BLUE, Items.f_41873_), Map.entry(DyeColor.YELLOW, Items.f_41874_), Map.entry(DyeColor.LIME, Items.f_41875_), Map.entry(DyeColor.PINK, Items.f_41876_), Map.entry(DyeColor.GRAY, Items.f_41877_), Map.entry(DyeColor.LIGHT_GRAY, Items.f_41878_), Map.entry(DyeColor.CYAN, Items.f_41932_), Map.entry(DyeColor.PURPLE, Items.f_41933_), Map.entry(DyeColor.BLUE, Items.f_41934_), Map.entry(DyeColor.BROWN, Items.f_41935_), Map.entry(DyeColor.GREEN, Items.f_41936_), Map.entry(DyeColor.RED, Items.f_41937_), Map.entry(DyeColor.BLACK, Items.f_41938_));
   }

   private static enum ShearStage implements StageKey {
      SHEAR_SHEEP,
      PICKUP_WOOL,
      END;

      // $FF: synthetic method
      private static ShearStage[] $values() {
         return new ShearStage[]{SHEAR_SHEEP, PICKUP_WOOL, END};
      }
   }
}
