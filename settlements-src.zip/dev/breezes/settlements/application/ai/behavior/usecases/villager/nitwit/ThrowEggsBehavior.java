package dev.breezes.settlements.application.ai.behavior.usecases.villager.nitwit;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.LoopBackStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.OneShotStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.ai.conditions.PerceivedEntityExistsCondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.domain.world.location.Vector;
import dev.breezes.settlements.infrastructure.minecraft.entities.projectiles.SettlementsEgg;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.phys.Vec3;

public class ThrowEggsBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ThrowEggsBehavior.class.getName());
   private static final int BURST_DURATION_TICKS = 30;
   private static final int BURST_ROUNDS_MIN = 2;
   private static final int BURST_ROUNDS_MAX = 4;
   private static final float EGG_VELOCITY = 1.5F;
   private static final float EGG_INACCURACY = 8.0F;
   private static final double HAND_LATERAL_OFFSET = 0.4;
   private static final double HAND_FORWARD_OFFSET = 0.1;
   private static final double HAND_RAISED_ABOVE_HEAD = 0.15;
   private static final int ANGRY_VILLAGER_PARTICLE_COUNT = 1;
   private static final double ANGRY_VILLAGER_PARTICLE_OFFSET = 0.3;
   private static final double ANGRY_VILLAGER_PARTICLE_SPEED = 0.1;
   private static final double RELOCATE_RADIUS = (double)4.0F;
   private static final double CLOSE_ENOUGH_DISTANCE = (double)1.5F;
   private static final int RELOCATE_TIMEOUT_TICKS = ClockTicks.seconds((double)4.0F).getTicksAsInt();
   private static final Set<Class<?>> TARGET_CLASSES = Set.of(Villager.class, WanderingTrader.class, Player.class);
   @Nullable
   private LivingEntity victim;
   private int eggsThrown;

   public ThrowEggsBehavior(ThrowEggsConfig config, BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.preconditions.add(PerceivedEntityExistsCondition.builder().entityType(LivingEntity.class).filter(this::isValidEggTarget).build());
      this.victim = null;
      this.initializeStateMachine(this.createControlStep(), ThrowEggsBehavior.Stage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      Map<StageKey, BehaviorStep<BaseVillager>> stageMap = new HashMap();
      stageMap.put(ThrowEggsBehavior.Stage.RELOCATE_PICK, this.createRelocatePickStep());
      stageMap.put(ThrowEggsBehavior.Stage.RELOCATE_MOVE, this.createRelocateMoveStep());
      stageMap.put(ThrowEggsBehavior.Stage.BURST, this.createBurstStep());
      stageMap.put(ThrowEggsBehavior.Stage.BURST_LOOP, LoopBackStep.builder().name("EggBurstLoop").loopBackTo(ThrowEggsBehavior.Stage.RELOCATE_PICK).completionTransition(ThrowEggsBehavior.Stage.END).maxIterationsResolver((ctx) -> RandomUtil.randomInt(2, 4, true)).build());
      return StagedStep.<BaseVillager>builder().name("ThrowEggsBehavior").initialStage(ThrowEggsBehavior.Stage.RELOCATE_PICK).stageStepMap(stageMap).nextStage(ThrowEggsBehavior.Stage.END).build();
   }

   private BehaviorStep<BaseVillager> createRelocatePickStep() {
      return OneShotStep.<BaseVillager>builder().name("EggRelocatePick").action((ctx) -> {
         if (this.victim == null) {
            return StepResult.transition(ThrowEggsBehavior.Stage.END);
         } else {
            BaseVillager villager = (BaseVillager)ctx.getInitiator();
            Level world = villager.m_9236_();
            villager.setMotion(AnimationArchetype.IDLE);
            double angle = RandomUtil.randomDouble((double)0.0F, (Math.PI * 2D));
            int targetX = (int)(this.victim.m_20185_() + Math.cos(angle) * (double)4.0F);
            int targetZ = (int)(this.victim.m_20189_() + Math.sin(angle) * (double)4.0F);
            int targetY;
            if (world instanceof ServerLevel) {
               ServerLevel server = (ServerLevel)world;
               targetY = server.m_6924_(Types.MOTION_BLOCKING_NO_LEAVES, targetX, targetZ) - 1;
            } else {
               targetY = villager.m_146904_();
            }

            targetY += (int)villager.m_20192_();
            BlockPos relocatePos = new BlockPos(targetX, targetY, targetZ);
            Location relocateLocation = Location.of(relocatePos, world);
            ctx.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromBlock(PhysicalBlock.of(relocateLocation, world.m_8055_(relocatePos)))));
            return StepResult.transition(ThrowEggsBehavior.Stage.RELOCATE_MOVE);
         }
      }).build();
   }

   private BehaviorStep<BaseVillager> createRelocateMoveStep() {
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)1.5F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.RUN).completionDistance(1).unreachableTransition(ThrowEggsBehavior.Stage.BURST).build()).actionStep(OneShotStep.builder().name("EggRelocateArrived").action((ctx) -> StepResult.transition(ThrowEggsBehavior.Stage.BURST)).build()).timeoutTicks(RELOCATE_TIMEOUT_TICKS).timeoutTransition(ThrowEggsBehavior.Stage.BURST).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      List<LivingEntity> candidates = ((PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_SENSED_ENTITIES).orElse(PerceivedEntities.empty())).ofType(LivingEntity.class, (target) -> this.isValidEggTarget(villager, target)).toList();
      if (candidates.isEmpty()) {
         log.behaviorStatus("No egg targets found nearby; stopping");
         this.requestStop("no_nearby_egg_targets");
      } else {
         this.victim = (LivingEntity)RandomUtil.choice(candidates).orElseThrow();
         this.eggsThrown = 0;
         villager.setHeldItem(new ItemStack(Items.f_42521_));
         villager.setOffhandItem(new ItemStack(Items.f_42521_));
      }
   }

   private boolean isValidEggTarget(@Nonnull BaseVillager villager, @Nonnull LivingEntity target) {
      if (target.m_6084_() && !target.m_213877_()) {
         if (target == villager) {
            return false;
         } else if (TARGET_CLASSES.stream().noneMatch((targetClass) -> targetClass.isInstance(target))) {
            return false;
         } else {
            if (target instanceof Player) {
               Player player = (Player)target;
               if (player.m_5833_() || player.m_7500_()) {
                  return false;
               }
            }

            return true;
         }
      } else {
         return false;
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      return this.victim != null && this.isValidEggTarget(villager, this.victim);
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.setMotion(AnimationArchetype.IDLE);
      villager.clearHeldItem();
      villager.clearOffhandItem();
      this.victim = null;
   }

   private BehaviorStep<BaseVillager> createBurstStep() {
      return TimeBasedStep.<BaseVillager>builder().name("EggBurst").withTickable(ClockTicks.of(30L).asTickable()).onStart((ctx) -> {
         if (this.victim != null) {
            ctx.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.victim)));
         }

         ((BaseVillager)ctx.getInitiator()).setMotion(AnimationArchetype.THROW);
         return StepResult.noOp();
      }).addPeriodicStep(ClockTicks.of(3L).getTicksAsInt(), this::throwEggAtVictim).onEnd((ctx) -> StepResult.transition(ThrowEggsBehavior.Stage.BURST_LOOP)).build();
   }

   private StepResult throwEggAtVictim(@Nonnull BehaviorContext<BaseVillager> context) {
      if (this.victim != null && this.victim.m_6084_()) {
         BaseVillager villager = context.getInitiator();
         Level world = villager.m_9236_();
         boolean rightHand = this.eggsThrown % 2 == 0;
         ++this.eggsThrown;
         Vec3 handPosition = this.computeRaisedHandPosition(villager, rightHand);
         Location handLocation = Location.of(handPosition.f_82479_, handPosition.f_82480_, handPosition.f_82481_, world);
         Location victimLocation = Location.fromEntity(this.victim, true);
         Vector direction = handLocation.getDirectionTo(victimLocation);
         SettlementsEgg egg = new SettlementsEgg(world, villager);
         egg.m_6034_(handPosition.f_82479_, handPosition.f_82480_, handPosition.f_82481_);
         egg.m_6686_(direction.getX(), direction.getY(), direction.getZ(), 1.5F, 8.0F);
         world.m_7967_(egg);
         SoundRegistry.THROW_EGG.playGlobally(handLocation, SoundSource.NEUTRAL);
         this.spawnAngryVillagerParticleOnVictim(world);
         if (context.primaryDeed().isEmpty()) {
            BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.TARGET_EGGED, (String)null);
            if (!(this.victim instanceof BaseVillager) && !(this.victim instanceof Villager)) {
               outcome.markSucceeded();
            } else {
               outcome.recordTargetedDeed(this.victim.m_20148_());
            }

            context.declarePrimaryDeed(outcome);
         }

         return StepResult.noOp();
      } else {
         return StepResult.transition(ThrowEggsBehavior.Stage.BURST_LOOP);
      }
   }

   private Vec3 computeRaisedHandPosition(@Nonnull BaseVillager villager, boolean rightHand) {
      Vec3 look = villager.m_20154_();
      Vec3 forward = new Vec3(look.f_82479_, (double)0.0F, look.f_82481_);
      forward = forward.m_82556_() < 1.0E-4 ? villager.m_20156_() : forward.m_82541_();
      Vec3 right = new Vec3(-forward.f_82481_, (double)0.0F, forward.f_82479_);
      double lateral = rightHand ? 0.4 : -0.4;
      return new Vec3(villager.m_20185_() + right.f_82479_ * lateral + forward.f_82479_ * 0.1, villager.m_20186_() + (double)villager.m_20206_() + 0.15, villager.m_20189_() + right.f_82481_ * lateral + forward.f_82481_ * 0.1);
   }

   private void spawnAngryVillagerParticleOnVictim(@Nonnull Level world) {
      if (this.victim != null && !(this.victim instanceof Player) && world instanceof ServerLevel server) {
         server.m_8767_(ParticleTypes.f_123792_, this.victim.m_20185_(), this.victim.m_20186_() + (double)this.victim.m_20206_(), this.victim.m_20189_(), 1, 0.3, 0.3, 0.3, 0.1);
      }
   }

   private static enum Stage implements StageKey {
      RELOCATE_PICK,
      RELOCATE_MOVE,
      BURST,
      BURST_LOOP,
      END;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{RELOCATE_PICK, RELOCATE_MOVE, BURST, BURST_LOOP, END};
      }
   }
}
