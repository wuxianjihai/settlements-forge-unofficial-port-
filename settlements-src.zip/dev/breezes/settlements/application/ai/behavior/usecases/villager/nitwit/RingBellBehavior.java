package dev.breezes.settlements.application.ai.behavior.usecases.villager.nitwit;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.domain.ai.conditions.IBlockCondition;
import dev.breezes.settlements.domain.ai.conditions.NearbyBlockExistsCondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BellBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class RingBellBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(RingBellBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private final NearbyBlockExistsCondition<BaseVillager> nearbyBellExistsCondition;
   @Nullable
   private BlockPos bellPos;

   public RingBellBehavior(@Nonnull RingBellConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.nearbyBellExistsCondition = new NearbyBlockExistsCondition<BaseVillager>((double)config.scanRangeHorizontal(), (double)config.scanRangeVertical(), Blocks.f_50680_, (IBlockCondition)null, 1);
      this.preconditions.add(this.nearbyBellExistsCondition);
      this.bellPos = null;
      this.initializeStateMachine(this.createControlStep(), RingBellBehavior.RingBellStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("RingBellBehavior").initialStage(RingBellBehavior.RingBellStage.RING_BELL).stageStepMap(Map.of(RingBellBehavior.RingBellStage.RING_BELL, this.createRingBellStep())).nextStage(RingBellBehavior.RingBellStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   private BehaviorStep<BaseVillager> createRingBellStep() {
      TimeBasedStep<BaseVillager> actionStep = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.of(12L).asTickable()).onStart((context) -> {
         ((BaseVillager)context.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).onEnd((context) -> {
         if (this.bellPos == null) {
            return StepResult.complete();
         } else {
            BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
            BlockState bellState = villager.m_9236_().m_8055_(this.bellPos);
            if (!bellState.m_60713_(Blocks.f_50680_)) {
               return StepResult.fail("Bell not found at " + String.valueOf(this.bellPos));
            } else {
               ((BellBlock)bellState.m_60734_()).m_152188_(villager, villager.m_9236_(), this.bellPos, (Direction)null);
               BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.BELL_RUNG, (String)null);
               outcome.markSucceeded();
               context.declarePrimaryDeed(outcome);
               return StepResult.complete();
            }
         }
      }).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.RUN, 1)).actionStep(actionStep).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      List<BlockPos> bells = new ArrayList(this.nearbyBellExistsCondition.getTargets());
      if (bells.isEmpty()) {
         this.requestStop("No bell found within range");
      } else {
         this.bellPos = (BlockPos)bells.get(world.m_213780_().m_188503_(bells.size()));
         context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromBlock(PhysicalBlock.of(Location.of(this.bellPos, world), world.m_8055_(this.bellPos)))));
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      return this.bellPos != null && world.m_8055_(this.bellPos).m_60713_(Blocks.f_50680_);
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.setMotion(AnimationArchetype.IDLE);
      this.bellPos = null;
   }

   private static enum RingBellStage implements StageKey {
      RING_BELL,
      END;

      // $FF: synthetic method
      private static RingBellStage[] $values() {
         return new RingBellStage[]{RING_BELL, END};
      }
   }
}
