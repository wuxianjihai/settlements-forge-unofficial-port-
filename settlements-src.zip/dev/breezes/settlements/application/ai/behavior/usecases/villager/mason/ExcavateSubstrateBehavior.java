package dev.breezes.settlements.application.ai.behavior.usecases.villager.mason;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.items.ItemState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetQueries;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.AwardExperienceStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.LoopBackStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.OneShotStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.PickupItemsStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.WaitStep;
import dev.breezes.settlements.application.ai.targeting.BlockMemoryTargetResolver;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.domain.ai.conditions.AnyOfCondition;
import dev.breezes.settlements.domain.ai.conditions.IEntityCondition;
import dev.breezes.settlements.domain.ai.conditions.KnownBlockSitesPrecondition;
import dev.breezes.settlements.domain.ai.memory.MemoryType;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.AabbBlockScan;
import dev.breezes.settlements.domain.world.blocks.BlockMatcher;
import dev.breezes.settlements.domain.world.blocks.BlockMatchers;
import dev.breezes.settlements.domain.world.blocks.BlockScanBox;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.data.mason.ExcavateSubstrateYieldDataManager;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

public class ExcavateSubstrateBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ExcavateSubstrateBehavior.class.getName());
   private static final ClockTicks SETTLE_DURATION = ClockTicks.seconds((double)1.0F);
   private static final int APPROACH_TIMEOUT_TICKS = ClockTicks.seconds((double)20.0F).getTicksAsInt();
   private static final ResourceLocation GRAVEL_BLOCK_ID = new ResourceLocation("minecraft", "gravel");
   private static final ResourceLocation SAND_BLOCK_ID = new ResourceLocation("minecraft", "sand");
   private static final ResourceLocation IRON_SHOVEL_ID = new ResourceLocation("minecraft", "iron_shovel");
   private static final ItemMatch.ItemRef IRON_SHOVEL_MATCH;
   private static final List<ExcavatableSubstrateSource> SOURCES;
   private final BlockScanBox confirmBox;
   private final int maxConfirms;
   private final ExcavateSubstrateConfig config;
   private final ExcavateSubstrateYieldDataManager yieldData;
   private final BlockMemoryTargetResolver targetResolver;
   private ExcavatableSubstrateSource selectedSource;

   public ExcavateSubstrateBehavior(@Nonnull ExcavateSubstrateConfig config, @Nonnull BehaviorSupport support, @Nonnull ExcavateSubstrateYieldDataManager yieldData) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.yieldData = yieldData;
      this.targetResolver = support.getBlockMemoryTargetResolver();
      this.confirmBox = BlockScanBox.confirm();
      this.maxConfirms = 8;
      this.preconditions.add(AnyOfCondition.builder().conditions(SOURCES.stream().map(this::knownSitesPrecondition).toList()).description("Known substrate excavation sites").build());
      this.initializeStateMachine(this.createControlStep(), ExcavateSubstrateBehavior.Stage.END);
   }

   private IEntityCondition<BaseVillager> knownSitesPrecondition(@Nonnull ExcavatableSubstrateSource source) {
      return KnownBlockSitesPrecondition.builder().memoryType(source.memoryType()).matcher(source.matcher()).confirmBox(this.confirmBox).maxSitesToConfirm(this.maxConfirms).completionRange(1).description("Known " + source.name() + " sites").build();
   }

   private StagedStep<BaseVillager> createControlStep() {
      Map<StageKey, BehaviorStep<BaseVillager>> stageMap = new HashMap();
      stageMap.put(ExcavateSubstrateBehavior.Stage.PICK_TARGET, this.createPickTargetStep());
      stageMap.put(ExcavateSubstrateBehavior.Stage.APPROACH, StayCloseStep.builder().closeEnoughDistance(1.2).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.WALK).completionDistance(1).unreachableTransition(ExcavateSubstrateBehavior.Stage.PICK_TARGET).build()).actionStep(OneShotStep.builder().name("ArrivedAtExcavationSite").action((ctx) -> StepResult.transition(ExcavateSubstrateBehavior.Stage.DIG)).build()).timeoutTicks(APPROACH_TIMEOUT_TICKS).timeoutTransition(ExcavateSubstrateBehavior.Stage.PICK_TARGET).build());
      stageMap.put(ExcavateSubstrateBehavior.Stage.DIG, this.createDigStep());
      stageMap.put(ExcavateSubstrateBehavior.Stage.SETTLE, WaitStep.builder().waitTime(SETTLE_DURATION.asTickable()).nextStage(ExcavateSubstrateBehavior.Stage.PICKUP).build());
      stageMap.put(ExcavateSubstrateBehavior.Stage.PICKUP, PickupItemsStep.builder().name("PickUpDrops").nextStage(ExcavateSubstrateBehavior.Stage.LOOP).build());
      stageMap.put(ExcavateSubstrateBehavior.Stage.LOOP, LoopBackStep.builder().name("LoopBack").loopBackTo(ExcavateSubstrateBehavior.Stage.PICK_TARGET).completionTransition(ExcavateSubstrateBehavior.Stage.AWARD).maxIterationsResolver((ctx) -> (Integer)this.config.expertiseHarvestLimit().getOrDefault(((BaseVillager)ctx.getInitiator()).getExpertise().getConfigName(), 1)).build());
      stageMap.put(ExcavateSubstrateBehavior.Stage.AWARD, AwardExperienceStep.builder().name("AwardExperience").experienceAmount(this.config.experienceReward()).nextStage(ExcavateSubstrateBehavior.Stage.END).build());
      return StagedStep.<BaseVillager>builder().name("ExcavateSubstrateBehavior").initialStage(ExcavateSubstrateBehavior.Stage.PICK_TARGET).stageStepMap(stageMap).nextStage(ExcavateSubstrateBehavior.Stage.END).build();
   }

   private BehaviorStep<BaseVillager> createPickTargetStep() {
      return OneShotStep.<BaseVillager>builder().name("PickExcavationTarget").action((ctx) -> {
         if (this.selectedSource == null) {
            return StepResult.transition(ExcavateSubstrateBehavior.Stage.AWARD);
         } else {
            boolean resolved = this.targetResolver.resolveBlockTarget(ctx, this.selectedSource.memoryType(), this.selectedSource.matcher(), this.confirmBox, this.maxConfirms, 1);
            if (!resolved) {
               log.behaviorStatus("Selected excavation site no longer has live sites, ending behavior");
               return StepResult.transition(ExcavateSubstrateBehavior.Stage.AWARD);
            } else {
               return StepResult.transition(ExcavateSubstrateBehavior.Stage.APPROACH);
            }
         }
      }).build();
   }

   private BehaviorStep<BaseVillager> createDigStep() {
      return TimeBasedStep.<BaseVillager>builder().name("ExcavateStep").withTickable(ClockTicks.of(30L).asTickable()).onStart((ctx) -> {
         BaseVillager initiator = (BaseVillager)ctx.getInitiator();
         if (hasIronShovel(initiator)) {
            initiator.setHeldItem(Items.f_42384_.m_7968_());
         }

         initiator.triggerMotion(AnimationArchetype.DIG);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(17L), this::spawnDrops).onEnd((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         return StepResult.transition(ExcavateSubstrateBehavior.Stage.SETTLE);
      }).build();
   }

   private StepResult spawnDrops(@Nonnull BehaviorContext<BaseVillager> context) {
      Optional<BlockPos> target = TargetQueries.firstBlockPos(context);
      if (!target.isEmpty() && this.selectedSource != null) {
         BaseVillager villager = context.getInitiator();
         Level level = villager.m_9236_();
         BlockPos pos = (BlockPos)target.get();
         BlockState state = level.m_8055_(pos);
         if (AabbBlockScan.findFirst(pos, BlockScanBox.self(), this.selectedSource.matcher(), level).isEmpty()) {
            return StepResult.noOp();
         } else {
            Location effectLocation = Location.of(pos, level).center(true).add((double)0.0F, (double)0.5F, (double)0.0F, true);
            ParticleRegistry.harvestBlock(effectLocation, state);
            effectLocation.playSound(state.getSoundType(level, pos, villager).m_56775_(), 0.8F, 1.0F, SoundSource.BLOCKS);
            String harvestedBlockId = BuiltInRegistries.f_256975_.m_7981_(state.m_60734_()).toString();
            String expertiseName = villager.getExpertise().getConfigName();
            List<ItemStack> drops = hasIronShovel(villager) ? this.yieldData.rollDrops(expertiseName, harvestedBlockId) : this.rollBareHandedDrops();
            if (drops.isEmpty()) {
               return StepResult.noOp();
            } else {
               List<ItemEntity> spawned = effectLocation.dropItems(drops, true);
               spawned.forEach((itemEntity) -> itemEntity.m_32010_(ClockTicks.seconds((double)5.0F).getTicksAsInt()));
               context.setState(BehaviorStateType.ITEMS_TO_PICK_UP, ItemState.of(spawned));
               context.primaryDeed().ifPresent((outcome) -> {
                  outcome.recordYield(totalItemCount(drops));
                  String excavatedItem = BuiltInRegistries.f_257033_.m_7981_(((ItemStack)drops.get(0)).m_41720_()).m_135815_();
                  outcome.recordDeedDetail(excavatedItem);
                  outcome.putDetailField("item", excavatedItem);
               });
               return StepResult.noOp();
            }
         }
      } else {
         return StepResult.noOp();
      }
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      context.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.RESOURCE_EXCAVATED, "substrate"));
      this.selectedSource = (ExcavatableSubstrateSource)this.selectSource(villager).orElse((Object)null);
      if (this.selectedSource == null) {
         this.requestStop("No excavation site available at behavior start");
      }

   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.selectedSource = null;
   }

   private Optional<ExcavatableSubstrateSource> selectSource(@Nonnull BaseVillager villager) {
      Map<ExcavatableSubstrateSource, Double> weightsBySource = new LinkedHashMap();

      for(ExcavatableSubstrateSource source : SOURCES) {
         Optional<List<GlobalPos>> memory = villager.getSettlementsBrain().getMemory(source.memoryType());
         if (memory.isPresent() && !((List)memory.get()).isEmpty()) {
            weightsBySource.put(source, this.yieldData.selectionWeight(source.selectionBlockId().toString()));
         }
      }

      if (weightsBySource.isEmpty()) {
         return Optional.empty();
      } else {
         return Optional.of((ExcavatableSubstrateSource)RandomUtil.weightedChoice(weightsBySource));
      }
   }

   private static int totalItemCount(@Nonnull List<ItemStack> drops) {
      return drops.stream().mapToInt(ItemStack::m_41613_).sum();
   }

   private static boolean hasIronShovel(@Nonnull BaseVillager villager) {
      return villager.getSettlementsInventory().countMatching(IRON_SHOVEL_MATCH) > 0;
   }

   private List<ItemStack> rollBareHandedDrops() {
      return !RandomUtil.chance(this.config.bareHandedNuggetChance()) ? List.of() : List.of(new ItemStack(Items.f_42749_, 1));
   }

   static {
      IRON_SHOVEL_MATCH = new ItemMatch.ItemRef(IRON_SHOVEL_ID);
      SOURCES = List.of(new ExcavatableSubstrateSource("gravel", MemoryTypeRegistry.GRAVEL_SITES, BlockMatchers.LOOSE_GRAVEL, GRAVEL_BLOCK_ID), new ExcavatableSubstrateSource("sand", MemoryTypeRegistry.SAND_SITES, BlockMatchers.LOOSE_SAND, SAND_BLOCK_ID));
   }

   private static enum Stage implements StageKey {
      PICK_TARGET,
      APPROACH,
      DIG,
      SETTLE,
      PICKUP,
      LOOP,
      AWARD,
      END;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{PICK_TARGET, APPROACH, DIG, SETTLE, PICKUP, LOOP, AWARD, END};
      }
   }

   private static record ExcavatableSubstrateSource(@Nonnull String name, @Nonnull MemoryType<List<GlobalPos>> memoryType, @Nonnull BlockMatcher matcher, @Nonnull ResourceLocation selectionBlockId) {
   }
}
