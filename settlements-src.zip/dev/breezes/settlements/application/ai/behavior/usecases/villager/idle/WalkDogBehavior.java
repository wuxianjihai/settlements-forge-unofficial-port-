package dev.breezes.settlements.application.ai.behavior.usecases.villager.idle;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.StopBehaviorException;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.infrastructure.minecraft.entities.wolves.SettlementsWolf;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.network.protocol.game.ClientboundSetEntityLinkPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

public class WalkDogBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(WalkDogBehavior.class.getName());
   private static final double LEASH_DISTANCE = (double)2.5F;
   private static final int FOLLOW_COMPLETION_DISTANCE = 3;
   private final WalkDogConfig config;
   private SettlementsWolf cachedWolf;
   private boolean wolfFollowLockAcquired;

   public WalkDogBehavior(@Nonnull WalkDogConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.config = config;
      this.preconditions.add(ICondition.named("HasValidWolfToWalk", this::hasValidWolfToWalk));
      this.continueConditions.add(ICondition.named("CachedWolfStillWalkable", (villager) -> this.cachedWolf != null && this.cachedWolf.m_6084_() && !this.cachedWolf.m_213877_() && villager.equals(this.cachedWolf.getOwner()) && (!this.wolfFollowLockAcquired || this.cachedWolf.isFollowOwnerLockedBy(WalkDogBehavior.class))));
      this.initializeStateMachine(this.createControlStep(), WalkDogBehavior.WalkDogStage.END);
   }

   private boolean hasValidWolfToWalk(@Nonnull BaseVillager villager) {
      return villager.m_6274_().m_21952_(MemoryTypeRegistry.OWNED_WOLVES.getModuleType()).filter((uuids) -> !uuids.isEmpty()).flatMap((uuids) -> this.findFirstValidWolf(villager, villager.m_9236_(), uuids)).isPresent();
   }

   private Optional<SettlementsWolf> findFirstValidWolf(@Nonnull BaseVillager villager, @Nonnull Level world, @Nonnull List<UUID> uuids) {
      AABB scanBox = this.createWolfScanBox(villager);
      List<SettlementsWolf> nearbyWolves = world.m_45976_(SettlementsWolf.class, scanBox);

      for(UUID uuid : uuids) {
         Optional<SettlementsWolf> matchingWolf = nearbyWolves.stream().filter((wolf) -> this.isValidWolfForWalk(villager, wolf, uuid)).findFirst();
         if (matchingWolf.isPresent()) {
            return matchingWolf;
         }
      }

      return Optional.empty();
   }

   private boolean isValidWolfForWalk(@Nonnull BaseVillager villager, @Nonnull SettlementsWolf wolf, @Nonnull UUID uuid) {
      return wolf.m_20148_().equals(uuid) && wolf.m_6084_() && villager.equals(wolf.getOwner());
   }

   private AABB createWolfScanBox(@Nonnull BaseVillager villager) {
      return villager.m_20191_().m_82377_((double)this.config.horizontalScanRange(), (double)this.config.verticalScanRange(), (double)this.config.horizontalScanRange());
   }

   private StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("WalkDogBehavior").initialStage(WalkDogBehavior.WalkDogStage.APPROACH_WOLF).stageStepMap(Map.of(WalkDogBehavior.WalkDogStage.APPROACH_WOLF, this.createApproachStep(), WalkDogBehavior.WalkDogStage.LEASH_WOLF, this.createLeashStep(), WalkDogBehavior.WalkDogStage.FOLLOWING_WOLF, this.createFollowingStep(), WalkDogBehavior.WalkDogStage.UNLEASH_WOLF, this.createUnleashStep())).nextStage(WalkDogBehavior.WalkDogStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   private BehaviorStep<BaseVillager> createApproachStep() {
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.5F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.WALK).completionDistance(1).reachabilityGated(false).build()).actionStep((ctx) -> StepResult.transition(WalkDogBehavior.WalkDogStage.LEASH_WOLF)).build();
   }

   private BehaviorStep<BaseVillager> createLeashStep() {
      return (context) -> {
         if (this.cachedWolf == null) {
            throw new StopBehaviorException("Cached wolf became unavailable before leashing");
         } else {
            BaseVillager villager = (BaseVillager)context.getInitiator();
            context.getLevel().m_7726_().m_8445_(this.cachedWolf, new ClientboundSetEntityLinkPacket(this.cachedWolf, villager));
            this.cachedWolf.lockFollowOwner(WalkDogBehavior.class);
            this.wolfFollowLockAcquired = true;
            ParticleRegistry.breedHearts(Location.fromEntity(this.cachedWolf, false));
            return StepResult.transition(WalkDogBehavior.WalkDogStage.FOLLOWING_WOLF);
         }
      };
   }

   private BehaviorStep<BaseVillager> createFollowingStep() {
      return TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.seconds((double)this.config.walkDurationSeconds()).asTickable()).addPeriodicStep(ClockTicks.seconds((double)1.0F).getTicksAsInt(), (context) -> {
         ((BaseVillager)context.getInitiator()).getNavigationManager().navigateTo(Location.fromEntity(this.cachedWolf, false), NavigationType.WALK, 3);
         return StepResult.noOp();
      }).onEnd((ctx) -> StepResult.transition(WalkDogBehavior.WalkDogStage.UNLEASH_WOLF)).build();
   }

   private BehaviorStep<BaseVillager> createUnleashStep() {
      return (context) -> {
         context.getLevel().m_7726_().m_8445_(this.cachedWolf, new ClientboundSetEntityLinkPacket(this.cachedWolf, (Entity)null));
         this.cachedWolf.unlockFollowOwner(WalkDogBehavior.class);
         BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.DOG_WALKED, (String)null);
         outcome.markSucceeded();
         context.declarePrimaryDeed(outcome);
         return StepResult.transition(WalkDogBehavior.WalkDogStage.END);
      };
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      this.cachedWolf = null;
      entity.m_6274_().m_21952_(MemoryTypeRegistry.OWNED_WOLVES.getModuleType()).flatMap((uuids) -> this.findFirstValidWolf(entity, world, uuids)).ifPresent((wolf) -> this.cachedWolf = wolf);
      if (this.cachedWolf != null) {
         context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.cachedWolf)));
         this.cachedWolf.m_21839_(false);
      }

   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager entity) {
      if (this.cachedWolf != null) {
         ((ServerLevel)world).m_7726_().m_8445_(this.cachedWolf, new ClientboundSetEntityLinkPacket(this.cachedWolf, (Entity)null));
         this.cachedWolf.unlockFollowOwner(WalkDogBehavior.class);
      }

      entity.getNavigationManager().stop();
      this.cachedWolf = null;
      this.wolfFollowLockAcquired = false;
   }

   private static enum WalkDogStage implements StageKey {
      APPROACH_WOLF,
      LEASH_WOLF,
      FOLLOWING_WOLF,
      UNLEASH_WOLF,
      END;

      // $FF: synthetic method
      private static WalkDogStage[] $values() {
         return new WalkDogStage[]{APPROACH_WOLF, LEASH_WOLF, FOLLOWING_WOLF, UNLEASH_WOLF, END};
      }
   }
}
