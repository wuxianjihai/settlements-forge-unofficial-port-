package dev.breezes.settlements.application.ai.behavior.usecases.villager.farming;

import dev.breezes.settlements.application.ai.behavior.runtime.timing.BehaviorTimingConfig;
import dev.breezes.settlements.application.config.validation.BehaviorCooldownValidator;
import dev.breezes.settlements.infrastructure.config.annotations.BehaviorConfig;
import dev.breezes.settlements.infrastructure.config.annotations.ConfigurationType;
import dev.breezes.settlements.infrastructure.config.annotations.integers.IntegerConfig;

@BehaviorConfig(
   name = "harvest_sweet_berries",
   type = ConfigurationType.BEHAVIOR
)
public record HarvestSweetBerriesConfig(@IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "precondition_check_cooldown_min",description = "Minimum interval (in seconds) between precondition checks",defaultValue = 10,min = 1) int preconditionCheckCooldownMin, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "precondition_check_cooldown_max",description = "Maximum interval (in seconds) between precondition checks",defaultValue = 20,min = 1) int preconditionCheckCooldownMax, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "behavior_cooldown_min",description = "Minimum behavior cooldown time (in seconds)",defaultValue = 20,min = 1) int behaviorCooldownMin, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "behavior_cooldown_max",description = "Maximum behavior cooldown time (in seconds)",defaultValue = 40,min = 1) int behaviorCooldownMax, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "experience_reward",description = "Villager experience awarded when the behavior completes successfully",defaultValue = 2,min = 0) int experienceReward) implements BehaviorTimingConfig {
   public HarvestSweetBerriesConfig {
      BehaviorCooldownValidator.validateRanges(preconditionCheckCooldownMin, preconditionCheckCooldownMax, behaviorCooldownMin, behaviorCooldownMax);
   }
}
