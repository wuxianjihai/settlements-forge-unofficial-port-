package dev.breezes.settlements.application.ai.behavior.usecases.villager.hunger;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.domain.ai.conditions.AnyOfCondition;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.conditions.IEntityCondition;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.Tickable;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class EatFoodBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(EatFoodBehavior.class.getName());
   private static final ClockTicks EATING_DURATION = ClockTicks.of(40L);
   private static final ClockTicks PARTICLE_INTERVAL = ClockTicks.of(2L);
   private static final ClockTicks CHEW_SOUND_INTERVAL = ClockTicks.of(4L);
   @Nullable
   private ItemStack selectedFood;
   @Nullable
   private Tickable particleTimer;
   @Nullable
   private Tickable chewSoundTimer;

   public EatFoodBehavior(@Nonnull BehaviorSupport support) {
      super(log, ClockTicks.seconds((double)10.0F).asTickable(), ClockTicks.seconds((double)20.0F).asTickable(), support);
      this.preconditions.add(AnyOfCondition.builder().conditions(List.of((IEntityCondition)(villager) -> villager.getHunger() < support.getHungerConfig().eatPriorityThreshold(), (IEntityCondition)(villager) -> villager.m_21223_() < villager.m_21233_())).description("IsHungryOrHurt").build());
      this.preconditions.add(ICondition.named("HasFood", (villager) -> villager.getSettlementsInventory().anyMatch((stack) -> stack.m_41720_().m_41473_() != null)));
      this.preconditions.add(ICondition.named("NotSleeping", (villager) -> !villager.m_5803_()));
      this.selectedFood = null;
      this.particleTimer = null;
      this.chewSoundTimer = null;
      this.initializeStateMachine(this.createControlStep(), EatFoodBehavior.EatStage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("EatFoodBehavior").initialStage(EatFoodBehavior.EatStage.EATING).stageStepMap(Map.of(EatFoodBehavior.EatStage.EATING, this.createEatingStep())).nextStage(EatFoodBehavior.EatStage.END).build();
   }

   private TimeBasedStep<BaseVillager> createEatingStep() {
      return TimeBasedStep.<BaseVillager>builder().withTickable(EATING_DURATION.asTickable()).onStart((context) -> {
         BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
         this.selectedFood = (ItemStack)this.findFirstFoodRepresentative(villager.getSettlementsInventory()).orElse((Object)null);
         if (this.selectedFood == null) {
            return StepResult.complete();
         } else {
            villager.setHeldItem(this.selectedFood.m_41777_());
            villager.triggerMotion(AnimationArchetype.EAT);
            this.particleTimer = PARTICLE_INTERVAL.asTickable();
            this.chewSoundTimer = CHEW_SOUND_INTERVAL.asTickable();
            return StepResult.noOp();
         }
      }).everyTick((context) -> {
         if (this.selectedFood != null && !this.selectedFood.m_41619_()) {
            BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
            Location villagerHead = Location.fromEntity(villager, true);
            if (this.particleTimer.tickCheckAndReset((double)1.0F)) {
               villagerHead.displayParticles(new ItemParticleOption(ParticleTypes.f_123752_, this.selectedFood.m_41777_()), 2, 0.2, 0.2, 0.2, 0.02);
            }

            if (this.chewSoundTimer.tickCheckAndReset((double)1.0F)) {
               villagerHead.playSound(SoundEvents.f_11912_, 0.6F, 1.0F, SoundSource.NEUTRAL);
            }

            return StepResult.noOp();
         } else {
            return StepResult.complete();
         }
      }).onEnd((context) -> {
         BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
         villager.setMotion(AnimationArchetype.IDLE);
         this.finishEating(villager);
         return StepResult.complete();
      }).build();
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.setMotion(AnimationArchetype.IDLE);
      villager.clearHeldItem();
      this.selectedFood = null;
      this.particleTimer = null;
      this.chewSoundTimer = null;
   }

   private void finishEating(@Nonnull BaseVillager villager) {
      if (this.selectedFood == null) {
         villager.clearHeldItem();
      } else {
         Location villagerHead = Location.fromEntity(villager, true);
         villagerHead.playSound(SoundEvents.f_12321_, 0.5F, 1.0F, SoundSource.NEUTRAL);
         villagerHead.playSound(SoundEvents.f_12509_, 0.8F, 1.0F, SoundSource.NEUTRAL);
         villagerHead.displayParticles(ParticleTypes.f_123748_, 6, 0.2, 0.2, 0.2, 0.01);
         FoodProperties food = this.selectedFood.m_41720_().m_41473_();
         if (food != null) {
            int nutrition = food.m_38744_();
            float hungerRestored = Math.min((float)nutrition / 20.0F, 1.0F - villager.getHunger());
            villager.setHunger(villager.getHunger() + hungerRestored);
            villager.m_7292_(new MobEffectInstance(MobEffects.f_19605_, ClockTicks.seconds((double)(nutrition * 5)).getTicksAsInt(), 0, true, true));
         }

         villager.getSettlementsInventory().consume((ItemStack)this.selectedFood, 1);
         villager.clearHeldItem();
         this.selectedFood = null;
      }
   }

   private Optional<ItemStack> findFirstFoodRepresentative(@Nonnull VillagerInventory inventory) {
      return inventory.findFirst((stack) -> stack.m_41720_().m_41473_() != null);
   }

   private static enum EatStage implements StageKey {
      EATING,
      END;

      // $FF: synthetic method
      private static EatStage[] $values() {
         return new EatStage[]{EATING, END};
      }
   }
}
