package dev.breezes.settlements.application.ai.behavior.usecases.villager.donation;

import dev.breezes.settlements.application.economy.VillagerWallet;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.Comparator;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import lombok.Generated;

@ServerScope
public final class DonationScanner {
   private final VillagerWallet villagerWallet;

   public Optional<BaseVillager> findNeediest(@Nonnull BaseVillager donor, int floor, int minDonation, int comfort) {
      int donorBalance = this.villagerWallet.getBalance(donor);
      if (donorBalance <= comfort) {
         return Optional.empty();
      } else {
         Stream var10000 = this.getPerceivedEntities(donor).ofType(BaseVillager.class, (candidate) -> this.isEligible(candidate, donor, floor, minDonation, donorBalance, comfort));
         VillagerWallet var10001 = this.villagerWallet;
         Objects.requireNonNull(var10001);
         return var10000.min(Comparator.comparingInt(var10001::getBalance));
      }
   }

   private boolean isEligible(@Nonnull BaseVillager candidate, @Nonnull BaseVillager donor, int floor, int minDonation, int donorBalance, int comfort) {
      if (candidate == donor) {
         return false;
      } else {
         int recipientBalance = this.villagerWallet.getBalance(candidate);
         if (recipientBalance >= floor) {
            return false;
         } else {
            return DonationAmountCalculator.cap(floor, recipientBalance, donorBalance, comfort) >= minDonation;
         }
      }
   }

   private PerceivedEntities getPerceivedEntities(@Nonnull BaseVillager villager) {
      return (PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_SENSED_ENTITIES).orElse(PerceivedEntities.empty());
   }

   @Inject
   @Generated
   DonationScanner(VillagerWallet villagerWallet) {
      this.villagerWallet = villagerWallet;
   }
}
