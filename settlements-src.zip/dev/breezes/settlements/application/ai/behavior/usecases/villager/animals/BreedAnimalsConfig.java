package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals;

import dev.breezes.settlements.application.ai.behavior.runtime.timing.BehaviorTimingConfig;
import dev.breezes.settlements.application.config.validation.BehaviorCooldownValidator;
import dev.breezes.settlements.infrastructure.config.annotations.BehaviorConfig;
import dev.breezes.settlements.infrastructure.config.annotations.ConfigurationType;
import dev.breezes.settlements.infrastructure.config.annotations.integers.IntegerConfig;

@BehaviorConfig(
   name = "breed_animals",
   type = ConfigurationType.BEHAVIOR
)
public record BreedAnimalsConfig(@IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "precondition_check_cooldown_min",description = "Minimum interval (in seconds) between precondition checks",defaultValue = 30,min = 1) int preconditionCheckCooldownMin, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "precondition_check_cooldown_max",description = "Maximum interval (in seconds) between precondition checks",defaultValue = 60,min = 1) int preconditionCheckCooldownMax, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "behavior_cooldown_min",description = "Minimum behavior cooldown time (in seconds)",defaultValue = 30,min = 1) int behaviorCooldownMin, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "behavior_cooldown_max",description = "Maximum behavior cooldown time (in seconds)",defaultValue = 60,min = 1) int behaviorCooldownMax, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "scan_range_horizontal",description = "Horizontal range (in blocks) to scan for animals to breed",defaultValue = 32,min = 5,max = 128) int scanRangeHorizontal, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "scan_range_vertical",description = "Vertical range (in blocks) to scan for animals to breed",defaultValue = 16,min = 1,max = 16) int scanRangeVertical, @IntegerConfig(type = ConfigurationType.BEHAVIOR,identifier = "experience_reward",description = "Villager experience awarded when the behavior completes successfully",defaultValue = 1,min = 0) int experienceReward) implements BehaviorTimingConfig {
   public BreedAnimalsConfig {
      BehaviorCooldownValidator.validateRanges(preconditionCheckCooldownMin, preconditionCheckCooldownMax, behaviorCooldownMin, behaviorCooldownMax);
   }
}
