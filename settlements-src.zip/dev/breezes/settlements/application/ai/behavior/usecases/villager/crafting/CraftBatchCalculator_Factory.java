package dev.breezes.settlements.application.ai.behavior.usecases.villager.crafting;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.domain.economy.catalog.TradeCatalogRegistry;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class CraftBatchCalculator_Factory implements Factory<CraftBatchCalculator> {
   private final Provider<TradeCatalogRegistry> tradeCatalogProvider;

   private CraftBatchCalculator_Factory(Provider<TradeCatalogRegistry> tradeCatalogProvider) {
      this.tradeCatalogProvider = tradeCatalogProvider;
   }

   public CraftBatchCalculator get() {
      return newInstance((TradeCatalogRegistry)this.tradeCatalogProvider.get());
   }

   public static CraftBatchCalculator_Factory create(Provider<TradeCatalogRegistry> tradeCatalogProvider) {
      return new CraftBatchCalculator_Factory(tradeCatalogProvider);
   }

   public static CraftBatchCalculator newInstance(TradeCatalogRegistry tradeCatalog) {
      return new CraftBatchCalculator(tradeCatalog);
   }
}
