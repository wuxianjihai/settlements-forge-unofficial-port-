package dev.breezes.settlements.application.ai.behavior.usecases.villager.leisure;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.infrastructure.minecraft.swing.content.entity.SwingSeatEntity;
import dev.breezes.settlements.infrastructure.minecraft.swing.content.seat.BaseSwingSeatBlock;
import dev.breezes.settlements.infrastructure.minecraft.swing.content.seat.SwingSeatBlock;
import dev.breezes.settlements.infrastructure.minecraft.swing.util.SwingPlayLimiter;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

public class PlaySwingBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(PlaySwingBehavior.class.getName());
   private static final double MOUNT_DISTANCE_SQR = 2.3;
   private static final int NAV_TIMEOUT_TICKS = 600;
   private static final int CHECK_INTERVAL_TICKS = 10;
   private static final int TOTAL_TIMEOUT_TICKS = ClockTicks.seconds((double)120.0F).getTicksAsInt();
   private final PlaySwingConfig config;
   @Nullable
   private BlockPos cachedSeatPos;
   private int navTicks;
   private boolean mounted;

   public PlaySwingBehavior(@Nonnull PlaySwingConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.config = config;
      this.cachedSeatPos = null;
      this.navTicks = 0;
      this.mounted = false;
      this.preconditions.add(ICondition.named("SwingPlayQuota", (villager) -> SwingPlayLimiter.canPlay(villager)));
      this.continueConditions.add(ICondition.named("CachedSeatStillValid", (villager) -> this.cachedSeatPos != null && villager.m_9236_().m_8055_(this.cachedSeatPos).m_60734_() instanceof BaseSwingSeatBlock));
      this.initializeStateMachine(this.createControlStep(), PlaySwingBehavior.SwingStage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("PlaySwingBehavior").initialStage(PlaySwingBehavior.SwingStage.APPROACH).stageStepMap(Map.of(PlaySwingBehavior.SwingStage.APPROACH, this.createApproachStep())).nextStage(PlaySwingBehavior.SwingStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   private BehaviorStep<BaseVillager> createApproachStep() {
      return TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.of((long)TOTAL_TIMEOUT_TICKS).asTickable()).onStart((ctx) -> {
         this.navTicks = 0;
         return StepResult.noOp();
      }).addPeriodicStep(10, this::tickApproach).onEnd((ctx) -> {
         if (!((BaseVillager)ctx.getInitiator()).m_20159_()) {
            ((BaseVillager)ctx.getInitiator()).getNavigationManager().stop();
         }

         return StepResult.transition(PlaySwingBehavior.SwingStage.END);
      }).build();
   }

   private StepResult tickApproach(@Nonnull BehaviorContext<BaseVillager> ctx) {
      BaseVillager villager = ctx.getInitiator();
      BlockPos seatPos = this.cachedSeatPos;
      if (seatPos != null && villager.m_9236_().m_8055_(seatPos).m_60734_() instanceof BaseSwingSeatBlock) {
         if (villager.m_20159_()) {
            return StepResult.noOp();
         } else if (this.mounted) {
            return StepResult.transition(PlaySwingBehavior.SwingStage.END);
         } else if (seatPos.m_123331_(villager.m_20183_()) <= 2.3) {
            if (this.tryMount(villager, seatPos)) {
               this.mounted = true;
               return StepResult.noOp();
            } else {
               return StepResult.transition(PlaySwingBehavior.SwingStage.END);
            }
         } else {
            return ++this.navTicks > 600 ? StepResult.transition(PlaySwingBehavior.SwingStage.END) : StepResult.noOp();
         }
      } else {
         return StepResult.transition(PlaySwingBehavior.SwingStage.END);
      }
   }

   private boolean tryMount(@Nonnull BaseVillager villager, @Nonnull BlockPos seatPos) {
      villager.getNavigationManager().stop();
      List<SwingSeatEntity> seats = villager.m_9236_().m_45976_(SwingSeatEntity.class, new AABB(seatPos));
      SwingSeatEntity seat = seats.isEmpty() ? null : (SwingSeatEntity)seats.get(0);
      if (seat != null && seat.m_20160_()) {
         return false;
      } else {
         if (seat == null) {
            seat = new SwingSeatEntity(villager.m_9236_());
            seat.m_6034_((double)seatPos.m_123341_() + (double)0.5F, (double)seatPos.m_123342_() + (double)0.5F, (double)seatPos.m_123343_() + (double)0.5F);
            seat.setOriginPos(seatPos);
            villager.m_9236_().m_7967_(seat);
         }

         return villager.m_20329_(seat);
      }
   }

   @Nullable
   private static BlockPos findNearbySwingSeat(@Nonnull BaseVillager villager, int radius) {
      BlockPos center = villager.m_20183_();
      BlockPos best = null;
      double bestDist = Double.MAX_VALUE;

      for(BlockPos pos : BlockPos.m_121940_(center.m_7918_(-radius, -3, -radius), center.m_7918_(radius, 3, radius))) {
         BlockState st = villager.m_9236_().m_8055_(pos);
         if (st.m_60734_() instanceof BaseSwingSeatBlock && (!st.m_61138_(SwingSeatBlock.PART) || st.m_61143_(SwingSeatBlock.PART) != SwingSeatBlock.SeatPart.RIGHT)) {
            double d = pos.m_123331_(center);
            if (d < bestDist) {
               bestDist = d;
               best = pos.m_7949_();
            }
         }
      }

      return best;
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      this.cachedSeatPos = null;
      this.navTicks = 0;
      this.mounted = false;
      BlockPos seat = findNearbySwingSeat(villager, this.config.horizontalScanRange());
      if (seat == null) {
         this.requestStop("No swing seat within range");
      } else {
         this.cachedSeatPos = seat;
         villager.getNavigationManager().navigateTo(Location.of(this.cachedSeatPos, villager.m_9236_()), NavigationType.WALK, 1);
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      if (!villager.m_20159_()) {
         villager.getNavigationManager().stop();
      }

      this.cachedSeatPos = null;
      this.navTicks = 0;
      this.mounted = false;
   }

   private static enum SwingStage implements StageKey {
      APPROACH,
      END;

      // $FF: synthetic method
      private static SwingStage[] $values() {
         return new SwingStage[]{APPROACH, END};
      }
   }
}
