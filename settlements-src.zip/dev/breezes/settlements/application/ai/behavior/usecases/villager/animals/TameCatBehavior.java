package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetQueries;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.conditions.PerceivedEntityExistsCondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.entities.Expertise;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.entities.cats.SettlementsCat;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.entity.animal.CatVariant;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public class TameCatBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(TameCatBehavior.class.getName());
   private static final ResourceLocation COD_ID = new ResourceLocation("minecraft", "cod");
   private static final double TAME_SUCCESS_CHANCE = 0.33;
   private static final int MAX_TAME_ATTEMPTS = 5;
   private final TameCatConfig config;
   private int attemptsRemaining;
   private boolean shouldRewardExperience;

   public TameCatBehavior(TameCatConfig config, BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.config = config;
      this.attemptsRemaining = 0;
      this.shouldRewardExperience = false;
      this.preconditions.add(PerceivedEntityExistsCondition.builder().entityType(Cat.class).filter((villager, cat) -> !cat.m_21824_()).completionRange(2).build());
      this.preconditions.add(support.getDemandSignalService().requireItem(new ItemMatch.ItemRef(COD_ID), 1, 50, this.getClass().getSimpleName()));
      this.preconditions.add(ICondition.named("OwnershipBelowLimit", (villager) -> {
         Expertise expertise = villager.getExpertise();
         int limit = (Integer)this.config.expertiseCatLimit().getOrDefault(expertise.getConfigName(), 1);
         int owned = villager.m_9236_().m_6443_(Cat.class, villager.m_20191_().m_82377_((double)48.0F, (double)16.0F, (double)48.0F), (cat) -> cat.m_21824_() && ownerMatches(villager, cat)).size();
         if (owned >= limit) {
            log.behaviorStatus("Owned cats {} >= limit {}, aborting tame (precondition)", owned, limit);
            return false;
         } else {
            return true;
         }
      }));
      this.initializeStateMachine(this.createControlStep(), TameCatBehavior.TameStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("TameCatBehavior").initialStage(TameCatBehavior.TameStage.TAME_CAT).stageStepMap(Map.of(TameCatBehavior.TameStage.TAME_CAT, this.createTameCatStep())).nextStage(TameCatBehavior.TameStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   private BehaviorStep<BaseVillager> createTameCatStep() {
      TimeBasedStep<BaseVillager> attemptStep = TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.seconds((double)1.0F).asTickable()).onStart((ctx) -> {
         this.attemptsRemaining = Math.max(0, this.attemptsRemaining - 1);
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         ((BaseVillager)ctx.getInitiator()).setHeldItem(Items.f_42526_.m_7968_());
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(12L), (ctx) -> {
         Optional<Cat> catOptional = this.getTargetCat(ctx);
         if (catOptional.isEmpty()) {
            return StepResult.complete();
         } else {
            Cat cat = (Cat)catOptional.get();
            if (cat.m_21824_()) {
               return StepResult.complete();
            } else if (!((BaseVillager)ctx.getInitiator()).getMinecraftEntity().getSettlementsInventory().consumeIfRequired(Items.f_42526_, 1, GeneralConfig.bypassInventoryRequirements)) {
               return StepResult.complete();
            } else {
               log.behaviorStatus("Attempting to tame cat {}", cat.m_20148_());
               Location catLoc = Location.fromEntity(cat, false);
               if (RandomUtil.chance(0.33)) {
                  catLoc.displayParticles(ParticleTypes.f_123750_, 7, 0.4, (double)0.5F, 0.4, 0.01);
                  catLoc.playSound(SoundEvents.f_11788_, 0.8F, 1.0F, SoundSource.NEUTRAL);
                  CatVariant variant = cat.m_28554_();
                  boolean wasBaby = cat.m_6162_();
                  cat.m_146870_();
                  SettlementsCat settlementsCat = SettlementsCat.spawn(catLoc);
                  settlementsCat.m_28464_(variant);
                  if (wasBaby) {
                     settlementsCat.m_6863_(true);
                  }

                  settlementsCat.m_7105_(true);
                  settlementsCat.m_21816_(((BaseVillager)ctx.getInitiator()).getMinecraftEntity().m_20148_());
                  settlementsCat.applyCollarColor(DyeColor.LIME);
                  this.shouldRewardExperience = true;
                  BehaviorOutcome tameOutcome = BehaviorOutcome.forDeed(WorldEventType.ANIMAL_TAMED, (String)null);
                  tameOutcome.recordDeedDetail("a cat");
                  tameOutcome.putDetailField("animal", "cat");
                  ctx.declarePrimaryDeed(tameOutcome);
                  log.behaviorStatus("Successfully tamed cat {}", settlementsCat.m_20148_());
                  return StepResult.complete();
               } else {
                  catLoc.displayParticles(ParticleTypes.f_123762_, 6, 0.35, (double)0.5F, 0.35, 0.01);
                  log.behaviorStatus("Failed to tame cat");
                  return StepResult.noOp();
               }
            }
         }
      }).onEnd((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).clearHeldItem();
         if (this.attemptsRemaining > 0) {
            Optional<Cat> target = this.getTargetCat(ctx);
            if (target.isPresent() && ((Cat)target.get()).m_6084_() && !((Cat)target.get()).m_21824_()) {
               return StepResult.transition(TameCatBehavior.TameStage.TAME_CAT);
            }
         }

         return StepResult.complete();
      }).build();
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.5F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 2)).actionStep(attemptStep).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      Expertise expertise = villager.getExpertise();
      int limit = (Integer)this.config.expertiseCatLimit().getOrDefault(expertise.getConfigName(), 1);
      int owned = villager.m_9236_().m_6443_(Cat.class, villager.m_20191_().m_82377_((double)48.0F, (double)16.0F, (double)48.0F), (cat) -> cat.m_21824_() && ownerMatches(villager, cat)).size();
      if (owned >= limit) {
         log.behaviorStatus("Owned cats {} >= limit {}, aborting tame", owned, limit);
         this.requestStop("Owned cats greater than taming limit");
      } else {
         Optional<Cat> chosenCat = this.findClosestReachableUntamedCat(villager);
         if (chosenCat.isEmpty()) {
            this.requestStop("No reachable untamed cats found");
         } else {
            context.setState(BehaviorStateType.TARGET, TargetState.of(List.of(Targetable.fromEntity((Entity)chosenCat.get()))));
            int codAvailable = villager.getSettlementsInventory().count(Items.f_42526_);
            this.attemptsRemaining = GeneralConfig.bypassInventoryRequirements ? 5 : Math.min(5, codAvailable);
            if (this.attemptsRemaining <= 0) {
               this.requestStop("No cod available at behavior start");
            } else {
               this.shouldRewardExperience = false;
            }
         }
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      if (this.shouldRewardExperience) {
         this.rewardExperience(villager);
      }

      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.shouldRewardExperience = false;
   }

   private Optional<Cat> getTargetCat(@Nonnull BehaviorContext<BaseVillager> context) {
      return TargetQueries.firstEntity(context, EntityType.f_20553_, Cat.class);
   }

   private Optional<Cat> findClosestReachableUntamedCat(@Nonnull BaseVillager villager) {
      return ((PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_SENSED_ENTITIES).orElse(PerceivedEntities.empty())).<Cat>closest(Cat.class, (cat) -> !cat.m_21824_() && villager.getNavigationManager().canReach(Location.fromEntity(cat, false), (double)2.0F), villager);
   }

   private static boolean ownerMatches(@Nonnull BaseVillager villager, @Nonnull Cat cat) {
      try {
         return villager.m_20148_().equals(cat.m_21805_());
      } catch (Throwable var3) {
         return cat.m_269323_() != null && cat.m_269323_().m_20148_().equals(villager.m_20148_());
      }
   }

   private static enum TameStage implements StageKey {
      TAME_CAT,
      END;

      // $FF: synthetic method
      private static TameStage[] $values() {
         return new TameStage[]{TAME_CAT, END};
      }
   }
}
