package dev.breezes.settlements.application.ai.behavior.usecases.villager.scavenge;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.blocks.VisitedBlockSitesState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.items.ItemState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetQueries;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.AwardExperienceStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.LoopBackStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.OneShotStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.PickupItemsStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.WaitStep;
import dev.breezes.settlements.application.ai.targeting.BlockMemoryTargetResolver;
import dev.breezes.settlements.bootstrap.registry.particles.ParticleRegistry;
import dev.breezes.settlements.domain.ai.conditions.KnownBlockSitesPrecondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.entities.Expertise;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.AabbBlockScan;
import dev.breezes.settlements.domain.world.blocks.BlockMatcher;
import dev.breezes.settlements.domain.world.blocks.BlockMatchers;
import dev.breezes.settlements.domain.world.blocks.BlockScanBox;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.data.scavenge.ScavengeYieldDataManager;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

public class ScavengeBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ScavengeBehavior.class.getName());
   private static final ClockTicks SETTLE_DURATION = ClockTicks.seconds((double)1.0F);
   private static final int APPROACH_TIMEOUT_TICKS = ClockTicks.seconds((double)20.0F).getTicksAsInt();
   private static final int DEFAULT_FORAGE_BUDGET = 3;
   private final BlockMatcher floraMatcher;
   private final BlockScanBox confirmBox;
   private final int maxConfirms;
   private final ScavengeConfig config;
   private final ScavengeYieldDataManager yieldData;
   private final BlockMemoryTargetResolver targetResolver;

   public ScavengeBehavior(@Nonnull ScavengeConfig config, @Nonnull BehaviorSupport support, @Nonnull ScavengeYieldDataManager yieldData) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.config = config;
      this.yieldData = yieldData;
      this.targetResolver = support.getBlockMemoryTargetResolver();
      this.floraMatcher = BlockMatchers.SCAVENGEABLE_FLORA;
      this.confirmBox = BlockScanBox.confirm();
      this.maxConfirms = 8;
      this.preconditions.add(KnownBlockSitesPrecondition.builder().memoryType(MemoryTypeRegistry.SCAVENGEABLE_FLORA_SITES).matcher(this.floraMatcher).confirmBox(this.confirmBox).maxSitesToConfirm(this.maxConfirms).completionRange(1).description("Known scavengeable flora sites").build());
      this.initializeStateMachine(this.createControlStep(), ScavengeBehavior.Stage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      Map<StageKey, BehaviorStep<BaseVillager>> stageMap = new HashMap();
      stageMap.put(ScavengeBehavior.Stage.PICK_TARGET, this.createPickTargetStep());
      stageMap.put(ScavengeBehavior.Stage.APPROACH, StayCloseStep.builder().closeEnoughDistance((double)1.5F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.WALK).completionDistance(1).unreachableTransition(ScavengeBehavior.Stage.PICK_TARGET).build()).actionStep(OneShotStep.builder().name("ArrivedAtFlora").action((ctx) -> StepResult.transition(ScavengeBehavior.Stage.FORAGE)).build()).timeoutTicks(APPROACH_TIMEOUT_TICKS).timeoutTransition(ScavengeBehavior.Stage.PICK_TARGET).build());
      stageMap.put(ScavengeBehavior.Stage.FORAGE, this.createForageStep());
      stageMap.put(ScavengeBehavior.Stage.SETTLE, WaitStep.builder().waitTime(SETTLE_DURATION.asTickable()).nextStage(ScavengeBehavior.Stage.PICKUP).build());
      stageMap.put(ScavengeBehavior.Stage.PICKUP, PickupItemsStep.builder().name("PickupForageDrops").nextStage(ScavengeBehavior.Stage.LOOP).build());
      stageMap.put(ScavengeBehavior.Stage.LOOP, LoopBackStep.builder().name("ScavengeLoopBack").loopBackTo(ScavengeBehavior.Stage.PICK_TARGET).completionTransition(ScavengeBehavior.Stage.AWARD).maxIterationsResolver((ctx) -> this.forageBudget(((BaseVillager)ctx.getInitiator()).getExpertise())).build());
      stageMap.put(ScavengeBehavior.Stage.AWARD, AwardExperienceStep.builder().name("AwardScavengeXp").experienceAmount(this.config.experienceReward()).nextStage(ScavengeBehavior.Stage.END).build());
      return StagedStep.<BaseVillager>builder().name("ScavengeBehavior").initialStage(ScavengeBehavior.Stage.PICK_TARGET).stageStepMap(stageMap).nextStage(ScavengeBehavior.Stage.END).build();
   }

   private BehaviorStep<BaseVillager> createPickTargetStep() {
      return OneShotStep.<BaseVillager>builder().name("PickForageTarget").action((ctx) -> {
         boolean resolved = this.targetResolver.resolveBlockTarget(ctx, MemoryTypeRegistry.SCAVENGEABLE_FLORA_SITES, this.floraMatcher, this.confirmBox, this.maxConfirms, 1);
         if (!resolved) {
            log.behaviorStatus("No additional forage targets found, ending behavior");
            return StepResult.transition(ScavengeBehavior.Stage.AWARD);
         } else {
            return StepResult.transition(ScavengeBehavior.Stage.APPROACH);
         }
      }).build();
   }

   private BehaviorStep<BaseVillager> createForageStep() {
      return TimeBasedStep.<BaseVillager>builder().name("ForageFlora").withTickable(ClockTicks.of(30L).asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.HARVEST);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(14L), (ctx) -> {
         Optional<BlockPos> target = TargetQueries.firstBlockPos(ctx);
         if (target.isEmpty()) {
            return StepResult.noOp();
         } else {
            BaseVillager villager = (BaseVillager)ctx.getInitiator();
            Level world = villager.m_9236_();
            BlockPos pos = (BlockPos)target.get();
            BlockState state = world.m_8055_(pos);
            if (AabbBlockScan.findFirst(pos, BlockScanBox.self(), this.floraMatcher, world).isEmpty()) {
               return StepResult.noOp();
            } else {
               Location effectLocation = Location.of(pos, world).center(true).add((double)0.0F, (double)0.5F, (double)0.0F, true);
               ParticleRegistry.harvestBlock(effectLocation, state);
               effectLocation.playSound(SoundEvents.f_11988_, 0.8F, 1.0F, SoundSource.BLOCKS);
               String harvestedBlockId = BuiltInRegistries.f_256975_.m_7981_(state.m_60734_()).toString();
               String expertiseName = villager.getExpertise().getConfigName();
               List<ItemStack> drops = this.yieldData.rollDrops(expertiseName, harvestedBlockId);
               List<ItemEntity> spawned = effectLocation.dropItems(drops, true);
               spawned.forEach((itemEntity) -> itemEntity.m_32010_(ClockTicks.seconds((double)5.0F).getTicksAsInt()));
               ctx.setState(BehaviorStateType.ITEMS_TO_PICK_UP, ItemState.of(spawned));
               ctx.getState(BehaviorStateType.VISITED_BLOCK_SITES, VisitedBlockSitesState.class).ifPresent((visitedSites) -> visitedSites.addSite(GlobalPos.m_122643_(world.m_46472_(), pos)));
               ctx.primaryDeed().ifPresent((outcome) -> outcome.recordYield(totalItemCount(drops)));
               return StepResult.noOp();
            }
         }
      }).onEnd((ctx) -> StepResult.transition(ScavengeBehavior.Stage.SETTLE)).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      context.declarePrimaryDeed(BehaviorOutcome.forDeed(WorldEventType.RESOURCE_HARVESTED, "forage"));
      context.setState(BehaviorStateType.VISITED_BLOCK_SITES, VisitedBlockSitesState.empty());
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
   }

   private int forageBudget(@Nonnull Expertise expertise) {
      return (Integer)this.config.expertiseForageBudget().getOrDefault(expertise.getConfigName(), 3);
   }

   private static int totalItemCount(@Nonnull List<ItemStack> drops) {
      return drops.stream().mapToInt(ItemStack::m_41613_).sum();
   }

   private static enum Stage implements StageKey {
      PICK_TARGET,
      APPROACH,
      FORAGE,
      SETTLE,
      PICKUP,
      LOOP,
      AWARD,
      END;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{PICK_TARGET, APPROACH, FORAGE, SETTLE, PICKUP, LOOP, AWARD, END};
      }
   }
}
