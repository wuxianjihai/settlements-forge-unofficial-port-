package dev.breezes.settlements.application.ai.behavior.usecases.villager.cartographer;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.bootstrap.registry.sounds.SoundRegistry;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.function.Function;
import javax.annotation.Nonnull;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Items;

final class MapSketch {
   private static final long SKETCH_DURATION_TICKS = 40L;
   private static final long FILLED_MAP_KEYFRAME_TICKS = 20L;

   static TimeBasedStep<BaseVillager> step(@Nonnull Function<BehaviorContext<BaseVillager>, StepResult> onSketched) {
      return TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.of(40L).asTickable()).onStart((context) -> {
         BaseVillager villager = (BaseVillager)context.getInitiator();
         villager.getNavigationManager().stop();
         villager.setHeldItem(Items.f_42676_.m_7968_());
         SoundRegistry.MAP_FLAP.playGlobally(Location.fromEntity(villager, false), SoundSource.NEUTRAL);
         villager.triggerMotion(AnimationArchetype.WRITE_TO_MAP);
         return StepResult.noOp();
      }).addKeyFrame(ClockTicks.of(20L), (context) -> {
         ((BaseVillager)context.getInitiator()).setHeldItem(Items.f_42573_.m_7968_());
         SoundRegistry.MAP_SCRIBBLE.playGlobally(Location.fromEntity((Entity)context.getInitiator(), false), SoundSource.NEUTRAL);
         return StepResult.noOp();
      }).onEnd((context) -> {
         ((BaseVillager)context.getInitiator()).clearHeldItem();
         return (StepResult)onSketched.apply(context);
      }).build();
   }

   private MapSketch() {
   }
}
