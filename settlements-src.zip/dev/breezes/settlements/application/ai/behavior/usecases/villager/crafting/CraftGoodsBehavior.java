package dev.breezes.settlements.application.ai.behavior.usecases.villager.crafting;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.conditions.JobSiteBlockExistsCondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.crafting.catalog.CraftCatalogRegistry;
import dev.breezes.settlements.domain.crafting.catalog.CraftRecipe;
import dev.breezes.settlements.domain.economy.catalog.TradeCatalogRegistry;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.world.level.Level;

public class CraftGoodsBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(CraftGoodsBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private static final int JOB_SITE_COMPLETION_RANGE = 1;
   private static final ClockTicks APPROACH_TIMEOUT = ClockTicks.seconds((double)20.0F);
   private final JobSiteBlockExistsCondition<BaseVillager> jobSiteBlockExistsCondition;
   private final CraftRecipeAvailableCondition craftRecipeAvailableCondition;
   private final CraftBatchCalculator batchCalculator;
   @Nullable
   private PhysicalBlock jobSite;
   @Nullable
   private CraftRecipe currentRecipe;

   public CraftGoodsBehavior(CraftGoodsConfig config, BehaviorSupport support, CraftCatalogRegistry craftCatalog, TradeCatalogRegistry tradeCatalog) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.batchCalculator = new CraftBatchCalculator(tradeCatalog);
      this.jobSiteBlockExistsCondition = new JobSiteBlockExistsCondition<BaseVillager>((ICondition)null, 1);
      this.craftRecipeAvailableCondition = new CraftRecipeAvailableCondition(craftCatalog, this.batchCalculator);
      this.preconditions.add(this.jobSiteBlockExistsCondition);
      this.preconditions.add(this.craftRecipeAvailableCondition);
      this.jobSite = null;
      this.currentRecipe = null;
      this.initializeStateMachine(this.createControlStep(), CraftGoodsBehavior.CraftStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("CraftGoodsBehavior").initialStage(CraftGoodsBehavior.CraftStage.CRAFT).stageStepMap(Map.of(CraftGoodsBehavior.CraftStage.CRAFT, this.createCraftStep())).nextStage(CraftGoodsBehavior.CraftStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      if (this.jobSiteBlockExistsCondition.getJobSiteBlock().isEmpty()) {
         this.requestStop("No job-site block found");
      } else {
         this.jobSite = (PhysicalBlock)this.jobSiteBlockExistsCondition.getJobSiteBlock().get();
         List<CraftRecipe> validRecipes = this.craftRecipeAvailableCondition.getValidRecipes();
         if (validRecipes.isEmpty()) {
            this.requestStop("No craftable recipes available");
         } else {
            this.currentRecipe = this.batchCalculator.selectPreferred(entity, validRecipes);
            context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromBlock(this.jobSite)));
         }
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      return this.jobSite != null;
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.jobSite = null;
      this.currentRecipe = null;
   }

   private BehaviorStep<BaseVillager> createCraftStep() {
      CraftSequenceStep craftSequence = new CraftSequenceStep("CraftGoodsBehavior.craft", () -> this.currentRecipe, this.batchCalculator, (x$0) -> this.rewardExperience(x$0), CraftGoodsBehavior.CraftStage.END);
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 1)).actionStep(craftSequence).timeoutTicks(APPROACH_TIMEOUT.getTicksAsInt()).timeoutTransition(CraftGoodsBehavior.CraftStage.END).build();
   }

   private static enum CraftStage implements StageKey {
      CRAFT,
      END;

      // $FF: synthetic method
      private static CraftStage[] $values() {
         return new CraftStage[]{CRAFT, END};
      }
   }
}
