package dev.breezes.settlements.application.ai.behavior.usecases.villager.donation;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.economy.VillagerWallet;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.EventOutcome;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.genetics.GeneType;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public final class DonateEmeraldsBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(DonateEmeraldsBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.5F;
   private static final int NAVIGATION_COMPLETION_DISTANCE = 2;
   private static final int APPROACH_TIMEOUT_TICKS = ClockTicks.seconds((double)15.0F).getTicksAsInt();
   private final DonationConfig config;
   private final DonationScanner scanner;
   private final DonationPresenter presenter;
   private final VillagerWallet wallet;
   @Nullable
   private BaseVillager pendingRecipient;

   public DonateEmeraldsBehavior(@Nonnull DonationConfig config, @Nonnull BehaviorSupport support, @Nonnull DonationScanner scanner, @Nonnull DonationPresenter presenter, @Nonnull VillagerWallet wallet) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.config = config;
      this.scanner = scanner;
      this.presenter = presenter;
      this.wallet = wallet;
      this.preconditions.add(ICondition.named("can donate", this::canDonate));
      this.preconditions.add(ICondition.named("generosity roll", this::rollGenerosity));
      this.initializeStateMachine(this.createControlStep(), DonateEmeraldsBehavior.Stage.CLOSED);
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      context.declarePrimaryDeed(BehaviorOutcome.silent());
      this.pendingRecipient = null;
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      this.pendingRecipient = null;
   }

   private boolean canDonate(@Nonnull BaseVillager donor) {
      int comfort = this.computeComfort(donor);
      return this.scanner.findNeediest(donor, this.config.floor(), this.config.minDonation(), comfort).isPresent();
   }

   private boolean rollGenerosity(@Nonnull BaseVillager donor) {
      double charisma = donor.getGenetics().getGeneValue(GeneType.CHARISMA);
      double chance = DonationAmountCalculator.chance(charisma, this.config.baseChance(), this.config.chanceImpact());
      return RandomUtil.chance(chance);
   }

   private int computeComfort(@Nonnull BaseVillager donor) {
      double charisma = donor.getGenetics().getGeneValue(GeneType.CHARISMA);
      return DonationAmountCalculator.comfort(charisma, this.config.baseComfort(), this.config.comfortImpact(), this.config.floor());
   }

   private StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("DonateEmeraldsBehavior").initialStage(DonateEmeraldsBehavior.Stage.SELECT_RECIPIENT).stageStepMap(Map.of(DonateEmeraldsBehavior.Stage.SELECT_RECIPIENT, this::selectRecipient, DonateEmeraldsBehavior.Stage.APPROACH, StayCloseStep.builder().closeEnoughDistance((double)2.5F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.WALK).completionDistance(2).unreachableTransition(DonateEmeraldsBehavior.Stage.WALK_AWAY).build()).actionStep(this::onArrivedAtRecipient).timeoutTicks(APPROACH_TIMEOUT_TICKS).timeoutTransition(DonateEmeraldsBehavior.Stage.WALK_AWAY).build(), DonateEmeraldsBehavior.Stage.GIFT, this::gift, DonateEmeraldsBehavior.Stage.WALK_AWAY, this::walkAway)).nextStage(DonateEmeraldsBehavior.Stage.CLOSED).build();
   }

   private StepResult selectRecipient(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager donor = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      int comfort = this.computeComfort(donor);
      BaseVillager recipient = (BaseVillager)this.scanner.findNeediest(donor, this.config.floor(), this.config.minDonation(), comfort).orElse((Object)null);
      if (recipient == null) {
         return StepResult.complete();
      } else {
         this.pendingRecipient = recipient;
         context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(recipient)));
         donor.setHeldItem(new ItemStack(Items.f_42616_));
         return StepResult.transition(DonateEmeraldsBehavior.Stage.APPROACH);
      }
   }

   private StepResult onArrivedAtRecipient(@Nonnull BehaviorContext<BaseVillager> context) {
      return StepResult.transition(DonateEmeraldsBehavior.Stage.GIFT);
   }

   private StepResult gift(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager donor = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      BaseVillager recipient = this.pendingRecipient;
      if (recipient != null && recipient.m_6084_() && !recipient.m_213877_()) {
         int recipientBalance = this.wallet.getBalance(recipient);
         if (recipientBalance >= this.config.floor()) {
            return StepResult.transition(DonateEmeraldsBehavior.Stage.WALK_AWAY);
         } else {
            int comfort = this.computeComfort(donor);
            int donorBalance = this.wallet.getBalance(donor);
            int cap = DonationAmountCalculator.cap(this.config.floor(), recipientBalance, donorBalance, comfort);
            if (cap < this.config.minDonation()) {
               return StepResult.transition(DonateEmeraldsBehavior.Stage.WALK_AWAY);
            } else {
               int amount = DonationAmountCalculator.pick(cap, this.config.minDonation());
               this.wallet.transfer(donor, recipient, amount);
               this.presenter.presentGift(donor, recipient, amount, donor.m_9236_().m_46467_());
               BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.EMERALDS_DONATED, (String)null);
               outcome.recordSocialOutcome(recipient.m_20148_(), (UUID)null, EventOutcome.SUCCESS, amount + " emeralds", (String)null);
               outcome.putDetailField("count", String.valueOf(amount));
               context.declarePrimaryDeed(outcome);
               return StepResult.transition(DonateEmeraldsBehavior.Stage.WALK_AWAY);
            }
         }
      } else {
         return StepResult.transition(DonateEmeraldsBehavior.Stage.WALK_AWAY);
      }
   }

   private StepResult walkAway(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager donor = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      donor.clearHeldItem();
      this.pendingRecipient = null;
      return StepResult.complete();
   }

   public static enum Stage implements StageKey {
      SELECT_RECIPIENT,
      APPROACH,
      GIFT,
      WALK_AWAY,
      CLOSED;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{SELECT_RECIPIENT, APPROACH, GIFT, WALK_AWAY, CLOSED};
      }
   }
}
