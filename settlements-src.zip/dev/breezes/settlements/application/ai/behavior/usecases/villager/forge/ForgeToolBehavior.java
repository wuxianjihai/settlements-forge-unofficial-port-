package dev.breezes.settlements.application.ai.behavior.usecases.villager.forge;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.usecases.villager.crafting.CraftBatchCalculator;
import dev.breezes.settlements.application.ai.behavior.usecases.villager.crafting.CraftRecipeAvailableCondition;
import dev.breezes.settlements.application.ai.behavior.usecases.villager.crafting.RecipeCommit;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.application.ai.targeting.BlockMemoryTargetResolver;
import dev.breezes.settlements.bootstrap.registry.items.ItemRegistry;
import dev.breezes.settlements.domain.ai.conditions.JobSiteBlockExistsCondition;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.crafting.catalog.CraftRecipe;
import dev.breezes.settlements.domain.economy.catalog.TradeCatalogRegistry;
import dev.breezes.settlements.domain.forge.catalog.ForgeCatalogRegistry;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.blocks.BlockMatchers;
import dev.breezes.settlements.domain.world.blocks.BlockScanBox;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

public class ForgeToolBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ForgeToolBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private static final int JOB_SITE_COMPLETION_RANGE = 1;
   private static final int ANVIL_COMPLETION_RANGE = 1;
   private static final ClockTicks APPROACH_TIMEOUT = ClockTicks.seconds((double)20.0F);
   private static final int STRIKE_COUNT = 5;
   private final JobSiteBlockExistsCondition<BaseVillager> jobSiteBlockExistsCondition;
   private final CraftRecipeAvailableCondition craftRecipeAvailableCondition;
   private final CraftBatchCalculator batchCalculator;
   private final BlockMemoryTargetResolver blockMemoryTargetResolver;
   @Nullable
   private PhysicalBlock jobSite;

   public ForgeToolBehavior(ForgeToolConfig config, BehaviorSupport support, ForgeCatalogRegistry forgeCatalog, TradeCatalogRegistry tradeCatalog) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support, config.experienceReward());
      this.batchCalculator = new CraftBatchCalculator(tradeCatalog);
      this.blockMemoryTargetResolver = support.getBlockMemoryTargetResolver();
      this.jobSiteBlockExistsCondition = new JobSiteBlockExistsCondition<BaseVillager>((block) -> block != null && block.is(Blocks.f_50625_), 1);
      this.craftRecipeAvailableCondition = new CraftRecipeAvailableCondition(forgeCatalog, this.batchCalculator);
      this.preconditions.add(this.jobSiteBlockExistsCondition);
      this.preconditions.add(this.craftRecipeAvailableCondition);
      this.jobSite = null;
      this.initializeStateMachine(this.createControlStep(), ForgeToolBehavior.ForgeStage.END);
   }

   protected StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("ForgeToolBehavior").initialStage(ForgeToolBehavior.ForgeStage.FORGE).stageStepMap(Map.of(ForgeToolBehavior.ForgeStage.FORGE, this.createForgeStep())).nextStage(ForgeToolBehavior.ForgeStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      if (this.jobSiteBlockExistsCondition.getJobSiteBlock().isEmpty()) {
         this.requestStop("No job-site block found");
      } else {
         this.jobSite = (PhysicalBlock)this.jobSiteBlockExistsCondition.getJobSiteBlock().get();
         List<CraftRecipe> validRecipes = this.craftRecipeAvailableCondition.getValidRecipes();
         if (validRecipes.isEmpty()) {
            this.requestStop("No forgeable recipes available");
         } else {
            CraftRecipe recipe = this.batchCalculator.selectPreferred(entity, validRecipes);
            RecipeCommit.commit(context, recipe, this.batchCalculator, WorldEventType.TOOL_FORGED, (x$0) -> this.rewardExperience(x$0));
            boolean resolvedAnvil = this.blockMemoryTargetResolver.resolveBlockTarget(context, MemoryTypeRegistry.ANVIL_SITES, BlockMatchers.ANVIL, BlockScanBox.confirm(), 8, 1);
            if (!resolvedAnvil) {
               context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromBlock(this.jobSite)));
            }

         }
      }
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull BaseVillager entity, @Nonnull BehaviorContext<BaseVillager> context) {
      return this.jobSite != null;
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.getNavigationManager().stop();
      villager.clearHeldItem();
      villager.clearOffhandItem();
      villager.setMotion(AnimationArchetype.IDLE);
      this.jobSite = null;
   }

   private BehaviorStep<BaseVillager> createForgeStep() {
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(new NavigateToTargetStep(NavigationType.WALK, 1)).actionStep(this.createHammerStep()).timeoutTicks(APPROACH_TIMEOUT.getTicksAsInt()).timeoutTransition(ForgeToolBehavior.ForgeStage.END).build();
   }

   private BehaviorStep<BaseVillager> createHammerStep() {
      int sessionTicks = 100;
      return TimeBasedStep.<BaseVillager>builder().name("ForgeToolBehavior.forge").withTickable(ClockTicks.of((long)sessionTicks).asTickable()).onStart(this::startForging).addPeriodicStep(20, 8, this::playStrikeBeat).build();
   }

   private StepResult startForging(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      villager.setHeldItem(((Item)ItemRegistry.HAMMER.get()).m_7968_());
      villager.setOffhandItem(new ItemStack(Items.f_42416_));
      villager.setMotion(AnimationArchetype.FORGE);
      return StepResult.noOp();
   }

   private StepResult playStrikeBeat(@Nonnull BehaviorContext<BaseVillager> context) {
      BaseVillager villager = ((BaseVillager)context.getInitiator()).getMinecraftEntity();
      Location location = Location.fromEntity(villager, true);
      location.displayParticles(ParticleTypes.f_123797_, 4, 0.2, 0.2, 0.2, 0.05);
      location.playSound(SoundEvents.f_11668_, 0.6F, 1.4F, SoundSource.BLOCKS);
      return StepResult.noOp();
   }

   private static enum ForgeStage implements StageKey {
      FORGE,
      END;

      // $FF: synthetic method
      private static ForgeStage[] $values() {
         return new ForgeStage[]{FORGE, END};
      }
   }
}
