package dev.breezes.settlements.application.ai.behavior.usecases.villager.animals.petting;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorSupport;
import dev.breezes.settlements.application.ai.behavior.runtime.VillagerStateMachineBehavior;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.look.LookState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.TimeBasedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.NavigateToTargetStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete.StayCloseStep;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.minecraft.entities.pet.Pettable;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

public class PetAnimalBehavior extends VillagerStateMachineBehavior {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(PetAnimalBehavior.class.getName());
   private static final double CLOSE_ENOUGH_DISTANCE = (double)2.0F;
   private static final int NAVIGATION_COMPLETION_DISTANCE = 1;
   private static final int APPROACH_TIMEOUT_TICKS = ClockTicks.seconds((double)30.0F).getTicksAsInt();
   private static final int PET_INTERVAL_TICKS = ClockTicks.seconds((double)1.0F).getTicksAsInt();
   private final PetAnimalConfig config;
   private final NearbyPettableExistsCondition nearbyPettableCondition;
   @Nullable
   private LivingEntity cachedPet;

   public PetAnimalBehavior(@Nonnull PetAnimalConfig config, @Nonnull BehaviorSupport support) {
      super(log, config.createPreconditionCheckCooldownTickable(), config.createBehaviorCooldownTickable(), support);
      this.config = config;
      this.cachedPet = null;
      this.nearbyPettableCondition = new NearbyPettableExistsCondition(config.horizontalScanRange(), config.verticalScanRange());
      this.preconditions.add(this.nearbyPettableCondition);
      this.continueConditions.add(ICondition.named("CachedPetStillValid", (villager) -> this.cachedPet != null && this.cachedPet.m_6084_() && !this.cachedPet.m_213877_()));
      this.initializeStateMachine(this.createControlStep(), PetAnimalBehavior.PetStage.END);
   }

   private StagedStep<BaseVillager> createControlStep() {
      return StagedStep.<BaseVillager>builder().name("PetAnimalBehavior").initialStage(PetAnimalBehavior.PetStage.APPROACH).stageStepMap(Map.of(PetAnimalBehavior.PetStage.APPROACH, this.createApproachStep(), PetAnimalBehavior.PetStage.PET, this.createPetStep())).nextStage(PetAnimalBehavior.PetStage.END).onEnd((ctx) -> StepResult.noOp()).build();
   }

   private BehaviorStep<BaseVillager> createApproachStep() {
      return StayCloseStep.<BaseVillager>builder().closeEnoughDistance((double)2.0F).navigateStep(NavigateToTargetStep.builder().navigationType(NavigationType.WALK).completionDistance(1).unreachableTransition(PetAnimalBehavior.PetStage.END).build()).actionStep((ctx) -> StepResult.transition(PetAnimalBehavior.PetStage.PET)).timeoutTicks(APPROACH_TIMEOUT_TICKS).timeoutTransition(PetAnimalBehavior.PetStage.END).build();
   }

   private BehaviorStep<BaseVillager> createPetStep() {
      return TimeBasedStep.<BaseVillager>builder().withTickable(ClockTicks.seconds((double)this.config.petCount()).asTickable()).onStart((ctx) -> {
         ((BaseVillager)ctx.getInitiator()).triggerMotion(AnimationArchetype.INTERACT);
         return StepResult.noOp();
      }).addPeriodicStep(PET_INTERVAL_TICKS, (ctx) -> {
         this.performPet(ctx);
         return StepResult.noOp();
      }).onEnd((ctx) -> StepResult.transition(PetAnimalBehavior.PetStage.END)).build();
   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull BaseVillager villager, @Nonnull BehaviorContext<BaseVillager> context) {
      this.cachedPet = null;
      if (!this.nearbyPettableCondition.test(villager)) {
         this.requestStop("No pettable animals within range");
      } else {
         this.cachedPet = (LivingEntity)this.nearbyPettableCondition.getTargets().stream().findFirst().orElse((Object)null);
         if (this.cachedPet == null) {
            this.requestStop("Chosen pettable animal is null");
         } else {
            context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromEntity(this.cachedPet)));
            context.setState(BehaviorStateType.LOOK_TARGET, LookState.ofEntity(this.cachedPet));
         }
      }
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull BaseVillager villager) {
      villager.setMotion(AnimationArchetype.IDLE);
      villager.getNavigationManager().stop();
      this.cachedPet = null;
   }

   private void performPet(@Nonnull BehaviorContext<BaseVillager> context) {
      if (this.cachedPet != null && this.cachedPet.m_6084_() && !this.cachedPet.m_213877_()) {
         ((Pettable)this.cachedPet).pet((LivingEntity)context.getInitiator());
         BehaviorOutcome outcome = BehaviorOutcome.forDeed(WorldEventType.ANIMAL_PETTED, (String)null);
         outcome.markSucceeded();
         context.declarePrimaryDeed(outcome);
      }
   }

   private static enum PetStage implements StageKey {
      APPROACH,
      PET,
      END;

      // $FF: synthetic method
      private static PetStage[] $values() {
         return new PetStage[]{APPROACH, PET, END};
      }
   }
}
