package dev.breezes.settlements.application.ai.behavior.usecases.villager.donation;

import dev.breezes.settlements.domain.genetics.GeneticMultiplierResolver;
import dev.breezes.settlements.shared.util.RandomUtil;
import lombok.Generated;

public final class DonationAmountCalculator {
   public static int cap(int floor, int recipientBalance, int donorBalance, int comfort) {
      return Math.min(floor - recipientBalance, donorBalance - comfort);
   }

   public static int pick(int cap, int minDonation) {
      if (cap < minDonation) {
         throw new IllegalArgumentException("cap (%d) must be >= minDonation (%d)".formatted(cap, minDonation));
      } else {
         return RandomUtil.randomInt(minDonation, cap, true);
      }
   }

   public static int comfort(double charisma, int baseComfort, double comfortImpact, int floor) {
      double multiplier = GeneticMultiplierResolver.centeredMultiplier(charisma, -comfortImpact);
      int computed = (int)Math.round((double)baseComfort * multiplier);
      return Math.max(floor, computed);
   }

   public static double chance(double charisma, double baseChance, double chanceImpact) {
      double multiplier = GeneticMultiplierResolver.centeredMultiplier(charisma, chanceImpact);
      return RandomUtil.clamp(baseChance * multiplier, (double)0.0F, (double)1.0F);
   }

   @Generated
   private DonationAmountCalculator() {
   }
}
