package dev.breezes.settlements.application.ai.behavior.teardown;

import dev.breezes.settlements.domain.world.blocks.BlockFlag;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public record RestoreBlockObligation(@Nonnull BlockPos pos, @Nonnull ResourceLocation restoreBlockId, @Nonnull ResourceLocation ownedBlockId) implements TeardownObligation {
   public BlockPos targetPos() {
      return this.pos;
   }

   public boolean stillValid(@Nonnull ServerLevel level) {
      if (!level.m_46749_(this.pos)) {
         return false;
      } else {
         Block owned = resolveBlock(this.ownedBlockId);
         BlockState current = level.m_8055_(this.pos);
         return current.m_60713_(owned);
      }
   }

   public void discharge(@Nonnull ServerLevel level) {
      Block owned = resolveBlock(this.ownedBlockId);
      BlockState current = level.m_8055_(this.pos);
      if (current.m_60713_(owned)) {
         Block restore = resolveBlock(this.restoreBlockId);
         level.m_7731_(this.pos, restore.m_49966_(), BlockFlag.of(BlockFlag.SEND_BLOCK_UPDATE, BlockFlag.SEND_CLIENT_UPDATE));
      }
   }

   public boolean durable() {
      return true;
   }

   public String describe() {
      String var10000 = String.valueOf(this.restoreBlockId);
      return "restore block " + var10000 + " (owned: " + String.valueOf(this.ownedBlockId) + ") at " + this.pos.m_123344_();
   }

   private static Block resolveBlock(@Nonnull ResourceLocation id) {
      return (Block)BuiltInRegistries.f_256975_.m_7745_(id);
   }
}
