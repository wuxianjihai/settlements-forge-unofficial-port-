package dev.breezes.settlements.application.ai.behavior.teardown;

import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.server.level.ServerLevel;

public final class TeardownScope {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(TeardownScope.class.getName());
   private final Deque<TeardownObligation> live = new ArrayDeque();
   @Nullable
   private ITeardownLedger ledger;

   public TemporaryArtifactHandle track(@Nonnull TeardownObligation obligation) {
      this.live.push(obligation);
      if (this.ledger != null && obligation.durable()) {
         this.ledger.add(obligation);
      }

      return new TemporaryArtifactHandle(obligation, this);
   }

   public void teardownAll(@Nonnull ServerLevel level) {
      while(!this.live.isEmpty()) {
         TeardownObligation obligation = (TeardownObligation)this.live.pop();

         try {
            if (obligation.stillValid(level)) {
               obligation.discharge(level);
            }
         } catch (Exception e) {
            log.error("Teardown obligation failed '{}': {}", obligation.describe(), e.getMessage());
         } finally {
            if (this.ledger != null && obligation.durable()) {
               this.ledger.remove(obligation);
            }

         }
      }

   }

   public void bindLedger(@Nonnull ITeardownLedger ledger) {
      this.ledger = ledger;
   }

   void removeObligation(@Nonnull TeardownObligation obligation) {
      this.live.remove(obligation);
      if (this.ledger != null && obligation.durable()) {
         this.ledger.remove(obligation);
      }

   }

   public Collection<TeardownObligation> openObligations() {
      return Collections.unmodifiableCollection(this.live);
   }
}
