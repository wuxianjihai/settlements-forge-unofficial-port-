package dev.breezes.settlements.application.ai.behavior.teardown;

import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.DebugPackets;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.village.poi.PoiTypes;

public record ReleaseHomePoiObligation(@Nonnull BlockPos bedPos) implements TeardownObligation {
   public BlockPos targetPos() {
      return this.bedPos;
   }

   public boolean stillValid(@Nonnull ServerLevel level) {
      return !level.m_46749_(this.bedPos) ? false : level.m_8904_().m_27091_(this.bedPos, (holder) -> holder.m_203565_(PoiTypes.f_218060_));
   }

   public void discharge(@Nonnull ServerLevel level) {
      level.m_8904_().m_27154_(this.bedPos);
      DebugPackets.m_133719_(level, this.bedPos);
   }

   public boolean durable() {
      return false;
   }

   public String describe() {
      return "release-home-poi@" + String.valueOf(this.bedPos);
   }
}
