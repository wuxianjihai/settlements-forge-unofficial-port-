package dev.breezes.settlements.application.ai.behavior.teardown;

import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.server.level.ServerLevel;

public final class TemporaryArtifactHandle {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(TemporaryArtifactHandle.class.getName());
   private final TeardownObligation obligation;
   private final TeardownScope scope;
   private boolean disposed;

   public TemporaryArtifactHandle(@Nonnull TeardownObligation obligation, @Nonnull TeardownScope scope) {
      this.obligation = obligation;
      this.scope = scope;
      this.disposed = false;
   }

   public void cancel() {
      if (!this.disposed) {
         this.disposed = true;
         this.scope.removeObligation(this.obligation);
      }
   }

   public void dispose(@Nonnull ServerLevel level) {
      if (!this.disposed) {
         this.disposed = true;
         this.scope.removeObligation(this.obligation);

         try {
            if (this.obligation.stillValid(level)) {
               this.obligation.discharge(level);
            }
         } catch (Exception e) {
            log.error("Failed to discharge obligation via handle '{}': {}", this.obligation.describe(), e.getMessage());
         }

      }
   }

   @Generated
   public boolean isDisposed() {
      return this.disposed;
   }
}
