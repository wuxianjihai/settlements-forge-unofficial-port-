package dev.breezes.settlements.application.ai.behavior.teardown;

public interface ProvidesTeardownLedger {
   ITeardownLedger getTeardownLedger();
}
