package dev.breezes.settlements.application.ai.behavior.teardown;

import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;

public interface TeardownObligation {
   BlockPos targetPos();

   boolean stillValid(@Nonnull ServerLevel var1);

   void discharge(@Nonnull ServerLevel var1);

   boolean durable();

   String describe();
}
