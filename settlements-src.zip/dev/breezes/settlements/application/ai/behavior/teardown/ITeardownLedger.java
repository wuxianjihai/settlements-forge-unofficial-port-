package dev.breezes.settlements.application.ai.behavior.teardown;

import java.util.List;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;

public interface ITeardownLedger {
   void add(@Nonnull TeardownObligation var1);

   void remove(@Nonnull TeardownObligation var1);

   List<LedgerEntry> pendingOrphans();

   void resolveOrphan(@Nonnull TeardownObligation var1);

   boolean hasLiveObligationAt(@Nonnull BlockPos var1);

   List<LedgerEntry> snapshot();
}
