package dev.breezes.settlements.application.ai.behavior.teardown;

import dev.breezes.settlements.domain.world.blocks.BlockFlag;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

public record ResetBlockStateObligation(@Nonnull BlockPos pos, @Nonnull ResourceLocation expectedBlockId, @Nonnull String propertyName, @Nonnull String resetValue) implements TeardownObligation {
   public BlockPos targetPos() {
      return this.pos;
   }

   public boolean stillValid(@Nonnull ServerLevel level) {
      if (!level.m_46749_(this.pos)) {
         return false;
      } else {
         BlockState state = level.m_8055_(this.pos);
         if (!state.m_60713_(this.resolveExpectedBlock())) {
            return false;
         } else {
            Property<?> property = findProperty(state, this.propertyName);
            if (property == null) {
               return false;
            } else {
               Optional<?> targetValueOpt = property.m_6215_(this.resetValue);
               if (targetValueOpt.isEmpty()) {
                  return false;
               } else {
                  Object currentValue = getCurrentValue(state, property);
                  return !currentValue.equals(targetValueOpt.get());
               }
            }
         }
      }
   }

   public void discharge(@Nonnull ServerLevel level) {
      BlockState currentState = level.m_8055_(this.pos);
      if (currentState.m_60713_(this.resolveExpectedBlock())) {
         Property<?> property = findProperty(currentState, this.propertyName);
         if (property != null) {
            Optional<?> targetValueOpt = property.m_6215_(this.resetValue);
            if (!targetValueOpt.isEmpty()) {
               BlockState newState = applyPropertyValue(currentState, property, targetValueOpt.get());
               level.m_7731_(this.pos, newState, BlockFlag.of(BlockFlag.SEND_BLOCK_UPDATE, BlockFlag.SEND_CLIENT_UPDATE));
            }
         }
      }
   }

   public boolean durable() {
      return true;
   }

   public String describe() {
      String var10000 = this.propertyName;
      return "reset block state " + var10000 + "=" + this.resetValue + " on " + String.valueOf(this.expectedBlockId) + " at " + this.pos.m_123344_();
   }

   @Nullable
   private Block resolveExpectedBlock() {
      return (Block)BuiltInRegistries.f_256975_.m_7745_(this.expectedBlockId);
   }

   @Nullable
   private static Property<?> findProperty(@Nonnull BlockState state, @Nonnull String name) {
      for(Property<?> p : state.m_61147_()) {
         if (p.m_61708_().equals(name)) {
            return p;
         }
      }

      return null;
   }

   private static <T extends Comparable<T>> T getCurrentValue(@Nonnull BlockState state, @Nonnull Property<?> property) {
      return (T)state.m_61143_(property);
   }

   private static BlockState applyPropertyValue(@Nonnull BlockState state, @Nonnull Property<?> property, @Nonnull Object value) {
      return (BlockState)state.m_61124_(property, (Comparable)value);
   }
}
