package dev.breezes.settlements.application.ai.behavior.teardown;

import java.util.UUID;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.animal.Animal;

public record DropLeashObligation(@Nonnull UUID animalId, @Nonnull UUID holderId, @Nonnull BlockPos animalPos) implements TeardownObligation {
   public BlockPos targetPos() {
      return this.animalPos;
   }

   public boolean stillValid(@Nonnull ServerLevel level) {
      if (!level.m_46749_(this.animalPos)) {
         return false;
      } else {
         Entity entity = level.m_8791_(this.animalId);
         if (!(entity instanceof Animal)) {
            return false;
         } else {
            Animal animal = (Animal)entity;
            Entity leashHolder = animal.m_21524_();
            return leashHolder != null && this.holderId.equals(leashHolder.m_20148_());
         }
      }
   }

   public void discharge(@Nonnull ServerLevel level) {
      Entity entity = level.m_8791_(this.animalId);
      if (entity instanceof Animal animal) {
         animal.m_21455_(true, false);
      }
   }

   public boolean durable() {
      return true;
   }

   public String describe() {
      String var10000 = String.valueOf(this.animalId);
      return "drop leash on animal " + var10000 + " held by " + String.valueOf(this.holderId) + " at " + this.animalPos.m_123344_();
   }
}
