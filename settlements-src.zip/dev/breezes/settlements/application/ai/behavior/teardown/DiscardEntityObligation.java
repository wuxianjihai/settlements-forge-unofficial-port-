package dev.breezes.settlements.application.ai.behavior.teardown;

import java.util.UUID;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;

public record DiscardEntityObligation(@Nonnull UUID entityId, @Nonnull BlockPos spawnPos) implements TeardownObligation {
   public BlockPos targetPos() {
      return this.spawnPos;
   }

   public boolean stillValid(@Nonnull ServerLevel level) {
      if (!level.m_46749_(this.spawnPos)) {
         return false;
      } else {
         Entity entity = level.m_8791_(this.entityId);
         return entity != null && !entity.m_213877_();
      }
   }

   public void discharge(@Nonnull ServerLevel level) {
      Entity entity = level.m_8791_(this.entityId);
      if (entity != null && !entity.m_213877_()) {
         entity.m_146870_();
      }
   }

   public boolean durable() {
      return true;
   }

   public String describe() {
      String var10000 = String.valueOf(this.entityId);
      return "discard entity " + var10000 + " at " + this.spawnPos.m_123344_();
   }
}
