package dev.breezes.settlements.application.ai.behavior.teardown;

import javax.annotation.Nonnull;
import lombok.Generated;

public final class LedgerEntry {
   private final TeardownObligation obligation;
   private int failedAttempts;

   public LedgerEntry(@Nonnull TeardownObligation obligation, int failedAttempts) {
      this.obligation = obligation;
      this.failedAttempts = failedAttempts;
   }

   public void incrementFailedAttempts() {
      ++this.failedAttempts;
   }

   @Generated
   public TeardownObligation getObligation() {
      return this.obligation;
   }

   @Generated
   public int getFailedAttempts() {
      return this.failedAttempts;
   }
}
