package dev.breezes.settlements.application.ai.behavior.runtime;

import dev.breezes.settlements.application.ai.behavior.teardown.ProvidesTeardownLedger;
import dev.breezes.settlements.application.ai.behavior.workflow.staged.StagedStep;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.look.LookQueries;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorDeedLedger;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.ITickable;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.util.crash.CrashUtil;
import dev.breezes.settlements.shared.util.crash.report.BehaviorConfigurationCrashReport;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

public abstract class StateMachineBehavior<T extends Entity & ISettlementsBrainEntity> extends AbstractBehavior<T> implements ProducesBehaviorOutcome {
   @Nullable
   private StagedStep<T> controlStep;
   @Nullable
   private StageKey expectedEndStage;
   @Nullable
   private BehaviorContext<T> context;
   @Nullable
   private BehaviorDeedLedger lastDeeds;
   private BehaviorLifecycleResult lastLifecycleResult = BehaviorLifecycleResult.clean();
   private final ITickable lookControlCooldown = ClockTicks.of(10L).asTickable();

   protected StateMachineBehavior(@Nonnull ILogger log, @Nonnull ITickable preconditionCheckCooldown, @Nonnull ITickable behaviorCoolDown) {
      super(log, preconditionCheckCooldown, behaviorCoolDown);
   }

   protected final void initializeStateMachine(@Nonnull StagedStep<T> controlStep, @Nonnull StageKey expectedEndStage) {
      if (this.controlStep != null || this.expectedEndStage != null) {
         crashInvalidConfiguration("StateMachineBehavior for '%s' was initialized more than once".formatted(this.getClass().getSimpleName()));
      }

      this.controlStep = controlStep;
      this.expectedEndStage = expectedEndStage;
   }

   public final void doStart(@Nonnull Level world, @Nonnull T entity) {
      this.requireInitialized();
      this.context = new BehaviorContext<T>(entity);
      this.lastDeeds = null;
      this.lastLifecycleResult = BehaviorLifecycleResult.clean();
      if (entity instanceof ProvidesTeardownLedger p) {
         this.context.getTeardownScope().bindLedger(p.getTeardownLedger());
      }

      this.onBehaviorStart(world, entity, this.context);
      this.controlStep.reset();
   }

   public final void tickBehavior(int delta, @Nonnull Level world, @Nonnull T entity) {
      this.requireInitialized();
      BehaviorContext<T> context = this.requireContext();
      if (!this.preTickGuard(delta, world, entity, context)) {
         throw new StopBehaviorException("Behavior '%s' pre-tick guard failed".formatted(this.getClass().getSimpleName()));
      } else {
         StepResult result = this.controlStep.tick(context);
         if (this.lookControlCooldown.tickCheckAndReset((double)1.0F) && this.shouldLookAtActiveTarget()) {
            Optional var10000 = LookQueries.resolveLookLocation(context);
            ISettlementsBrainEntity var10001 = entity;
            Objects.requireNonNull(entity);
            var10000.ifPresent(var10001::lookAt);
         }

         this.handleStepResult(result, this.expectedEndStage, this.getClass().getSimpleName());
      }
   }

   public final void doStop(@Nonnull Level world, @Nonnull T entity) {
      this.requireInitialized();

      try {
         this.onBehaviorStop(world, entity);
      } finally {
         if (this.context != null) {
            this.lastDeeds = (BehaviorDeedLedger)this.context.getState(BehaviorStateType.BEHAVIOR_OUTCOME, BehaviorDeedLedger.class).orElse((Object)null);
            this.context.getTeardownScope().teardownAll(this.context.getLevel());
         }

         this.context = null;
         this.controlStep.reset();
      }

   }

   protected void onBehaviorStart(@Nonnull Level world, @Nonnull T entity, @Nonnull BehaviorContext<T> context) {
   }

   protected void onBehaviorStop(@Nonnull Level world, @Nonnull T entity) {
   }

   protected Optional<String> getCurrentStageLabel() {
      return this.controlStep != null && this.controlStep.getCurrentStage() != null ? Optional.ofNullable(this.controlStep.getCurrentStage().name()) : Optional.empty();
   }

   protected final <S extends BehaviorState> Optional<S> getContextState(@Nonnull BehaviorStateType type, @Nonnull Class<S> castTo) {
      return this.context == null ? Optional.empty() : this.context.getState(type, castTo);
   }

   public Optional<BehaviorDeedLedger> getLastDeeds() {
      return Optional.ofNullable(this.lastDeeds);
   }

   @Nonnull
   public BehaviorLifecycleResult getLastLifecycleResult() {
      return this.lastLifecycleResult;
   }

   protected boolean preTickGuard(int delta, @Nonnull Level world, @Nonnull T entity, @Nonnull BehaviorContext<T> context) {
      return true;
   }

   protected boolean shouldLookAtActiveTarget() {
      return true;
   }

   private BehaviorContext<T> requireContext() {
      if (this.context == null) {
         throw new StopBehaviorException("Behavior context is null");
      } else {
         return this.context;
      }
   }

   private void requireInitialized() {
      if (this.controlStep == null || this.expectedEndStage == null) {
         Object[] var10001 = new Object[]{this.getClass().getSimpleName()};
         crashInvalidConfiguration("StateMachineBehavior for '%s' was not initialized. ".formatted(var10001) + "Call initializeStateMachine(...) as the final step of subclass constructor.");
      }

   }

   private static void crashInvalidConfiguration(@Nonnull String message) throws IllegalArgumentException {
      CrashUtil.crash(new BehaviorConfigurationCrashReport(new IllegalArgumentException(message)));
   }

   protected final void handleStepResult(@Nonnull StepResult result, @Nonnull StageKey endStage, @Nonnull String behaviorName) {
      if (!(result instanceof StepResult.NoOp) && !(result instanceof StepResult.Complete)) {
         if (result instanceof StepResult.Transition) {
            StepResult.Transition transition = (StepResult.Transition)result;
            StageKey key = transition.key();
            if (key.equals(endStage)) {
               this.lastLifecycleResult = BehaviorLifecycleResult.clean();
               throw new StopBehaviorException("Behavior '%s' has ended".formatted(behaviorName));
            } else {
               this.getLog().behaviorError("Behavior '{}' produced unexpected transition '{}' (expected end '{}')", behaviorName, key.name(), endStage.name());
               this.lastLifecycleResult = BehaviorLifecycleResult.fail("unexpected transition '%s'".formatted(key.name()));
               throw new StopBehaviorException("Behavior '%s' unexpected transition '%s'".formatted(behaviorName, key.name()));
            }
         } else if (result instanceof StepResult.Fail) {
            StepResult.Fail fail = (StepResult.Fail)result;
            this.getLog().behaviorWarn("Behavior '{}' failed with code '{}' and details {}", behaviorName, fail.code(), fail.details());
            this.lastLifecycleResult = BehaviorLifecycleResult.fail(fail.code());
            throw new StopBehaviorException("Behavior '%s' failed with code '%s'".formatted(behaviorName, fail.code()));
         } else if (result instanceof StepResult.Abort) {
            StepResult.Abort abort = (StepResult.Abort)result;
            this.getLog().behaviorError("Behavior '{}' aborted with code '{}'", behaviorName, abort.code());
            if (abort.cause() != null) {
               this.getLog().error(abort.cause(), "Behavior '{}' abort cause", behaviorName);
            }

            this.lastLifecycleResult = BehaviorLifecycleResult.abort(abort.code());
            throw new StopBehaviorException("Behavior '%s' aborted with code '%s'".formatted(behaviorName, abort.code()));
         }
      }
   }
}
