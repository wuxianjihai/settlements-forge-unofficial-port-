package dev.breezes.settlements.application.ai.behavior.runtime;

import dev.breezes.settlements.application.hunger.HungerConfig;
import dev.breezes.settlements.domain.time.ITickable;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import javax.annotation.Nonnull;
import lombok.Generated;

public abstract class VillagerStateMachineBehavior extends StateMachineBehavior<BaseVillager> {
   private final BehaviorSupport support;
   private final int experienceReward;

   protected VillagerStateMachineBehavior(@Nonnull ILogger log, @Nonnull ITickable preconditionCheckCooldown, @Nonnull ITickable behaviorCoolDown, @Nonnull BehaviorSupport support) {
      this(log, preconditionCheckCooldown, behaviorCoolDown, support, 0);
   }

   protected VillagerStateMachineBehavior(@Nonnull ILogger log, @Nonnull ITickable preconditionCheckCooldown, @Nonnull ITickable behaviorCoolDown, @Nonnull BehaviorSupport support, int experienceReward) {
      super(log, preconditionCheckCooldown, behaviorCoolDown);
      this.support = support;
      this.experienceReward = experienceReward;
   }

   protected double getCooldownMultiplier(@Nonnull BaseVillager villager) {
      float hunger = villager.getHunger();
      HungerConfig hungerConfig = this.support.getHungerConfig();
      if (hunger >= hungerConfig.hungerBonusThreshold()) {
         return (double)hungerConfig.cooldownBonusMultiplier();
      } else if (hunger <= hungerConfig.cooldownScaleStartThreshold()) {
         double t = (double)1.0F - (double)(hunger / hungerConfig.cooldownScaleStartThreshold());
         return (double)1.0F + ((double)hungerConfig.maxCooldownMultiplier() - (double)1.0F) * t;
      } else {
         return (double)1.0F;
      }
   }

   public double getHungerDrainModifier() {
      return (double)1.0F;
   }

   protected final void rewardExperience(@Nonnull BaseVillager villager) {
      if (!GeneralConfig.disableNaturalExperienceGain && this.experienceReward > 0) {
         villager.gainExperience(this.experienceReward);
      }
   }

   @Generated
   public BehaviorSupport getSupport() {
      return this.support;
   }

   @Generated
   public int getExperienceReward() {
      return this.experienceReward;
   }
}
