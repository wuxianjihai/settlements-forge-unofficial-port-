package dev.breezes.settlements.application.ai.behavior.runtime;

import dev.breezes.settlements.application.ai.targeting.BlockMemoryTargetResolver;
import dev.breezes.settlements.application.economy.demand.DemandEvaluator;
import dev.breezes.settlements.application.economy.demand.DemandSignalService;
import dev.breezes.settlements.application.economy.supply.SupplyEvaluator;
import dev.breezes.settlements.application.hunger.HungerConfig;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventEmitter;
import jakarta.inject.Inject;
import lombok.Generated;

@ServerScope
public class BehaviorSupport {
   private final HungerConfig hungerConfig;
   private final WorldEventEmitter worldEventEmitter;
   private final DemandSignalService demandSignalService;
   private final DemandEvaluator demandEvaluator;
   private final SupplyEvaluator supplyEvaluator;
   private final BlockMemoryTargetResolver blockMemoryTargetResolver;

   @Generated
   public HungerConfig getHungerConfig() {
      return this.hungerConfig;
   }

   @Generated
   public WorldEventEmitter getWorldEventEmitter() {
      return this.worldEventEmitter;
   }

   @Generated
   public DemandSignalService getDemandSignalService() {
      return this.demandSignalService;
   }

   @Generated
   public DemandEvaluator getDemandEvaluator() {
      return this.demandEvaluator;
   }

   @Generated
   public SupplyEvaluator getSupplyEvaluator() {
      return this.supplyEvaluator;
   }

   @Generated
   public BlockMemoryTargetResolver getBlockMemoryTargetResolver() {
      return this.blockMemoryTargetResolver;
   }

   @Inject
   @Generated
   BehaviorSupport(HungerConfig hungerConfig, WorldEventEmitter worldEventEmitter, DemandSignalService demandSignalService, DemandEvaluator demandEvaluator, SupplyEvaluator supplyEvaluator, BlockMemoryTargetResolver blockMemoryTargetResolver) {
      this.hungerConfig = hungerConfig;
      this.worldEventEmitter = worldEventEmitter;
      this.demandSignalService = demandSignalService;
      this.demandEvaluator = demandEvaluator;
      this.supplyEvaluator = supplyEvaluator;
      this.blockMemoryTargetResolver = blockMemoryTargetResolver;
   }
}
