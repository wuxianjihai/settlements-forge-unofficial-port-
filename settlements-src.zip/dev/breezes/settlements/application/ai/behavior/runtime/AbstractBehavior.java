package dev.breezes.settlements.application.ai.behavior.runtime;

import dev.breezes.settlements.domain.ai.behavior.contracts.IBehavior;
import dev.breezes.settlements.domain.ai.behavior.model.BehaviorStatus;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.time.ITickable;
import dev.breezes.settlements.shared.logging.ILogger;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

public abstract class AbstractBehavior<T extends Entity & ISettlementsBrainEntity> implements IBehavior<T> {
   private final ILogger log;
   protected final ITickable preconditionCheckCooldown;
   protected final ITickable behaviorCoolDown;
   protected final List<ICondition<T>> preconditions;
   protected final List<ICondition<T>> continueConditions;
   protected BehaviorStatus status;
   private boolean stopRequested;
   private final Map<Class<?>, Boolean> latestPreconditionEvaluationResults;

   protected AbstractBehavior(@Nonnull ILogger log, @Nonnull ITickable preconditionCheckCooldown, @Nonnull ITickable behaviorCoolDown) {
      this.log = log;
      this.preconditionCheckCooldown = preconditionCheckCooldown;
      this.behaviorCoolDown = behaviorCoolDown;
      this.preconditions = new ArrayList();
      this.continueConditions = new ArrayList();
      this.latestPreconditionEvaluationResults = new LinkedHashMap();
      this.status = BehaviorStatus.STOPPED;
      this.stopRequested = false;
   }

   public boolean tickPreconditions(int delta, @Nonnull Level world, @Nonnull T entity) {
      if (this.status != BehaviorStatus.STOPPED) {
         return false;
      } else {
         boolean preconditionCheckCooldownComplete = this.preconditionCheckCooldown.tickAndCheck((double)delta);
         if (!this.behaviorCoolDown.tickAndCheck((double)delta)) {
            return false;
         } else if (!preconditionCheckCooldownComplete) {
            return false;
         } else {
            this.preconditionCheckCooldown.reset();
            this.latestPreconditionEvaluationResults.clear();
            if (this.preconditions.isEmpty()) {
               this.log.behaviorWarn("No preconditions configured");
               return true;
            } else {
               boolean allPassed = true;

               for(ICondition<T> precondition : this.preconditions) {
                  boolean passed = precondition.test(entity);
                  this.latestPreconditionEvaluationResults.put(precondition.getClass(), passed);
                  if (!passed) {
                     this.log.behaviorTrace("Precondition '{}' is not met", precondition.description());
                     allPassed = false;
                  }
               }

               return allPassed;
            }
         }
      }
   }

   public final void start(@Nonnull Level world, @Nonnull T entity) {
      if (this.status != BehaviorStatus.STOPPED) {
         this.log.warn("Ignoring start request since behavior is already running");
      } else {
         this.log.behaviorTrace("Starting behavior (entity: {})", entity.m_20148_().toString());
         this.doStart(world, entity);
         this.status = BehaviorStatus.RUNNING;
      }
   }

   public abstract void doStart(@Nonnull Level var1, @Nonnull T var2);

   protected double getCooldownMultiplier(@Nonnull T entity) {
      return (double)1.0F;
   }

   public final void tick(int delta, @Nonnull Level world, @Nonnull T entity) {
      if (this.status != BehaviorStatus.STOPPED) {
         if (this.stopRequested) {
            this.log.behaviorTrace("Stop requested, stopping behavior");
            this.stop(world, entity);
         } else {
            try {
               this.tickBehavior(delta, world, entity);
            } catch (StopBehaviorException var5) {
               this.requestStop("Behavior stop requested by exception");
            }

            boolean canContinue = !this.stopRequested && this.tickContinueConditions(delta, world, entity);
            if (!canContinue) {
               this.log.behaviorTrace("Behavior can no longer continue, stopping behavior");
               this.stop(world, entity);
            }

         }
      }
   }

   public abstract void tickBehavior(int var1, @Nonnull Level var2, @Nonnull T var3);

   public boolean tickContinueConditions(int delta, @Nonnull Level world, @Nonnull T entity) {
      for(ICondition<T> continueCondition : this.continueConditions) {
         if (!continueCondition.test(entity)) {
            this.log.behaviorTrace("Continue condition '{}' is not met", continueCondition.description());
            return false;
         }
      }

      return true;
   }

   public void requestStop(@Nonnull String reason) {
      if (this.stopRequested) {
         this.log.behaviorTrace("Ignoring stop request since behavior is already stopping");
      } else {
         this.log.behaviorTrace("Requesting to stop behavior: {}", reason);
         this.stopRequested = true;
      }
   }

   public final void stop(@Nonnull Level world, @Nonnull T entity) {
      if (this.status == BehaviorStatus.STOPPED) {
         this.log.warn("Ignoring stop request since behavior is already stopped");
      } else {
         this.log.behaviorTrace("Stopping behavior");

         try {
            this.doStop(world, entity);
         } catch (RuntimeException e) {
            this.log.behaviorError("Behavior teardown threw for entity {}: {}", entity.m_20148_(), e.getMessage(), e);
         } finally {
            this.behaviorCoolDown.resetWithMultiplier(this.getCooldownMultiplier(entity));
            this.status = BehaviorStatus.STOPPED;
            this.stopRequested = false;
         }

      }
   }

   public abstract void doStop(@Nonnull Level var1, @Nonnull T var2);

   @Generated
   public ILogger getLog() {
      return this.log;
   }

   @Generated
   public ITickable getPreconditionCheckCooldown() {
      return this.preconditionCheckCooldown;
   }

   @Generated
   public ITickable getBehaviorCoolDown() {
      return this.behaviorCoolDown;
   }

   @Generated
   public List<ICondition<T>> getPreconditions() {
      return this.preconditions;
   }

   @Generated
   public List<ICondition<T>> getContinueConditions() {
      return this.continueConditions;
   }

   @Generated
   public BehaviorStatus getStatus() {
      return this.status;
   }

   @Generated
   public boolean isStopRequested() {
      return this.stopRequested;
   }

   @Generated
   public Map<Class<?>, Boolean> getLatestPreconditionEvaluationResults() {
      return this.latestPreconditionEvaluationResults;
   }
}
