package dev.breezes.settlements.application.ai.behavior.runtime;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public final class BehaviorLifecycleResult {
   public static final BehaviorLifecycleResult CLEAN;
   private final Kind kind;
   @Nullable
   private final String reason;

   public static BehaviorLifecycleResult clean() {
      return CLEAN;
   }

   public static BehaviorLifecycleResult fail(@Nonnull String reason) {
      return new BehaviorLifecycleResult(BehaviorLifecycleResult.Kind.FAIL, reason);
   }

   public static BehaviorLifecycleResult abort(@Nonnull String reason) {
      return new BehaviorLifecycleResult(BehaviorLifecycleResult.Kind.ABORT, reason);
   }

   public boolean isClean() {
      return this.kind == BehaviorLifecycleResult.Kind.CLEAN;
   }

   @Generated
   private BehaviorLifecycleResult(Kind kind, @Nullable String reason) {
      this.kind = kind;
      this.reason = reason;
   }

   @Generated
   public Kind getKind() {
      return this.kind;
   }

   @Nullable
   @Generated
   public String getReason() {
      return this.reason;
   }

   static {
      CLEAN = new BehaviorLifecycleResult(BehaviorLifecycleResult.Kind.CLEAN, (String)null);
   }

   public static enum Kind {
      CLEAN,
      FAIL,
      ABORT;

      // $FF: synthetic method
      private static Kind[] $values() {
         return new Kind[]{CLEAN, FAIL, ABORT};
      }
   }
}
