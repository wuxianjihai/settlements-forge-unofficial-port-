package dev.breezes.settlements.application.ai.behavior.runtime;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.targeting.BlockMemoryTargetResolver;
import dev.breezes.settlements.application.economy.demand.DemandEvaluator;
import dev.breezes.settlements.application.economy.demand.DemandSignalService;
import dev.breezes.settlements.application.economy.supply.SupplyEvaluator;
import dev.breezes.settlements.application.hunger.HungerConfig;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventEmitter;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class BehaviorSupport_Factory implements Factory<BehaviorSupport> {
   private final Provider<HungerConfig> hungerConfigProvider;
   private final Provider<WorldEventEmitter> worldEventEmitterProvider;
   private final Provider<DemandSignalService> demandSignalServiceProvider;
   private final Provider<DemandEvaluator> demandEvaluatorProvider;
   private final Provider<SupplyEvaluator> supplyEvaluatorProvider;
   private final Provider<BlockMemoryTargetResolver> blockMemoryTargetResolverProvider;

   private BehaviorSupport_Factory(Provider<HungerConfig> hungerConfigProvider, Provider<WorldEventEmitter> worldEventEmitterProvider, Provider<DemandSignalService> demandSignalServiceProvider, Provider<DemandEvaluator> demandEvaluatorProvider, Provider<SupplyEvaluator> supplyEvaluatorProvider, Provider<BlockMemoryTargetResolver> blockMemoryTargetResolverProvider) {
      this.hungerConfigProvider = hungerConfigProvider;
      this.worldEventEmitterProvider = worldEventEmitterProvider;
      this.demandSignalServiceProvider = demandSignalServiceProvider;
      this.demandEvaluatorProvider = demandEvaluatorProvider;
      this.supplyEvaluatorProvider = supplyEvaluatorProvider;
      this.blockMemoryTargetResolverProvider = blockMemoryTargetResolverProvider;
   }

   public BehaviorSupport get() {
      return newInstance((HungerConfig)this.hungerConfigProvider.get(), (WorldEventEmitter)this.worldEventEmitterProvider.get(), (DemandSignalService)this.demandSignalServiceProvider.get(), (DemandEvaluator)this.demandEvaluatorProvider.get(), (SupplyEvaluator)this.supplyEvaluatorProvider.get(), (BlockMemoryTargetResolver)this.blockMemoryTargetResolverProvider.get());
   }

   public static BehaviorSupport_Factory create(Provider<HungerConfig> hungerConfigProvider, Provider<WorldEventEmitter> worldEventEmitterProvider, Provider<DemandSignalService> demandSignalServiceProvider, Provider<DemandEvaluator> demandEvaluatorProvider, Provider<SupplyEvaluator> supplyEvaluatorProvider, Provider<BlockMemoryTargetResolver> blockMemoryTargetResolverProvider) {
      return new BehaviorSupport_Factory(hungerConfigProvider, worldEventEmitterProvider, demandSignalServiceProvider, demandEvaluatorProvider, supplyEvaluatorProvider, blockMemoryTargetResolverProvider);
   }

   public static BehaviorSupport newInstance(HungerConfig hungerConfig, WorldEventEmitter worldEventEmitter, DemandSignalService demandSignalService, DemandEvaluator demandEvaluator, SupplyEvaluator supplyEvaluator, BlockMemoryTargetResolver blockMemoryTargetResolver) {
      return new BehaviorSupport(hungerConfig, worldEventEmitter, demandSignalService, demandEvaluator, supplyEvaluator, blockMemoryTargetResolver);
   }
}
