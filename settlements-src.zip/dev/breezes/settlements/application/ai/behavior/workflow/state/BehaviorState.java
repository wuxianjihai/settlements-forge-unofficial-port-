package dev.breezes.settlements.application.ai.behavior.workflow.state;

public interface BehaviorState {
   void reset();
}
