package dev.breezes.settlements.application.ai.behavior.workflow.steps;

public interface StageKey {
   String name();
}
