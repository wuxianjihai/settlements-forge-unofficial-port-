package dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets;

import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.shared.util.SettlementsException;
import lombok.Generated;
import net.minecraft.world.entity.Entity;

public class TargetableLocation implements Targetable {
   private final Location target;

   public TargetableType getType() {
      return TargetableType.LOCATION;
   }

   public Entity getAsEntity() {
      throw new SettlementsException("Cannot get targetable location as an entity");
   }

   public PhysicalBlock getAsBlock() {
      throw new SettlementsException("Cannot get targetable location as a block");
   }

   public Location getLocation() {
      return this.target.clone();
   }

   @Generated
   public TargetableLocation(Location target) {
      this.target = target;
   }
}
