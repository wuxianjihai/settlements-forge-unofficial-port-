package dev.breezes.settlements.application.ai.behavior.workflow.steps;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public abstract class AbstractStep<T extends ISettlementsBrainEntity> implements BehaviorStep<T> {
   public static final int NO_TIMEOUT = -1;
   private final String name;
   private final UUID uuid;
   private final int timeoutTicks;
   @Nullable
   private final StageKey timeoutTransition;
   private int elapsedTicks;

   protected AbstractStep(@Nonnull String name) {
      this(name, -1, (StageKey)null);
   }

   protected AbstractStep(@Nonnull String name, int timeoutTicks, @Nullable StageKey timeoutTransition) {
      this.name = name;
      this.uuid = UUID.randomUUID();
      this.timeoutTicks = timeoutTicks;
      this.timeoutTransition = timeoutTransition;
      this.elapsedTicks = 0;
   }

   public final StepResult tick(@Nonnull BehaviorContext<T> context) {
      ++this.elapsedTicks;
      if (this.timeoutTicks > 0 && this.elapsedTicks > this.timeoutTicks) {
         return this.timeoutTransition != null ? StepResult.transition(this.timeoutTransition) : StepResult.fail("timed out");
      } else {
         return this.doTick(context);
      }
   }

   protected abstract StepResult doTick(@Nonnull BehaviorContext<T> var1);

   public final void onEnter() {
      this.elapsedTicks = 0;
      this.doOnEnter();
   }

   public final void reset() {
      this.onEnter();
      this.doReset();
   }

   protected void doOnEnter() {
   }

   protected void doReset() {
   }

   @Generated
   public String getName() {
      return this.name;
   }

   @Generated
   public UUID getUuid() {
      return this.uuid;
   }
}
