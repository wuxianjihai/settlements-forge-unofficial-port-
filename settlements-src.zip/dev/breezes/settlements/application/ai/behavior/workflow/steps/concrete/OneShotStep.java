package dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.AbstractStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.function.Function;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public class OneShotStep<T extends ISettlementsBrainEntity> extends AbstractStep<T> {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(OneShotStep.class.getName());
   @Nonnull
   private final Function<BehaviorContext<T>, StepResult> action;

   private OneShotStep(@Nonnull String name, @Nonnull Function<BehaviorContext<T>, StepResult> action, int timeoutTicks, @Nullable StageKey timeoutTransition) {
      super(name, timeoutTicks, timeoutTransition);
      this.action = action;
   }

   protected StepResult doTick(@Nonnull BehaviorContext<T> context) {
      StepResult result = (StepResult)this.action.apply(context);
      if (result instanceof StepResult.NoOp) {
         log.warn("OneShotStep '{}' returned NoOp; the action must return a terminal result. Treating as complete.", this.getName());
         return StepResult.complete();
      } else {
         return result;
      }
   }

   @Generated
   public static <T extends ISettlementsBrainEntity> OneShotStepBuilder<T> builder() {
      return new OneShotStepBuilder<T>();
   }

   @Generated
   public static class OneShotStepBuilder<T extends ISettlementsBrainEntity> {
      @Generated
      private String name;
      @Generated
      private Function<BehaviorContext<T>, StepResult> action;
      @Generated
      private int timeoutTicks;
      @Generated
      private StageKey timeoutTransition;

      @Generated
      OneShotStepBuilder() {
      }

      @Generated
      public OneShotStepBuilder<T> name(@Nonnull String name) {
         if (name == null) {
            throw new NullPointerException("name is marked non-null but is null");
         } else {
            this.name = name;
            return this;
         }
      }

      @Generated
      public OneShotStepBuilder<T> action(@Nonnull Function<BehaviorContext<T>, StepResult> action) {
         if (action == null) {
            throw new NullPointerException("action is marked non-null but is null");
         } else {
            this.action = action;
            return this;
         }
      }

      @Generated
      public OneShotStepBuilder<T> timeoutTicks(int timeoutTicks) {
         this.timeoutTicks = timeoutTicks;
         return this;
      }

      @Generated
      public OneShotStepBuilder<T> timeoutTransition(@Nullable StageKey timeoutTransition) {
         this.timeoutTransition = timeoutTransition;
         return this;
      }

      @Generated
      public OneShotStep<T> build() {
         return new OneShotStep<T>(this.name, this.action, this.timeoutTicks, this.timeoutTransition);
      }

      @Generated
      public String toString() {
         String var10000 = this.name;
         return "OneShotStep.OneShotStepBuilder(name=" + var10000 + ", action=" + String.valueOf(this.action) + ", timeoutTicks=" + this.timeoutTicks + ", timeoutTransition=" + String.valueOf(this.timeoutTransition) + ")";
      }
   }
}
