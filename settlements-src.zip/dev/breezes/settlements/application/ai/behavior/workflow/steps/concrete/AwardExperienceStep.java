package dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.AbstractStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.domain.genetics.GeneType;
import dev.breezes.settlements.domain.genetics.IntelligenceExperienceResolver;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.util.RandomUtil;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public class AwardExperienceStep extends AbstractStep<BaseVillager> {
   private final int experienceAmount;
   private final StageKey nextStage;

   private AwardExperienceStep(@Nonnull String name, int experienceAmount, @Nonnull StageKey nextStage, int timeoutTicks, @Nullable StageKey timeoutTransition) {
      super(name, timeoutTicks, timeoutTransition);
      this.experienceAmount = experienceAmount;
      this.nextStage = nextStage;
   }

   protected StepResult doTick(@Nonnull BehaviorContext<BaseVillager> context) {
      if (!GeneralConfig.disableNaturalExperienceGain && this.experienceAmount > 0) {
         context.primaryDeed().filter(BehaviorOutcome::isSuccess).ifPresent((state) -> {
            double multiplier = IntelligenceExperienceResolver.resolveMultiplier(((BaseVillager)context.getInitiator()).getGenetics().getGeneValue(GeneType.INTELLIGENCE));
            int awarded = RandomUtil.stochasticRound((double)this.experienceAmount * multiplier);
            if (awarded > 0) {
               ((BaseVillager)context.getInitiator()).gainExperience(awarded);
            }

         });
         return StepResult.transition(this.nextStage);
      } else {
         return StepResult.transition(this.nextStage);
      }
   }

   @Generated
   public static AwardExperienceStepBuilder builder() {
      return new AwardExperienceStepBuilder();
   }

   @Generated
   public static class AwardExperienceStepBuilder {
      @Generated
      private String name;
      @Generated
      private int experienceAmount;
      @Generated
      private StageKey nextStage;
      @Generated
      private int timeoutTicks;
      @Generated
      private StageKey timeoutTransition;

      @Generated
      AwardExperienceStepBuilder() {
      }

      @Generated
      public AwardExperienceStepBuilder name(@Nonnull String name) {
         if (name == null) {
            throw new NullPointerException("name is marked non-null but is null");
         } else {
            this.name = name;
            return this;
         }
      }

      @Generated
      public AwardExperienceStepBuilder experienceAmount(int experienceAmount) {
         this.experienceAmount = experienceAmount;
         return this;
      }

      @Generated
      public AwardExperienceStepBuilder nextStage(@Nonnull StageKey nextStage) {
         if (nextStage == null) {
            throw new NullPointerException("nextStage is marked non-null but is null");
         } else {
            this.nextStage = nextStage;
            return this;
         }
      }

      @Generated
      public AwardExperienceStepBuilder timeoutTicks(int timeoutTicks) {
         this.timeoutTicks = timeoutTicks;
         return this;
      }

      @Generated
      public AwardExperienceStepBuilder timeoutTransition(@Nullable StageKey timeoutTransition) {
         this.timeoutTransition = timeoutTransition;
         return this;
      }

      @Generated
      public AwardExperienceStep build() {
         return new AwardExperienceStep(this.name, this.experienceAmount, this.nextStage, this.timeoutTicks, this.timeoutTransition);
      }

      @Generated
      public String toString() {
         String var10000 = this.name;
         return "AwardExperienceStep.AwardExperienceStepBuilder(name=" + var10000 + ", experienceAmount=" + this.experienceAmount + ", nextStage=" + String.valueOf(this.nextStage) + ", timeoutTicks=" + this.timeoutTicks + ", timeoutTransition=" + String.valueOf(this.timeoutTransition) + ")";
      }
   }
}
