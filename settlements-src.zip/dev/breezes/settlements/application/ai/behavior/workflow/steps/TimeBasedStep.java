package dev.breezes.settlements.application.ai.behavior.workflow.steps;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.ITickable;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public class TimeBasedStep<T extends ISettlementsBrainEntity> extends AbstractStep<T> {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(TimeBasedStep.class.getName());
   private final ITickable tickable;
   private final Map<Long, BehaviorStep<T>> keyFrames;
   @Nonnull
   private final Map<PeriodicSchedule, List<BehaviorStep<T>>> periodicSteps;
   @Nullable
   private final BehaviorStep<T> onStart;
   @Nullable
   private final BehaviorStep<T> onEnd;

   public TimeBasedStep(@Nonnull String name, @Nonnull ITickable tickable, @Nullable BehaviorStep<T> onStart, @Nullable BehaviorStep<T> onEnd) {
      super(name);
      this.tickable = tickable;
      this.keyFrames = new HashMap();
      this.periodicSteps = new HashMap();
      this.onStart = onStart;
      this.onEnd = onEnd;
   }

   public void addKeyFrames(@Nonnull Map<Long, BehaviorStep<T>> keyFrames) {
      this.keyFrames.putAll(keyFrames);
   }

   public void addPeriodicSteps(@Nonnull Map<PeriodicSchedule, List<BehaviorStep<T>>> periodicSteps) {
      this.periodicSteps.putAll(periodicSteps);
   }

   protected StepResult doTick(@Nonnull BehaviorContext<T> context) {
      if (this.onStart != null && this.tickable.getTicksElapsed() == (double)0.0F) {
         StepResult result = this.onStart.tick(context);
         if (!(result instanceof StepResult.NoOp)) {
            return result;
         }
      }

      boolean completed = this.tickable.tickCheckAndReset((double)1.0F);
      if (completed) {
         if (this.onEnd == null) {
            log.behaviorStatus("No onEnd step, returning complete");
            return StepResult.complete();
         } else {
            StepResult nextStage = this.onEnd.tick(context);
            log.behaviorStatus("Next stage: {}", nextStage);
            return nextStage instanceof StepResult.NoOp ? StepResult.complete() : nextStage;
         }
      } else {
         long elapsed = this.tickable.getTicksElapsedRounded();

         for(Map.Entry<PeriodicSchedule, List<BehaviorStep<T>>> entry : this.periodicSteps.entrySet()) {
            PeriodicSchedule schedule = (PeriodicSchedule)entry.getKey();
            if (elapsed % (long)schedule.interval() == (long)schedule.offset()) {
               for(BehaviorStep<T> step : (List)entry.getValue()) {
                  StepResult result = step.tick(context);
                  if (!(result instanceof StepResult.NoOp)) {
                     return result;
                  }
               }
            }
         }

         if (!this.keyFrames.containsKey(elapsed)) {
            return StepResult.noOp();
         } else {
            BehaviorStep<T> step = (BehaviorStep)this.keyFrames.get(elapsed);
            return step.tick(context);
         }
      }
   }

   protected void doOnEnter() {
      this.tickable.reset();
      if (this.onStart != null) {
         this.onStart.onEnter();
      }

      if (this.onEnd != null) {
         this.onEnd.onEnter();
      }

      this.periodicSteps.values().forEach((steps) -> steps.forEach(BehaviorStep::onEnter));
      this.keyFrames.values().forEach(BehaviorStep::onEnter);
   }

   protected void doReset() {
      if (this.onStart != null) {
         this.onStart.reset();
      }

      if (this.onEnd != null) {
         this.onEnd.reset();
      }

      this.periodicSteps.values().forEach((steps) -> steps.forEach(BehaviorStep::reset));
      this.keyFrames.values().forEach(BehaviorStep::reset);
   }

   public static <T extends ISettlementsBrainEntity> Builder<T> builder() {
      return new Builder<T>();
   }

   public static record PeriodicSchedule(int interval, int offset) {
      public PeriodicSchedule(int interval, int offset) {
         if (interval <= 0) {
            throw new IllegalArgumentException("Interval must be greater than 0");
         } else if (offset >= 0 && offset < interval) {
            this.interval = interval;
            this.offset = offset;
         } else {
            throw new IllegalArgumentException("Offset must be within [0, interval)");
         }
      }
   }

   public static class Builder<T extends ISettlementsBrainEntity> {
      @Nullable
      private String name;
      @Nullable
      private ITickable tickable;
      @Nonnull
      private final Map<Long, BehaviorStep<T>> keyFrames = new HashMap();
      @Nonnull
      private final Map<PeriodicSchedule, List<BehaviorStep<T>>> periodicSteps = new HashMap();
      @Nullable
      private BehaviorStep<T> onStart;
      @Nullable
      private BehaviorStep<T> onEnd;

      public Builder<T> name(@Nonnull String name) {
         this.name = name;
         return this;
      }

      public Builder<T> withTickable(@Nonnull ITickable tickable) {
         this.tickable = tickable;
         return this;
      }

      public Builder<T> addKeyFrame(@Nonnull ClockTicks elapsed, @Nonnull BehaviorStep<T> step) {
         this.keyFrames.put(elapsed.getTicks(), step);
         return this;
      }

      public Builder<T> everyTick(@Nonnull BehaviorStep<T> step) {
         return this.addPeriodicStep(1, step);
      }

      public Builder<T> addPeriodicStep(int interval, @Nonnull BehaviorStep<T> step) {
         return this.addPeriodicStep(interval, 0, step);
      }

      public Builder<T> addPeriodicStep(int interval, int offset, @Nonnull BehaviorStep<T> step) {
         PeriodicSchedule schedule = new PeriodicSchedule(interval, offset);
         List<BehaviorStep<T>> steps = (List)this.periodicSteps.getOrDefault(schedule, new ArrayList());
         steps.add(step);
         this.periodicSteps.put(schedule, steps);
         return this;
      }

      public Builder<T> onStart(@Nonnull BehaviorStep<T> step) {
         this.onStart = step;
         return this;
      }

      public Builder<T> onEnd(@Nonnull BehaviorStep<T> step) {
         this.onEnd = step;
         return this;
      }

      public TimeBasedStep<T> build() {
         if (this.tickable == null) {
            throw new IllegalStateException("Tickable must be set");
         } else {
            String resolvedName = this.name != null ? this.name : "TimeBasedStep[%s]".formatted(this.tickable.getRemainingCooldownsAsPrettyString());
            TimeBasedStep<T> step = new TimeBasedStep<T>(resolvedName, this.tickable, this.onStart, this.onEnd);
            step.addKeyFrames(this.keyFrames);
            step.addPeriodicSteps(this.periodicSteps);
            return step;
         }
      }
   }
}
