package dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.AbstractStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import dev.breezes.settlements.domain.time.Tickable;
import javax.annotation.Nonnull;
import lombok.Generated;

public class WaitStep<T extends ISettlementsBrainEntity> extends AbstractStep<T> {
   private final Tickable waitTime;
   private final StageKey nextStage;

   public WaitStep(@Nonnull Tickable waitTime, @Nonnull StageKey nextStage) {
      super("WaitStep[%s]".formatted(waitTime.getRemainingCooldownsAsPrettyString()));
      this.waitTime = waitTime;
      this.nextStage = nextStage;
   }

   protected StepResult doTick(@Nonnull BehaviorContext<T> context) {
      return this.waitTime.tickCheckAndReset((double)1.0F) ? StepResult.transition(this.nextStage) : StepResult.noOp();
   }

   protected void doOnEnter() {
      this.waitTime.reset();
   }

   @Generated
   public static <T extends ISettlementsBrainEntity> WaitStepBuilder<T> builder() {
      return new WaitStepBuilder<T>();
   }

   @Generated
   public static class WaitStepBuilder<T extends ISettlementsBrainEntity> {
      @Generated
      private Tickable waitTime;
      @Generated
      private StageKey nextStage;

      @Generated
      WaitStepBuilder() {
      }

      @Generated
      public WaitStepBuilder<T> waitTime(@Nonnull Tickable waitTime) {
         if (waitTime == null) {
            throw new NullPointerException("waitTime is marked non-null but is null");
         } else {
            this.waitTime = waitTime;
            return this;
         }
      }

      @Generated
      public WaitStepBuilder<T> nextStage(@Nonnull StageKey nextStage) {
         if (nextStage == null) {
            throw new NullPointerException("nextStage is marked non-null but is null");
         } else {
            this.nextStage = nextStage;
            return this;
         }
      }

      @Generated
      public WaitStep<T> build() {
         return new WaitStep<T>(this.waitTime, this.nextStage);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.waitTime);
         return "WaitStep.WaitStepBuilder(waitTime=" + var10000 + ", nextStage=" + String.valueOf(this.nextStage) + ")";
      }
   }
}
