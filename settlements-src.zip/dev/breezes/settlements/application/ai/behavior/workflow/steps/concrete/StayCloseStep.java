package dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.AbstractStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public class StayCloseStep<T extends ISettlementsBrainEntity> extends AbstractStep<T> {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(StayCloseStep.class.getName());
   private static final String DEFAULT_NAME = "StayCloseStep";
   private final double closeEnoughDistanceSquared;
   private final NavigateToTargetStep<T> navigateStep;
   private final BehaviorStep<T> actionStep;

   private StayCloseStep(@Nullable String name, double closeEnoughDistance, @Nonnull NavigateToTargetStep<T> navigateStep, @Nonnull BehaviorStep<T> actionStep, int timeoutTicks, @Nullable StageKey timeoutTransition) {
      super(name == null ? "StayCloseStep" : name, timeoutTicks, timeoutTransition);
      this.closeEnoughDistanceSquared = closeEnoughDistance * closeEnoughDistance;
      this.navigateStep = navigateStep;
      this.actionStep = actionStep;
   }

   protected StepResult doTick(@Nonnull BehaviorContext<T> context) {
      return this.isCloseEnough(context) ? this.actionStep.tick(context) : this.navigateStep.tick(context);
   }

   protected void doOnEnter() {
      this.navigateStep.onEnter();
      this.actionStep.onEnter();
   }

   protected void doReset() {
      this.navigateStep.reset();
      this.actionStep.reset();
   }

   private boolean isCloseEnough(@Nonnull BehaviorContext<T> context) {
      T initiator = context.getInitiator();
      return (Boolean)context.getState(BehaviorStateType.TARGET, TargetState.class).flatMap(TargetState::getFirst).map(Targetable::getLocation).map((target) -> target.distanceSquared(initiator.getMinecraftEntity()) < this.closeEnoughDistanceSquared).orElse(false);
   }

   @Generated
   public static <T extends ISettlementsBrainEntity> StayCloseStepBuilder<T> builder() {
      return new StayCloseStepBuilder<T>();
   }

   @Generated
   public static class StayCloseStepBuilder<T extends ISettlementsBrainEntity> {
      @Generated
      private String name;
      @Generated
      private double closeEnoughDistance;
      @Generated
      private NavigateToTargetStep<T> navigateStep;
      @Generated
      private BehaviorStep<T> actionStep;
      @Generated
      private int timeoutTicks;
      @Generated
      private StageKey timeoutTransition;

      @Generated
      StayCloseStepBuilder() {
      }

      @Generated
      public StayCloseStepBuilder<T> name(@Nullable String name) {
         this.name = name;
         return this;
      }

      @Generated
      public StayCloseStepBuilder<T> closeEnoughDistance(double closeEnoughDistance) {
         this.closeEnoughDistance = closeEnoughDistance;
         return this;
      }

      @Generated
      public StayCloseStepBuilder<T> navigateStep(@Nonnull NavigateToTargetStep<T> navigateStep) {
         if (navigateStep == null) {
            throw new NullPointerException("navigateStep is marked non-null but is null");
         } else {
            this.navigateStep = navigateStep;
            return this;
         }
      }

      @Generated
      public StayCloseStepBuilder<T> actionStep(@Nonnull BehaviorStep<T> actionStep) {
         if (actionStep == null) {
            throw new NullPointerException("actionStep is marked non-null but is null");
         } else {
            this.actionStep = actionStep;
            return this;
         }
      }

      @Generated
      public StayCloseStepBuilder<T> timeoutTicks(int timeoutTicks) {
         this.timeoutTicks = timeoutTicks;
         return this;
      }

      @Generated
      public StayCloseStepBuilder<T> timeoutTransition(@Nullable StageKey timeoutTransition) {
         this.timeoutTransition = timeoutTransition;
         return this;
      }

      @Generated
      public StayCloseStep<T> build() {
         return new StayCloseStep<T>(this.name, this.closeEnoughDistance, this.navigateStep, this.actionStep, this.timeoutTicks, this.timeoutTransition);
      }

      @Generated
      public String toString() {
         String var10000 = this.name;
         return "StayCloseStep.StayCloseStepBuilder(name=" + var10000 + ", closeEnoughDistance=" + this.closeEnoughDistance + ", navigateStep=" + String.valueOf(this.navigateStep) + ", actionStep=" + String.valueOf(this.actionStep) + ", timeoutTicks=" + this.timeoutTicks + ", timeoutTransition=" + String.valueOf(this.timeoutTransition) + ")";
      }
   }
}
