package dev.breezes.settlements.application.ai.behavior.workflow.steps;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public class ConditionalStep<T extends ISettlementsBrainEntity> extends AbstractStep<T> {
   private final ICondition<BehaviorContext<T>> condition;
   private final BehaviorStep<T> trueStep;
   private final BehaviorStep<T> falseStep;

   private ConditionalStep(@Nonnull String name, @Nonnull ICondition<BehaviorContext<T>> condition, @Nonnull BehaviorStep<T> trueStep, @Nonnull BehaviorStep<T> falseStep, int timeoutTicks, @Nullable StageKey timeoutTransition) {
      super(name, timeoutTicks, timeoutTransition);
      this.condition = condition;
      this.trueStep = trueStep;
      this.falseStep = falseStep;
   }

   protected StepResult doTick(@Nonnull BehaviorContext<T> context) {
      return this.condition.test(context) ? this.trueStep.tick(context) : this.falseStep.tick(context);
   }

   protected void doOnEnter() {
      this.trueStep.onEnter();
      this.falseStep.onEnter();
   }

   protected void doReset() {
      this.trueStep.reset();
      this.falseStep.reset();
   }

   @Generated
   public static <T extends ISettlementsBrainEntity> ConditionalStepBuilder<T> builder() {
      return new ConditionalStepBuilder<T>();
   }

   @Generated
   public static class ConditionalStepBuilder<T extends ISettlementsBrainEntity> {
      @Generated
      private String name;
      @Generated
      private ICondition<BehaviorContext<T>> condition;
      @Generated
      private BehaviorStep<T> trueStep;
      @Generated
      private BehaviorStep<T> falseStep;
      @Generated
      private int timeoutTicks;
      @Generated
      private StageKey timeoutTransition;

      @Generated
      ConditionalStepBuilder() {
      }

      @Generated
      public ConditionalStepBuilder<T> name(@Nonnull String name) {
         if (name == null) {
            throw new NullPointerException("name is marked non-null but is null");
         } else {
            this.name = name;
            return this;
         }
      }

      @Generated
      public ConditionalStepBuilder<T> condition(@Nonnull ICondition<BehaviorContext<T>> condition) {
         if (condition == null) {
            throw new NullPointerException("condition is marked non-null but is null");
         } else {
            this.condition = condition;
            return this;
         }
      }

      @Generated
      public ConditionalStepBuilder<T> trueStep(@Nonnull BehaviorStep<T> trueStep) {
         if (trueStep == null) {
            throw new NullPointerException("trueStep is marked non-null but is null");
         } else {
            this.trueStep = trueStep;
            return this;
         }
      }

      @Generated
      public ConditionalStepBuilder<T> falseStep(@Nonnull BehaviorStep<T> falseStep) {
         if (falseStep == null) {
            throw new NullPointerException("falseStep is marked non-null but is null");
         } else {
            this.falseStep = falseStep;
            return this;
         }
      }

      @Generated
      public ConditionalStepBuilder<T> timeoutTicks(int timeoutTicks) {
         this.timeoutTicks = timeoutTicks;
         return this;
      }

      @Generated
      public ConditionalStepBuilder<T> timeoutTransition(@Nullable StageKey timeoutTransition) {
         this.timeoutTransition = timeoutTransition;
         return this;
      }

      @Generated
      public ConditionalStep<T> build() {
         return new ConditionalStep<T>(this.name, this.condition, this.trueStep, this.falseStep, this.timeoutTicks, this.timeoutTransition);
      }

      @Generated
      public String toString() {
         String var10000 = this.name;
         return "ConditionalStep.ConditionalStepBuilder(name=" + var10000 + ", condition=" + String.valueOf(this.condition) + ", trueStep=" + String.valueOf(this.trueStep) + ", falseStep=" + String.valueOf(this.falseStep) + ", timeoutTicks=" + this.timeoutTicks + ", timeoutTransition=" + String.valueOf(this.timeoutTransition) + ")";
      }
   }
}
