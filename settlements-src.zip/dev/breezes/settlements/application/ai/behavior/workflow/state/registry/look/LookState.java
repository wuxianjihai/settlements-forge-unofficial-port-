package dev.breezes.settlements.application.ai.behavior.workflow.state.registry.look;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorState;
import dev.breezes.settlements.domain.world.location.Location;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.world.entity.Entity;

public class LookState implements BehaviorState {
   @Nullable
   private Entity entity;
   @Nullable
   private Location location;

   private LookState(@Nullable Entity entity, @Nullable Location location) {
      this.entity = entity;
      this.location = location;
   }

   public static LookState ofEntity(@Nonnull Entity entity) {
      return new LookState(entity, (Location)null);
   }

   public static LookState ofLocation(@Nonnull Location location) {
      return new LookState((Entity)null, location);
   }

   public Optional<Location> resolveLocation() {
      return this.entity != null ? Optional.of(Location.fromEntity(this.entity, false)) : Optional.ofNullable(this.location);
   }

   public void reset() {
      this.entity = null;
      this.location = null;
   }
}
