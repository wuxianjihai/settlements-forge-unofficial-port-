package dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.items.ItemState;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.AbstractStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.domain.entities.ISettlementsVillager;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.Objects;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.world.entity.Entity;

public class PickupItemsStep extends AbstractStep<BaseVillager> {
   private final StageKey nextStage;
   private int elapsedTicks;
   private boolean pickedUp;

   private PickupItemsStep(@Nonnull String name, @Nonnull StageKey nextStage, int timeoutTicks, @Nullable StageKey timeoutTransition) {
      super(name, timeoutTicks, timeoutTransition);
      this.nextStage = nextStage;
      this.elapsedTicks = 0;
      this.pickedUp = false;
   }

   protected StepResult doTick(@Nonnull BehaviorContext<BaseVillager> context) {
      ++this.elapsedTicks;
      if (this.elapsedTicks == 1) {
         ((BaseVillager)context.getInitiator()).triggerMotion(AnimationArchetype.PICK_UP);
      }

      if (!this.pickedUp && this.elapsedTicks >= 11) {
         this.pickUpItems(context);
         this.pickedUp = true;
      }

      return this.elapsedTicks >= 24 ? StepResult.transition(this.nextStage) : StepResult.noOp();
   }

   private void pickUpItems(@Nonnull BehaviorContext<BaseVillager> context) {
      ISettlementsVillager villager = context.getInitiator();
      context.getState(BehaviorStateType.ITEMS_TO_PICK_UP, ItemState.class).ifPresent((items) -> {
         Stream var10000 = items.getItems().stream().filter(Entity::m_6084_);
         Objects.requireNonNull(villager);
         var10000.forEach(villager::pickUp);
      });
   }

   protected void doOnEnter() {
      this.elapsedTicks = 0;
      this.pickedUp = false;
   }

   @Generated
   public static PickupItemsStepBuilder builder() {
      return new PickupItemsStepBuilder();
   }

   @Generated
   public static class PickupItemsStepBuilder {
      @Generated
      private String name;
      @Generated
      private StageKey nextStage;
      @Generated
      private int timeoutTicks;
      @Generated
      private StageKey timeoutTransition;

      @Generated
      PickupItemsStepBuilder() {
      }

      @Generated
      public PickupItemsStepBuilder name(@Nonnull String name) {
         if (name == null) {
            throw new NullPointerException("name is marked non-null but is null");
         } else {
            this.name = name;
            return this;
         }
      }

      @Generated
      public PickupItemsStepBuilder nextStage(@Nonnull StageKey nextStage) {
         if (nextStage == null) {
            throw new NullPointerException("nextStage is marked non-null but is null");
         } else {
            this.nextStage = nextStage;
            return this;
         }
      }

      @Generated
      public PickupItemsStepBuilder timeoutTicks(int timeoutTicks) {
         this.timeoutTicks = timeoutTicks;
         return this;
      }

      @Generated
      public PickupItemsStepBuilder timeoutTransition(@Nullable StageKey timeoutTransition) {
         this.timeoutTransition = timeoutTransition;
         return this;
      }

      @Generated
      public PickupItemsStep build() {
         return new PickupItemsStep(this.name, this.nextStage, this.timeoutTicks, this.timeoutTransition);
      }

      @Generated
      public String toString() {
         String var10000 = this.name;
         return "PickupItemsStep.PickupItemsStepBuilder(name=" + var10000 + ", nextStage=" + String.valueOf(this.nextStage) + ", timeoutTicks=" + this.timeoutTicks + ", timeoutTransition=" + String.valueOf(this.timeoutTransition) + ")";
      }
   }
}
