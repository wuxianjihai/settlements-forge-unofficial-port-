package dev.breezes.settlements.application.ai.behavior.workflow.steps;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import javax.annotation.Nonnull;

public interface BehaviorStep<T extends ISettlementsBrainEntity> {
   StepResult tick(@Nonnull BehaviorContext<T> var1);

   default void onEnter() {
   }

   default void reset() {
   }
}
