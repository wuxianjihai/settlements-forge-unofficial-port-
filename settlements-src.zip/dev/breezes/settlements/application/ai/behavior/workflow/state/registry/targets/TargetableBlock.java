package dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets;

import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.shared.util.SettlementsException;
import lombok.Generated;
import net.minecraft.world.entity.Entity;

public class TargetableBlock implements Targetable {
   private final PhysicalBlock target;

   public TargetableType getType() {
      return TargetableType.BLOCK;
   }

   public Entity getAsEntity() {
      throw new SettlementsException("Cannot get targetable block as an entity");
   }

   public PhysicalBlock getAsBlock() {
      return this.target;
   }

   public Location getLocation() {
      return this.target.getLocation(true);
   }

   @Generated
   public TargetableBlock(PhysicalBlock target) {
      this.target = target;
   }
}
