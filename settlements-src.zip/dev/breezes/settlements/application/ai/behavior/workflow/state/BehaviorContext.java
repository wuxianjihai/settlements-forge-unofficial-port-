package dev.breezes.settlements.application.ai.behavior.workflow.state;

import dev.breezes.settlements.application.ai.behavior.teardown.TeardownScope;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorDeedLedger;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import java.util.EnumMap;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.server.level.ServerLevel;

public class BehaviorContext<T extends ISettlementsBrainEntity> {
   private final T initiator;
   private final Map<BehaviorStateType, BehaviorState> states;
   private final TeardownScope teardownScope;

   public BehaviorContext(@Nonnull T initiator) {
      this.initiator = initiator;
      this.states = new EnumMap(BehaviorStateType.class);
      this.teardownScope = new TeardownScope();
   }

   public <S extends BehaviorState> Optional<S> getState(@Nonnull BehaviorStateType type, @Nonnull Class<S> castTo) {
      if (type.getClazz() != castTo) {
         throw new IllegalArgumentException("The type of the state does not match the cast type");
      } else {
         return Optional.ofNullable((BehaviorState)castTo.cast(this.states.get(type)));
      }
   }

   public void setState(@Nonnull BehaviorStateType type, @Nonnull BehaviorState state) {
      this.states.put(type, state);
   }

   public void clearState(@Nonnull BehaviorStateType type) {
      this.states.remove(type);
   }

   public BehaviorOutcome declarePrimaryDeed(@Nonnull BehaviorOutcome primary) {
      return this.ledger().declarePrimary(primary);
   }

   public BehaviorOutcome addSecondaryDeed(@Nonnull BehaviorOutcome secondary) {
      return this.ledger().addSecondary(secondary);
   }

   public Optional<BehaviorOutcome> primaryDeed() {
      return this.deedLedger().flatMap(BehaviorDeedLedger::primary);
   }

   public Optional<BehaviorDeedLedger> deedLedger() {
      return this.<BehaviorDeedLedger>getState(BehaviorStateType.BEHAVIOR_OUTCOME, BehaviorDeedLedger.class);
   }

   private BehaviorDeedLedger ledger() {
      return (BehaviorDeedLedger)this.deedLedger().orElseGet(() -> {
         BehaviorDeedLedger newLedger = new BehaviorDeedLedger();
         this.setState(BehaviorStateType.BEHAVIOR_OUTCOME, newLedger);
         return newLedger;
      });
   }

   public ServerLevel getLevel() {
      return (ServerLevel)this.initiator.getMinecraftEntity().m_9236_();
   }

   @Generated
   public T getInitiator() {
      return this.initiator;
   }

   @Generated
   public TeardownScope getTeardownScope() {
      return this.teardownScope;
   }
}
