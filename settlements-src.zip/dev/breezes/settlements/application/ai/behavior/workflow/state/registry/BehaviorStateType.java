package dev.breezes.settlements.application.ai.behavior.workflow.state.registry;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.blocks.VisitedBlockSitesState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.items.ItemState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.look.LookState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorDeedLedger;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import lombok.Generated;

public enum BehaviorStateType {
   TARGET("target", TargetState.class),
   LOOK_TARGET("look_target", LookState.class),
   ITEMS_TO_PICK_UP("items_to_pick_up", ItemState.class),
   BEHAVIOR_OUTCOME("behavior_outcome", BehaviorDeedLedger.class),
   VISITED_BLOCK_SITES("visited_block_sites", VisitedBlockSitesState.class);

   private final String name;
   private final Class<? extends BehaviorState> clazz;

   @Generated
   private BehaviorStateType(String name, Class<? extends BehaviorState> clazz) {
      this.name = name;
      this.clazz = clazz;
   }

   @Generated
   public String getName() {
      return this.name;
   }

   @Generated
   public Class<? extends BehaviorState> getClazz() {
      return this.clazz;
   }

   // $FF: synthetic method
   private static BehaviorStateType[] $values() {
      return new BehaviorStateType[]{TARGET, LOOK_TARGET, ITEMS_TO_PICK_UP, BEHAVIOR_OUTCOME, VISITED_BLOCK_SITES};
   }
}
