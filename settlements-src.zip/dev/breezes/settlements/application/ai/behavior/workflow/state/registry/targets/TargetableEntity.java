package dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets;

import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.shared.util.SettlementsException;
import lombok.Generated;
import net.minecraft.world.entity.Entity;

public class TargetableEntity implements Targetable {
   private final Entity target;

   public TargetableType getType() {
      return TargetableType.ENTITY;
   }

   public Entity getAsEntity() {
      return this.target;
   }

   public PhysicalBlock getAsBlock() {
      throw new SettlementsException("Cannot get targetable entity as a block");
   }

   public Location getLocation() {
      return Location.fromEntity(this.target, false);
   }

   @Generated
   public TargetableEntity(Entity target) {
      this.target = target;
   }
}
