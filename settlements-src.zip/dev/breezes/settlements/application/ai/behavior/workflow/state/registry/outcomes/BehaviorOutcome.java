package dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorState;
import dev.breezes.settlements.domain.ai.worldevent.EventOutcome;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public final class BehaviorOutcome implements BehaviorState {
   @Nullable
   private WorldEventType deedType;
   @Nullable
   private String unitNoun;
   @Nullable
   private String unitQualifier;
   private boolean success;
   private int magnitude;
   @Nullable
   private UUID partnerId;
   @Nullable
   private UUID registryId;
   @Nullable
   private EventOutcome eventOutcome;
   @Nullable
   private String detail;
   @Nullable
   private String failureReason;
   private boolean silent;
   @Nullable
   private Map<String, String> detailFields;

   private BehaviorOutcome(@Nullable WorldEventType deedType, @Nullable String unitNoun, @Nullable String unitQualifier, boolean success, int magnitude, @Nullable UUID partnerId, @Nullable UUID registryId, @Nullable EventOutcome eventOutcome, @Nullable String detail, @Nullable String failureReason) {
      this.deedType = deedType;
      this.unitNoun = unitNoun;
      this.unitQualifier = unitQualifier;
      this.success = success;
      this.magnitude = magnitude;
      this.partnerId = partnerId;
      this.registryId = registryId;
      this.eventOutcome = eventOutcome;
      this.detail = detail;
      this.failureReason = failureReason;
   }

   public static BehaviorOutcome blank() {
      return builder().build();
   }

   public static BehaviorOutcome silent() {
      BehaviorOutcome outcome = new BehaviorOutcome();
      outcome.silent = true;
      return outcome;
   }

   public static BehaviorOutcome forDeed(@Nonnull WorldEventType deedType, @Nullable String unitNoun) {
      return forDeed(deedType, unitNoun, (String)null);
   }

   public static BehaviorOutcome forDeed(@Nonnull WorldEventType deedType, @Nullable String unitNoun, @Nullable String unitQualifier) {
      return builder().deedType(deedType).unitNoun(unitNoun).unitQualifier(unitQualifier).build();
   }

   public void recordTargetedDeed(@Nonnull UUID targetId) {
      this.partnerId = targetId;
      this.markSucceeded();
   }

   public void recordDeedDetail(@Nonnull String detail) {
      this.detail = detail;
      this.markSucceeded();
   }

   public void recordYield(int units) {
      if (units > 0) {
         this.magnitude += units;
         this.markSucceeded();
      }
   }

   public void recordSocialOutcome(@Nullable UUID partnerId, @Nullable UUID registryId, @Nonnull EventOutcome outcome, @Nullable String detail, @Nullable String reason) {
      this.partnerId = partnerId;
      this.registryId = registryId;
      this.eventOutcome = outcome;
      this.detail = detail;
      this.failureReason = reason;
      this.success = outcome == EventOutcome.SUCCESS;
   }

   public void markSucceeded() {
      this.success = true;
      this.eventOutcome = EventOutcome.SUCCESS;
      this.failureReason = null;
   }

   public void markFailed(@Nullable String reason) {
      this.success = false;
      this.eventOutcome = EventOutcome.FAILURE;
      this.failureReason = reason;
   }

   public void putDetailField(@Nonnull String key, @Nonnull String value) {
      if (this.detailFields == null) {
         this.detailFields = new HashMap();
      }

      this.detailFields.put(key, value);
   }

   public boolean hasDeclaredDeed() {
      return this.deedType != null;
   }

   public boolean hasExplicitEventOutcome() {
      return this.eventOutcome != null;
   }

   @Nullable
   public String resolveDetail() {
      if (this.detail != null) {
         return this.detail;
      } else if (this.unitNoun != null) {
         String counted = "%d %s".formatted(this.magnitude, this.unitNoun);
         return this.unitQualifier != null ? counted + " " + this.unitQualifier : counted;
      } else {
         return null;
      }
   }

   public void reset() {
      this.success = false;
      this.magnitude = 0;
      this.partnerId = null;
      this.registryId = null;
      this.eventOutcome = null;
      this.detail = null;
      this.failureReason = null;
      this.detailFields = null;
   }

   @Generated
   private static BehaviorOutcomeBuilder builder() {
      return new BehaviorOutcomeBuilder();
   }

   @Generated
   private BehaviorOutcome() {
   }

   @Nullable
   @Generated
   public WorldEventType getDeedType() {
      return this.deedType;
   }

   @Nullable
   @Generated
   public String getUnitNoun() {
      return this.unitNoun;
   }

   @Nullable
   @Generated
   public String getUnitQualifier() {
      return this.unitQualifier;
   }

   @Generated
   public boolean isSuccess() {
      return this.success;
   }

   @Generated
   public int getMagnitude() {
      return this.magnitude;
   }

   @Nullable
   @Generated
   public UUID getPartnerId() {
      return this.partnerId;
   }

   @Nullable
   @Generated
   public UUID getRegistryId() {
      return this.registryId;
   }

   @Nullable
   @Generated
   public EventOutcome getEventOutcome() {
      return this.eventOutcome;
   }

   @Nullable
   @Generated
   public String getDetail() {
      return this.detail;
   }

   @Nullable
   @Generated
   public String getFailureReason() {
      return this.failureReason;
   }

   @Generated
   public boolean isSilent() {
      return this.silent;
   }

   @Nullable
   @Generated
   public Map<String, String> getDetailFields() {
      return this.detailFields;
   }

   @Generated
   private static class BehaviorOutcomeBuilder {
      @Generated
      private WorldEventType deedType;
      @Generated
      private String unitNoun;
      @Generated
      private String unitQualifier;
      @Generated
      private boolean success;
      @Generated
      private int magnitude;
      @Generated
      private UUID partnerId;
      @Generated
      private UUID registryId;
      @Generated
      private EventOutcome eventOutcome;
      @Generated
      private String detail;
      @Generated
      private String failureReason;

      @Generated
      BehaviorOutcomeBuilder() {
      }

      @Generated
      private BehaviorOutcomeBuilder deedType(@Nullable WorldEventType deedType) {
         this.deedType = deedType;
         return this;
      }

      @Generated
      private BehaviorOutcomeBuilder unitNoun(@Nullable String unitNoun) {
         this.unitNoun = unitNoun;
         return this;
      }

      @Generated
      private BehaviorOutcomeBuilder unitQualifier(@Nullable String unitQualifier) {
         this.unitQualifier = unitQualifier;
         return this;
      }

      @Generated
      private BehaviorOutcomeBuilder success(boolean success) {
         this.success = success;
         return this;
      }

      @Generated
      private BehaviorOutcomeBuilder magnitude(int magnitude) {
         this.magnitude = magnitude;
         return this;
      }

      @Generated
      private BehaviorOutcomeBuilder partnerId(@Nullable UUID partnerId) {
         this.partnerId = partnerId;
         return this;
      }

      @Generated
      private BehaviorOutcomeBuilder registryId(@Nullable UUID registryId) {
         this.registryId = registryId;
         return this;
      }

      @Generated
      private BehaviorOutcomeBuilder eventOutcome(@Nullable EventOutcome eventOutcome) {
         this.eventOutcome = eventOutcome;
         return this;
      }

      @Generated
      private BehaviorOutcomeBuilder detail(@Nullable String detail) {
         this.detail = detail;
         return this;
      }

      @Generated
      private BehaviorOutcomeBuilder failureReason(@Nullable String failureReason) {
         this.failureReason = failureReason;
         return this;
      }

      @Generated
      private BehaviorOutcome build() {
         return new BehaviorOutcome(this.deedType, this.unitNoun, this.unitQualifier, this.success, this.magnitude, this.partnerId, this.registryId, this.eventOutcome, this.detail, this.failureReason);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.deedType);
         return "BehaviorOutcome.BehaviorOutcomeBuilder(deedType=" + var10000 + ", unitNoun=" + this.unitNoun + ", unitQualifier=" + this.unitQualifier + ", success=" + this.success + ", magnitude=" + this.magnitude + ", partnerId=" + String.valueOf(this.partnerId) + ", registryId=" + String.valueOf(this.registryId) + ", eventOutcome=" + String.valueOf(this.eventOutcome) + ", detail=" + this.detail + ", failureReason=" + this.failureReason + ")";
      }
   }
}
