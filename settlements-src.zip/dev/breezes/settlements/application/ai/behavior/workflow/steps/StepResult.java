package dev.breezes.settlements.application.ai.behavior.workflow.steps;

import java.util.Map;

public sealed interface StepResult {
   StepResult NO_OP = new NoOp();
   StepResult COMPLETE = new Complete();

   static StepResult noOp() {
      return NO_OP;
   }

   static StepResult complete() {
      return COMPLETE;
   }

   static StepResult transition(StageKey key) {
      return new Transition(key);
   }

   static StepResult fail(String code) {
      return new Fail(code, Map.of());
   }

   static StepResult fail(String code, Map<String, Object> details) {
      return new Fail(code, details);
   }

   static StepResult abort(String code, Throwable cause) {
      return new Abort(code, cause);
   }

   public static record NoOp() implements StepResult {
   }

   public static record Complete() implements StepResult {
   }

   public static record Transition(StageKey key) implements StepResult {
   }

   public static record Fail(String code, Map<String, Object> details) implements StepResult {
   }

   public static record Abort(String code, Throwable cause) implements StepResult {
   }
}
