package dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.AbstractStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import dev.breezes.settlements.domain.ai.navigation.NavigationType;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.world.location.Location;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public class NavigateToTargetStep<T extends ISettlementsBrainEntity> extends AbstractStep<T> {
   private static final int DEFAULT_NAV_TIMEOUT_TICKS = ClockTicks.seconds((double)30.0F).getTicksAsInt();
   private final NavigationType navigationType;
   private final int completionDistance;
   @Nullable
   private final StageKey unreachableTransition;
   private final boolean reachabilityGated;

   public NavigateToTargetStep(@Nonnull NavigationType navigationType, int completionDistance) {
      this(navigationType, completionDistance, (StageKey)null, (Boolean)null);
   }

   public NavigateToTargetStep(@Nonnull NavigationType navigationType, int completionDistance, @Nullable StageKey unreachableTransition, @Nullable Boolean reachabilityGated) {
      super("NavigateToTargetStep", DEFAULT_NAV_TIMEOUT_TICKS, unreachableTransition);
      this.navigationType = navigationType;
      this.completionDistance = completionDistance;
      this.unreachableTransition = unreachableTransition;
      this.reachabilityGated = reachabilityGated == null || reachabilityGated;
   }

   protected StepResult doTick(@Nonnull BehaviorContext<T> context) {
      T initiator = context.getInitiator();
      if (initiator.getNavigationManager().isNavigating()) {
         return StepResult.noOp();
      } else {
         Optional<Location> target = context.getState(BehaviorStateType.TARGET, TargetState.class).flatMap(TargetState::getFirst).map(Targetable::getLocation);
         if (target.isEmpty()) {
            return StepResult.noOp();
         } else if (this.reachabilityGated && !initiator.getNavigationManager().canReach((Location)target.get(), (double)this.completionDistance)) {
            return this.unreachableTransition != null ? StepResult.transition(this.unreachableTransition) : StepResult.fail("unreachable");
         } else {
            initiator.getNavigationManager().navigateTo((Location)target.get(), this.navigationType, this.completionDistance);
            return StepResult.noOp();
         }
      }
   }

   @Generated
   public static <T extends ISettlementsBrainEntity> NavigateToTargetStepBuilder<T> builder() {
      return new NavigateToTargetStepBuilder<T>();
   }

   @Generated
   public static class NavigateToTargetStepBuilder<T extends ISettlementsBrainEntity> {
      @Generated
      private NavigationType navigationType;
      @Generated
      private int completionDistance;
      @Generated
      private StageKey unreachableTransition;
      @Generated
      private Boolean reachabilityGated;

      @Generated
      NavigateToTargetStepBuilder() {
      }

      @Generated
      public NavigateToTargetStepBuilder<T> navigationType(@Nonnull NavigationType navigationType) {
         if (navigationType == null) {
            throw new NullPointerException("navigationType is marked non-null but is null");
         } else {
            this.navigationType = navigationType;
            return this;
         }
      }

      @Generated
      public NavigateToTargetStepBuilder<T> completionDistance(int completionDistance) {
         this.completionDistance = completionDistance;
         return this;
      }

      @Generated
      public NavigateToTargetStepBuilder<T> unreachableTransition(@Nullable StageKey unreachableTransition) {
         this.unreachableTransition = unreachableTransition;
         return this;
      }

      @Generated
      public NavigateToTargetStepBuilder<T> reachabilityGated(@Nullable Boolean reachabilityGated) {
         this.reachabilityGated = reachabilityGated;
         return this;
      }

      @Generated
      public NavigateToTargetStep<T> build() {
         return new NavigateToTargetStep<T>(this.navigationType, this.completionDistance, this.unreachableTransition, this.reachabilityGated);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.navigationType);
         return "NavigateToTargetStep.NavigateToTargetStepBuilder(navigationType=" + var10000 + ", completionDistance=" + this.completionDistance + ", unreachableTransition=" + String.valueOf(this.unreachableTransition) + ", reachabilityGated=" + this.reachabilityGated + ")";
      }
   }
}
