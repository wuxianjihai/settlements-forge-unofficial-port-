package dev.breezes.settlements.application.ai.behavior.workflow.state.registry.look;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetQueries;
import dev.breezes.settlements.application.ai.socialcue.SocialCueRuntimeState;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class LookQueries {
   public static <T extends ISettlementsBrainEntity> Optional<Location> resolveLookLocation(@Nonnull BehaviorContext<T> context) {
      Optional<LookState> lookState = context.<LookState>getState(BehaviorStateType.LOOK_TARGET, LookState.class);
      if (lookState.isPresent()) {
         return lookState.flatMap(LookState::resolveLocation);
      } else {
         T initiator = context.getInitiator();
         if (initiator instanceof BaseVillager) {
            BaseVillager baseVillager = (BaseVillager)initiator;
            SocialCueRuntimeState cueState = baseVillager.getSocialCueRuntimeState();
            if (cueState.isCueActive() && cueState.getGazeLookTarget() != null) {
               return Optional.of(cueState.getGazeLookTarget());
            }
         }

         return TargetQueries.firstTargetLocation(context);
      }
   }

   @Generated
   private LookQueries() {
   }
}
