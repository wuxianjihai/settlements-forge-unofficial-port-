package dev.breezes.settlements.application.ai.behavior.workflow.state.registry.items;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorState;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.world.entity.item.ItemEntity;

public class ItemState implements BehaviorState {
   private List<ItemEntity> items;

   public ItemState(@Nonnull List<ItemEntity> items) {
      this.items = new ArrayList(items);
   }

   public static ItemState of(@Nonnull List<ItemEntity> items) {
      return new ItemState(items);
   }

   public void addItem(@Nonnull ItemEntity item) {
      this.items.add(item);
   }

   public Stream<ItemEntity> match(@Nonnull ICondition<ItemEntity> condition) {
      return this.items.stream().filter(condition);
   }

   public void reset() {
      this.items = new ArrayList();
   }

   @Generated
   public List<ItemEntity> getItems() {
      return this.items;
   }
}
