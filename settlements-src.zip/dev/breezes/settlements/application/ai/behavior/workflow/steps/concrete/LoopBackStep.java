package dev.breezes.settlements.application.ai.behavior.workflow.steps.concrete;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.AbstractStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import java.util.function.ToIntFunction;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public class LoopBackStep<T extends ISettlementsBrainEntity> extends AbstractStep<T> {
   private static final int UNINITIALIZED = -1;
   private static final int MINIMUM_ITERATIONS = 1;
   private final StageKey loopBackTo;
   private final StageKey completionTransition;
   private final ToIntFunction<BehaviorContext<T>> maxIterationsResolver;
   private int remaining;

   private LoopBackStep(@Nonnull String name, @Nonnull StageKey loopBackTo, @Nonnull StageKey completionTransition, @Nonnull ToIntFunction<BehaviorContext<T>> maxIterationsResolver, int timeoutTicks, @Nullable StageKey timeoutTransition) {
      super(name, timeoutTicks, timeoutTransition);
      this.loopBackTo = loopBackTo;
      this.completionTransition = completionTransition;
      this.maxIterationsResolver = maxIterationsResolver;
      this.remaining = -1;
   }

   protected StepResult doTick(@Nonnull BehaviorContext<T> context) {
      if (this.remaining == -1) {
         this.remaining = Math.max(1, this.maxIterationsResolver.applyAsInt(context));
      }

      --this.remaining;
      return this.remaining > 0 ? StepResult.transition(this.loopBackTo) : StepResult.transition(this.completionTransition);
   }

   protected void doReset() {
      this.remaining = -1;
   }

   @Generated
   public static <T extends ISettlementsBrainEntity> LoopBackStepBuilder<T> builder() {
      return new LoopBackStepBuilder<T>();
   }

   @Generated
   public static class LoopBackStepBuilder<T extends ISettlementsBrainEntity> {
      @Generated
      private String name;
      @Generated
      private StageKey loopBackTo;
      @Generated
      private StageKey completionTransition;
      @Generated
      private ToIntFunction<BehaviorContext<T>> maxIterationsResolver;
      @Generated
      private int timeoutTicks;
      @Generated
      private StageKey timeoutTransition;

      @Generated
      LoopBackStepBuilder() {
      }

      @Generated
      public LoopBackStepBuilder<T> name(@Nonnull String name) {
         if (name == null) {
            throw new NullPointerException("name is marked non-null but is null");
         } else {
            this.name = name;
            return this;
         }
      }

      @Generated
      public LoopBackStepBuilder<T> loopBackTo(@Nonnull StageKey loopBackTo) {
         if (loopBackTo == null) {
            throw new NullPointerException("loopBackTo is marked non-null but is null");
         } else {
            this.loopBackTo = loopBackTo;
            return this;
         }
      }

      @Generated
      public LoopBackStepBuilder<T> completionTransition(@Nonnull StageKey completionTransition) {
         if (completionTransition == null) {
            throw new NullPointerException("completionTransition is marked non-null but is null");
         } else {
            this.completionTransition = completionTransition;
            return this;
         }
      }

      @Generated
      public LoopBackStepBuilder<T> maxIterationsResolver(@Nonnull ToIntFunction<BehaviorContext<T>> maxIterationsResolver) {
         if (maxIterationsResolver == null) {
            throw new NullPointerException("maxIterationsResolver is marked non-null but is null");
         } else {
            this.maxIterationsResolver = maxIterationsResolver;
            return this;
         }
      }

      @Generated
      public LoopBackStepBuilder<T> timeoutTicks(int timeoutTicks) {
         this.timeoutTicks = timeoutTicks;
         return this;
      }

      @Generated
      public LoopBackStepBuilder<T> timeoutTransition(@Nullable StageKey timeoutTransition) {
         this.timeoutTransition = timeoutTransition;
         return this;
      }

      @Generated
      public LoopBackStep<T> build() {
         return new LoopBackStep<T>(this.name, this.loopBackTo, this.completionTransition, this.maxIterationsResolver, this.timeoutTicks, this.timeoutTransition);
      }

      @Generated
      public String toString() {
         String var10000 = this.name;
         return "LoopBackStep.LoopBackStepBuilder(name=" + var10000 + ", loopBackTo=" + String.valueOf(this.loopBackTo) + ", completionTransition=" + String.valueOf(this.completionTransition) + ", maxIterationsResolver=" + String.valueOf(this.maxIterationsResolver) + ", timeoutTicks=" + this.timeoutTicks + ", timeoutTransition=" + String.valueOf(this.timeoutTransition) + ")";
      }
   }
}
