package dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;

public final class TargetQueries {
   public static <T extends ISettlementsBrainEntity> Optional<Targetable> firstMatching(@Nonnull BehaviorContext<T> context, @Nonnull ICondition<Targetable> condition) {
      return context.getState(BehaviorStateType.TARGET, TargetState.class).map((targetState) -> targetState.match(condition)).flatMap(Stream::findFirst);
   }

   public static <T extends ISettlementsBrainEntity, E extends Entity> Optional<E> firstEntity(@Nonnull BehaviorContext<T> context, @Nonnull EntityType<E> type, @Nonnull Class<E> castTo) {
      ICondition<Targetable> matchesType = (target) -> target != null && target.getType() == TargetableType.ENTITY && target.getAsEntity().m_6095_() == type;
      Optional var10000 = firstMatching(context, matchesType).map(Targetable::getAsEntity);
      Objects.requireNonNull(castTo);
      var10000 = var10000.filter(castTo::isInstance);
      Objects.requireNonNull(castTo);
      return var10000.map(castTo::cast);
   }

   public static <T extends ISettlementsBrainEntity> Optional<PhysicalBlock> firstBlock(@Nonnull BehaviorContext<T> context) {
      return context.getState(BehaviorStateType.TARGET, TargetState.class).flatMap(TargetState::getFirst).filter((target) -> target.getType() == TargetableType.BLOCK).map(Targetable::getAsBlock);
   }

   public static <T extends ISettlementsBrainEntity> Optional<BlockPos> firstBlockPos(@Nonnull BehaviorContext<T> context) {
      return firstBlock(context).map((block) -> block.getLocation(false).toBlockPos());
   }

   public static <T extends ISettlementsBrainEntity> Optional<Location> firstTargetLocation(@Nonnull BehaviorContext<T> context) {
      return context.getState(BehaviorStateType.TARGET, TargetState.class).flatMap(TargetState::getFirst).map(Targetable::getLocation);
   }
}
