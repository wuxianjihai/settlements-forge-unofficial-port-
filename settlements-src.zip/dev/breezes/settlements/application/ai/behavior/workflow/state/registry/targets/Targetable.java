package dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets;

import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import javax.annotation.Nonnull;
import net.minecraft.world.entity.Entity;

public interface Targetable {
   TargetableType getType();

   static Targetable fromEntity(@Nonnull Entity entity) {
      return new TargetableEntity(entity);
   }

   static Targetable fromBlock(@Nonnull PhysicalBlock block) {
      return new TargetableBlock(block);
   }

   static Targetable fromLocation(@Nonnull Location location) {
      return new TargetableLocation(location);
   }

   Entity getAsEntity();

   PhysicalBlock getAsBlock();

   Location getLocation();
}
