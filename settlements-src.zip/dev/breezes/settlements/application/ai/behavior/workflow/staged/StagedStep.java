package dev.breezes.settlements.application.ai.behavior.workflow.staged;

import dev.breezes.settlements.application.ai.behavior.runtime.StopBehaviorException;
import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.AbstractStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.BehaviorStep;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StageKey;
import dev.breezes.settlements.application.ai.behavior.workflow.steps.StepResult;
import dev.breezes.settlements.domain.ai.brain.ISettlementsBrainEntity;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.crash.CrashUtil;
import dev.breezes.settlements.shared.util.crash.report.BehaviorConfigurationCrashReport;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public class StagedStep<T extends ISettlementsBrainEntity> extends AbstractStep<T> {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(StagedStep.class.getName());
   private final Map<StageKey, BehaviorStep<T>> stageStepMap;
   private final StageKey startingStage;
   private final StageKey initialActionStage;
   private final StageKey nextStage;
   @Nullable
   private final BehaviorStep<T> onStart;
   @Nullable
   private final BehaviorStep<T> onEnd;
   private StageKey currentStage;

   private StagedStep(@Nonnull String name, @Nonnull Map<StageKey, BehaviorStep<T>> stageStepMap, @Nonnull StageKey initialStage, @Nonnull StageKey nextStage, @Nullable BehaviorStep<T> onStart, @Nullable BehaviorStep<T> onEnd) {
      super("StagedStep[%s]".formatted(name));
      if (stageStepMap.isEmpty()) {
         crashInvalidConfiguration("Staged step must have at least one stage");
      }

      this.stageStepMap = new HashMap(stageStepMap);
      this.validate(this.stageStepMap, onStart, onEnd);
      this.initialActionStage = initialStage;
      this.nextStage = nextStage;
      this.startingStage = StagedStep.InternalStage.START;
      this.stageStepMap.put(this.startingStage, this::onStart);
      this.currentStage = this.startingStage;
      this.onStart = onStart;
      this.onEnd = onEnd;
   }

   protected StepResult onStart(@Nonnull BehaviorContext<T> context) {
      log.behaviorStatus("Starting {} ({})", this.getName(), this.getUuid());
      if (this.onStart != null) {
         StepResult result = this.onStart.tick(context);
         if (!(result instanceof StepResult.NoOp)) {
            return result;
         }
      }

      return StepResult.transition(this.initialActionStage);
   }

   protected StepResult doTick(@Nonnull BehaviorContext<T> context) {
      BehaviorStep<T> step = (BehaviorStep)this.stageStepMap.get(this.currentStage);
      if (step == null) {
         log.error("Missing step for stage: {} in {} ({})", this.currentStage.name(), this.getName(), this.getUuid());
         return StepResult.abort("MISSING_STEP", new IllegalStateException("Missing step for stage: " + this.currentStage.name()));
      } else {
         StepResult result = step.tick(context);
         if (result instanceof StepResult.NoOp) {
            return StepResult.noOp();
         } else if (result instanceof StepResult.Transition) {
            StepResult.Transition transition = (StepResult.Transition)result;
            StageKey key = transition.key();
            if (key.equals(this.nextStage)) {
               this.transitionStage(StagedStep.InternalStage.END);
               this.onEnd(context);
               return StepResult.transition(this.nextStage);
            } else {
               this.transitionStage(key);
               return StepResult.noOp();
            }
         } else if (result instanceof StepResult.Complete) {
            this.transitionStage(StagedStep.InternalStage.END);
            this.onEnd(context);
            return StepResult.transition(this.nextStage);
         } else if (result instanceof StepResult.Fail) {
            return result;
         } else {
            return result instanceof StepResult.Abort ? result : StepResult.noOp();
         }
      }
   }

   protected void onEnd(@Nonnull BehaviorContext<T> context) {
      log.behaviorStatus("Ending {} ({})", this.getName(), this.getUuid());
      if (this.onEnd != null) {
         this.onEnd.tick(context);
      }

   }

   protected void doOnEnter() {
      this.currentStage = this.startingStage;
   }

   protected void doReset() {
      if (this.onStart != null) {
         this.onStart.reset();
      }

      if (this.onEnd != null) {
         this.onEnd.reset();
      }

      for(BehaviorStep<T> step : this.stageStepMap.values()) {
         step.reset();
      }

   }

   private void validate(@Nonnull Map<StageKey, BehaviorStep<T>> stageStepMap, @Nullable BehaviorStep<T> onStart, @Nullable BehaviorStep<T> onEnd) {
      Map<BehaviorStep<T>, StageKey> seenByIdentity = new IdentityHashMap();

      for(Map.Entry<StageKey, BehaviorStep<T>> entry : stageStepMap.entrySet()) {
         StageKey stage = (StageKey)entry.getKey();
         BehaviorStep<T> step = (BehaviorStep)entry.getValue();
         if (step == null) {
            crashInvalidConfiguration("Stage '%s' has a null step".formatted(stage.name()));
         }

         StageKey previousStage = (StageKey)seenByIdentity.put(step, stage);
         if (previousStage != null) {
            crashInvalidConfiguration("Each stage must have a unique step instance. Duplicate instance used by stages '%s' and '%s'".formatted(previousStage.name(), stage.name()));
         }
      }

      if (onStart != null && seenByIdentity.containsKey(onStart)) {
         crashInvalidConfiguration("onStart step instance must be unique and not reused by stage '%s'".formatted(((StageKey)seenByIdentity.get(onStart)).name()));
      }

      if (onEnd != null && seenByIdentity.containsKey(onEnd)) {
         crashInvalidConfiguration("onEnd step instance must be unique and not reused by stage '%s'".formatted(((StageKey)seenByIdentity.get(onEnd)).name()));
      }

      if (onStart != null && onStart == onEnd) {
         crashInvalidConfiguration("onStart and onEnd must be different step instances");
      }

   }

   private static void crashInvalidConfiguration(@Nonnull String message) throws IllegalArgumentException {
      CrashUtil.crash(new BehaviorConfigurationCrashReport(new IllegalArgumentException(message)));
   }

   private void transitionStage(@Nonnull StageKey stage) {
      if (stage == StagedStep.InternalStage.END) {
         log.behaviorStatus("End requested for {} ({})", this.getName(), this.getUuid());
         this.currentStage = StagedStep.InternalStage.END;
      } else {
         BehaviorStep<T> nextStep = (BehaviorStep)this.stageStepMap.get(stage);
         if (nextStep == null) {
            log.warn("Attempted to transition to an unknown stage: {} for {} ({})", stage.name(), this.getName(), this.getUuid());
            throw new StopBehaviorException("Attempted to transition to an unknown stage: %s".formatted(stage.name()));
         } else {
            log.behaviorStatus("Transitioning from {} to {} stage for {} ({})", this.currentStage.name(), stage.name(), this.getName(), this.getUuid());
            this.currentStage = stage;
            nextStep.onEnter();
         }
      }
   }

   @Generated
   public static <T extends ISettlementsBrainEntity> StagedStepBuilder<T> builder() {
      return new StagedStepBuilder<T>();
   }

   @Generated
   public StageKey getCurrentStage() {
      return this.currentStage;
   }

   @Generated
   public static class StagedStepBuilder<T extends ISettlementsBrainEntity> {
      @Generated
      private String name;
      @Generated
      private Map<StageKey, BehaviorStep<T>> stageStepMap;
      @Generated
      private StageKey initialStage;
      @Generated
      private StageKey nextStage;
      @Generated
      private BehaviorStep<T> onStart;
      @Generated
      private BehaviorStep<T> onEnd;

      @Generated
      StagedStepBuilder() {
      }

      @Generated
      public StagedStepBuilder<T> name(@Nonnull String name) {
         if (name == null) {
            throw new NullPointerException("name is marked non-null but is null");
         } else {
            this.name = name;
            return this;
         }
      }

      @Generated
      public StagedStepBuilder<T> stageStepMap(@Nonnull Map<StageKey, BehaviorStep<T>> stageStepMap) {
         if (stageStepMap == null) {
            throw new NullPointerException("stageStepMap is marked non-null but is null");
         } else {
            this.stageStepMap = stageStepMap;
            return this;
         }
      }

      @Generated
      public StagedStepBuilder<T> initialStage(@Nonnull StageKey initialStage) {
         if (initialStage == null) {
            throw new NullPointerException("initialStage is marked non-null but is null");
         } else {
            this.initialStage = initialStage;
            return this;
         }
      }

      @Generated
      public StagedStepBuilder<T> nextStage(@Nonnull StageKey nextStage) {
         if (nextStage == null) {
            throw new NullPointerException("nextStage is marked non-null but is null");
         } else {
            this.nextStage = nextStage;
            return this;
         }
      }

      @Generated
      public StagedStepBuilder<T> onStart(@Nullable BehaviorStep<T> onStart) {
         this.onStart = onStart;
         return this;
      }

      @Generated
      public StagedStepBuilder<T> onEnd(@Nullable BehaviorStep<T> onEnd) {
         this.onEnd = onEnd;
         return this;
      }

      @Generated
      public StagedStep<T> build() {
         return new StagedStep<T>(this.name, this.stageStepMap, this.initialStage, this.nextStage, this.onStart, this.onEnd);
      }

      @Generated
      public String toString() {
         String var10000 = this.name;
         return "StagedStep.StagedStepBuilder(name=" + var10000 + ", stageStepMap=" + String.valueOf(this.stageStepMap) + ", initialStage=" + String.valueOf(this.initialStage) + ", nextStage=" + String.valueOf(this.nextStage) + ", onStart=" + String.valueOf(this.onStart) + ", onEnd=" + String.valueOf(this.onEnd) + ")";
      }
   }

   private static enum InternalStage implements StageKey {
      START,
      END;

      // $FF: synthetic method
      private static InternalStage[] $values() {
         return new InternalStage[]{START, END};
      }
   }
}
