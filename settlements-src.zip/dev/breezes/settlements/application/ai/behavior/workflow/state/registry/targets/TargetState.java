package dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorState;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import javax.annotation.Nonnull;

public class TargetState implements BehaviorState {
   private List<Targetable> targets;

   public TargetState(@Nonnull List<Targetable> targets) {
      this.targets = new ArrayList(targets);
   }

   public static TargetState of(@Nonnull List<Targetable> targets) {
      return new TargetState(targets);
   }

   public static TargetState of(@Nonnull Targetable target) {
      return new TargetState(List.of(target));
   }

   public boolean hasTarget() {
      return !this.targets.isEmpty();
   }

   public Optional<Targetable> getFirst() {
      return this.targets.stream().findFirst();
   }

   public void setTargets(@Nonnull List<Targetable> targets) {
      this.targets = new ArrayList(targets);
   }

   public void addTarget(@Nonnull Targetable target) {
      this.targets.add(target);
   }

   public Stream<Targetable> match(@Nonnull ICondition<Targetable> condition) {
      return this.targets.stream().filter(condition);
   }

   public void reset() {
      this.targets = new ArrayList();
   }
}
