package dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorState;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class BehaviorDeedLedger implements BehaviorState {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(BehaviorDeedLedger.class.getName());
   public static final int MAX_ENTRIES = 3;
   private final List<BehaviorOutcome> entries = new ArrayList(1);

   public Optional<BehaviorOutcome> primary() {
      return this.entries.isEmpty() ? Optional.empty() : Optional.of((BehaviorOutcome)this.entries.get(0));
   }

   public BehaviorOutcome declarePrimary(@Nonnull BehaviorOutcome primary) {
      if (this.entries.isEmpty()) {
         this.entries.add(primary);
      } else {
         this.entries.set(0, primary);
      }

      return primary;
   }

   public BehaviorOutcome addSecondary(@Nonnull BehaviorOutcome secondary) {
      if (this.entries.size() >= 3) {
         log.behaviorWarn("Behavior deed ledger reached cap of {}; dropping secondary deed {}", 3, secondary.getDeedType());
         return secondary;
      } else {
         this.entries.add(secondary);
         return secondary;
      }
   }

   public List<BehaviorOutcome> entriesView() {
      return List.copyOf(this.entries);
   }

   public void reset() {
      this.entries.clear();
   }
}
