package dev.breezes.settlements.application.ai.behavior.publication;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventEmitter;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class BehaviorOutcomePublisher_Factory implements Factory<BehaviorOutcomePublisher> {
   private final Provider<WorldEventEmitter> worldEventEmitterProvider;

   private BehaviorOutcomePublisher_Factory(Provider<WorldEventEmitter> worldEventEmitterProvider) {
      this.worldEventEmitterProvider = worldEventEmitterProvider;
   }

   public BehaviorOutcomePublisher get() {
      return newInstance((WorldEventEmitter)this.worldEventEmitterProvider.get());
   }

   public static BehaviorOutcomePublisher_Factory create(Provider<WorldEventEmitter> worldEventEmitterProvider) {
      return new BehaviorOutcomePublisher_Factory(worldEventEmitterProvider);
   }

   public static BehaviorOutcomePublisher newInstance(WorldEventEmitter worldEventEmitter) {
      return new BehaviorOutcomePublisher(worldEventEmitter);
   }
}
