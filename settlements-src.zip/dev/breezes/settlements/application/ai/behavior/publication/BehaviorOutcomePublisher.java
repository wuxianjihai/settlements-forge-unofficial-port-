package dev.breezes.settlements.application.ai.behavior.publication;

import dev.breezes.settlements.application.ai.behavior.runtime.BehaviorLifecycleResult;
import dev.breezes.settlements.application.ai.behavior.runtime.ProducesBehaviorOutcome;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorDeedLedger;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.outcomes.BehaviorOutcome;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.behavior.contracts.IBehavior;
import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.worldevent.EventOutcome;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventEmitter;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

@ServerScope
public final class BehaviorOutcomePublisher {
   private final WorldEventEmitter worldEventEmitter;

   public void publishCompleted(@Nonnull BaseVillager villager, @Nonnull BehaviorKey key, @Nonnull IBehavior<BaseVillager> behavior) {
      if (behavior instanceof ProducesBehaviorOutcome outcomeProducer) {
         BehaviorLifecycleResult lifecycleResult = outcomeProducer.getLastLifecycleResult();
         BehaviorDeedLedger ledger = (BehaviorDeedLedger)outcomeProducer.getLastDeeds().orElse((Object)null);
         if (ledger == null) {
            this.publishWithoutOutcome(villager, key, lifecycleResult);
         } else {
            BehaviorOutcome primary = (BehaviorOutcome)ledger.primary().orElse((Object)null);
            if (primary == null) {
               this.publishWithoutOutcome(villager, key, lifecycleResult);
            } else if (!primary.isSilent()) {
               if (!lifecycleResult.isClean() && !primary.hasExplicitEventOutcome()) {
                  this.worldEventEmitter.emitBehaviorFailed(villager, key, lifecycleResult.getReason());
               } else {
                  boolean emittedAny = false;

                  for(BehaviorOutcome outcome : ledger.entriesView()) {
                     if (!outcome.isSilent() && outcome.hasDeclaredDeed()) {
                        this.publishDeed(villager, key, outcome);
                        emittedAny = true;
                     }
                  }

                  if (!emittedAny) {
                     this.publishWithoutOutcome(villager, key, lifecycleResult);
                  }
               }
            }
         }
      } else {
         this.worldEventEmitter.emitBehaviorCompleted(villager, key);
      }
   }

   public void publishFailed(@Nonnull BaseVillager villager, @Nonnull BehaviorKey key, @Nullable String reason) {
      this.worldEventEmitter.emitBehaviorFailed(villager, key, reason);
   }

   private void publishWithoutOutcome(@Nonnull BaseVillager villager, @Nonnull BehaviorKey key, @Nonnull BehaviorLifecycleResult lifecycleResult) {
      if (lifecycleResult.isClean()) {
         this.worldEventEmitter.emitBehaviorCompleted(villager, key);
      } else {
         this.worldEventEmitter.emitBehaviorFailed(villager, key, lifecycleResult.getReason());
      }

   }

   private void publishDeed(@Nonnull BaseVillager villager, @Nonnull BehaviorKey key, @Nonnull BehaviorOutcome outcome) {
      WorldEventType deedType = outcome.getDeedType();
      if (deedType == null) {
         this.worldEventEmitter.emitBehaviorCompleted(villager, key);
      } else {
         EventOutcome eventOutcome = outcome.getEventOutcome();
         if (eventOutcome == null) {
            eventOutcome = outcome.isSuccess() ? EventOutcome.SUCCESS : null;
         }

         this.worldEventEmitter.emitTerminalBehaviorEvent(villager, key, deedType, outcome.getPartnerId(), outcome.getRegistryId(), eventOutcome, outcome.resolveDetail(), resolveReason(outcome), buildDetailFields(outcome));
      }
   }

   @Nullable
   private static String resolveReason(@Nonnull BehaviorOutcome outcome) {
      return outcome.getEventOutcome() == EventOutcome.FAILURE ? outcome.getFailureReason() : null;
   }

   @Nullable
   static Map<String, String> buildDetailFields(@Nonnull BehaviorOutcome outcome) {
      Map<String, String> fields = new HashMap();
      if (outcome.getUnitNoun() != null) {
         fields.put("item", outcome.getUnitNoun());
         fields.put("count", String.valueOf(outcome.getMagnitude()));
      }

      Map<String, String> explicit = outcome.getDetailFields();
      if (explicit != null) {
         fields.putAll(explicit);
      }

      return fields.isEmpty() ? null : Map.copyOf(fields);
   }

   @Inject
   @Generated
   BehaviorOutcomePublisher(WorldEventEmitter worldEventEmitter) {
      this.worldEventEmitter = worldEventEmitter;
   }
}
