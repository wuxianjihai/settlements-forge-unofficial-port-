package dev.breezes.settlements.application.ai.targeting;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class BlockMemoryTargetResolver_Factory implements Factory<BlockMemoryTargetResolver> {
   public BlockMemoryTargetResolver get() {
      return newInstance();
   }

   public static BlockMemoryTargetResolver_Factory create() {
      return BlockMemoryTargetResolver_Factory.InstanceHolder.INSTANCE;
   }

   public static BlockMemoryTargetResolver newInstance() {
      return new BlockMemoryTargetResolver();
   }

   private static final class InstanceHolder {
      static final BlockMemoryTargetResolver_Factory INSTANCE = new BlockMemoryTargetResolver_Factory();
   }
}
