package dev.breezes.settlements.application.ai.targeting;

import dev.breezes.settlements.application.ai.behavior.workflow.state.BehaviorContext;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.BehaviorStateType;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.blocks.VisitedBlockSitesState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.TargetState;
import dev.breezes.settlements.application.ai.behavior.workflow.state.registry.targets.Targetable;
import dev.breezes.settlements.domain.ai.memory.MemoryType;
import dev.breezes.settlements.domain.ai.navigation.INavigationManager;
import dev.breezes.settlements.domain.world.blocks.BlockMemorySiteConfirmer;
import dev.breezes.settlements.domain.world.blocks.BlockScanBox;
import dev.breezes.settlements.domain.world.blocks.LiveBlockSiteMatcher;
import dev.breezes.settlements.domain.world.blocks.PhysicalBlock;
import dev.breezes.settlements.domain.world.location.Location;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.world.level.Level;

public final class BlockMemoryTargetResolver {
   public boolean resolveBlockTarget(@Nonnull BehaviorContext<BaseVillager> context, @Nonnull MemoryType<List<GlobalPos>> memoryType, @Nonnull LiveBlockSiteMatcher matcher, @Nonnull BlockScanBox confirmBox, int maxSitesToConfirm, int completionRange) {
      BaseVillager villager = context.getInitiator();
      Level level = villager.m_9236_();
      Optional<List<GlobalPos>> memory = villager.getSettlementsBrain().getMemory(memoryType);
      if (!memory.isEmpty() && !((List)memory.get()).isEmpty()) {
         Set<GlobalPos> visitedSites = (Set)context.getState(BehaviorStateType.VISITED_BLOCK_SITES, VisitedBlockSitesState.class).map(VisitedBlockSitesState::getSites).orElse(Set.of());
         List<GlobalPos> candidates = ((List)memory.get()).stream().filter((site) -> !visitedSites.contains(site)).toList();
         BlockPos var10001 = villager.m_20183_();
         INavigationManager var10006 = villager.getNavigationManager();
         Objects.requireNonNull(var10006);
         Optional<GlobalPos> liveSite = BlockMemorySiteConfirmer.confirmNearest(candidates, var10001, level, matcher, confirmBox, maxSitesToConfirm, var10006::canReach, completionRange);
         if (liveSite.isEmpty()) {
            context.clearState(BehaviorStateType.TARGET);
            return false;
         } else {
            GlobalPos picked = (GlobalPos)liveSite.get();
            context.setState(BehaviorStateType.TARGET, TargetState.of(Targetable.fromBlock(PhysicalBlock.of(Location.of(picked.m_122646_(), level), level.m_8055_(picked.m_122646_())))));
            return true;
         }
      } else {
         context.clearState(BehaviorStateType.TARGET);
         return false;
      }
   }

   @Inject
   @Generated
   BlockMemoryTargetResolver() {
   }
}
