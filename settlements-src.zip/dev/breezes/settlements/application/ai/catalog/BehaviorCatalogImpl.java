package dev.breezes.settlements.application.ai.catalog;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.di.catalog.BehaviorCatalogEntry;
import dev.breezes.settlements.domain.ai.behavior.contracts.IBehavior;
import dev.breezes.settlements.domain.ai.catalog.BehaviorDisplayMetadata;
import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.catalog.BehaviorPlanningMetadata;
import dev.breezes.settlements.domain.ai.catalog.IBehaviorCatalog;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import lombok.Generated;

@ServerScope
public class BehaviorCatalogImpl implements IBehaviorCatalog {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(BehaviorCatalogImpl.class.getName());
   private static final int MAX_RUN_DURATION_SAFETY_FACTOR = 2;
   private final Map<BehaviorKey, BehaviorPlanningMetadata> descriptors;
   private final Map<BehaviorKey, BehaviorDisplayMetadata> displayInfos;
   private final Map<BehaviorKey, Supplier<IBehavior<BaseVillager>>> factories;

   @Inject
   BehaviorCatalogImpl(Set<BehaviorCatalogEntry> entries) {
      this.descriptors = (Map)entries.stream().collect(Collectors.toUnmodifiableMap((e) -> e.descriptor().getKey(), BehaviorCatalogEntry::descriptor));
      this.displayInfos = (Map)entries.stream().collect(Collectors.toUnmodifiableMap((e) -> e.descriptor().getKey(), BehaviorCatalogEntry::displayInfo));
      this.factories = (Map)entries.stream().collect(Collectors.toUnmodifiableMap((e) -> e.descriptor().getKey(), BehaviorCatalogEntry::factory));
      this.descriptors.values().forEach(BehaviorCatalogImpl::validateRunDurationCeiling);
   }

   private static void validateRunDurationCeiling(@Nonnull BehaviorPlanningMetadata descriptor) {
      int estimatedAsWallClockTicks = descriptor.getEstimatedDuration().asClockTicks().getTicksAsInt();
      int maxRunDurationTicks = descriptor.getMaxRunDuration().getTicksAsInt();
      int minimumPlausibleTicks = estimatedAsWallClockTicks * 2;
      if (maxRunDurationTicks < minimumPlausibleTicks) {
         log.warn("Behavior '{}' has maxRunDuration ({} ticks) shorter than {}x its wall-clock-converted estimatedDuration ({} ticks) — it may be force-stopped mid-run on a typical execution", descriptor.getKey().id(), maxRunDurationTicks, 2, estimatedAsWallClockTicks);
      }

   }

   public Optional<BehaviorPlanningMetadata> getDescriptor(BehaviorKey key) {
      return Optional.ofNullable((BehaviorPlanningMetadata)this.descriptors.get(key));
   }

   public Optional<BehaviorDisplayMetadata> getDisplayInfo(BehaviorKey key) {
      return Optional.ofNullable((BehaviorDisplayMetadata)this.displayInfos.get(key));
   }

   public Optional<IBehavior<BaseVillager>> createBehavior(BehaviorKey key) {
      Supplier<IBehavior<BaseVillager>> factory = (Supplier)this.factories.get(key);
      return factory == null ? Optional.empty() : Optional.of((IBehavior)factory.get());
   }

   public boolean exists(BehaviorKey key) {
      return this.descriptors.containsKey(key);
   }

   public List<BehaviorPlanningMetadata> getAllDescriptors() {
      return List.copyOf(this.descriptors.values());
   }
}
