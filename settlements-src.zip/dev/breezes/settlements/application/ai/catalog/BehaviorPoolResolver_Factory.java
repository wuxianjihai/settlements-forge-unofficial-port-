package dev.breezes.settlements.application.ai.catalog;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.domain.ai.catalog.IBehaviorCatalog;
import dev.breezes.settlements.domain.ai.catalog.ProfessionBehaviorPool;
import java.util.Set;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class BehaviorPoolResolver_Factory implements Factory<BehaviorPoolResolver> {
   private final Provider<IBehaviorCatalog> catalogProvider;
   private final Provider<Set<ProfessionBehaviorPool>> poolsProvider;

   private BehaviorPoolResolver_Factory(Provider<IBehaviorCatalog> catalogProvider, Provider<Set<ProfessionBehaviorPool>> poolsProvider) {
      this.catalogProvider = catalogProvider;
      this.poolsProvider = poolsProvider;
   }

   public BehaviorPoolResolver get() {
      return newInstance((IBehaviorCatalog)this.catalogProvider.get(), (Set)this.poolsProvider.get());
   }

   public static BehaviorPoolResolver_Factory create(Provider<IBehaviorCatalog> catalogProvider, Provider<Set<ProfessionBehaviorPool>> poolsProvider) {
      return new BehaviorPoolResolver_Factory(catalogProvider, poolsProvider);
   }

   public static BehaviorPoolResolver newInstance(IBehaviorCatalog catalog, Set<ProfessionBehaviorPool> pools) {
      return new BehaviorPoolResolver(catalog, pools);
   }
}
