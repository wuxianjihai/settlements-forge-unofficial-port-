package dev.breezes.settlements.application.ai.catalog;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.di.catalog.BehaviorCatalogEntry;
import java.util.Set;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class BehaviorCatalogImpl_Factory implements Factory<BehaviorCatalogImpl> {
   private final Provider<Set<BehaviorCatalogEntry>> entriesProvider;

   private BehaviorCatalogImpl_Factory(Provider<Set<BehaviorCatalogEntry>> entriesProvider) {
      this.entriesProvider = entriesProvider;
   }

   public BehaviorCatalogImpl get() {
      return newInstance((Set)this.entriesProvider.get());
   }

   public static BehaviorCatalogImpl_Factory create(Provider<Set<BehaviorCatalogEntry>> entriesProvider) {
      return new BehaviorCatalogImpl_Factory(entriesProvider);
   }

   public static BehaviorCatalogImpl newInstance(Set<BehaviorCatalogEntry> entries) {
      return new BehaviorCatalogImpl(entries);
   }
}
