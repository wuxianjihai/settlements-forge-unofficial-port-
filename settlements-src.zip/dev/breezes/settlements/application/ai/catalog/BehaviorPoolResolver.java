package dev.breezes.settlements.application.ai.catalog;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.catalog.IBehaviorCatalog;
import dev.breezes.settlements.domain.ai.catalog.PoolEntry;
import dev.breezes.settlements.domain.ai.catalog.ProfessionBehaviorPool;
import dev.breezes.settlements.domain.ai.catalog.WeightedBehavior;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@ServerScope
public class BehaviorPoolResolver {
   private static final List<PoolEntry> UNIVERSAL_ENTRIES;
   private final IBehaviorCatalog catalog;
   private final Map<VillagerProfessionKey, ProfessionBehaviorPool> pools;

   @Inject
   public BehaviorPoolResolver(IBehaviorCatalog catalog, Set<ProfessionBehaviorPool> pools) {
      this.catalog = catalog;
      this.pools = (Map)pools.stream().collect(Collectors.toUnmodifiableMap(ProfessionBehaviorPool::getProfession, Function.identity()));
   }

   public List<WeightedBehavior> resolve(VillagerProfessionKey profession) {
      Map<BehaviorKey, Integer> weightsByKey = new LinkedHashMap();

      for(PoolEntry entry : this.getProfessionEntries(profession)) {
         weightsByKey.put(entry.key(), entry.weight());
      }

      for(PoolEntry entry : UNIVERSAL_ENTRIES) {
         weightsByKey.putIfAbsent(entry.key(), entry.weight());
      }

      List<WeightedBehavior> resolved = new ArrayList();

      for(Map.Entry<BehaviorKey, Integer> entry : weightsByKey.entrySet()) {
         Optional var10000 = this.catalog.getDescriptor((BehaviorKey)entry.getKey()).map((descriptor) -> new WeightedBehavior(descriptor, (Integer)entry.getValue()));
         Objects.requireNonNull(resolved);
         var10000.ifPresent(resolved::add);
      }

      return List.copyOf(resolved);
   }

   private List<PoolEntry> getProfessionEntries(VillagerProfessionKey profession) {
      ProfessionBehaviorPool pool = (ProfessionBehaviorPool)this.pools.get(profession);
      return pool == null ? List.of() : pool.getEntries();
   }

   static {
      UNIVERSAL_ENTRIES = List.of(PoolEntry.of(BehaviorKey.EAT_FOOD), PoolEntry.of(BehaviorKey.TRADE_INITIATE), PoolEntry.of(BehaviorKey.COURTSHIP_INITIATE), PoolEntry.of(BehaviorKey.DONATE_EMERALDS), PoolEntry.of(BehaviorKey.MANAGE_CHESTS), PoolEntry.of(BehaviorKey.CRAFT_GOODS), PoolEntry.of(BehaviorKey.PET_ANIMAL), PoolEntry.of(BehaviorKey.PLAY_SWING));
   }
}
