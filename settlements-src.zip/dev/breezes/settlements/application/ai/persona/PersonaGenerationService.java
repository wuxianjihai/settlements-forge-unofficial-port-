package dev.breezes.settlements.application.ai.persona;

import dev.breezes.settlements.application.ai.inference.InferenceConfig;
import dev.breezes.settlements.application.ai.inference.InferenceStreamHandle;
import dev.breezes.settlements.application.ai.inference.persona.PersonaBatchRequest;
import dev.breezes.settlements.application.ai.inference.persona.PersonaGateway;
import dev.breezes.settlements.application.ai.inference.persona.PersonaRequestAssembler;
import dev.breezes.settlements.application.ai.inference.persona.PersonaVillagerResult;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.personality.PersonalityStatus;
import dev.breezes.settlements.domain.personality.VillagerPersonality;
import dev.breezes.settlements.infrastructure.minecraft.attachments.VillagerPersonalityAttachment;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;

@ServerScope
public final class PersonaGenerationService {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(PersonaGenerationService.class.getName());
   private final PersonaRequestAssembler assembler;
   private final PersonaGateway gateway;
   private final PersonaConfig config;
   private final InferenceConfig inferenceConfig;
   private final Set<UUID> inFlight = ConcurrentHashMap.newKeySet();
   private final ConcurrentLinkedQueue<PersonaVillagerResult> arrivals = new ConcurrentLinkedQueue();
   private final AtomicBoolean batchInFlight = new AtomicBoolean(false);
   private final AtomicReference<InferenceStreamHandle> currentHandle = new AtomicReference(InferenceStreamHandle.noOp());
   private final AtomicInteger currentBackoffTicks = new AtomicInteger(0);
   private final AtomicInteger cooldownRemainingTicks = new AtomicInteger(0);

   @Inject
   public PersonaGenerationService(@Nonnull PersonaRequestAssembler assembler, @Nonnull PersonaGateway gateway, @Nonnull PersonaConfig config, @Nonnull InferenceConfig inferenceConfig) {
      this.assembler = assembler;
      this.gateway = gateway;
      this.config = config;
      this.inferenceConfig = inferenceConfig;
   }

   public void sweep(@Nonnull Supplier<? extends Collection<BaseVillager>> villagerSupplier) {
      if (this.inferenceConfig.hasEndpoint() && !this.batchInFlight.get() && !this.isInBackoffCooldown()) {
         Collection<BaseVillager> villagers = (Collection)villagerSupplier.get();
         List<BaseVillager> due = new ArrayList();

         for(BaseVillager villager : villagers) {
            if (due.size() >= this.config.maxBatchSize()) {
               break;
            }

            if (!this.inFlight.contains(villager.m_20148_()) && VillagerPersonalityAttachment.read(villager).status() == PersonalityStatus.PENDING) {
               due.add(villager);
            }
         }

         if (!due.isEmpty()) {
            this.dispatchBatch(due);
         }
      }
   }

   private void dispatchBatch(@Nonnull List<BaseVillager> due) {
      PersonaBatchRequest.PersonaBatchRequestBuilder batchBuilder = PersonaBatchRequest.builder();
      List<UUID> batchIds = new ArrayList(due.size());

      for(BaseVillager villager : due) {
         batchBuilder.villager(this.assembler.assemble(villager));
         batchIds.add(villager.m_20148_());
      }

      PersonaBatchRequest batch = batchBuilder.build();
      this.inFlight.addAll(batchIds);
      this.batchInFlight.set(true);
      Duration deadline = Duration.ofSeconds((long)this.config.batchDeadlineSeconds());
      AtomicInteger resultCount = new AtomicInteger(0);
      InferenceStreamHandle handle = this.gateway.generate(batch, deadline, (result) -> {
         resultCount.incrementAndGet();
         this.arrivals.offer(result);
      });
      this.currentHandle.set(handle);
      log.debug("Persona batch dispatched: {} villager(s)", batchIds.size());
      handle.completion().thenRun(() -> this.onBatchCompleted(batchIds, resultCount.get()));
   }

   private void onBatchCompleted(@Nonnull List<UUID> batchIds, int resultCount) {
      Set var10001 = this.inFlight;
      Objects.requireNonNull(var10001);
      batchIds.forEach(var10001::remove);
      this.batchInFlight.set(false);
      if (resultCount > 0) {
         this.currentBackoffTicks.set(0);
         this.cooldownRemainingTicks.set(0);
      } else {
         int previous = this.currentBackoffTicks.get();
         int next = previous <= 0 ? this.config.backoffFloorTicks() : Math.min(previous * 2, this.config.backoffCeilingTicks());
         this.currentBackoffTicks.set(next);
         this.cooldownRemainingTicks.set(next);
         log.warn("Persona batch returned zero results for {} villager(s); backing off {} ticks", batchIds.size(), next);
      }
   }

   private boolean isInBackoffCooldown() {
      int remaining = this.cooldownRemainingTicks.get();
      if (remaining <= 0) {
         return false;
      } else {
         int updated = Math.max(0, remaining - this.config.sweepIntervalTicks());
         this.cooldownRemainingTicks.set(updated);
         return updated > 0;
      }
   }

   public void drain(@Nonnull MinecraftServer server) {
      PersonaVillagerResult result;
      while((result = (PersonaVillagerResult)this.arrivals.poll()) != null) {
         this.install(server, result);
      }

   }

   private void install(@Nonnull MinecraftServer server, @Nonnull PersonaVillagerResult result) {
      BaseVillager villager = resolveVillager(server, result.getVillagerId());
      if (villager != null) {
         if (VillagerPersonalityAttachment.read(villager).status() == PersonalityStatus.PENDING) {
            VillagerPersonality ready = VillagerPersonality.ready(result.getAdjectives(), result.getCharacterSketch(), result.getSpeechStyle());
            VillagerPersonalityAttachment.write(villager, ready);
         }
      }
   }

   @Nullable
   private static BaseVillager resolveVillager(@Nonnull MinecraftServer server, @Nonnull UUID villagerId) {
      for(ServerLevel level : server.m_129785_()) {
         Entity entity = level.m_8791_(villagerId);
         if (entity instanceof BaseVillager villager) {
            if (villager.m_6084_() && !villager.m_213877_()) {
               return villager;
            }
         }
      }

      return null;
   }

   public void shutdown() {
      ((InferenceStreamHandle)this.currentHandle.getAndSet(InferenceStreamHandle.noOp())).cancel();
      this.arrivals.clear();
      this.inFlight.clear();
      this.batchInFlight.set(false);
   }
}
