package dev.breezes.settlements.application.ai.persona;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.inference.InferenceConfig;
import dev.breezes.settlements.application.ai.inference.persona.PersonaGateway;
import dev.breezes.settlements.application.ai.inference.persona.PersonaRequestAssembler;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class PersonaGenerationService_Factory implements Factory<PersonaGenerationService> {
   private final Provider<PersonaRequestAssembler> assemblerProvider;
   private final Provider<PersonaGateway> gatewayProvider;
   private final Provider<PersonaConfig> configProvider;
   private final Provider<InferenceConfig> inferenceConfigProvider;

   private PersonaGenerationService_Factory(Provider<PersonaRequestAssembler> assemblerProvider, Provider<PersonaGateway> gatewayProvider, Provider<PersonaConfig> configProvider, Provider<InferenceConfig> inferenceConfigProvider) {
      this.assemblerProvider = assemblerProvider;
      this.gatewayProvider = gatewayProvider;
      this.configProvider = configProvider;
      this.inferenceConfigProvider = inferenceConfigProvider;
   }

   public PersonaGenerationService get() {
      return newInstance((PersonaRequestAssembler)this.assemblerProvider.get(), (PersonaGateway)this.gatewayProvider.get(), (PersonaConfig)this.configProvider.get(), (InferenceConfig)this.inferenceConfigProvider.get());
   }

   public static PersonaGenerationService_Factory create(Provider<PersonaRequestAssembler> assemblerProvider, Provider<PersonaGateway> gatewayProvider, Provider<PersonaConfig> configProvider, Provider<InferenceConfig> inferenceConfigProvider) {
      return new PersonaGenerationService_Factory(assemblerProvider, gatewayProvider, configProvider, inferenceConfigProvider);
   }

   public static PersonaGenerationService newInstance(PersonaRequestAssembler assembler, PersonaGateway gateway, PersonaConfig config, InferenceConfig inferenceConfig) {
      return new PersonaGenerationService(assembler, gateway, config, inferenceConfig);
   }
}
