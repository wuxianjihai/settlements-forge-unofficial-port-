package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.override.OverrideTier;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.Optional;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.schedule.Activity;

@ServerScope
public final class RetrieveProjectilesOverridePolicy implements OverridePolicy {
   private static final Set<Activity> IDLE_WINDOW_ACTIVITIES;

   public OverrideTier tier() {
      return OverrideTier.OPPORTUNISTIC;
   }

   public boolean isAdmissibleDuring(@Nullable Activity activity) {
      return activity != null && IDLE_WINDOW_ACTIVITIES.contains(activity);
   }

   public Optional<OverrideRequest> evaluate(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      if (!VillagerProfessionKey.FLETCHER.equals(villager.getProfession())) {
         return Optional.empty();
      } else if (villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.RETRIEVABLE_PROJECTILES).isEmpty()) {
         return Optional.empty();
      } else {
         return villager.getPlanRuntimeState().getCurrentDescriptor() != null ? Optional.empty() : Optional.of(new OverrideRequest.CatalogBehavior(BehaviorKey.RETRIEVE_PROJECTILES));
      }
   }

   @Inject
   RetrieveProjectilesOverridePolicy() {
   }

   static {
      IDLE_WINDOW_ACTIVITIES = Set.of(Activity.f_37980_, Activity.f_37983_, Activity.f_37979_);
   }
}
