package dev.breezes.settlements.application.ai.override;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.courtship.CourtshipSessionRegistry;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class CourtshipAcceptOverridePolicy_Factory implements Factory<CourtshipAcceptOverridePolicy> {
   private final Provider<CourtshipSessionRegistry> courtshipSessionRegistryProvider;

   private CourtshipAcceptOverridePolicy_Factory(Provider<CourtshipSessionRegistry> courtshipSessionRegistryProvider) {
      this.courtshipSessionRegistryProvider = courtshipSessionRegistryProvider;
   }

   public CourtshipAcceptOverridePolicy get() {
      return newInstance((CourtshipSessionRegistry)this.courtshipSessionRegistryProvider.get());
   }

   public static CourtshipAcceptOverridePolicy_Factory create(Provider<CourtshipSessionRegistry> courtshipSessionRegistryProvider) {
      return new CourtshipAcceptOverridePolicy_Factory(courtshipSessionRegistryProvider);
   }

   public static CourtshipAcceptOverridePolicy newInstance(CourtshipSessionRegistry courtshipSessionRegistry) {
      return new CourtshipAcceptOverridePolicy(courtshipSessionRegistry);
   }
}
