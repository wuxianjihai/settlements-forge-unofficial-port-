package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.override.OverrideTier;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.Optional;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.schedule.Activity;

@ServerScope
public final class CollectDemandedItemOverridePolicy implements OverridePolicy {
   private static final Set<Activity> IDLE_WINDOW_ACTIVITIES;

   public OverrideTier tier() {
      return OverrideTier.OPPORTUNISTIC;
   }

   public boolean isAdmissibleDuring(@Nullable Activity activity) {
      return activity != null && IDLE_WINDOW_ACTIVITIES.contains(activity);
   }

   public Optional<OverrideRequest> evaluate(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      boolean itemNearby = (Boolean)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.DEMANDED_GROUND_ITEM_NEARBY).orElse(false);
      if (!itemNearby) {
         return Optional.empty();
      } else {
         return villager.hasActiveExecution() ? Optional.empty() : Optional.of(new OverrideRequest.CatalogBehavior(BehaviorKey.COLLECT_DEMANDED_ITEM));
      }
   }

   @Inject
   @Generated
   CollectDemandedItemOverridePolicy() {
   }

   static {
      IDLE_WINDOW_ACTIVITIES = Set.of(Activity.f_37980_, Activity.f_37983_, Activity.f_37979_);
   }
}
