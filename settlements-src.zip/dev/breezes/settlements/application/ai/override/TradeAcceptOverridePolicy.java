package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.application.ai.trading.TradeSessionRegistry;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.override.OverrideTier;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.schedule.Activity;

@ServerScope
public final class TradeAcceptOverridePolicy implements OverridePolicy {
   private final TradeSessionRegistry tradeSessionRegistry;

   public OverrideTier tier() {
      return OverrideTier.REACTIVE;
   }

   public boolean isAdmissibleDuring(@Nullable Activity activity) {
      return true;
   }

   public Optional<OverrideRequest> evaluate(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      return !this.tradeSessionRegistry.hasInviteFor(villager.m_20148_()) ? Optional.empty() : Optional.of(new OverrideRequest.CatalogBehavior(BehaviorKey.TRADE_ACCEPT));
   }

   @Inject
   @Generated
   TradeAcceptOverridePolicy(TradeSessionRegistry tradeSessionRegistry) {
      this.tradeSessionRegistry = tradeSessionRegistry;
   }
}
