package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.domain.ai.catalog.BehaviorChannel;
import dev.breezes.settlements.domain.ai.catalog.BehaviorDisplayMetadata;
import dev.breezes.settlements.domain.ai.override.OverrideTier;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.Optional;
import java.util.Set;
import javax.annotation.Nonnull;
import net.minecraft.server.level.ServerLevel;

public interface OverrideRunner {
   void start(@Nonnull ServerLevel var1, @Nonnull BaseVillager var2);

   void tick(@Nonnull ServerLevel var1, @Nonnull BaseVillager var2);

   void stop(@Nonnull ServerLevel var1, @Nonnull BaseVillager var2);

   boolean isComplete();

   OverrideTier tier();

   Set<BehaviorChannel> occupiedChannels();

   Optional<BehaviorDisplayMetadata> displayInfo();

   String diagnosticId();
}
