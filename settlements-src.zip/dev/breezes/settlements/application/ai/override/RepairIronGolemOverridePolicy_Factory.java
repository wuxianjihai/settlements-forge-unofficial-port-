package dev.breezes.settlements.application.ai.override;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.behavior.usecases.villager.support.RepairIronGolemConfig;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class RepairIronGolemOverridePolicy_Factory implements Factory<RepairIronGolemOverridePolicy> {
   private final Provider<RepairIronGolemConfig> configProvider;

   private RepairIronGolemOverridePolicy_Factory(Provider<RepairIronGolemConfig> configProvider) {
      this.configProvider = configProvider;
   }

   public RepairIronGolemOverridePolicy get() {
      return newInstance((RepairIronGolemConfig)this.configProvider.get());
   }

   public static RepairIronGolemOverridePolicy_Factory create(Provider<RepairIronGolemConfig> configProvider) {
      return new RepairIronGolemOverridePolicy_Factory(configProvider);
   }

   public static RepairIronGolemOverridePolicy newInstance(RepairIronGolemConfig config) {
      return new RepairIronGolemOverridePolicy(config);
   }
}
