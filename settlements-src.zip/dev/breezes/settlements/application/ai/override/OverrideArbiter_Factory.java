package dev.breezes.settlements.application.ai.override;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.domain.ai.catalog.IBehaviorCatalog;
import java.util.List;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class OverrideArbiter_Factory implements Factory<OverrideArbiter> {
   private final Provider<List<OverridePolicy>> policiesProvider;
   private final Provider<IBehaviorCatalog> catalogProvider;
   private final Provider<DayPlanHandoff> dayPlanHandoffProvider;

   private OverrideArbiter_Factory(Provider<List<OverridePolicy>> policiesProvider, Provider<IBehaviorCatalog> catalogProvider, Provider<DayPlanHandoff> dayPlanHandoffProvider) {
      this.policiesProvider = policiesProvider;
      this.catalogProvider = catalogProvider;
      this.dayPlanHandoffProvider = dayPlanHandoffProvider;
   }

   public OverrideArbiter get() {
      return newInstance((List)this.policiesProvider.get(), (IBehaviorCatalog)this.catalogProvider.get(), (DayPlanHandoff)this.dayPlanHandoffProvider.get());
   }

   public static OverrideArbiter_Factory create(Provider<List<OverridePolicy>> policiesProvider, Provider<IBehaviorCatalog> catalogProvider, Provider<DayPlanHandoff> dayPlanHandoffProvider) {
      return new OverrideArbiter_Factory(policiesProvider, catalogProvider, dayPlanHandoffProvider);
   }

   public static OverrideArbiter newInstance(List<OverridePolicy> policies, IBehaviorCatalog catalog, DayPlanHandoff dayPlanHandoff) {
      return new OverrideArbiter(policies, catalog, dayPlanHandoff);
   }
}
