package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;

public sealed interface OverrideRequest {
   public static record CatalogBehavior(BehaviorKey behaviorKey) implements OverrideRequest {
   }

   public static record PreparedRunner(OverrideRunner runner) implements OverrideRequest {
   }
}
