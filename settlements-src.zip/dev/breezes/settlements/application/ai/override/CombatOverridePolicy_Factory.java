package dev.breezes.settlements.application.ai.override;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class CombatOverridePolicy_Factory implements Factory<CombatOverridePolicy> {
   public CombatOverridePolicy get() {
      return newInstance();
   }

   public static CombatOverridePolicy_Factory create() {
      return CombatOverridePolicy_Factory.InstanceHolder.INSTANCE;
   }

   public static CombatOverridePolicy newInstance() {
      return new CombatOverridePolicy();
   }

   private static final class InstanceHolder {
      static final CombatOverridePolicy_Factory INSTANCE = new CombatOverridePolicy_Factory();
   }
}
