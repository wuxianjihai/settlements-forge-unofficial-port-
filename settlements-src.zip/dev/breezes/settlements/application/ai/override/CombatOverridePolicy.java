package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.bootstrap.registry.activities.ActivityRegistry;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.override.OverrideTier;
import dev.breezes.settlements.domain.ai.threat.ThreatVerdict;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.schedule.Activity;

@ServerScope
public final class CombatOverridePolicy implements OverridePolicy {
   public OverrideTier tier() {
      return OverrideTier.EMERGENCY;
   }

   public boolean isAdmissibleDuring(@Nullable Activity activity) {
      return activity == ActivityRegistry.COMBAT;
   }

   public Optional<OverrideRequest> evaluate(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      return villager.getSettlementsBrain().threats().verdict() != ThreatVerdict.COMBAT ? Optional.empty() : Optional.of(new OverrideRequest.PreparedRunner(new CombatOverrideRunner(this.tier())));
   }

   @Inject
   CombatOverridePolicy() {
   }
}
