package dev.breezes.settlements.application.ai.override;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class RetrieveProjectilesOverridePolicy_Factory implements Factory<RetrieveProjectilesOverridePolicy> {
   public RetrieveProjectilesOverridePolicy get() {
      return newInstance();
   }

   public static RetrieveProjectilesOverridePolicy_Factory create() {
      return RetrieveProjectilesOverridePolicy_Factory.InstanceHolder.INSTANCE;
   }

   public static RetrieveProjectilesOverridePolicy newInstance() {
      return new RetrieveProjectilesOverridePolicy();
   }

   private static final class InstanceHolder {
      static final RetrieveProjectilesOverridePolicy_Factory INSTANCE = new RetrieveProjectilesOverridePolicy_Factory();
   }
}
