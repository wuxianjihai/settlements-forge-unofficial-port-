package dev.breezes.settlements.application.ai.override;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.trading.TradeSessionRegistry;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class TradeAcceptOverridePolicy_Factory implements Factory<TradeAcceptOverridePolicy> {
   private final Provider<TradeSessionRegistry> tradeSessionRegistryProvider;

   private TradeAcceptOverridePolicy_Factory(Provider<TradeSessionRegistry> tradeSessionRegistryProvider) {
      this.tradeSessionRegistryProvider = tradeSessionRegistryProvider;
   }

   public TradeAcceptOverridePolicy get() {
      return newInstance((TradeSessionRegistry)this.tradeSessionRegistryProvider.get());
   }

   public static TradeAcceptOverridePolicy_Factory create(Provider<TradeSessionRegistry> tradeSessionRegistryProvider) {
      return new TradeAcceptOverridePolicy_Factory(tradeSessionRegistryProvider);
   }

   public static TradeAcceptOverridePolicy newInstance(TradeSessionRegistry tradeSessionRegistry) {
      return new TradeAcceptOverridePolicy(tradeSessionRegistry);
   }
}
