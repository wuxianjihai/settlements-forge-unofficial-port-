package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.domain.ai.behavior.contracts.IBehavior;
import dev.breezes.settlements.domain.ai.behavior.model.BehaviorStatus;
import dev.breezes.settlements.domain.ai.catalog.BehaviorChannel;
import dev.breezes.settlements.domain.ai.catalog.BehaviorDisplayMetadata;
import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.catalog.BehaviorPlanningMetadata;
import dev.breezes.settlements.domain.ai.catalog.IBehaviorCatalog;
import dev.breezes.settlements.domain.ai.override.OverrideTier;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.server.level.ServerLevel;

final class SimpleBehaviorOverrideRunner implements OverrideRunner {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(SimpleBehaviorOverrideRunner.class.getName());
   private static final ClockTicks FALLBACK_MAX_DURATION = ClockTicks.seconds((double)120.0F);
   private final BehaviorKey behaviorKey;
   private final IBehavior<BaseVillager> behavior;
   private final OverrideTier tier;
   private final Set<BehaviorChannel> occupiedChannels;
   private final int maxDurationTicks;
   @Nullable
   private final BehaviorDisplayMetadata displayInfo;
   private int elapsedTicks;
   private boolean wedged;

   SimpleBehaviorOverrideRunner(@Nonnull BehaviorKey behaviorKey, @Nonnull IBehavior<BaseVillager> behavior, @Nonnull OverrideTier tier, @Nonnull IBehaviorCatalog catalog) {
      this.behaviorKey = behaviorKey;
      this.behavior = behavior;
      this.tier = tier;
      BehaviorPlanningMetadata descriptor = (BehaviorPlanningMetadata)catalog.getDescriptor(behaviorKey).orElse((Object)null);
      this.maxDurationTicks = descriptor != null ? descriptor.getMaxRunDuration().getTicksAsInt() : FALLBACK_MAX_DURATION.getTicksAsInt();
      this.occupiedChannels = descriptor != null ? descriptor.getRequiredChannels() : Collections.emptySet();
      this.displayInfo = (BehaviorDisplayMetadata)catalog.getDisplayInfo(behaviorKey).orElse((Object)null);
   }

   public void start(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      this.behavior.start(level, villager);
   }

   public void tick(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      ++this.elapsedTicks;
      if (this.elapsedTicks > this.maxDurationTicks) {
         log.warn("Override '{}' exceeded max duration ({} ticks) for villager {}; force-stopping wedged override", this.behaviorKey, this.maxDurationTicks, villager.m_20148_());
         this.wedged = true;
      } else {
         try {
            this.behavior.tick(1, level, villager);
         } catch (RuntimeException e) {
            log.error(e, "Override '{}' threw during tick for villager {}; force-stopping wedged override", this.behaviorKey, villager.m_20148_());
            this.wedged = true;
         }
      }

   }

   public void stop(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      if (this.behavior.getStatus() != BehaviorStatus.STOPPED) {
         this.behavior.stop(level, villager);
      }

   }

   public boolean isComplete() {
      return this.wedged || this.behavior.getStatus() == BehaviorStatus.STOPPED;
   }

   public OverrideTier tier() {
      return this.tier;
   }

   public Set<BehaviorChannel> occupiedChannels() {
      return this.occupiedChannels;
   }

   public Optional<BehaviorDisplayMetadata> displayInfo() {
      return Optional.ofNullable(this.displayInfo);
   }

   public String diagnosticId() {
      return this.behaviorKey.toString();
   }
}
