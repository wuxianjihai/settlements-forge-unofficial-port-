package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.application.ai.behavior.usecases.villager.cartographer.RaidCharting;
import dev.breezes.settlements.bootstrap.registry.activities.ActivityRegistry;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.override.OverrideTier;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.raid.Raid;
import net.minecraft.world.entity.schedule.Activity;

@ServerScope
public final class ChartRaidersOverridePolicy implements OverridePolicy {
   public OverrideTier tier() {
      return OverrideTier.DUTY;
   }

   public boolean isAdmissibleDuring(@Nullable Activity activity) {
      return activity == ActivityRegistry.RAID_HIDE;
   }

   public Optional<OverrideRequest> evaluate(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      if (!VillagerProfessionKey.CARTOGRAPHER.equals(villager.getProfession())) {
         return Optional.empty();
      } else if (villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.CHART_RAIDERS_COOLDOWN).isPresent()) {
         return Optional.empty();
      } else {
         Optional<Raid> raid = RaidCharting.raidInWave(level, villager);
         if (raid.isEmpty()) {
            return Optional.empty();
         } else {
            boolean anyChartable = ((Raid)raid.get()).m_150221_().stream().anyMatch((raider) -> RaidCharting.isChartable(raider, level));
            return !anyChartable ? Optional.empty() : Optional.of(new OverrideRequest.CatalogBehavior(BehaviorKey.CHART_RAIDERS));
         }
      }
   }

   @Inject
   ChartRaidersOverridePolicy() {
   }
}
