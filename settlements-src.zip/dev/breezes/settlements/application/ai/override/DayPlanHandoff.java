package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import javax.annotation.Nonnull;
import net.minecraft.server.level.ServerLevel;

public interface DayPlanHandoff {
   boolean suspendIfActive(@Nonnull ServerLevel var1, @Nonnull BaseVillager var2);

   void reAttemptInterruptedSlot(@Nonnull BaseVillager var1);
}
