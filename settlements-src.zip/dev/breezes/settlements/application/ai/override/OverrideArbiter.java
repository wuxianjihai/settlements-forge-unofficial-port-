package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.application.ai.brain.ActivityArbiter;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.behavior.contracts.IBehavior;
import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.catalog.BehaviorPlanningMetadata;
import dev.breezes.settlements.domain.ai.catalog.IBehaviorCatalog;
import dev.breezes.settlements.domain.ai.override.OverrideArbitrationRules;
import dev.breezes.settlements.domain.ai.override.OverrideTier;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.annotations.stylistic.VisibleForTesting;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.function.Predicate;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.schedule.Activity;
import org.apache.commons.lang3.Validate;

@ServerScope
public final class OverrideArbiter {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(OverrideArbiter.class.getName());
   private final List<OverridePolicy> orderedPolicies;
   private final IBehaviorCatalog catalog;
   private final DayPlanHandoff dayPlanHandoff;

   @Inject
   OverrideArbiter(@Nonnull List<OverridePolicy> policies, @Nonnull IBehaviorCatalog catalog, @Nonnull DayPlanHandoff dayPlanHandoff) {
      List<OverrideTier> rankedTiers = policies.stream().map(OverridePolicy::tier).toList();
      OptionalInt outOfOrder = OverrideArbitrationRules.firstOutOfTierOrder(rankedTiers);
      Validate.isTrue(outOfOrder.isEmpty(), "Override policy at index %d is ranked behind a lower tier; ranked tiers: %s", new Object[]{outOfOrder.orElse(-1), rankedTiers});
      this.orderedPolicies = List.copyOf(policies);
      this.catalog = catalog;
      this.dayPlanHandoff = dayPlanHandoff;
   }

   public boolean tick(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      OverrideRuntimeState runtime = villager.getOverrideRuntimeState();
      if (runtime.hasRunner()) {
         this.tickRunning(level, villager, runtime);
         return true;
      } else {
         return this.tryStart(level, villager, runtime);
      }
   }

   public void forceStop(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      OverrideRuntimeState runtime = villager.getOverrideRuntimeState();
      OverrideRunner runner = runtime.getRunner();
      if (runner != null) {
         stopRunner(level, villager, runner);
      }

      runtime.clearRunner();
   }

   private void tickRunning(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull OverrideRuntimeState runtime) {
      if (runtime.getEvaluationCooldown().tickCheckAndReset((double)1.0F)) {
         Activity activity = currentActivity(villager);
         if (!isAdmissible(runtime.getOwningPolicy(), activity, isReactive(activity))) {
            this.stopAndRequeue(level, villager, runtime);
            return;
         }

         if (this.tryPreempt(level, villager, runtime)) {
            return;
         }
      }

      this.advanceRunner(level, villager, runtime);
   }

   private boolean tryPreempt(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull OverrideRuntimeState runtime) {
      OverrideTier runningTier = runtime.getRunner().tier();
      Activity activity = currentActivity(villager);
      boolean activityReactive = isReactive(activity);
      Optional<Installed> candidate = this.prepareFirstRequestedOverride(level, villager, (policy) -> policy.tier().isAbove(runningTier) && isAdmissible(policy, activity, activityReactive));
      if (candidate.isEmpty()) {
         return false;
      } else {
         OverrideRunner outgoing = runtime.getRunner();
         stopRunner(level, villager, outgoing);
         runtime.clearRunner();
         Installed installed = (Installed)candidate.get();
         if (!this.tryStartAndInstall(level, villager, runtime, installed)) {
            log.debug("Override '{}' stopped for villager {} to make way for '{}'; re-queuing interrupted plan slot", outgoing.diagnosticId(), villager.m_20148_(), installed.runner().diagnosticId());
            this.dayPlanHandoff.reAttemptInterruptedSlot(villager);
            return true;
         } else {
            log.debug("Override '{}' preempted '{}' for villager {}", installed.runner().diagnosticId(), outgoing.diagnosticId(), villager.m_20148_());
            return true;
         }
      }
   }

   private void advanceRunner(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull OverrideRuntimeState runtime) {
      OverrideRunner runner = runtime.getRunner();
      runner.tick(level, villager);
      if (runner.isComplete()) {
         this.stopAndRequeue(level, villager, runtime);
      }

   }

   private void stopAndRequeue(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull OverrideRuntimeState runtime) {
      OverrideRunner runner = runtime.getRunner();
      String diagnosticId = runner.diagnosticId();
      stopRunner(level, villager, runner);
      runtime.clearRunner();
      this.dayPlanHandoff.reAttemptInterruptedSlot(villager);
      log.debug("Override '{}' stopped for villager {}; re-queuing interrupted plan slot", diagnosticId, villager.m_20148_());
   }

   private boolean tryStart(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull OverrideRuntimeState runtime) {
      if (!runtime.getEvaluationCooldown().tickCheckAndReset((double)1.0F)) {
         return false;
      } else {
         boolean planInterruptible = isPlanInterruptible(villager.getPlanRuntimeState().getCurrentDescriptor());
         Activity activity = currentActivity(villager);
         boolean activityReactive = isReactive(activity);
         Optional<Installed> candidate = this.prepareFirstRequestedOverride(level, villager, (policy) -> OverrideArbitrationRules.isAdmittedDespiteProtectedPlan(policy.tier(), planInterruptible) && isAdmissible(policy, activity, activityReactive));
         if (candidate.isEmpty()) {
            return false;
         } else {
            this.dayPlanHandoff.suspendIfActive(level, villager);
            this.dayPlanHandoff.reAttemptInterruptedSlot(villager);
            Installed installed = (Installed)candidate.get();
            if (!this.tryStartAndInstall(level, villager, runtime, installed)) {
               return false;
            } else {
               log.debug("Override '{}' installed for villager {}", installed.runner().diagnosticId(), villager.m_20148_());
               return true;
            }
         }
      }
   }

   private boolean tryStartAndInstall(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull OverrideRuntimeState runtime, @Nonnull Installed installed) {
      try {
         installed.runner().start(level, villager);
      } catch (RuntimeException e) {
         log.error(e, "Override '{}' threw during start for villager {}; skipping override", installed.runner().diagnosticId(), villager.m_20148_());
         return false;
      }

      runtime.installRunner(installed.runner(), installed.policy());
      return true;
   }

   private static void stopRunner(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull OverrideRunner runner) {
      try {
         runner.stop(level, villager);
      } catch (RuntimeException e) {
         log.error(e, "Override '{}' threw during stop for villager {}; discarding it", runner.diagnosticId(), villager.m_20148_());
      }

   }

   private Optional<Installed> prepareFirstRequestedOverride(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull Predicate<OverridePolicy> eligible) {
      for(OverridePolicy policy : this.orderedPolicies) {
         if (eligible.test(policy)) {
            Optional<OverrideRequest> request = policy.evaluate(level, villager);
            if (!request.isEmpty()) {
               OverrideRequest req = (OverrideRequest)request.get();
               if (req instanceof OverrideRequest.PreparedRunner) {
                  OverrideRequest.PreparedRunner prepared = (OverrideRequest.PreparedRunner)req;
                  return Optional.of(new Installed(prepared.runner(), policy));
               }

               if (req instanceof OverrideRequest.CatalogBehavior) {
                  OverrideRequest.CatalogBehavior catalogBehavior = (OverrideRequest.CatalogBehavior)req;
                  BehaviorKey key = catalogBehavior.behaviorKey();
                  OverrideTier tier = policy.tier();
                  return this.validate(level, villager, key).map((behavior) -> new Installed(new SimpleBehaviorOverrideRunner(key, behavior, tier, this.catalog), policy));
               }
            }
         }
      }

      return Optional.empty();
   }

   private Optional<IBehavior<BaseVillager>> validate(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull BehaviorKey key) {
      IBehavior<BaseVillager> behavior = (IBehavior)this.catalog.createBehavior(key).orElse((Object)null);
      if (behavior == null) {
         log.error("Override behavior '{}' not found in catalog for villager {}", key, villager.m_20148_());
         return Optional.empty();
      } else {
         behavior.getBehaviorCoolDown().forceComplete();
         behavior.getPreconditionCheckCooldown().forceComplete();
         if (!behavior.tickPreconditions(1, level, villager)) {
            log.debug("Override preconditions not met for '{}' on villager {}", key, villager.m_20148_());
            return Optional.empty();
         } else {
            return Optional.of(behavior);
         }
      }
   }

   @Nullable
   private static Activity currentActivity(@Nonnull BaseVillager villager) {
      return (Activity)villager.m_6274_().m_21968_().orElse((Object)null);
   }

   private static boolean isReactive(@Nullable Activity activity) {
      return activity != null && ActivityArbiter.isReactive(activity);
   }

   @VisibleForTesting
   static boolean isAdmissible(@Nonnull OverridePolicy policy, @Nullable Activity activity, boolean activityReactive) {
      return OverrideArbitrationRules.isAdmittedDuringActivity(policy.tier(), activityReactive) && policy.isAdmissibleDuring(activity);
   }

   @VisibleForTesting
   static boolean isPlanInterruptible(@Nullable BehaviorPlanningMetadata descriptor) {
      return descriptor == null || descriptor.isInterruptible();
   }

   private static record Installed(OverrideRunner runner, OverridePolicy policy) {
   }
}
