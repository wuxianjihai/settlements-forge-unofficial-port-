package dev.breezes.settlements.application.ai.override;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class ChartRaidersOverridePolicy_Factory implements Factory<ChartRaidersOverridePolicy> {
   public ChartRaidersOverridePolicy get() {
      return newInstance();
   }

   public static ChartRaidersOverridePolicy_Factory create() {
      return ChartRaidersOverridePolicy_Factory.InstanceHolder.INSTANCE;
   }

   public static ChartRaidersOverridePolicy newInstance() {
      return new ChartRaidersOverridePolicy();
   }

   private static final class InstanceHolder {
      static final ChartRaidersOverridePolicy_Factory INSTANCE = new ChartRaidersOverridePolicy_Factory();
   }
}
