package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.application.ai.behavior.usecases.villager.support.RepairIronGolemBehavior;
import dev.breezes.settlements.application.ai.behavior.usecases.villager.support.RepairIronGolemConfig;
import dev.breezes.settlements.application.ai.brain.ActivityArbiter;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.override.OverrideTier;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.Optional;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.schedule.Activity;

@ServerScope
public final class RepairIronGolemOverridePolicy implements OverridePolicy {
   private static final Set<VillagerProfessionKey> SMITHS;
   private final RepairIronGolemConfig config;

   public OverrideTier tier() {
      return OverrideTier.DUTY;
   }

   public boolean isAdmissibleDuring(@Nullable Activity activity) {
      return activity == Activity.f_37986_;
   }

   public Optional<OverrideRequest> evaluate(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      if (!SMITHS.contains(villager.getProfession())) {
         return Optional.empty();
      } else if (villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.REPAIR_IRON_GOLEM_RETRY_COOLDOWN).isPresent()) {
         return Optional.empty();
      } else if (!ActivityArbiter.isRaidAwaitingWave(level.m_8832_(villager.m_20183_()))) {
         return Optional.empty();
      } else {
         boolean anyGolemNeedsRepair = ((PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_SENSED_ENTITIES).orElse(PerceivedEntities.empty())).ofType(IronGolem.class, (golem) -> RepairIronGolemBehavior.needsRepair(golem, this.config)).findAny().isPresent();
         return !anyGolemNeedsRepair ? Optional.empty() : Optional.of(new OverrideRequest.CatalogBehavior(BehaviorKey.REPAIR_IRON_GOLEM));
      }
   }

   @Inject
   RepairIronGolemOverridePolicy(RepairIronGolemConfig config) {
      this.config = config;
   }

   static {
      SMITHS = Set.of(VillagerProfessionKey.ARMORER, VillagerProfessionKey.TOOLSMITH, VillagerProfessionKey.WEAPONSMITH);
   }
}
