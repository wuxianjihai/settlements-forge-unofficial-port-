package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.application.ai.behavior.usecases.villager.librarian.VexBinding;
import dev.breezes.settlements.application.ai.brain.ActivityArbiter;
import dev.breezes.settlements.bootstrap.registry.activities.ActivityRegistry;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.catalog.BehaviorKey;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.override.OverrideTier;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.schedule.Activity;

@ServerScope
public final class BindVexesOverridePolicy implements OverridePolicy {
   public OverrideTier tier() {
      return OverrideTier.DUTY;
   }

   public boolean isAdmissibleDuring(@Nullable Activity activity) {
      return activity == ActivityRegistry.RAID_HIDE;
   }

   public Optional<OverrideRequest> evaluate(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      if (!VillagerProfessionKey.LIBRARIAN.equals(villager.getProfession())) {
         return Optional.empty();
      } else if (villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.BIND_VEXES_COOLDOWN).isPresent()) {
         return Optional.empty();
      } else if (!ActivityArbiter.isRaidWaveLive(level.m_8832_(villager.m_20183_()))) {
         return Optional.empty();
      } else {
         boolean anyBindable = ((PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_HOSTILES).orElse(PerceivedEntities.empty())).ofType(LivingEntity.class, (hostile) -> VexBinding.isBindable(hostile, level)).findAny().isPresent();
         return !anyBindable ? Optional.empty() : Optional.of(new OverrideRequest.CatalogBehavior(BehaviorKey.BIND_VEXES));
      }
   }

   @Inject
   BindVexesOverridePolicy() {
   }
}
