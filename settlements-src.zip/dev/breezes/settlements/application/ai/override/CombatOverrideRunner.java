package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.application.ai.threat.CombatOption;
import dev.breezes.settlements.application.ai.threat.CombatSelection;
import dev.breezes.settlements.application.ai.threat.IThreatResponse;
import dev.breezes.settlements.domain.ai.behavior.contracts.IBehavior;
import dev.breezes.settlements.domain.ai.behavior.model.BehaviorStatus;
import dev.breezes.settlements.domain.ai.catalog.BehaviorChannel;
import dev.breezes.settlements.domain.ai.catalog.BehaviorDisplayMetadata;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.override.OverrideTier;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.perception.SensedEntity;
import dev.breezes.settlements.domain.ai.threat.ThreatVerdict;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.behavior.EntityTracker;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.npc.Villager;

final class CombatOverrideRunner implements OverrideRunner {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(CombatOverrideRunner.class.getName());
   private static final ClockTicks ACTION_MAX_DURATION = ClockTicks.seconds((double)60.0F);
   private static final Set<BehaviorChannel> OCCUPIED_CHANNELS;
   private static final BehaviorDisplayMetadata FIGHTING_DISPLAY_INFO;
   private final OverrideTier tier;
   @Nullable
   private IBehavior<BaseVillager> action;
   @Nullable
   private CombatOption actionOption;
   @Nullable
   private UUID actionTargetId;
   private int actionElapsedTicks;
   @Nullable
   private LivingEntity facedHostile;
   private boolean ended;

   CombatOverrideRunner(@Nonnull OverrideTier tier) {
      this.tier = tier;
   }

   public void start(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
   }

   public void tick(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      if (!this.ended) {
         IThreatResponse threats = villager.getSettlementsBrain().threats();
         CombatSelection selection = threats.selection();
         if (selection == null) {
            if (threats.verdict() == ThreatVerdict.COMBAT) {
               this.lookAtNearestAwareHostile(villager);
            } else {
               this.ended = true;
            }

         } else {
            if (this.action != null) {
               if (!this.shouldReplaceAction(villager, selection)) {
                  this.tickAction(level, villager);
                  return;
               }

               this.stopAction(level, villager);
            }

            LivingEntity target = resolveTarget(level, villager, selection);
            if (target == null) {
               this.lookAtNearestAwareHostile(villager);
            } else {
               this.launchAction(level, villager, selection.option(), target);
            }

         }
      }
   }

   public void stop(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      if (this.action != null) {
         this.stopAction(level, villager);
      }

      if (this.facedHostile != null) {
         villager.m_6274_().m_21936_(MemoryModuleType.f_26371_);
         this.facedHostile = null;
      }

   }

   public boolean isComplete() {
      return this.ended;
   }

   public OverrideTier tier() {
      return this.tier;
   }

   public Set<BehaviorChannel> occupiedChannels() {
      return OCCUPIED_CHANNELS;
   }

   public Optional<BehaviorDisplayMetadata> displayInfo() {
      return Optional.of(this.actionOption != null ? this.actionOption.displayInfo() : FIGHTING_DISPLAY_INFO);
   }

   public String diagnosticId() {
      return "combat";
   }

   private boolean shouldReplaceAction(@Nonnull BaseVillager villager, @Nonnull CombatSelection selection) {
      if (this.action.getStatus() == BehaviorStatus.STOPPED) {
         return true;
      } else if (selection.option() == this.actionOption && (selection.targetId() == null || selection.targetId().equals(this.actionTargetId))) {
         if (this.actionElapsedTicks >= ACTION_MAX_DURATION.getTicksAsInt()) {
            log.warn("Combat action exceeded max duration ({} ticks) for villager {}; replacing it", ACTION_MAX_DURATION.getTicksAsInt(), villager.m_20148_());
            return true;
         } else {
            return false;
         }
      } else {
         return true;
      }
   }

   private void tickAction(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      ++this.actionElapsedTicks;

      try {
         this.action.tick(1, level, villager);
      } catch (Exception e) {
         log.error(e, "Combat action threw during tick for villager {}; ending combat execution", villager.m_20148_());
         this.ended = true;
      }

   }

   private void launchAction(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull CombatOption option, @Nonnull LivingEntity target) {
      IBehavior<BaseVillager> next;
      try {
         next = option.createBehavior(target);
         next.getBehaviorCoolDown().forceComplete();
         next.getPreconditionCheckCooldown().forceComplete();
         if (!next.tickPreconditions(1, level, villager)) {
            villager.getSettlementsBrain().threats().revokeSelection();
            return;
         }

         next.start(level, villager);
      } catch (Exception e) {
         log.error(e, "Combat action threw during start for villager {}; ending combat execution", villager.m_20148_());
         this.ended = true;
         return;
      }

      this.facedHostile = null;
      this.action = next;
      this.actionOption = option;
      this.actionTargetId = target.m_20148_();
      this.actionElapsedTicks = 0;
   }

   private void stopAction(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      if (this.action.getStatus() != BehaviorStatus.STOPPED) {
         this.action.stop(level, villager);
      }

      this.action = null;
      this.actionOption = null;
      this.actionTargetId = null;
   }

   @Nullable
   private static LivingEntity resolveTarget(@Nonnull ServerLevel level, @Nonnull BaseVillager villager, @Nonnull CombatSelection selection) {
      UUID targetId = selection.targetId();
      if (targetId == null) {
         return null;
      } else {
         Entity var5 = level.m_8791_(targetId);
         if (var5 instanceof LivingEntity) {
            LivingEntity target = (LivingEntity)var5;
            if (target.m_6084_()) {
               double reach = selection.option().reachBlocks();
               return villager.m_20280_(target) <= reach * reach ? target : null;
            }
         }

         return null;
      }
   }

   private void lookAtNearestAwareHostile(@Nonnull BaseVillager villager) {
      PerceivedEntities hostiles = (PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_HOSTILES).orElse(PerceivedEntities.empty());

      for(SensedEntity sensed : hostiles.entities()) {
         LivingEntity hostile = sensed.entity();
         if (hostile.m_6084_()) {
            Brain<Villager> brain = villager.m_6274_();
            if (hostile != this.facedHostile || !brain.m_21874_(MemoryModuleType.f_26371_)) {
               brain.m_21879_(MemoryModuleType.f_26371_, new EntityTracker(hostile, true));
               this.facedHostile = hostile;
            }

            return;
         }
      }

   }

   static {
      OCCUPIED_CHANNELS = Set.of(BehaviorChannel.MOVEMENT, BehaviorChannel.INTERACTION);
      FIGHTING_DISPLAY_INFO = BehaviorDisplayMetadata.builder().displayNameKey("ui.settlements.behavior.combat.fighting").iconItemId(new ResourceLocation("minecraft", "iron_sword")).build();
   }
}
