package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.ITickable;
import dev.breezes.settlements.domain.time.Tickable;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public final class OverrideRuntimeState {
   private static final ClockTicks EVALUATION_INTERVAL = ClockTicks.of(5L);
   @Nullable
   private OverrideRunner runner;
   @Nullable
   private OverridePolicy owningPolicy;
   private final ITickable evaluationCooldown;

   public OverrideRuntimeState() {
      this.evaluationCooldown = Tickable.staggered(EVALUATION_INTERVAL);
   }

   public boolean hasRunner() {
      return this.runner != null;
   }

   public void installRunner(@Nonnull OverrideRunner runner, @Nonnull OverridePolicy owningPolicy) {
      this.runner = runner;
      this.owningPolicy = owningPolicy;
   }

   public void clearRunner() {
      this.runner = null;
      this.owningPolicy = null;
   }

   @Nullable
   public OverrideRunner getRunner() {
      return this.runner;
   }

   @Nullable
   public OverridePolicy getOwningPolicy() {
      return this.owningPolicy;
   }

   public ITickable getEvaluationCooldown() {
      return this.evaluationCooldown;
   }
}
