package dev.breezes.settlements.application.ai.override;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class BindVexesOverridePolicy_Factory implements Factory<BindVexesOverridePolicy> {
   public BindVexesOverridePolicy get() {
      return newInstance();
   }

   public static BindVexesOverridePolicy_Factory create() {
      return BindVexesOverridePolicy_Factory.InstanceHolder.INSTANCE;
   }

   public static BindVexesOverridePolicy newInstance() {
      return new BindVexesOverridePolicy();
   }

   private static final class InstanceHolder {
      static final BindVexesOverridePolicy_Factory INSTANCE = new BindVexesOverridePolicy_Factory();
   }
}
