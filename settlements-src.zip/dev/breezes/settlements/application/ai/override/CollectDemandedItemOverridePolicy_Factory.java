package dev.breezes.settlements.application.ai.override;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class CollectDemandedItemOverridePolicy_Factory implements Factory<CollectDemandedItemOverridePolicy> {
   public CollectDemandedItemOverridePolicy get() {
      return newInstance();
   }

   public static CollectDemandedItemOverridePolicy_Factory create() {
      return CollectDemandedItemOverridePolicy_Factory.InstanceHolder.INSTANCE;
   }

   public static CollectDemandedItemOverridePolicy newInstance() {
      return new CollectDemandedItemOverridePolicy();
   }

   private static final class InstanceHolder {
      static final CollectDemandedItemOverridePolicy_Factory INSTANCE = new CollectDemandedItemOverridePolicy_Factory();
   }
}
