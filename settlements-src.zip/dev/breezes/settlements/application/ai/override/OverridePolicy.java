package dev.breezes.settlements.application.ai.override;

import dev.breezes.settlements.domain.ai.override.OverrideTier;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.schedule.Activity;

public interface OverridePolicy {
   OverrideTier tier();

   boolean isAdmissibleDuring(@Nullable Activity var1);

   Optional<OverrideRequest> evaluate(@Nonnull ServerLevel var1, @Nonnull BaseVillager var2);
}
