package dev.breezes.settlements.application.ai.perception;

import dev.breezes.settlements.application.ai.memory.MemoryImportanceGate;
import dev.breezes.settlements.application.ai.socialcue.SocialCueRuntimeState;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.knowledge.KnowledgeEntry;
import dev.breezes.settlements.domain.ai.knowledge.VillagerKnowledgeStore;
import dev.breezes.settlements.domain.ai.memory.PackedPos;
import dev.breezes.settlements.domain.ai.observation.Observation;
import dev.breezes.settlements.domain.ai.observation.ObservationBuffer;
import dev.breezes.settlements.domain.ai.observation.ObservationType;
import dev.breezes.settlements.domain.ai.perception.ObservationFactory;
import dev.breezes.settlements.domain.ai.perception.PerceptionGate;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventBus;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.domain.genetics.GeneticsProfile;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Map;
import lombok.Generated;
import net.minecraft.core.SectionPos;

@ServerScope
public final class PerceptionPipeline {
   private static final ObservationType[] OBSERVATION_TYPES = ObservationType.values();
   private final WorldEventBus worldEventBus;
   private final MemoryImportanceGate importanceGate;

   public void tick(BaseVillager villager, SocialCueRuntimeState runtimeState, long gameTime) {
      long lastSeenSeq = runtimeState.getLastSeenSeq();
      int villagerChunkX = SectionPos.m_123171_((int)Math.floor(villager.m_20185_()));
      int villagerChunkZ = SectionPos.m_123171_((int)Math.floor(villager.m_20189_()));
      ObservationBuffer buffer = runtimeState.getObservationBuffer();
      long newSeq = this.worldEventBus.visitDelta(lastSeenSeq, (event) -> {
         if (PerceptionGate.admits(event, villagerChunkX, villagerChunkZ)) {
            buffer.add(ObservationFactory.fromEvent(event, gameTime));
         }
      });
      if (newSeq != lastSeenSeq) {
         runtimeState.advanceCursor(newSeq);
         if (!buffer.isEmpty()) {
            VillagerProfessionKey professionKey = villager.getProfession();
            GeneticsProfile genetics = villager.getGenetics();
            List<Observation> observations = buffer.drain();
            int[] observationTypeFrequencies = countObservationTypes(observations);
            VillagerKnowledgeStore knowledgeStore = villager.getKnowledgeStore();

            for(Observation observation : observations) {
               int similarPeerCount = observationTypeFrequencies[observation.type().ordinal()] - 1;
               boolean isSelfDeed = villager.m_20148_().equals(observation.actorId());
               float score = this.importanceGate.score(observation, professionKey, genetics, similarPeerCount, isSelfDeed);
               boolean forceAdmit = observation.eventType().isSelfRememberableTerminalEvent() && (isSelfDeed || observation.eventType().isSelfWitnessed());
               if (forceAdmit || this.importanceGate.shouldPromote(score)) {
                  Map<String, String> metadata = ObservationFactory.metadataFor(observation);
                  long packedPos = PackedPos.asLong((int)Math.floor(observation.posX()), (int)Math.floor(observation.posY()), (int)Math.floor(observation.posZ()));
                  KnowledgeEntry entry = KnowledgeEntry.fromDirectObservation(observation.id(), observation.type(), observation.timestampTick(), observation.timestampTick(), observation.relatedEntity(), metadata, score, packedPos);
                  knowledgeStore.admit(entry);
               }
            }

         }
      }
   }

   private static int[] countObservationTypes(List<Observation> observations) {
      int[] frequencies = new int[OBSERVATION_TYPES.length];

      for(Observation observation : observations) {
         ++frequencies[observation.type().ordinal()];
      }

      return frequencies;
   }

   @Inject
   @Generated
   PerceptionPipeline(WorldEventBus worldEventBus, MemoryImportanceGate importanceGate) {
      this.worldEventBus = worldEventBus;
      this.importanceGate = importanceGate;
   }
}
