package dev.breezes.settlements.application.ai.perception;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.memory.MemoryImportanceGate;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventBus;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class PerceptionPipeline_Factory implements Factory<PerceptionPipeline> {
   private final Provider<WorldEventBus> worldEventBusProvider;
   private final Provider<MemoryImportanceGate> importanceGateProvider;

   private PerceptionPipeline_Factory(Provider<WorldEventBus> worldEventBusProvider, Provider<MemoryImportanceGate> importanceGateProvider) {
      this.worldEventBusProvider = worldEventBusProvider;
      this.importanceGateProvider = importanceGateProvider;
   }

   public PerceptionPipeline get() {
      return newInstance((WorldEventBus)this.worldEventBusProvider.get(), (MemoryImportanceGate)this.importanceGateProvider.get());
   }

   public static PerceptionPipeline_Factory create(Provider<WorldEventBus> worldEventBusProvider, Provider<MemoryImportanceGate> importanceGateProvider) {
      return new PerceptionPipeline_Factory(worldEventBusProvider, importanceGateProvider);
   }

   public static PerceptionPipeline newInstance(WorldEventBus worldEventBus, MemoryImportanceGate importanceGate) {
      return new PerceptionPipeline(worldEventBus, importanceGate);
   }
}
