package dev.breezes.settlements.application.ai.threat;

import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.threat.QualifyingHit;
import dev.breezes.settlements.domain.ai.threat.ThreatDecision;
import dev.breezes.settlements.domain.ai.threat.ThreatVerdict;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.domain.time.Tickable;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public final class ThreatAssessmentState implements IThreatResponse {
   static final ClockTicks ASSESSMENT_INTERVAL = ClockTicks.of(5L);
   @Nullable
   private QualifyingHit latestHit;
   private boolean assessmentDirty;
   @Nullable
   private ThreatAssessmentResult latestResult;
   private boolean selectionRevoked;
   private long lastEngagedGameTime;
   @Nullable
   private UUID lockedTargetId;
   private long lastAlarmedGameTime;
   private PerceivedEntities lastAssessedHostiles = PerceivedEntities.empty();
   private final Tickable cadence;

   public ThreatAssessmentState() {
      this.cadence = Tickable.staggered(ASSESSMENT_INTERVAL);
   }

   public Optional<QualifyingHit> recordHit(@Nullable UUID attackerId, float healthLost, long gameTime) {
      if (attackerId != null && !(healthLost <= 0.0F)) {
         QualifyingHit hit = new QualifyingHit(healthLost, gameTime, attackerId);
         this.latestHit = hit;
         this.assessmentDirty = true;
         return Optional.of(hit);
      } else {
         return Optional.empty();
      }
   }

   @Nullable
   public ThreatVerdict verdict() {
      return this.latestResult == null ? null : this.latestResult.verdict();
   }

   @Nullable
   public CombatSelection selection() {
      return this.latestResult != null && !this.selectionRevoked ? this.latestResult.selection() : null;
   }

   public void revokeSelection() {
      this.selectionRevoked = true;
      this.assessmentDirty = true;
   }

   boolean isDue(@Nonnull PerceivedEntities currentHostiles) {
      boolean cadenceElapsed = this.cadence.tickCheckAndReset((double)1.0F);
      boolean due = cadenceElapsed || this.assessmentDirty || !Objects.equals(currentHostiles, this.lastAssessedHostiles);
      if (due && !cadenceElapsed) {
         this.cadence.reset();
      }

      return due;
   }

   void recordAssessment(@Nonnull ThreatDecision decision, @Nonnull ThreatAssessmentResult result, @Nonnull PerceivedEntities assessedHostiles, long gameTime) {
      this.latestResult = result;
      this.selectionRevoked = false;
      this.lastAssessedHostiles = assessedHostiles;
      this.assessmentDirty = false;
      CombatSelection selection = result.selection();
      if (selection != null && selection.targetId() != null) {
         this.lastEngagedGameTime = gameTime;
         this.lockedTargetId = selection.targetId();
      } else if (result.verdict() != ThreatVerdict.COMBAT) {
         this.lockedTargetId = null;
      }

      if (decision == ThreatDecision.PANIC) {
         this.lastAlarmedGameTime = gameTime;
      }

   }

   @Nullable
   QualifyingHit getLatestHit() {
      return this.latestHit;
   }

   boolean isAssessmentDirty() {
      return this.assessmentDirty;
   }

   @Nullable
   ThreatAssessmentResult getLatestResult() {
      return this.latestResult;
   }

   long getLastEngagedGameTime() {
      return this.lastEngagedGameTime;
   }

   @Nullable
   UUID getLockedTargetId() {
      return this.lockedTargetId;
   }

   long getLastAlarmedGameTime() {
      return this.lastAlarmedGameTime;
   }
}
