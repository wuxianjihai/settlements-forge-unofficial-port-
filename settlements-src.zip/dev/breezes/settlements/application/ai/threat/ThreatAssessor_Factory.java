package dev.breezes.settlements.application.ai.threat;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.List;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class ThreatAssessor_Factory implements Factory<ThreatAssessor> {
   private final Provider<List<CombatOption>> combatOptionsProvider;

   private ThreatAssessor_Factory(Provider<List<CombatOption>> combatOptionsProvider) {
      this.combatOptionsProvider = combatOptionsProvider;
   }

   public ThreatAssessor get() {
      return newInstance((List)this.combatOptionsProvider.get());
   }

   public static ThreatAssessor_Factory create(Provider<List<CombatOption>> combatOptionsProvider) {
      return new ThreatAssessor_Factory(combatOptionsProvider);
   }

   public static ThreatAssessor newInstance(List<CombatOption> combatOptions) {
      return new ThreatAssessor(combatOptions);
   }
}
