package dev.breezes.settlements.application.ai.threat;

import dev.breezes.settlements.domain.ai.threat.ThreatVerdict;
import javax.annotation.Nullable;
import org.apache.commons.lang3.Validate;

public record ThreatAssessmentResult(ThreatVerdict verdict, @Nullable CombatSelection selection) {
   public ThreatAssessmentResult {
      Validate.isTrue(verdict == ThreatVerdict.COMBAT == (selection != null), "selection must be present exactly when verdict is COMBAT, but verdict is %s and selection is %s", new Object[]{verdict, selection});
   }
}
