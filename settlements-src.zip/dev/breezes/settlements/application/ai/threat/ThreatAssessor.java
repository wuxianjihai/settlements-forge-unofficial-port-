package dev.breezes.settlements.application.ai.threat;

import dev.breezes.settlements.bootstrap.registry.datamaps.SettlementsDataMaps;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.perception.PerceivedEntities;
import dev.breezes.settlements.domain.ai.perception.SensedEntity;
import dev.breezes.settlements.domain.ai.threat.QualifyingHit;
import dev.breezes.settlements.domain.ai.threat.ThreatDecision;
import dev.breezes.settlements.domain.ai.threat.ThreatResponseRules;
import dev.breezes.settlements.domain.ai.threat.ThreatSituation;
import dev.breezes.settlements.domain.ai.threat.ThreatVerdict;
import dev.breezes.settlements.domain.genetics.GeneType;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.util.List;
import java.util.StringJoiner;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.ZombieVillager;
import net.minecraft.world.level.Level;

@ServerScope
public final class ThreatAssessor {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(ThreatAssessor.class.getName());
   private static final ThreatAssessmentResult PANIC_RESULT;
   private static final ThreatAssessmentResult HOLD_RESULT;
   private static final double UNSEEN_THREAT_FRACTION = 0.2;
   private static final double CLOSE_QUARTERS_BLOCKS = (double)5.0F;
   private final List<CombatOption> combatOptions;

   public void tick(@Nonnull BaseVillager villager, @Nonnull ThreatAssessmentState state) {
      PerceivedEntities nearbyHostiles = (PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.NEARBY_HOSTILES).orElse(PerceivedEntities.empty());
      if (state.isDue(nearbyHostiles)) {
         long gameTime = villager.m_9236_().m_46467_();
         QualifyingHit latestHit = state.getLatestHit();
         boolean wasHitRecently = latestHit != null && latestHit.isLive(gameTime);
         ThreatAssessmentResult previousAssessment = state.getLatestResult();
         ThreatVerdict previousVerdict = previousAssessment == null ? null : previousAssessment.verdict();
         PerceivedEntities unseenHostiles = (PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.UNSEEN_HOSTILES).orElse(PerceivedEntities.empty());
         double danger = (double)0.0F;
         double totalHostileThreat = (double)0.0F;
         boolean awareHostilePresent = false;

         for(SensedEntity sensed : nearbyHostiles.entities()) {
            LivingEntity hostile = sensed.entity();
            if (hostile.m_6084_()) {
               double threatWeight = (double)SettlementsDataMaps.threatWeight(hostile.m_6095_());
               if (contains(unseenHostiles, hostile)) {
                  threatWeight *= 0.2;
               }

               danger += ThreatResponseRules.dangerContribution(sensed.distance(), threatWeight);
               totalHostileThreat += threatWeight;
               awareHostilePresent = true;
            }
         }

         if (awareHostilePresent || wasHitRecently || previousVerdict != null && previousVerdict != ThreatVerdict.HOLD) {
            PerceivedEntities sightedHostiles = (PerceivedEntities)villager.getSettlementsBrain().getMemory(MemoryTypeRegistry.SIGHTED_HOSTILES).orElse(PerceivedEntities.empty());
            CombatSelection previousSelection = previousAssessment == null ? null : previousAssessment.selection();
            CombatReadiness continuingReadiness = previousSelection == null ? null : previousSelection.option().prepare(villager);
            CombatOption continuingOption = continuingReadiness == null ? null : previousSelection.option();
            LivingEntity lock = resolveLock(villager, state.getLockedTargetId());
            LivingEntity continuationTarget = null;
            boolean lockHeld = false;
            if (continuingOption != null) {
               double reachBlocks = continuingOption.reachBlocks();
               lockHeld = lock != null && (continuingReadiness.canStayLockedOn(lock) || canEngageSighted(continuingReadiness, reachBlocks, sightedHostiles, lock));
               continuationTarget = chooseTarget(villager, continuingReadiness, reachBlocks, sightedHostiles, lockHeld ? lock : null);
            }

            ClockTicks sinceEngageableTarget = continuationTarget != null ? ClockTicks.ZERO : ClockTicks.of(gameTime - state.getLastEngagedGameTime());
            double willGeneValue = villager.getGenetics().getGeneValue(GeneType.WILL);
            double healthFraction = (double)(villager.m_21223_() / villager.m_21233_());
            Double continuingNerve = continuingOption == null ? null : ThreatResponseRules.nerve(willGeneValue, healthFraction, continuingOption.nerveContribution(), totalHostileThreat);
            ThreatSituation.ThreatSituationBuilder situation = ThreatSituation.builder().previousVerdict(previousVerdict).danger(danger).awareHostilePresent(awareHostilePresent || lockHeld).liveHitPresent(wasHitRecently).continuingNerve(continuingNerve).sinceEngageableTarget(sinceEngageableTarget).sinceAlarmed(ClockTicks.of(gameTime - state.getLastAlarmedGameTime()));
            CombatSelection entryCandidate = null;
            ThreatDecision decision;
            if (ThreatResponseRules.continues(situation.build())) {
               decision = ThreatDecision.CONTINUE_COMBAT;
            } else {
               entryCandidate = villager.m_6162_() ? null : this.findFirstCombatCandidate(villager, sightedHostiles, lock, continuingOption, continuingReadiness);
               Double enteringNerve = entryCandidate == null ? null : ThreatResponseRules.nerve(willGeneValue, healthFraction, entryCandidate.option().nerveContribution(), totalHostileThreat);
               decision = ThreatResponseRules.decide(situation.enteringNerve(enteringNerve).build());
            }

            ThreatAssessmentResult var10000;
            switch (decision) {
               case CONTINUE_COMBAT:
                  var10000 = new ThreatAssessmentResult(ThreatVerdict.COMBAT, new CombatSelection(continuingOption, continuationTarget == null ? null : continuationTarget.m_20148_()));
                  break;
               case ENTER_COMBAT:
                  var10000 = new ThreatAssessmentResult(ThreatVerdict.COMBAT, entryCandidate);
                  break;
               case PANIC:
               case LINGER_IN_PANIC:
                  var10000 = PANIC_RESULT;
                  break;
               case HOLD:
                  var10000 = HOLD_RESULT;
                  break;
               default:
                  throw new IncompatibleClassChangeError();
            }

            ThreatAssessmentResult result = var10000;
            log.info("[threat-decision] villager={} decision={} danger={} hostiles={} sighted={} will={} hp={} aware={} hit={} continuing={} entry={}", villager.m_19879_(), decision, String.format("%.2f", danger), nearbyHostiles.entities().size(), sightedHostiles.entities().size(), String.format("%.2f", willGeneValue), String.format("%.2f", healthFraction), awareHostilePresent || lockHeld, wasHitRecently, continuingOption != null, entryCandidate != null);
            state.recordAssessment(decision, result, nearbyHostiles, gameTime);
         } else {
            if (previousVerdict != null && previousVerdict != ThreatVerdict.HOLD) {
               log.info("[threat-decision] villager={} decision=HOLD(early) previous={} hostiles={}", villager.m_19879_(), previousVerdict, nearbyHostiles.entities().size());
            }

            state.recordAssessment(ThreatDecision.HOLD, HOLD_RESULT, nearbyHostiles, gameTime);
         }
      }
   }

   @Nullable
   private CombatSelection findFirstCombatCandidate(@Nonnull BaseVillager villager, @Nonnull PerceivedEntities sightedHostiles, @Nullable LivingEntity lock, @Nullable CombatOption continuingOption, @Nullable CombatReadiness continuingReadiness) {
      StringJoiner scan = new StringJoiner(",");

      for(CombatOption option : this.combatOptions) {
         CombatReadiness readiness = option == continuingOption ? continuingReadiness : option.prepare(villager);
         String var10001 = option.getClass().getSimpleName();
         scan.add(var10001 + (readiness == null ? ":unready" : ":ready"));
         if (readiness != null) {
            double reachBlocks = option.reachBlocks();
            LivingEntity engageableLock = lock != null && canEngageSighted(readiness, reachBlocks, sightedHostiles, lock) ? lock : null;
            LivingEntity target = chooseTarget(villager, readiness, reachBlocks, sightedHostiles, engageableLock);
            if (target != null) {
               return new CombatSelection(option, target.m_20148_());
            }
         }
      }

      if (!sightedHostiles.entities().isEmpty()) {
         log.info("[threat-decision] villager={} entry-scan=none options=[{}]", villager.m_19879_(), scan);
      }

      return null;
   }

   @Nullable
   private static LivingEntity chooseTarget(@Nonnull BaseVillager villager, @Nonnull CombatReadiness readiness, double reachBlocks, @Nonnull PerceivedEntities sightedHostiles, @Nullable LivingEntity lock) {
      if (lock == null) {
         return findNearestEngageableHostile(readiness, sightedHostiles, reachBlocks);
      } else if (villager.m_20280_(lock) > (double)25.0F) {
         LivingEntity closeHostile = findNearestEngageableHostile(readiness, sightedHostiles, Math.min((double)5.0F, reachBlocks));
         return closeHostile != null ? closeHostile : lock;
      } else {
         return lock;
      }
   }

   @Nullable
   private static LivingEntity findNearestEngageableHostile(@Nonnull CombatReadiness readiness, @Nonnull PerceivedEntities sightedHostiles, double withinBlocks) {
      for(SensedEntity sensed : sightedHostiles.entities()) {
         LivingEntity candidate = sensed.entity();
         if (candidate.m_6084_()) {
            if (sensed.distance() > withinBlocks) {
               break;
            }

            if (!isBeingCured(candidate) && readiness.canEngage(candidate)) {
               return candidate;
            }
         }
      }

      return null;
   }

   private static boolean canEngageSighted(@Nonnull CombatReadiness readiness, double reachBlocks, @Nonnull PerceivedEntities sightedHostiles, @Nonnull LivingEntity hostile) {
      for(SensedEntity sensed : sightedHostiles.entities()) {
         if (sensed.entity() == hostile) {
            return sensed.distance() <= reachBlocks && readiness.canEngage(hostile);
         }
      }

      return false;
   }

   @Nullable
   private static LivingEntity resolveLock(@Nonnull BaseVillager villager, @Nullable UUID lockedTargetId) {
      if (lockedTargetId != null) {
         Level var3 = villager.m_9236_();
         if (var3 instanceof ServerLevel) {
            ServerLevel level = (ServerLevel)var3;
            Entity var4 = level.m_8791_(lockedTargetId);
            LivingEntity var10000;
            if (var4 instanceof LivingEntity) {
               LivingEntity target = (LivingEntity)var4;
               if (target.m_6084_() && !isBeingCured(target)) {
                  var10000 = target;
                  return var10000;
               }
            }

            var10000 = null;
            return var10000;
         }
      }

      return null;
   }

   private static boolean isBeingCured(@Nonnull LivingEntity hostile) {
      boolean var10000;
      if (hostile instanceof ZombieVillager patient) {
         if (patient.m_34408_()) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   private static boolean contains(@Nonnull PerceivedEntities perceived, @Nonnull LivingEntity entity) {
      for(SensedEntity sensed : perceived.entities()) {
         if (sensed.entity() == entity) {
            return true;
         }
      }

      return false;
   }

   @Inject
   ThreatAssessor(List<CombatOption> combatOptions) {
      this.combatOptions = combatOptions;
   }

   static {
      PANIC_RESULT = new ThreatAssessmentResult(ThreatVerdict.PANIC, (CombatSelection)null);
      HOLD_RESULT = new ThreatAssessmentResult(ThreatVerdict.HOLD, (CombatSelection)null);
   }
}
