package dev.breezes.settlements.application.ai.threat;

import dev.breezes.settlements.domain.ai.threat.QualifyingHit;
import dev.breezes.settlements.domain.ai.threat.ThreatVerdict;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;

public interface IThreatResponse {
   Optional<QualifyingHit> recordHit(@Nullable UUID var1, float var2, long var3);

   @Nullable
   ThreatVerdict verdict();

   @Nullable
   CombatSelection selection();

   void revokeSelection();
}
