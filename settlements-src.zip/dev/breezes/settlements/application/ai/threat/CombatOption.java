package dev.breezes.settlements.application.ai.threat;

import dev.breezes.settlements.domain.ai.behavior.contracts.IBehavior;
import dev.breezes.settlements.domain.ai.catalog.BehaviorDisplayMetadata;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.world.entity.LivingEntity;

public interface CombatOption {
   double nerveContribution();

   double reachBlocks();

   @Nullable
   CombatReadiness prepare(@Nonnull BaseVillager var1);

   IBehavior<BaseVillager> createBehavior(@Nonnull LivingEntity var1);

   BehaviorDisplayMetadata displayInfo();
}
