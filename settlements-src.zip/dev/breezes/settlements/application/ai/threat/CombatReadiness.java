package dev.breezes.settlements.application.ai.threat;

import javax.annotation.Nonnull;
import net.minecraft.world.entity.LivingEntity;

public interface CombatReadiness {
   boolean canEngage(@Nonnull LivingEntity var1);

   default boolean canStayLockedOn(@Nonnull LivingEntity target) {
      return false;
   }
}
