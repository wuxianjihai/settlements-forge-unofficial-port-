package dev.breezes.settlements.application.ai.threat;

import java.util.UUID;
import javax.annotation.Nullable;

public record CombatSelection(CombatOption option, @Nullable UUID targetId) {
}
