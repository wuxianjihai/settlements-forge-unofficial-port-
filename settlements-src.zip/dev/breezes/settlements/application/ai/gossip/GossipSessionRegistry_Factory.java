package dev.breezes.settlements.application.ai.gossip;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class GossipSessionRegistry_Factory implements Factory<GossipSessionRegistry> {
   public GossipSessionRegistry get() {
      return newInstance();
   }

   public static GossipSessionRegistry_Factory create() {
      return GossipSessionRegistry_Factory.InstanceHolder.INSTANCE;
   }

   public static GossipSessionRegistry newInstance() {
      return new GossipSessionRegistry();
   }

   private static final class InstanceHolder {
      static final GossipSessionRegistry_Factory INSTANCE = new GossipSessionRegistry_Factory();
   }
}
