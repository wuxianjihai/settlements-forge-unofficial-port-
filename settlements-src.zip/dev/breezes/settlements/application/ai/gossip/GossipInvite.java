package dev.breezes.settlements.application.ai.gossip;

import java.util.UUID;

public record GossipInvite(UUID sessionId, UUID initiatorId, UUID receiverId, long createdAtTick, long expireAtTick) {
}
