package dev.breezes.settlements.application.ai.gossip;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.knowledge.KnowledgeEntry;
import dev.breezes.settlements.domain.time.ClockTicks;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.Nonnull;
import lombok.Generated;

@ServerScope
public final class GossipSessionRegistry {
   public static final int INVITE_TIMEOUT_SECONDS = 10;
   public static final int SESSION_MAX_LIFETIME_SECONDS = 20;
   private final Map<UUID, GossipSession> activeSessionsByParticipant = new ConcurrentHashMap();
   private final Map<UUID, GossipInvite> invitesByReceiver = new ConcurrentHashMap();
   private final Map<UUID, GossipSession> sessionsById = new ConcurrentHashMap();

   public GossipSession sendInvite(@Nonnull UUID initiatorId, @Nonnull UUID receiverId, @Nonnull KnowledgeEntry entryToShare, long currentTick) {
      if (initiatorId.equals(receiverId)) {
         throw new IllegalArgumentException("Gossip initiator and receiver must be different villagers");
      } else {
         UUID sessionId = UUID.randomUUID();
         GossipSession session = GossipSession.builder().sessionId(sessionId).initiatorId(initiatorId).receiverId(receiverId).entryToShare(entryToShare).openedAtTick(currentTick).phase(GossipPhase.INVITE_SENT).build();
         long expireAtTick = currentTick + ClockTicks.seconds((double)10.0F).getTicks();
         GossipInvite invite = new GossipInvite(sessionId, initiatorId, receiverId, currentTick, expireAtTick);
         this.sessionsById.put(sessionId, session);
         this.activeSessionsByParticipant.put(initiatorId, session);
         this.activeSessionsByParticipant.put(receiverId, session);
         this.invitesByReceiver.put(receiverId, invite);
         return session;
      }
   }

   public boolean hasInviteFor(@Nonnull UUID receiverId) {
      return this.invitesByReceiver.containsKey(receiverId);
   }

   public Optional<GossipInvite> getInvite(@Nonnull UUID receiverId) {
      return Optional.ofNullable((GossipInvite)this.invitesByReceiver.get(receiverId));
   }

   public Optional<GossipSession> getActiveSession(@Nonnull UUID participantId) {
      return Optional.ofNullable((GossipSession)this.activeSessionsByParticipant.get(participantId));
   }

   public boolean isParticipating(@Nonnull UUID villagerId) {
      return this.activeSessionsByParticipant.containsKey(villagerId);
   }

   public GossipSession acceptInvite(@Nonnull UUID receiverId) {
      GossipInvite invite = (GossipInvite)this.invitesByReceiver.remove(receiverId);
      if (invite == null) {
         throw new IllegalStateException("No pending gossip invite for receiverId=" + String.valueOf(receiverId));
      } else {
         GossipSession session = (GossipSession)this.sessionsById.get(invite.sessionId());
         if (session == null) {
            throw new IllegalStateException("Gossip invite had no matching session: sessionId=" + String.valueOf(invite.sessionId()));
         } else {
            session.transitionTo(GossipPhase.ACCEPTED);
            return session;
         }
      }
   }

   public void completeSession(UUID sessionId) {
      this.closeSession(sessionId, GossipPhase.COMPLETED);
   }

   public void abortSession(UUID sessionId) {
      this.closeSession(sessionId, GossipPhase.ABORTED);
   }

   private void closeSession(UUID sessionId, GossipPhase terminalPhase) {
      GossipSession session = (GossipSession)this.sessionsById.remove(sessionId);
      if (session != null) {
         session.transitionTo(terminalPhase);
         this.activeSessionsByParticipant.remove(session.getInitiatorId());
         this.activeSessionsByParticipant.remove(session.getReceiverId());
         this.invitesByReceiver.remove(session.getReceiverId());
      }
   }

   public void tickTimeouts(long currentTick) {
      this.invitesByReceiver.entrySet().removeIf((entry) -> {
         if (((GossipInvite)entry.getValue()).expireAtTick() < currentTick) {
            UUID sessionId = ((GossipInvite)entry.getValue()).sessionId();
            GossipSession session = (GossipSession)this.sessionsById.get(sessionId);
            if (session != null && session.getPhase() == GossipPhase.INVITE_SENT) {
               this.closeSession(sessionId, GossipPhase.ABORTED);
            }

            return true;
         } else {
            return false;
         }
      });
      long maxLifetimeTicks = ClockTicks.seconds((double)20.0F).getTicks();
      List<UUID> expiredSessionIds = new ArrayList();

      for(GossipSession session : this.sessionsById.values()) {
         if (session.getPhase() != GossipPhase.COMPLETED && session.getPhase() != GossipPhase.ABORTED && currentTick - session.getOpenedAtTick() > maxLifetimeTicks) {
            expiredSessionIds.add(session.getSessionId());
         }
      }

      for(UUID sessionId : expiredSessionIds) {
         this.closeSession(sessionId, GossipPhase.ABORTED);
      }

   }
}
