package dev.breezes.settlements.application.ai.gossip;

import dev.breezes.settlements.domain.ai.knowledge.KnowledgeEntry;
import java.util.UUID;
import lombok.Generated;

public final class GossipSession {
   private final UUID sessionId;
   private final UUID initiatorId;
   private final UUID receiverId;
   private final KnowledgeEntry entryToShare;
   private final long openedAtTick;
   private GossipPhase phase;

   public void transitionTo(GossipPhase newPhase) {
      this.phase = newPhase;
   }

   @Generated
   GossipSession(UUID sessionId, UUID initiatorId, UUID receiverId, KnowledgeEntry entryToShare, long openedAtTick, GossipPhase phase) {
      this.sessionId = sessionId;
      this.initiatorId = initiatorId;
      this.receiverId = receiverId;
      this.entryToShare = entryToShare;
      this.openedAtTick = openedAtTick;
      this.phase = phase;
   }

   @Generated
   public static GossipSessionBuilder builder() {
      return new GossipSessionBuilder();
   }

   @Generated
   public UUID getSessionId() {
      return this.sessionId;
   }

   @Generated
   public UUID getInitiatorId() {
      return this.initiatorId;
   }

   @Generated
   public UUID getReceiverId() {
      return this.receiverId;
   }

   @Generated
   public KnowledgeEntry getEntryToShare() {
      return this.entryToShare;
   }

   @Generated
   public long getOpenedAtTick() {
      return this.openedAtTick;
   }

   @Generated
   public GossipPhase getPhase() {
      return this.phase;
   }

   @Generated
   public static class GossipSessionBuilder {
      @Generated
      private UUID sessionId;
      @Generated
      private UUID initiatorId;
      @Generated
      private UUID receiverId;
      @Generated
      private KnowledgeEntry entryToShare;
      @Generated
      private long openedAtTick;
      @Generated
      private GossipPhase phase;

      @Generated
      GossipSessionBuilder() {
      }

      @Generated
      public GossipSessionBuilder sessionId(UUID sessionId) {
         this.sessionId = sessionId;
         return this;
      }

      @Generated
      public GossipSessionBuilder initiatorId(UUID initiatorId) {
         this.initiatorId = initiatorId;
         return this;
      }

      @Generated
      public GossipSessionBuilder receiverId(UUID receiverId) {
         this.receiverId = receiverId;
         return this;
      }

      @Generated
      public GossipSessionBuilder entryToShare(KnowledgeEntry entryToShare) {
         this.entryToShare = entryToShare;
         return this;
      }

      @Generated
      public GossipSessionBuilder openedAtTick(long openedAtTick) {
         this.openedAtTick = openedAtTick;
         return this;
      }

      @Generated
      public GossipSessionBuilder phase(GossipPhase phase) {
         this.phase = phase;
         return this;
      }

      @Generated
      public GossipSession build() {
         return new GossipSession(this.sessionId, this.initiatorId, this.receiverId, this.entryToShare, this.openedAtTick, this.phase);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.sessionId);
         return "GossipSession.GossipSessionBuilder(sessionId=" + var10000 + ", initiatorId=" + String.valueOf(this.initiatorId) + ", receiverId=" + String.valueOf(this.receiverId) + ", entryToShare=" + String.valueOf(this.entryToShare) + ", openedAtTick=" + this.openedAtTick + ", phase=" + String.valueOf(this.phase) + ")";
      }
   }
}
