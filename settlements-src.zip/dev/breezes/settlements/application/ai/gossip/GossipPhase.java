package dev.breezes.settlements.application.ai.gossip;

public enum GossipPhase {
   INVITE_SENT,
   ACCEPTED,
   COMPLETED,
   ABORTED;

   // $FF: synthetic method
   private static GossipPhase[] $values() {
      return new GossipPhase[]{INVITE_SENT, ACCEPTED, COMPLETED, ABORTED};
   }
}
