package dev.breezes.settlements.application.ai.memory;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class SensedSiteReader_Factory implements Factory<SensedSiteReader> {
   public SensedSiteReader get() {
      return newInstance();
   }

   public static SensedSiteReader_Factory create() {
      return SensedSiteReader_Factory.InstanceHolder.INSTANCE;
   }

   public static SensedSiteReader newInstance() {
      return new SensedSiteReader();
   }

   private static final class InstanceHolder {
      static final SensedSiteReader_Factory INSTANCE = new SensedSiteReader_Factory();
   }
}
