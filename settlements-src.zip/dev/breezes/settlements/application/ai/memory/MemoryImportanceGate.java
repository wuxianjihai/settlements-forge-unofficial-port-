package dev.breezes.settlements.application.ai.memory;

import dev.breezes.settlements.domain.ai.observation.Observation;
import dev.breezes.settlements.domain.ai.observation.ObservationType;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.domain.genetics.GeneType;
import dev.breezes.settlements.domain.genetics.GeneticsProfile;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Locale;
import lombok.Generated;

public class MemoryImportanceGate {
   public static final float PROMOTION_THRESHOLD = 2.0F;
   private static final float SELF_DEED_SALIENCE_BONUS = 0.5F;

   public float score(Observation observation, VillagerProfessionKey profession, GeneticsProfile genetics) {
      return this.score(observation, profession, genetics, List.of());
   }

   public float score(Observation observation, VillagerProfessionKey profession, GeneticsProfile genetics, List<Observation> recentObservations) {
      int similarPeerCount = 0;

      for(Observation recent : recentObservations) {
         if (recent.type() == observation.type()) {
            ++similarPeerCount;
         }
      }

      return this.score(observation, profession, genetics, similarPeerCount);
   }

   public float score(Observation observation, VillagerProfessionKey profession, GeneticsProfile genetics, int similarPeerCount) {
      return this.score(observation, profession, genetics, similarPeerCount, false);
   }

   public float score(Observation observation, VillagerProfessionKey profession, GeneticsProfile genetics, int similarPeerCount, boolean isSelfDeed) {
      float base = observation.baseImportance();
      float novelty = this.computeNovelty(similarPeerCount);
      float geneModifier = this.computeGeneModifier(observation, genetics);
      float professionRelevance = this.computeProfessionRelevance(observation, profession);
      float selfDeedBonus = this.computeSelfDeedBonus(observation, isSelfDeed);
      return base * novelty * geneModifier + professionRelevance + selfDeedBonus;
   }

   public boolean shouldPromote(float score) {
      return score >= 2.0F;
   }

   private float computeNovelty(int similarPeerCount) {
      if (similarPeerCount == 0) {
         return 1.5F;
      } else if (similarPeerCount == 1) {
         return 1.0F;
      } else {
         return similarPeerCount <= 3 ? 0.5F : 0.1F;
      }
   }

   private float computeSelfDeedBonus(Observation observation, boolean isSelfDeed) {
      return !isSelfDeed ? 0.0F : 0.5F;
   }

   private float computeGeneModifier(Observation observation, GeneticsProfile genetics) {
      float intelligenceBonus = (float)genetics.getGeneValue(GeneType.INTELLIGENCE) * 0.2F;
      float modifier = 1.0F + intelligenceBonus;
      if (observation.type() == ObservationType.THREAT) {
         modifier *= 1.5F - (float)genetics.getGeneValue(GeneType.WILL) * 0.6F;
      }

      if (observation.type() == ObservationType.SOCIAL || observation.type() == ObservationType.GOSSIP_RECEIVED) {
         modifier *= 1.0F + (float)genetics.getGeneValue(GeneType.CHARISMA) * 0.3F;
      }

      return Math.max(0.1F, modifier);
   }

   private float computeProfessionRelevance(Observation observation, VillagerProfessionKey profession) {
      if (observation.type() == ObservationType.THREAT) {
         return 1.0F;
      } else {
         String normalizedContent = observation.content().toLowerCase(Locale.ROOT);
         String professionId = profession.id().toLowerCase(Locale.ROOT);
         if (normalizedContent.contains(professionId)) {
            return 0.75F;
         } else {
            float var10000;
            switch (professionId) {
               case "farmer" -> var10000 = containsAny(normalizedContent, "crop", "wheat", "sugarcane", "cow", "chicken", "honey") ? 0.5F : 0.0F;
               case "fisherman" -> var10000 = containsAny(normalizedContent, "fish", "water", "cat") ? 0.5F : 0.0F;
               case "librarian" -> var10000 = containsAny(normalizedContent, "book", "enchant", "library") ? 0.5F : 0.0F;
               case "mason" -> var10000 = containsAny(normalizedContent, "stone", "ore", "mine") ? 0.5F : 0.0F;
               case "shepherd" -> var10000 = containsAny(normalizedContent, "sheep", "wool", "wolf") ? 0.5F : 0.0F;
               case "butcher" -> var10000 = containsAny(normalizedContent, "pig", "meat", "livestock", "smoker") ? 0.5F : 0.0F;
               case "cleric" -> var10000 = containsAny(normalizedContent, "potion", "soul sand") ? 0.5F : 0.0F;
               default -> var10000 = 0.0F;
            }

            return var10000;
         }
      }
   }

   private static boolean containsAny(String value, String... needles) {
      for(String needle : needles) {
         if (value.contains(needle)) {
            return true;
         }
      }

      return false;
   }
}
