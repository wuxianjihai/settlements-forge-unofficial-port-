package dev.breezes.settlements.application.ai.memory;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class MemoryImportanceGate_Factory implements Factory<MemoryImportanceGate> {
   public MemoryImportanceGate get() {
      return newInstance();
   }

   public static MemoryImportanceGate_Factory create() {
      return MemoryImportanceGate_Factory.InstanceHolder.INSTANCE;
   }

   public static MemoryImportanceGate newInstance() {
      return new MemoryImportanceGate();
   }

   private static final class InstanceHolder {
      static final MemoryImportanceGate_Factory INSTANCE = new MemoryImportanceGate_Factory();
   }
}
