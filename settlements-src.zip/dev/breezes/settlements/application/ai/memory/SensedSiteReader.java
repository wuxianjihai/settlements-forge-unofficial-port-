package dev.breezes.settlements.application.ai.memory;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.brain.IBrain;
import dev.breezes.settlements.domain.ai.memory.MemoryType;
import dev.breezes.settlements.domain.ai.memory.MemoryTypeRegistry;
import dev.breezes.settlements.domain.ai.memory.SensedSites;
import dev.breezes.settlements.domain.ai.memory.SiteCoord;
import jakarta.inject.Inject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.GlobalPos;

@ServerScope
public final class SensedSiteReader {
   public SensedSites read(@Nonnull IBrain brain) {
      Map<MemoryType<List<GlobalPos>>, List<SiteCoord>> sites = new HashMap();

      for(MemoryType<List<GlobalPos>> type : MemoryTypeRegistry.spatialSiteTypes()) {
         List<GlobalPos> positions = (List)brain.getMemory(type).orElse(List.of());
         if (!positions.isEmpty()) {
            List<SiteCoord> coords = positions.stream().map((globalPos) -> new SiteCoord(globalPos.m_122646_().m_123341_(), globalPos.m_122646_().m_123342_(), globalPos.m_122646_().m_123343_())).toList();
            sites.put(type, coords);
         }
      }

      return new SensedSites(sites);
   }

   @Inject
   @Generated
   SensedSiteReader() {
   }
}
