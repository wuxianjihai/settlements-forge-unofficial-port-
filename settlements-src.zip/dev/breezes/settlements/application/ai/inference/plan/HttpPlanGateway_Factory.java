package dev.breezes.settlements.application.ai.inference.plan;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.inference.InferenceTransport;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class HttpPlanGateway_Factory implements Factory<HttpPlanGateway> {
   private final Provider<InferenceTransport> transportProvider;

   private HttpPlanGateway_Factory(Provider<InferenceTransport> transportProvider) {
      this.transportProvider = transportProvider;
   }

   public HttpPlanGateway get() {
      return newInstance((InferenceTransport)this.transportProvider.get());
   }

   public static HttpPlanGateway_Factory create(Provider<InferenceTransport> transportProvider) {
      return new HttpPlanGateway_Factory(transportProvider);
   }

   public static HttpPlanGateway newInstance(InferenceTransport transport) {
      return new HttpPlanGateway(transport);
   }
}
