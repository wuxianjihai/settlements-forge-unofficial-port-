package dev.breezes.settlements.application.ai.inference.plan;

import dev.breezes.settlements.infrastructure.config.annotations.BehaviorConfig;
import dev.breezes.settlements.infrastructure.config.annotations.ConfigurationType;
import dev.breezes.settlements.infrastructure.config.annotations.integers.IntegerConfig;
import dev.breezes.settlements.infrastructure.config.annotations.strings.StringConfig;

@BehaviorConfig(
   name = "plan_inference",
   type = ConfigurationType.INFERENCE
)
public record PlanInferenceConfig(@StringConfig(type = ConfigurationType.INFERENCE,identifier = "mode",description = "Plan mode: HEURISTIC (default) or LLM (an always-on per-villager overlay may replace the heuristic plan).",defaultValue = "HEURISTIC") String mode, @IntegerConfig(type = ConfigurationType.INFERENCE,identifier = "overlay_deadline_seconds",description = "Total time budget in seconds for one PLAN overlay sub-batch's streaming request.",defaultValue = 300,min = 5,max = 1200) int overlayDeadlineSeconds, @IntegerConfig(type = ConfigurationType.INFERENCE,identifier = "sub_batch_size",description = "Max villagers coalesced into one streaming PLAN POST. Purely bounds HTTP payload size and per-connection failure blast radius — the backend (SIS + vLLM continuous batching) owns actual LLM concurrency, so this is not a throughput knob.",defaultValue = 20,min = 1,max = 200) int subBatchSize, @IntegerConfig(type = ConfigurationType.INFERENCE,identifier = "sub_batch_window_seconds",description = "Max real seconds a partial sub-batch is held before being sent. A sub-batch flushes when it reaches sub_batch_size villagers OR this window elapses since its first buffered villager, whichever comes first.",defaultValue = 3,min = 1,max = 30) int subBatchWindowSeconds, @IntegerConfig(type = ConfigurationType.INFERENCE,identifier = "overlay_cutoff_civil_tick",description = "Latest point in a plan's own day (civil ticks; 0 = 00:00, 24000 = next midnight; default 11_000 = 11:00) at which an LLM PLAN overlay is still worth requesting.",defaultValue = 11000,min = 0,max = 24000) int overlayCutoffCivilTick) {
   public PlanInferenceMode resolvedMode() {
      try {
         return PlanInferenceMode.valueOf(this.mode.toUpperCase());
      } catch (IllegalArgumentException var2) {
         return PlanInferenceMode.HEURISTIC;
      }
   }
}
