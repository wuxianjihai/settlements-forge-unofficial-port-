package dev.breezes.settlements.application.ai.inference.plan;

public enum PlanInferenceMode {
   HEURISTIC,
   LLM;

   // $FF: synthetic method
   private static PlanInferenceMode[] $values() {
      return new PlanInferenceMode[]{HEURISTIC, LLM};
   }
}
