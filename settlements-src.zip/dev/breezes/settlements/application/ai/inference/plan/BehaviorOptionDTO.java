package dev.breezes.settlements.application.ai.inference.plan;

import javax.annotation.Nullable;
import lombok.Generated;

public final class BehaviorOptionDTO {
   private final String id;
   private final String description;
   @Nullable
   private final String requiredItems;
   @Nullable
   private final String produces;
   private final String category;
   private final String intensity;
   private final int estimatedMinutes;
   private final boolean hasOpportunity;

   @Generated
   BehaviorOptionDTO(String id, String description, @Nullable String requiredItems, @Nullable String produces, String category, String intensity, int estimatedMinutes, boolean hasOpportunity) {
      this.id = id;
      this.description = description;
      this.requiredItems = requiredItems;
      this.produces = produces;
      this.category = category;
      this.intensity = intensity;
      this.estimatedMinutes = estimatedMinutes;
      this.hasOpportunity = hasOpportunity;
   }

   @Generated
   public static BehaviorOptionDTOBuilder builder() {
      return new BehaviorOptionDTOBuilder();
   }

   @Generated
   public String getId() {
      return this.id;
   }

   @Generated
   public String getDescription() {
      return this.description;
   }

   @Nullable
   @Generated
   public String getRequiredItems() {
      return this.requiredItems;
   }

   @Nullable
   @Generated
   public String getProduces() {
      return this.produces;
   }

   @Generated
   public String getCategory() {
      return this.category;
   }

   @Generated
   public String getIntensity() {
      return this.intensity;
   }

   @Generated
   public int getEstimatedMinutes() {
      return this.estimatedMinutes;
   }

   @Generated
   public boolean isHasOpportunity() {
      return this.hasOpportunity;
   }

   @Generated
   public static class BehaviorOptionDTOBuilder {
      @Generated
      private String id;
      @Generated
      private String description;
      @Generated
      private String requiredItems;
      @Generated
      private String produces;
      @Generated
      private String category;
      @Generated
      private String intensity;
      @Generated
      private int estimatedMinutes;
      @Generated
      private boolean hasOpportunity;

      @Generated
      BehaviorOptionDTOBuilder() {
      }

      @Generated
      public BehaviorOptionDTOBuilder id(String id) {
         this.id = id;
         return this;
      }

      @Generated
      public BehaviorOptionDTOBuilder description(String description) {
         this.description = description;
         return this;
      }

      @Generated
      public BehaviorOptionDTOBuilder requiredItems(@Nullable String requiredItems) {
         this.requiredItems = requiredItems;
         return this;
      }

      @Generated
      public BehaviorOptionDTOBuilder produces(@Nullable String produces) {
         this.produces = produces;
         return this;
      }

      @Generated
      public BehaviorOptionDTOBuilder category(String category) {
         this.category = category;
         return this;
      }

      @Generated
      public BehaviorOptionDTOBuilder intensity(String intensity) {
         this.intensity = intensity;
         return this;
      }

      @Generated
      public BehaviorOptionDTOBuilder estimatedMinutes(int estimatedMinutes) {
         this.estimatedMinutes = estimatedMinutes;
         return this;
      }

      @Generated
      public BehaviorOptionDTOBuilder hasOpportunity(boolean hasOpportunity) {
         this.hasOpportunity = hasOpportunity;
         return this;
      }

      @Generated
      public BehaviorOptionDTO build() {
         return new BehaviorOptionDTO(this.id, this.description, this.requiredItems, this.produces, this.category, this.intensity, this.estimatedMinutes, this.hasOpportunity);
      }

      @Generated
      public String toString() {
         return "BehaviorOptionDTO.BehaviorOptionDTOBuilder(id=" + this.id + ", description=" + this.description + ", requiredItems=" + this.requiredItems + ", produces=" + this.produces + ", category=" + this.category + ", intensity=" + this.intensity + ", estimatedMinutes=" + this.estimatedMinutes + ", hasOpportunity=" + this.hasOpportunity + ")";
      }
   }
}
