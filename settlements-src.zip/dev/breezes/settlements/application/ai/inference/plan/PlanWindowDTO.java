package dev.breezes.settlements.application.ai.inference.plan;

import lombok.Generated;

public final class PlanWindowDTO {
   private final String id;
   private final int startTick;
   private final int endTick;

   @Generated
   PlanWindowDTO(String id, int startTick, int endTick) {
      this.id = id;
      this.startTick = startTick;
      this.endTick = endTick;
   }

   @Generated
   public static PlanWindowDTOBuilder builder() {
      return new PlanWindowDTOBuilder();
   }

   @Generated
   public String getId() {
      return this.id;
   }

   @Generated
   public int getStartTick() {
      return this.startTick;
   }

   @Generated
   public int getEndTick() {
      return this.endTick;
   }

   @Generated
   public static class PlanWindowDTOBuilder {
      @Generated
      private String id;
      @Generated
      private int startTick;
      @Generated
      private int endTick;

      @Generated
      PlanWindowDTOBuilder() {
      }

      @Generated
      public PlanWindowDTOBuilder id(String id) {
         this.id = id;
         return this;
      }

      @Generated
      public PlanWindowDTOBuilder startTick(int startTick) {
         this.startTick = startTick;
         return this;
      }

      @Generated
      public PlanWindowDTOBuilder endTick(int endTick) {
         this.endTick = endTick;
         return this;
      }

      @Generated
      public PlanWindowDTO build() {
         return new PlanWindowDTO(this.id, this.startTick, this.endTick);
      }

      @Generated
      public String toString() {
         return "PlanWindowDTO.PlanWindowDTOBuilder(id=" + this.id + ", startTick=" + this.startTick + ", endTick=" + this.endTick + ")";
      }
   }
}
