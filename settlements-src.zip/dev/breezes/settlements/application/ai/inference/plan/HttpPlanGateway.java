package dev.breezes.settlements.application.ai.inference.plan;

import com.google.gson.Gson;
import dev.breezes.settlements.application.ai.inference.InferenceCapability;
import dev.breezes.settlements.application.ai.inference.InferenceStreamHandle;
import dev.breezes.settlements.application.ai.inference.InferenceTransport;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class HttpPlanGateway implements PlanGateway {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(HttpPlanGateway.class.getName());
   private static final Gson GSON = new Gson();
   private final InferenceTransport transport;

   public InferenceStreamHandle generate(@Nonnull PlanBatchRequest request, @Nonnull Duration deadline, @Nonnull Consumer<VillagerPlanResult> onVillager) {
      return this.transport.postStreaming(InferenceCapability.PLAN, request, deadline, (line) -> this.parseLine(line, onVillager));
   }

   private void parseLine(String line, Consumer<VillagerPlanResult> onVillager) {
      String trimmed = line.strip();
      if (!trimmed.isEmpty()) {
         try {
            VillagerPlanResult result = (VillagerPlanResult)GSON.fromJson(trimmed, VillagerPlanResult.class);
            if (result != null && result.getVillagerId() != null) {
               onVillager.accept(normalizeVillager(result));
            }
         } catch (RuntimeException e) {
            log.error("PLAN response line parse failed: {}", e.getMessage());
         }

      }
   }

   private static VillagerPlanResult normalizeVillager(VillagerPlanResult villager) {
      return VillagerPlanResult.builder().villagerId(villager.getVillagerId()).selections(normalizeSelections(villager.getSelections())).build();
   }

   private static Map<String, List<PlanSelection>> normalizeSelections(Map<String, List<PlanSelection>> selections) {
      return selections == null ? Map.of() : (Map)selections.entrySet().stream().filter((entry) -> entry.getValue() != null).collect(Collectors.toMap(Map.Entry::getKey, (entry) -> ((List)entry.getValue()).stream().filter(Objects::nonNull).toList()));
   }

   @Inject
   @Generated
   HttpPlanGateway(InferenceTransport transport) {
      this.transport = transport;
   }
}
