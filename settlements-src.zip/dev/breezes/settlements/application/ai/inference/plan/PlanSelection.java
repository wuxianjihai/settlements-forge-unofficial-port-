package dev.breezes.settlements.application.ai.inference.plan;

import javax.annotation.Nullable;
import lombok.Generated;

public final class PlanSelection {
   private final String id;
   @Nullable
   private final String at;

   @Generated
   PlanSelection(String id, @Nullable String at) {
      this.id = id;
      this.at = at;
   }

   @Generated
   public static PlanSelectionBuilder builder() {
      return new PlanSelectionBuilder();
   }

   @Generated
   public String getId() {
      return this.id;
   }

   @Nullable
   @Generated
   public String getAt() {
      return this.at;
   }

   @Generated
   public static class PlanSelectionBuilder {
      @Generated
      private String id;
      @Generated
      private String at;

      @Generated
      PlanSelectionBuilder() {
      }

      @Generated
      public PlanSelectionBuilder id(String id) {
         this.id = id;
         return this;
      }

      @Generated
      public PlanSelectionBuilder at(@Nullable String at) {
         this.at = at;
         return this;
      }

      @Generated
      public PlanSelection build() {
         return new PlanSelection(this.id, this.at);
      }

      @Generated
      public String toString() {
         return "PlanSelection.PlanSelectionBuilder(id=" + this.id + ", at=" + this.at + ")";
      }
   }
}
