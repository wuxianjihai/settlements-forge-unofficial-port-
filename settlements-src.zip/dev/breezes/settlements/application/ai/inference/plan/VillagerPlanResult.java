package dev.breezes.settlements.application.ai.inference.plan;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import lombok.Generated;

public final class VillagerPlanResult {
   private final UUID villagerId;
   private final Map<String, List<PlanSelection>> selections;

   @Generated
   VillagerPlanResult(UUID villagerId, Map<String, List<PlanSelection>> selections) {
      this.villagerId = villagerId;
      this.selections = selections;
   }

   @Generated
   public static VillagerPlanResultBuilder builder() {
      return new VillagerPlanResultBuilder();
   }

   @Generated
   public UUID getVillagerId() {
      return this.villagerId;
   }

   @Generated
   public Map<String, List<PlanSelection>> getSelections() {
      return this.selections;
   }

   @Generated
   public static class VillagerPlanResultBuilder {
      @Generated
      private UUID villagerId;
      @Generated
      private ArrayList<String> selections$key;
      @Generated
      private ArrayList<List<PlanSelection>> selections$value;

      @Generated
      VillagerPlanResultBuilder() {
      }

      @Generated
      public VillagerPlanResultBuilder villagerId(UUID villagerId) {
         this.villagerId = villagerId;
         return this;
      }

      @Generated
      public VillagerPlanResultBuilder selection(String selectionKey, List<PlanSelection> selectionValue) {
         if (this.selections$key == null) {
            this.selections$key = new ArrayList();
            this.selections$value = new ArrayList();
         }

         this.selections$key.add(selectionKey);
         this.selections$value.add(selectionValue);
         return this;
      }

      @Generated
      public VillagerPlanResultBuilder selections(Map<? extends String, ? extends List<PlanSelection>> selections) {
         if (selections == null) {
            throw new NullPointerException("selections cannot be null");
         } else {
            if (this.selections$key == null) {
               this.selections$key = new ArrayList();
               this.selections$value = new ArrayList();
            }

            for(Map.Entry<? extends String, ? extends List<PlanSelection>> $lombokEntry : selections.entrySet()) {
               this.selections$key.add((String)$lombokEntry.getKey());
               this.selections$value.add((List)$lombokEntry.getValue());
            }

            return this;
         }
      }

      @Generated
      public VillagerPlanResultBuilder clearSelections() {
         if (this.selections$key != null) {
            this.selections$key.clear();
            this.selections$value.clear();
         }

         return this;
      }

      @Generated
      public VillagerPlanResult build() {
         Map<String, List<PlanSelection>> selections;
         switch (this.selections$key == null ? 0 : this.selections$key.size()) {
            case 0:
               selections = Collections.emptyMap();
               break;
            case 1:
               selections = Collections.singletonMap((String)this.selections$key.get(0), (List)this.selections$value.get(0));
               break;
            default:
               selections = new LinkedHashMap(this.selections$key.size() < 1073741824 ? 1 + this.selections$key.size() + (this.selections$key.size() - 3) / 3 : Integer.MAX_VALUE);

               for(int $i = 0; $i < this.selections$key.size(); ++$i) {
                  selections.put((String)this.selections$key.get($i), (List)this.selections$value.get($i));
               }

               selections = Collections.unmodifiableMap(selections);
         }

         return new VillagerPlanResult(this.villagerId, selections);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.villagerId);
         return "VillagerPlanResult.VillagerPlanResultBuilder(villagerId=" + var10000 + ", selections$key=" + String.valueOf(this.selections$key) + ", selections$value=" + String.valueOf(this.selections$value) + ")";
      }
   }
}
