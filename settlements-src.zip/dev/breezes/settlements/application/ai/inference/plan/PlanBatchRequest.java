package dev.breezes.settlements.application.ai.inference.plan;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import lombok.Generated;

public final class PlanBatchRequest {
   private final List<VillagerPlanRequest> villagers;

   @Generated
   PlanBatchRequest(List<VillagerPlanRequest> villagers) {
      this.villagers = villagers;
   }

   @Generated
   public static PlanBatchRequestBuilder builder() {
      return new PlanBatchRequestBuilder();
   }

   @Generated
   public List<VillagerPlanRequest> getVillagers() {
      return this.villagers;
   }

   @Generated
   public static class PlanBatchRequestBuilder {
      @Generated
      private ArrayList<VillagerPlanRequest> villagers;

      @Generated
      PlanBatchRequestBuilder() {
      }

      @Generated
      public PlanBatchRequestBuilder villager(VillagerPlanRequest villager) {
         if (this.villagers == null) {
            this.villagers = new ArrayList();
         }

         this.villagers.add(villager);
         return this;
      }

      @Generated
      public PlanBatchRequestBuilder villagers(Collection<? extends VillagerPlanRequest> villagers) {
         if (villagers == null) {
            throw new NullPointerException("villagers cannot be null");
         } else {
            if (this.villagers == null) {
               this.villagers = new ArrayList();
            }

            this.villagers.addAll(villagers);
            return this;
         }
      }

      @Generated
      public PlanBatchRequestBuilder clearVillagers() {
         if (this.villagers != null) {
            this.villagers.clear();
         }

         return this;
      }

      @Generated
      public PlanBatchRequest build() {
         List<VillagerPlanRequest> villagers;
         switch (this.villagers == null ? 0 : this.villagers.size()) {
            case 0 -> villagers = Collections.emptyList();
            case 1 -> villagers = Collections.singletonList((VillagerPlanRequest)this.villagers.get(0));
            default -> villagers = Collections.unmodifiableList(new ArrayList(this.villagers));
         }

         return new PlanBatchRequest(villagers);
      }

      @Generated
      public String toString() {
         return "PlanBatchRequest.PlanBatchRequestBuilder(villagers=" + String.valueOf(this.villagers) + ")";
      }
   }
}
