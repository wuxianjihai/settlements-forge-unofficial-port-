package dev.breezes.settlements.application.ai.inference.plan;

import lombok.Generated;

public final class DemandDTO {
   private final String token;
   private final int shortfall;
   private final int priority;

   @Generated
   DemandDTO(String token, int shortfall, int priority) {
      this.token = token;
      this.shortfall = shortfall;
      this.priority = priority;
   }

   @Generated
   public static DemandDTOBuilder builder() {
      return new DemandDTOBuilder();
   }

   @Generated
   public String getToken() {
      return this.token;
   }

   @Generated
   public int getShortfall() {
      return this.shortfall;
   }

   @Generated
   public int getPriority() {
      return this.priority;
   }

   @Generated
   public static class DemandDTOBuilder {
      @Generated
      private String token;
      @Generated
      private int shortfall;
      @Generated
      private int priority;

      @Generated
      DemandDTOBuilder() {
      }

      @Generated
      public DemandDTOBuilder token(String token) {
         this.token = token;
         return this;
      }

      @Generated
      public DemandDTOBuilder shortfall(int shortfall) {
         this.shortfall = shortfall;
         return this;
      }

      @Generated
      public DemandDTOBuilder priority(int priority) {
         this.priority = priority;
         return this;
      }

      @Generated
      public DemandDTO build() {
         return new DemandDTO(this.token, this.shortfall, this.priority);
      }

      @Generated
      public String toString() {
         return "DemandDTO.DemandDTOBuilder(token=" + this.token + ", shortfall=" + this.shortfall + ", priority=" + this.priority + ")";
      }
   }
}
