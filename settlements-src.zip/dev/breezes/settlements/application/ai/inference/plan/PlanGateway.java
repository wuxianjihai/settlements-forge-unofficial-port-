package dev.breezes.settlements.application.ai.inference.plan;

import dev.breezes.settlements.application.ai.inference.InferenceStreamHandle;
import java.time.Duration;
import java.util.function.Consumer;

public interface PlanGateway {
   InferenceStreamHandle generate(PlanBatchRequest var1, Duration var2, Consumer<VillagerPlanResult> var3);
}
