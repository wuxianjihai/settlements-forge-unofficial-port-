package dev.breezes.settlements.application.ai.inference.plan;

import lombok.Generated;

public final class SurplusDTO {
   private final String token;
   private final int sellable;
   private final int dumpable;

   @Generated
   SurplusDTO(String token, int sellable, int dumpable) {
      this.token = token;
      this.sellable = sellable;
      this.dumpable = dumpable;
   }

   @Generated
   public static SurplusDTOBuilder builder() {
      return new SurplusDTOBuilder();
   }

   @Generated
   public String getToken() {
      return this.token;
   }

   @Generated
   public int getSellable() {
      return this.sellable;
   }

   @Generated
   public int getDumpable() {
      return this.dumpable;
   }

   @Generated
   public static class SurplusDTOBuilder {
      @Generated
      private String token;
      @Generated
      private int sellable;
      @Generated
      private int dumpable;

      @Generated
      SurplusDTOBuilder() {
      }

      @Generated
      public SurplusDTOBuilder token(String token) {
         this.token = token;
         return this;
      }

      @Generated
      public SurplusDTOBuilder sellable(int sellable) {
         this.sellable = sellable;
         return this;
      }

      @Generated
      public SurplusDTOBuilder dumpable(int dumpable) {
         this.dumpable = dumpable;
         return this;
      }

      @Generated
      public SurplusDTO build() {
         return new SurplusDTO(this.token, this.sellable, this.dumpable);
      }

      @Generated
      public String toString() {
         return "SurplusDTO.SurplusDTOBuilder(token=" + this.token + ", sellable=" + this.sellable + ", dumpable=" + this.dumpable + ")";
      }
   }
}
