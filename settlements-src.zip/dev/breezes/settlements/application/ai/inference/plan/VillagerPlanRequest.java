package dev.breezes.settlements.application.ai.inference.plan;

import dev.breezes.settlements.application.ai.inference.monologue.EpisodicEntryDTO;
import dev.breezes.settlements.application.ai.inference.monologue.PersonaBundle;
import dev.breezes.settlements.application.ai.inference.monologue.Snapshot;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import lombok.Generated;

public final class VillagerPlanRequest {
   private final UUID villagerId;
   private final PersonaBundle persona;
   private final Snapshot snapshot;
   private final List<EpisodicEntryDTO> episodic;
   private final String dayType;
   private final List<BehaviorOptionDTO> options;
   private final List<PlanWindowDTO> windows;
   private final Map<String, Integer> wallet;
   private final float hunger;
   private final Map<String, Integer> inventory;
   private final List<DemandDTO> demands;
   private final List<SurplusDTO> surplus;

   @Generated
   VillagerPlanRequest(UUID villagerId, PersonaBundle persona, Snapshot snapshot, List<EpisodicEntryDTO> episodic, String dayType, List<BehaviorOptionDTO> options, List<PlanWindowDTO> windows, Map<String, Integer> wallet, float hunger, Map<String, Integer> inventory, List<DemandDTO> demands, List<SurplusDTO> surplus) {
      this.villagerId = villagerId;
      this.persona = persona;
      this.snapshot = snapshot;
      this.episodic = episodic;
      this.dayType = dayType;
      this.options = options;
      this.windows = windows;
      this.wallet = wallet;
      this.hunger = hunger;
      this.inventory = inventory;
      this.demands = demands;
      this.surplus = surplus;
   }

   @Generated
   public static VillagerPlanRequestBuilder builder() {
      return new VillagerPlanRequestBuilder();
   }

   @Generated
   public UUID getVillagerId() {
      return this.villagerId;
   }

   @Generated
   public PersonaBundle getPersona() {
      return this.persona;
   }

   @Generated
   public Snapshot getSnapshot() {
      return this.snapshot;
   }

   @Generated
   public List<EpisodicEntryDTO> getEpisodic() {
      return this.episodic;
   }

   @Generated
   public String getDayType() {
      return this.dayType;
   }

   @Generated
   public List<BehaviorOptionDTO> getOptions() {
      return this.options;
   }

   @Generated
   public List<PlanWindowDTO> getWindows() {
      return this.windows;
   }

   @Generated
   public Map<String, Integer> getWallet() {
      return this.wallet;
   }

   @Generated
   public float getHunger() {
      return this.hunger;
   }

   @Generated
   public Map<String, Integer> getInventory() {
      return this.inventory;
   }

   @Generated
   public List<DemandDTO> getDemands() {
      return this.demands;
   }

   @Generated
   public List<SurplusDTO> getSurplus() {
      return this.surplus;
   }

   @Generated
   public static class VillagerPlanRequestBuilder {
      @Generated
      private UUID villagerId;
      @Generated
      private PersonaBundle persona;
      @Generated
      private Snapshot snapshot;
      @Generated
      private ArrayList<EpisodicEntryDTO> episodic;
      @Generated
      private String dayType;
      @Generated
      private ArrayList<BehaviorOptionDTO> options;
      @Generated
      private ArrayList<PlanWindowDTO> windows;
      @Generated
      private Map<String, Integer> wallet;
      @Generated
      private float hunger;
      @Generated
      private Map<String, Integer> inventory;
      @Generated
      private ArrayList<DemandDTO> demands;
      @Generated
      private ArrayList<SurplusDTO> surplus;

      @Generated
      VillagerPlanRequestBuilder() {
      }

      @Generated
      public VillagerPlanRequestBuilder villagerId(UUID villagerId) {
         this.villagerId = villagerId;
         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder persona(PersonaBundle persona) {
         this.persona = persona;
         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder snapshot(Snapshot snapshot) {
         this.snapshot = snapshot;
         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder episodic(EpisodicEntryDTO episodic) {
         if (this.episodic == null) {
            this.episodic = new ArrayList();
         }

         this.episodic.add(episodic);
         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder episodic(Collection<? extends EpisodicEntryDTO> episodic) {
         if (episodic == null) {
            throw new NullPointerException("episodic cannot be null");
         } else {
            if (this.episodic == null) {
               this.episodic = new ArrayList();
            }

            this.episodic.addAll(episodic);
            return this;
         }
      }

      @Generated
      public VillagerPlanRequestBuilder clearEpisodic() {
         if (this.episodic != null) {
            this.episodic.clear();
         }

         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder dayType(String dayType) {
         this.dayType = dayType;
         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder option(BehaviorOptionDTO option) {
         if (this.options == null) {
            this.options = new ArrayList();
         }

         this.options.add(option);
         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder options(Collection<? extends BehaviorOptionDTO> options) {
         if (options == null) {
            throw new NullPointerException("options cannot be null");
         } else {
            if (this.options == null) {
               this.options = new ArrayList();
            }

            this.options.addAll(options);
            return this;
         }
      }

      @Generated
      public VillagerPlanRequestBuilder clearOptions() {
         if (this.options != null) {
            this.options.clear();
         }

         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder window(PlanWindowDTO window) {
         if (this.windows == null) {
            this.windows = new ArrayList();
         }

         this.windows.add(window);
         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder windows(Collection<? extends PlanWindowDTO> windows) {
         if (windows == null) {
            throw new NullPointerException("windows cannot be null");
         } else {
            if (this.windows == null) {
               this.windows = new ArrayList();
            }

            this.windows.addAll(windows);
            return this;
         }
      }

      @Generated
      public VillagerPlanRequestBuilder clearWindows() {
         if (this.windows != null) {
            this.windows.clear();
         }

         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder wallet(Map<String, Integer> wallet) {
         this.wallet = wallet;
         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder hunger(float hunger) {
         this.hunger = hunger;
         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder inventory(Map<String, Integer> inventory) {
         this.inventory = inventory;
         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder demand(DemandDTO demand) {
         if (this.demands == null) {
            this.demands = new ArrayList();
         }

         this.demands.add(demand);
         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder demands(Collection<? extends DemandDTO> demands) {
         if (demands == null) {
            throw new NullPointerException("demands cannot be null");
         } else {
            if (this.demands == null) {
               this.demands = new ArrayList();
            }

            this.demands.addAll(demands);
            return this;
         }
      }

      @Generated
      public VillagerPlanRequestBuilder clearDemands() {
         if (this.demands != null) {
            this.demands.clear();
         }

         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder surplus(SurplusDTO surplus) {
         if (this.surplus == null) {
            this.surplus = new ArrayList();
         }

         this.surplus.add(surplus);
         return this;
      }

      @Generated
      public VillagerPlanRequestBuilder surplus(Collection<? extends SurplusDTO> surplus) {
         if (surplus == null) {
            throw new NullPointerException("surplus cannot be null");
         } else {
            if (this.surplus == null) {
               this.surplus = new ArrayList();
            }

            this.surplus.addAll(surplus);
            return this;
         }
      }

      @Generated
      public VillagerPlanRequestBuilder clearSurplus() {
         if (this.surplus != null) {
            this.surplus.clear();
         }

         return this;
      }

      @Generated
      public VillagerPlanRequest build() {
         List<EpisodicEntryDTO> episodic;
         switch (this.episodic == null ? 0 : this.episodic.size()) {
            case 0 -> episodic = Collections.emptyList();
            case 1 -> episodic = Collections.singletonList((EpisodicEntryDTO)this.episodic.get(0));
            default -> episodic = Collections.unmodifiableList(new ArrayList(this.episodic));
         }

         List<BehaviorOptionDTO> options;
         switch (this.options == null ? 0 : this.options.size()) {
            case 0 -> options = Collections.emptyList();
            case 1 -> options = Collections.singletonList((BehaviorOptionDTO)this.options.get(0));
            default -> options = Collections.unmodifiableList(new ArrayList(this.options));
         }

         List<PlanWindowDTO> windows;
         switch (this.windows == null ? 0 : this.windows.size()) {
            case 0 -> windows = Collections.emptyList();
            case 1 -> windows = Collections.singletonList((PlanWindowDTO)this.windows.get(0));
            default -> windows = Collections.unmodifiableList(new ArrayList(this.windows));
         }

         List<DemandDTO> demands;
         switch (this.demands == null ? 0 : this.demands.size()) {
            case 0 -> demands = Collections.emptyList();
            case 1 -> demands = Collections.singletonList((DemandDTO)this.demands.get(0));
            default -> demands = Collections.unmodifiableList(new ArrayList(this.demands));
         }

         List<SurplusDTO> surplus;
         switch (this.surplus == null ? 0 : this.surplus.size()) {
            case 0 -> surplus = Collections.emptyList();
            case 1 -> surplus = Collections.singletonList((SurplusDTO)this.surplus.get(0));
            default -> surplus = Collections.unmodifiableList(new ArrayList(this.surplus));
         }

         return new VillagerPlanRequest(this.villagerId, this.persona, this.snapshot, episodic, this.dayType, options, windows, this.wallet, this.hunger, this.inventory, demands, surplus);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.villagerId);
         return "VillagerPlanRequest.VillagerPlanRequestBuilder(villagerId=" + var10000 + ", persona=" + String.valueOf(this.persona) + ", snapshot=" + String.valueOf(this.snapshot) + ", episodic=" + String.valueOf(this.episodic) + ", dayType=" + this.dayType + ", options=" + String.valueOf(this.options) + ", windows=" + String.valueOf(this.windows) + ", wallet=" + String.valueOf(this.wallet) + ", hunger=" + this.hunger + ", inventory=" + String.valueOf(this.inventory) + ", demands=" + String.valueOf(this.demands) + ", surplus=" + String.valueOf(this.surplus) + ")";
      }
   }
}
