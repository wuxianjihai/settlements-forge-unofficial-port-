package dev.breezes.settlements.application.ai.inference;

import java.util.UUID;
import lombok.Generated;

final class InferenceRequestEnvelope {
   private final int protocolVersion;
   private final UUID requestId;
   private final InferenceCapability capability;
   private final long deadlineMillis;
   private final Object payload;

   @Generated
   InferenceRequestEnvelope(int protocolVersion, UUID requestId, InferenceCapability capability, long deadlineMillis, Object payload) {
      this.protocolVersion = protocolVersion;
      this.requestId = requestId;
      this.capability = capability;
      this.deadlineMillis = deadlineMillis;
      this.payload = payload;
   }

   @Generated
   public static InferenceRequestEnvelopeBuilder builder() {
      return new InferenceRequestEnvelopeBuilder();
   }

   @Generated
   public int getProtocolVersion() {
      return this.protocolVersion;
   }

   @Generated
   public UUID getRequestId() {
      return this.requestId;
   }

   @Generated
   public InferenceCapability getCapability() {
      return this.capability;
   }

   @Generated
   public long getDeadlineMillis() {
      return this.deadlineMillis;
   }

   @Generated
   public Object getPayload() {
      return this.payload;
   }

   @Generated
   public static class InferenceRequestEnvelopeBuilder {
      @Generated
      private int protocolVersion;
      @Generated
      private UUID requestId;
      @Generated
      private InferenceCapability capability;
      @Generated
      private long deadlineMillis;
      @Generated
      private Object payload;

      @Generated
      InferenceRequestEnvelopeBuilder() {
      }

      @Generated
      public InferenceRequestEnvelopeBuilder protocolVersion(int protocolVersion) {
         this.protocolVersion = protocolVersion;
         return this;
      }

      @Generated
      public InferenceRequestEnvelopeBuilder requestId(UUID requestId) {
         this.requestId = requestId;
         return this;
      }

      @Generated
      public InferenceRequestEnvelopeBuilder capability(InferenceCapability capability) {
         this.capability = capability;
         return this;
      }

      @Generated
      public InferenceRequestEnvelopeBuilder deadlineMillis(long deadlineMillis) {
         this.deadlineMillis = deadlineMillis;
         return this;
      }

      @Generated
      public InferenceRequestEnvelopeBuilder payload(Object payload) {
         this.payload = payload;
         return this;
      }

      @Generated
      public InferenceRequestEnvelope build() {
         return new InferenceRequestEnvelope(this.protocolVersion, this.requestId, this.capability, this.deadlineMillis, this.payload);
      }

      @Generated
      public String toString() {
         int var10000 = this.protocolVersion;
         return "InferenceRequestEnvelope.InferenceRequestEnvelopeBuilder(protocolVersion=" + var10000 + ", requestId=" + String.valueOf(this.requestId) + ", capability=" + String.valueOf(this.capability) + ", deadlineMillis=" + this.deadlineMillis + ", payload=" + String.valueOf(this.payload) + ")";
      }
   }
}
