package dev.breezes.settlements.application.ai.inference;

import lombok.Generated;

public enum InferenceCapability {
   MONOLOGUE("/v1/monologue"),
   PERSONA("/v1/persona"),
   PLAN("/v1/plan");

   private final String path;

   @Generated
   private InferenceCapability(String path) {
      this.path = path;
   }

   @Generated
   public String getPath() {
      return this.path;
   }

   // $FF: synthetic method
   private static InferenceCapability[] $values() {
      return new InferenceCapability[]{MONOLOGUE, PERSONA, PLAN};
   }
}
