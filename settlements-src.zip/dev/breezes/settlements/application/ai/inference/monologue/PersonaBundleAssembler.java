package dev.breezes.settlements.application.ai.inference.monologue;

import dev.breezes.settlements.application.ai.dialogue.DialogueFacet;
import dev.breezes.settlements.application.ai.naming.VillagerNameResolver;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.genetics.GeneSignal;
import dev.breezes.settlements.domain.personality.PersonalityStatus;
import dev.breezes.settlements.domain.personality.VillagerPersonality;
import dev.breezes.settlements.infrastructure.minecraft.attachments.VillagerPersonalityAttachment;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Objects;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;

@ServerScope
public final class PersonaBundleAssembler {
   private final VillagerNameResolver nameResolver;
   private final VillagerFacetDeriver facetDeriver;

   public PersonaBundle assemble(@Nonnull BaseVillager villager) {
      List<DialogueFacet> facets = this.facetDeriver.derive(villager);
      Anchors anchors = buildAnchors(villager);
      PersonaBundle.PersonaBundleBuilder builder = PersonaBundle.builder().name(this.nameResolver.resolve(villager.m_20148_())).profession(villager.getProfession().id()).geneSignals(GeneSignal.allFrom(villager.getGenetics())).anchors(anchors);
      Objects.requireNonNull(builder);
      facets.forEach(builder::facet);
      applyPersonaEnrichment(villager, builder);
      return builder.build();
   }

   private static void applyPersonaEnrichment(@Nonnull BaseVillager villager, PersonaBundle.PersonaBundleBuilder builder) {
      VillagerPersonality personality = VillagerPersonalityAttachment.read(villager);
      if (personality.status() == PersonalityStatus.READY) {
         if (!personality.speechStyle().isBlank()) {
            builder.speechStyle(personality.speechStyle());
         }

         if (!personality.characterSketch().isBlank()) {
            builder.characterSketch(personality.characterSketch());
         }

      }
   }

   private static Anchors buildAnchors(@Nonnull BaseVillager villager) {
      BlockPos body = villager.m_20183_();
      int[] jobSitePos = (int[])villager.m_6274_().m_21952_(MemoryModuleType.f_26360_).map(GlobalPos::m_122646_).map(PersonaBundleAssembler::toCoords).orElse((Object)null);
      int[] homePos = (int[])villager.m_6274_().m_21952_(MemoryModuleType.f_26359_).map(GlobalPos::m_122646_).map(PersonaBundleAssembler::toCoords).orElse((Object)null);
      return Anchors.builder().body(toCoords(body)).jobSite(jobSitePos).home(homePos).build();
   }

   private static int[] toCoords(@Nonnull BlockPos pos) {
      return new int[]{pos.m_123341_(), pos.m_123342_(), pos.m_123343_()};
   }

   @Inject
   @Generated
   PersonaBundleAssembler(VillagerNameResolver nameResolver, VillagerFacetDeriver facetDeriver) {
      this.nameResolver = nameResolver;
      this.facetDeriver = facetDeriver;
   }
}
