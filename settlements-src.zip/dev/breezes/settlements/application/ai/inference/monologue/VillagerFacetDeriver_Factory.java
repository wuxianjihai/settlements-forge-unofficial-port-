package dev.breezes.settlements.application.ai.inference.monologue;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class VillagerFacetDeriver_Factory implements Factory<VillagerFacetDeriver> {
   public VillagerFacetDeriver get() {
      return newInstance();
   }

   public static VillagerFacetDeriver_Factory create() {
      return VillagerFacetDeriver_Factory.InstanceHolder.INSTANCE;
   }

   public static VillagerFacetDeriver newInstance() {
      return new VillagerFacetDeriver();
   }

   private static final class InstanceHolder {
      static final VillagerFacetDeriver_Factory INSTANCE = new VillagerFacetDeriver_Factory();
   }
}
