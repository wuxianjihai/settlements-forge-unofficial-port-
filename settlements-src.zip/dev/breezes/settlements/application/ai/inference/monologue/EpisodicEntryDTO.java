package dev.breezes.settlements.application.ai.inference.monologue;

import java.util.Arrays;
import java.util.Map;
import javax.annotation.Nullable;
import lombok.Generated;

public final class EpisodicEntryDTO {
   private final String eventType;
   private final String perspective;
   @Nullable
   private final String actor;
   @Nullable
   private final String target;
   @Nullable
   private final String source;
   @Nullable
   private final String outcome;
   @Nullable
   private final String reason;
   @Nullable
   private final Map<String, String> detail;
   @Nullable
   private final int[] pos;
   private final int hop;
   private final long ageTicks;

   @Generated
   EpisodicEntryDTO(String eventType, String perspective, @Nullable String actor, @Nullable String target, @Nullable String source, @Nullable String outcome, @Nullable String reason, @Nullable Map<String, String> detail, @Nullable int[] pos, int hop, long ageTicks) {
      this.eventType = eventType;
      this.perspective = perspective;
      this.actor = actor;
      this.target = target;
      this.source = source;
      this.outcome = outcome;
      this.reason = reason;
      this.detail = detail;
      this.pos = pos;
      this.hop = hop;
      this.ageTicks = ageTicks;
   }

   @Generated
   public static EpisodicEntryDTOBuilder builder() {
      return new EpisodicEntryDTOBuilder();
   }

   @Generated
   public String getEventType() {
      return this.eventType;
   }

   @Generated
   public String getPerspective() {
      return this.perspective;
   }

   @Nullable
   @Generated
   public String getActor() {
      return this.actor;
   }

   @Nullable
   @Generated
   public String getTarget() {
      return this.target;
   }

   @Nullable
   @Generated
   public String getSource() {
      return this.source;
   }

   @Nullable
   @Generated
   public String getOutcome() {
      return this.outcome;
   }

   @Nullable
   @Generated
   public String getReason() {
      return this.reason;
   }

   @Nullable
   @Generated
   public Map<String, String> getDetail() {
      return this.detail;
   }

   @Nullable
   @Generated
   public int[] getPos() {
      return this.pos;
   }

   @Generated
   public int getHop() {
      return this.hop;
   }

   @Generated
   public long getAgeTicks() {
      return this.ageTicks;
   }

   @Generated
   public static class EpisodicEntryDTOBuilder {
      @Generated
      private String eventType;
      @Generated
      private String perspective;
      @Generated
      private String actor;
      @Generated
      private String target;
      @Generated
      private String source;
      @Generated
      private String outcome;
      @Generated
      private String reason;
      @Generated
      private Map<String, String> detail;
      @Generated
      private int[] pos;
      @Generated
      private int hop;
      @Generated
      private long ageTicks;

      @Generated
      EpisodicEntryDTOBuilder() {
      }

      @Generated
      public EpisodicEntryDTOBuilder eventType(String eventType) {
         this.eventType = eventType;
         return this;
      }

      @Generated
      public EpisodicEntryDTOBuilder perspective(String perspective) {
         this.perspective = perspective;
         return this;
      }

      @Generated
      public EpisodicEntryDTOBuilder actor(@Nullable String actor) {
         this.actor = actor;
         return this;
      }

      @Generated
      public EpisodicEntryDTOBuilder target(@Nullable String target) {
         this.target = target;
         return this;
      }

      @Generated
      public EpisodicEntryDTOBuilder source(@Nullable String source) {
         this.source = source;
         return this;
      }

      @Generated
      public EpisodicEntryDTOBuilder outcome(@Nullable String outcome) {
         this.outcome = outcome;
         return this;
      }

      @Generated
      public EpisodicEntryDTOBuilder reason(@Nullable String reason) {
         this.reason = reason;
         return this;
      }

      @Generated
      public EpisodicEntryDTOBuilder detail(@Nullable Map<String, String> detail) {
         this.detail = detail;
         return this;
      }

      @Generated
      public EpisodicEntryDTOBuilder pos(@Nullable int[] pos) {
         this.pos = pos;
         return this;
      }

      @Generated
      public EpisodicEntryDTOBuilder hop(int hop) {
         this.hop = hop;
         return this;
      }

      @Generated
      public EpisodicEntryDTOBuilder ageTicks(long ageTicks) {
         this.ageTicks = ageTicks;
         return this;
      }

      @Generated
      public EpisodicEntryDTO build() {
         return new EpisodicEntryDTO(this.eventType, this.perspective, this.actor, this.target, this.source, this.outcome, this.reason, this.detail, this.pos, this.hop, this.ageTicks);
      }

      @Generated
      public String toString() {
         String var10000 = this.eventType;
         return "EpisodicEntryDTO.EpisodicEntryDTOBuilder(eventType=" + var10000 + ", perspective=" + this.perspective + ", actor=" + this.actor + ", target=" + this.target + ", source=" + this.source + ", outcome=" + this.outcome + ", reason=" + this.reason + ", detail=" + String.valueOf(this.detail) + ", pos=" + Arrays.toString(this.pos) + ", hop=" + this.hop + ", ageTicks=" + this.ageTicks + ")";
      }
   }
}
