package dev.breezes.settlements.application.ai.inference.monologue;

import dev.breezes.settlements.application.ai.dialogue.Occasion;
import lombok.Generated;

public final class OccasionBucketSpec {
   private final Occasion occasion;
   private final int lineCount;

   @Generated
   OccasionBucketSpec(Occasion occasion, int lineCount) {
      this.occasion = occasion;
      this.lineCount = lineCount;
   }

   @Generated
   public static OccasionBucketSpecBuilder builder() {
      return new OccasionBucketSpecBuilder();
   }

   @Generated
   public Occasion getOccasion() {
      return this.occasion;
   }

   @Generated
   public int getLineCount() {
      return this.lineCount;
   }

   @Generated
   public static class OccasionBucketSpecBuilder {
      @Generated
      private Occasion occasion;
      @Generated
      private int lineCount;

      @Generated
      OccasionBucketSpecBuilder() {
      }

      @Generated
      public OccasionBucketSpecBuilder occasion(Occasion occasion) {
         this.occasion = occasion;
         return this;
      }

      @Generated
      public OccasionBucketSpecBuilder lineCount(int lineCount) {
         this.lineCount = lineCount;
         return this;
      }

      @Generated
      public OccasionBucketSpec build() {
         return new OccasionBucketSpec(this.occasion, this.lineCount);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.occasion);
         return "OccasionBucketSpec.OccasionBucketSpecBuilder(occasion=" + var10000 + ", lineCount=" + this.lineCount + ")";
      }
   }
}
