package dev.breezes.settlements.application.ai.inference.monologue;

import dev.breezes.settlements.application.ai.dialogue.Occasion;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import lombok.Generated;

public final class VillagerMonologueResult {
   private final UUID villagerId;
   private final Map<Occasion, List<String>> buckets;

   @Generated
   VillagerMonologueResult(UUID villagerId, Map<Occasion, List<String>> buckets) {
      this.villagerId = villagerId;
      this.buckets = buckets;
   }

   @Generated
   public static VillagerMonologueResultBuilder builder() {
      return new VillagerMonologueResultBuilder();
   }

   @Generated
   public UUID getVillagerId() {
      return this.villagerId;
   }

   @Generated
   public Map<Occasion, List<String>> getBuckets() {
      return this.buckets;
   }

   @Generated
   public static class VillagerMonologueResultBuilder {
      @Generated
      private UUID villagerId;
      @Generated
      private ArrayList<Occasion> buckets$key;
      @Generated
      private ArrayList<List<String>> buckets$value;

      @Generated
      VillagerMonologueResultBuilder() {
      }

      @Generated
      public VillagerMonologueResultBuilder villagerId(UUID villagerId) {
         this.villagerId = villagerId;
         return this;
      }

      @Generated
      public VillagerMonologueResultBuilder bucket(Occasion bucketKey, List<String> bucketValue) {
         if (this.buckets$key == null) {
            this.buckets$key = new ArrayList();
            this.buckets$value = new ArrayList();
         }

         this.buckets$key.add(bucketKey);
         this.buckets$value.add(bucketValue);
         return this;
      }

      @Generated
      public VillagerMonologueResultBuilder buckets(Map<? extends Occasion, ? extends List<String>> buckets) {
         if (buckets == null) {
            throw new NullPointerException("buckets cannot be null");
         } else {
            if (this.buckets$key == null) {
               this.buckets$key = new ArrayList();
               this.buckets$value = new ArrayList();
            }

            for(Map.Entry<? extends Occasion, ? extends List<String>> $lombokEntry : buckets.entrySet()) {
               this.buckets$key.add((Occasion)$lombokEntry.getKey());
               this.buckets$value.add((List)$lombokEntry.getValue());
            }

            return this;
         }
      }

      @Generated
      public VillagerMonologueResultBuilder clearBuckets() {
         if (this.buckets$key != null) {
            this.buckets$key.clear();
            this.buckets$value.clear();
         }

         return this;
      }

      @Generated
      public VillagerMonologueResult build() {
         Map<Occasion, List<String>> buckets;
         switch (this.buckets$key == null ? 0 : this.buckets$key.size()) {
            case 0:
               buckets = Collections.emptyMap();
               break;
            case 1:
               buckets = Collections.singletonMap((Occasion)this.buckets$key.get(0), (List)this.buckets$value.get(0));
               break;
            default:
               buckets = new LinkedHashMap(this.buckets$key.size() < 1073741824 ? 1 + this.buckets$key.size() + (this.buckets$key.size() - 3) / 3 : Integer.MAX_VALUE);

               for(int $i = 0; $i < this.buckets$key.size(); ++$i) {
                  buckets.put((Occasion)this.buckets$key.get($i), (List)this.buckets$value.get($i));
               }

               buckets = Collections.unmodifiableMap(buckets);
         }

         return new VillagerMonologueResult(this.villagerId, buckets);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.villagerId);
         return "VillagerMonologueResult.VillagerMonologueResultBuilder(villagerId=" + var10000 + ", buckets$key=" + String.valueOf(this.buckets$key) + ", buckets$value=" + String.valueOf(this.buckets$value) + ")";
      }
   }
}
