package dev.breezes.settlements.application.ai.inference.monologue;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.naming.VillagerNameResolver;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class PersonaBundleAssembler_Factory implements Factory<PersonaBundleAssembler> {
   private final Provider<VillagerNameResolver> nameResolverProvider;
   private final Provider<VillagerFacetDeriver> facetDeriverProvider;

   private PersonaBundleAssembler_Factory(Provider<VillagerNameResolver> nameResolverProvider, Provider<VillagerFacetDeriver> facetDeriverProvider) {
      this.nameResolverProvider = nameResolverProvider;
      this.facetDeriverProvider = facetDeriverProvider;
   }

   public PersonaBundleAssembler get() {
      return newInstance((VillagerNameResolver)this.nameResolverProvider.get(), (VillagerFacetDeriver)this.facetDeriverProvider.get());
   }

   public static PersonaBundleAssembler_Factory create(Provider<VillagerNameResolver> nameResolverProvider, Provider<VillagerFacetDeriver> facetDeriverProvider) {
      return new PersonaBundleAssembler_Factory(nameResolverProvider, facetDeriverProvider);
   }

   public static PersonaBundleAssembler newInstance(VillagerNameResolver nameResolver, VillagerFacetDeriver facetDeriver) {
      return new PersonaBundleAssembler(nameResolver, facetDeriver);
   }
}
