package dev.breezes.settlements.application.ai.inference.monologue;

import dev.breezes.settlements.application.ai.inference.InferenceStreamHandle;
import java.time.Duration;
import java.util.function.Consumer;

public interface MonologueGateway {
   InferenceStreamHandle generate(MonologueBatchRequest var1, Duration var2, Consumer<VillagerMonologueResult> var3);
}
