package dev.breezes.settlements.application.ai.inference.monologue;

import dev.breezes.settlements.application.ai.dialogue.Occasion;
import dev.breezes.settlements.application.ai.dialogue.RehearsedDialogueConfig;
import dev.breezes.settlements.application.ai.inference.InferenceConfig;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import javax.annotation.Nonnull;
import lombok.Generated;

@ServerScope
public final class MonologueRequestAssembler {
   private final PersonaBundleAssembler personaBundleAssembler;
   private final SnapshotAssembler snapshotAssembler;
   private final InferenceConfig inferenceConfig;
   private final RehearsedDialogueConfig rehearsedDialogueConfig;
   private final EpisodicEntryAssembler episodicEntryAssembler;

   public MonologueBatchRequest assembleForVillager(@Nonnull BaseVillager villager, @Nonnull Collection<Occasion> occasions) {
      VillagerMonologueRequest villagerRequest = this.buildVillagerRequest(villager, occasions);
      return MonologueBatchRequest.builder().locale(this.inferenceConfig.locale()).villager(villagerRequest).build();
   }

   public MonologueBatchRequest assembleForVillagers(@Nonnull Map<BaseVillager, Collection<Occasion>> villagersWithOccasions) {
      MonologueBatchRequest.MonologueBatchRequestBuilder builder = MonologueBatchRequest.builder().locale(this.inferenceConfig.locale());

      for(Map.Entry<BaseVillager, Collection<Occasion>> entry : villagersWithOccasions.entrySet()) {
         builder.villager(this.buildVillagerRequest((BaseVillager)entry.getKey(), (Collection)entry.getValue()));
      }

      return builder.build();
   }

   private VillagerMonologueRequest buildVillagerRequest(@Nonnull BaseVillager villager, @Nonnull Collection<Occasion> occasions) {
      List<OccasionBucketSpec> buckets = occasions.stream().map((occasion) -> OccasionBucketSpec.builder().occasion(occasion).lineCount(this.rehearsedDialogueConfig.packLinesPerVillager()).build()).toList();
      Snapshot snapshot = this.snapshotAssembler.assemble(villager);
      UUID villagerId = villager.m_20148_();
      long currentTick = villager.m_9236_().m_46467_();
      List<EpisodicEntryDTO> episodic = this.episodicEntryAssembler.assemble(villagerId, villager.getKnowledgeStore(), currentTick);
      VillagerMonologueRequest.VillagerMonologueRequestBuilder requestBuilder = VillagerMonologueRequest.builder().villagerId(villagerId).persona(this.personaBundleAssembler.assemble(villager)).snapshot(snapshot);
      Objects.requireNonNull(requestBuilder);
      buckets.forEach(requestBuilder::bucket);
      Objects.requireNonNull(requestBuilder);
      episodic.forEach(requestBuilder::episodic);
      return requestBuilder.build();
   }

   @Inject
   @Generated
   MonologueRequestAssembler(PersonaBundleAssembler personaBundleAssembler, SnapshotAssembler snapshotAssembler, InferenceConfig inferenceConfig, RehearsedDialogueConfig rehearsedDialogueConfig, EpisodicEntryAssembler episodicEntryAssembler) {
      this.personaBundleAssembler = personaBundleAssembler;
      this.snapshotAssembler = snapshotAssembler;
      this.inferenceConfig = inferenceConfig;
      this.rehearsedDialogueConfig = rehearsedDialogueConfig;
      this.episodicEntryAssembler = episodicEntryAssembler;
   }
}
