package dev.breezes.settlements.application.ai.inference.monologue;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.memory.SensedSiteReader;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class SnapshotAssembler_Factory implements Factory<SnapshotAssembler> {
   private final Provider<SensedSiteReader> sensedSiteReaderProvider;

   private SnapshotAssembler_Factory(Provider<SensedSiteReader> sensedSiteReaderProvider) {
      this.sensedSiteReaderProvider = sensedSiteReaderProvider;
   }

   public SnapshotAssembler get() {
      return newInstance((SensedSiteReader)this.sensedSiteReaderProvider.get());
   }

   public static SnapshotAssembler_Factory create(Provider<SensedSiteReader> sensedSiteReaderProvider) {
      return new SnapshotAssembler_Factory(sensedSiteReaderProvider);
   }

   public static SnapshotAssembler newInstance(SensedSiteReader sensedSiteReader) {
      return new SnapshotAssembler(sensedSiteReader);
   }
}
