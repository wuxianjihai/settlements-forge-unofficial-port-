package dev.breezes.settlements.application.ai.inference.monologue;

import com.google.gson.Gson;
import dev.breezes.settlements.application.ai.dialogue.Occasion;
import dev.breezes.settlements.application.ai.inference.InferenceCapability;
import dev.breezes.settlements.application.ai.inference.InferenceStreamHandle;
import dev.breezes.settlements.application.ai.inference.InferenceTransport;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class HttpMonologueGateway implements MonologueGateway {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(HttpMonologueGateway.class.getName());
   private static final Gson GSON = new Gson();
   private final InferenceTransport transport;

   public InferenceStreamHandle generate(@Nonnull MonologueBatchRequest request, @Nonnull Duration deadline, @Nonnull Consumer<VillagerMonologueResult> onVillager) {
      return this.transport.postStreaming(InferenceCapability.MONOLOGUE, request, deadline, (line) -> this.parseLine(line, onVillager));
   }

   private void parseLine(String line, Consumer<VillagerMonologueResult> onVillager) {
      String trimmed = line.strip();
      if (!trimmed.isEmpty()) {
         try {
            VillagerMonologueResult result = (VillagerMonologueResult)GSON.fromJson(trimmed, VillagerMonologueResult.class);
            if (result != null && result.getVillagerId() != null) {
               onVillager.accept(normalizeVillager(result));
            }
         } catch (RuntimeException e) {
            log.error("MONOLOGUE response line parse failed: {}", e.getMessage());
         }

      }
   }

   private static VillagerMonologueResult normalizeVillager(VillagerMonologueResult villager) {
      return VillagerMonologueResult.builder().villagerId(villager.getVillagerId()).buckets(normalizeBuckets(villager.getBuckets())).build();
   }

   private static Map<Occasion, List<String>> normalizeBuckets(Map<Occasion, List<String>> buckets) {
      return buckets == null ? Map.of() : (Map)buckets.entrySet().stream().filter((entry) -> entry.getValue() != null).collect(Collectors.toMap(Map.Entry::getKey, (entry) -> ((List)entry.getValue()).stream().filter(Objects::nonNull).toList()));
   }

   @Inject
   @Generated
   HttpMonologueGateway(InferenceTransport transport) {
      this.transport = transport;
   }
}
