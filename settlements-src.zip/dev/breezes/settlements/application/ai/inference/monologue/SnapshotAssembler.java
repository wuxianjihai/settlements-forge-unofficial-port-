package dev.breezes.settlements.application.ai.inference.monologue;

import dev.breezes.settlements.application.ai.memory.SensedSiteReader;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.memory.MemoryType;
import dev.breezes.settlements.domain.ai.memory.SensedSites;
import dev.breezes.settlements.domain.ai.memory.SiteCoord;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.GlobalPos;

@ServerScope
public final class SnapshotAssembler {
   private static final String SITE_IDENTIFIER_SUFFIX = "_sites";
   private final SensedSiteReader sensedSiteReader;

   public Snapshot assemble(@Nonnull BaseVillager villager) {
      SensedSites sensedSites = this.sensedSiteReader.read(villager.getSettlementsBrain());
      return toSnapshot(sensedSites);
   }

   static Snapshot toSnapshot(@Nonnull SensedSites sensedSites) {
      Snapshot.SnapshotBuilder builder = Snapshot.builder();

      for(Map.Entry<MemoryType<List<GlobalPos>>, List<SiteCoord>> entry : sensedSites.coordsByType().entrySet()) {
         String token = toWireToken(((MemoryType)entry.getKey()).identifier());
         List<int[]> coords = ((List)entry.getValue()).stream().map((coord) -> new int[]{coord.x(), coord.y(), coord.z()}).toList();
         builder.site(token, coords);
      }

      return builder.build();
   }

   static String toWireToken(@Nonnull String identifier) {
      String base = identifier;
      if (identifier.endsWith("_sites")) {
         base = identifier.substring(0, identifier.length() - "_sites".length());
      }

      return base.toUpperCase(Locale.ROOT);
   }

   @Inject
   @Generated
   SnapshotAssembler(SensedSiteReader sensedSiteReader) {
      this.sensedSiteReader = sensedSiteReader;
   }
}
