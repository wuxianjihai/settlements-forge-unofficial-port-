package dev.breezes.settlements.application.ai.inference.monologue;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.inference.InferenceTransport;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class HttpMonologueGateway_Factory implements Factory<HttpMonologueGateway> {
   private final Provider<InferenceTransport> transportProvider;

   private HttpMonologueGateway_Factory(Provider<InferenceTransport> transportProvider) {
      this.transportProvider = transportProvider;
   }

   public HttpMonologueGateway get() {
      return newInstance((InferenceTransport)this.transportProvider.get());
   }

   public static HttpMonologueGateway_Factory create(Provider<InferenceTransport> transportProvider) {
      return new HttpMonologueGateway_Factory(transportProvider);
   }

   public static HttpMonologueGateway newInstance(InferenceTransport transport) {
      return new HttpMonologueGateway(transport);
   }
}
