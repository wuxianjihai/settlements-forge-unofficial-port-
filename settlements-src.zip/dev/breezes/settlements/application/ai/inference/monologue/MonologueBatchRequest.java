package dev.breezes.settlements.application.ai.inference.monologue;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import lombok.Generated;

public final class MonologueBatchRequest {
   private final String locale;
   private final List<VillagerMonologueRequest> villagers;

   @Generated
   MonologueBatchRequest(String locale, List<VillagerMonologueRequest> villagers) {
      this.locale = locale;
      this.villagers = villagers;
   }

   @Generated
   public static MonologueBatchRequestBuilder builder() {
      return new MonologueBatchRequestBuilder();
   }

   @Generated
   public String getLocale() {
      return this.locale;
   }

   @Generated
   public List<VillagerMonologueRequest> getVillagers() {
      return this.villagers;
   }

   @Generated
   public static class MonologueBatchRequestBuilder {
      @Generated
      private String locale;
      @Generated
      private ArrayList<VillagerMonologueRequest> villagers;

      @Generated
      MonologueBatchRequestBuilder() {
      }

      @Generated
      public MonologueBatchRequestBuilder locale(String locale) {
         this.locale = locale;
         return this;
      }

      @Generated
      public MonologueBatchRequestBuilder villager(VillagerMonologueRequest villager) {
         if (this.villagers == null) {
            this.villagers = new ArrayList();
         }

         this.villagers.add(villager);
         return this;
      }

      @Generated
      public MonologueBatchRequestBuilder villagers(Collection<? extends VillagerMonologueRequest> villagers) {
         if (villagers == null) {
            throw new NullPointerException("villagers cannot be null");
         } else {
            if (this.villagers == null) {
               this.villagers = new ArrayList();
            }

            this.villagers.addAll(villagers);
            return this;
         }
      }

      @Generated
      public MonologueBatchRequestBuilder clearVillagers() {
         if (this.villagers != null) {
            this.villagers.clear();
         }

         return this;
      }

      @Generated
      public MonologueBatchRequest build() {
         List<VillagerMonologueRequest> villagers;
         switch (this.villagers == null ? 0 : this.villagers.size()) {
            case 0 -> villagers = Collections.emptyList();
            case 1 -> villagers = Collections.singletonList((VillagerMonologueRequest)this.villagers.get(0));
            default -> villagers = Collections.unmodifiableList(new ArrayList(this.villagers));
         }

         return new MonologueBatchRequest(this.locale, villagers);
      }

      @Generated
      public String toString() {
         String var10000 = this.locale;
         return "MonologueBatchRequest.MonologueBatchRequestBuilder(locale=" + var10000 + ", villagers=" + String.valueOf(this.villagers) + ")";
      }
   }
}
