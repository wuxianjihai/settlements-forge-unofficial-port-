package dev.breezes.settlements.application.ai.inference.monologue;

import dev.breezes.settlements.application.ai.inference.InferenceConfig;
import dev.breezes.settlements.application.ai.naming.VillagerNameResolver;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.knowledge.KnowledgeEntry;
import dev.breezes.settlements.domain.ai.knowledge.VillagerKnowledgeStore;
import dev.breezes.settlements.domain.ai.memory.PackedPos;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

@ServerScope
public final class EpisodicEntryAssembler {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(EpisodicEntryAssembler.class.getName());
   private static final String PERSPECTIVE_PARTICIPANT = "FIRST_HAND_PARTICIPANT";
   private static final String PERSPECTIVE_BYSTANDER = "FIRST_HAND_BYSTANDER";
   private static final String PERSPECTIVE_HEARSAY = "HEARSAY";
   private static final Comparator<KnowledgeEntry> WEIGHT_DESC = Comparator.comparingDouble(KnowledgeEntry::getWeight).reversed();
   private static final Comparator<KnowledgeEntry> ADMITTED_AT_TICK_DESC = Comparator.comparingLong(KnowledgeEntry::getAdmittedAtTick).reversed();
   private final VillagerNameResolver nameResolver;
   private final InferenceConfig inferenceConfig;

   public List<EpisodicEntryDTO> assemble(UUID observerId, VillagerKnowledgeStore store, long currentTick) {
      Map<UUID, ResolvedEntry> bestByOriginId = new HashMap();

      for(KnowledgeEntry entry : store.entriesView()) {
         WorldEventType eventType = resolveEventType(entry);
         if (eventType != null && eventType.isSeedWorthy()) {
            UUID originId = entry.getOriginObservationId();
            ResolvedEntry existing = (ResolvedEntry)bestByOriginId.get(originId);
            if (existing == null || isBetterCandidate(entry, existing.entry())) {
               bestByOriginId.put(originId, new ResolvedEntry(entry, eventType));
            }
         }
      }

      return bestByOriginId.values().stream().sorted(Comparator.comparing(ResolvedEntry::entry, WEIGHT_DESC.thenComparing(ADMITTED_AT_TICK_DESC))).limit((long)this.inferenceConfig.maxEpisodicEntries()).map((resolved) -> this.toDto(observerId, resolved, currentTick)).toList();
   }

   private EpisodicEntryDTO toDto(UUID observerId, ResolvedEntry resolved, long currentTick) {
      KnowledgeEntry entry = resolved.entry();
      WorldEventType eventType = resolved.eventType();
      String perspective = derivePerspective(entry, observerId);
      long ageTicks = Math.max(0L, currentTick - entry.getAdmittedAtTick());
      return EpisodicEntryDTO.builder().eventType(eventType.name()).perspective(perspective).actor(this.resolveActor(entry, perspective)).target(this.resolveTarget(entry, eventType)).source(this.resolveSource(entry)).outcome((String)entry.getMetadata().get("outcome")).reason((String)entry.getMetadata().get("reason")).detail(collectDetailMap(entry.getMetadata())).pos(resolvePos(entry.getPackedPos())).hop(entry.getHop()).ageTicks(ageTicks).build();
   }

   @Nullable
   private static Map<String, String> collectDetailMap(@Nonnull Map<String, String> metadata) {
      Map<String, String> result = null;

      for(Map.Entry<String, String> entry : metadata.entrySet()) {
         if (((String)entry.getKey()).startsWith("detail.")) {
            if (result == null) {
               result = new HashMap();
            }

            result.put(((String)entry.getKey()).substring("detail.".length()), (String)entry.getValue());
         }
      }

      return result;
   }

   @Nullable
   private static int[] resolvePos(@Nullable Long packedPos) {
      return packedPos == null ? null : new int[]{PackedPos.x(packedPos), PackedPos.y(packedPos), PackedPos.z(packedPos)};
   }

   private static String derivePerspective(KnowledgeEntry entry, UUID observerId) {
      if (entry.isHearsay()) {
         return "HEARSAY";
      } else {
         UUID actorId = parseUuid((String)entry.getMetadata().get("actor_id"));
         return actorId != null && !observerId.equals(actorId) ? "FIRST_HAND_BYSTANDER" : "FIRST_HAND_PARTICIPANT";
      }
   }

   @Nullable
   private String resolveActor(KnowledgeEntry entry, String perspective) {
      if ("FIRST_HAND_PARTICIPANT".equals(perspective)) {
         return null;
      } else {
         UUID actorId = parseUuid((String)entry.getMetadata().get("actor_id"));
         return actorId != null ? this.nameResolver.resolve(actorId) : null;
      }
   }

   @Nullable
   private String resolveTarget(KnowledgeEntry entry, WorldEventType eventType) {
      boolean isNamableTarget = eventType == WorldEventType.TRADE_COMPLETED || eventType == WorldEventType.COURTSHIP_CHILD_BIRTH || eventType == WorldEventType.COURTSHIP_DATE_COMPLETED || eventType == WorldEventType.COURTSHIP_REJECTED || eventType == WorldEventType.EMERALDS_DONATED;
      if (!isNamableTarget) {
         return null;
      } else {
         UUID targetId = entry.getRelatedEntity();
         return targetId != null ? this.nameResolver.resolve(targetId) : null;
      }
   }

   @Nullable
   private String resolveSource(KnowledgeEntry entry) {
      return !entry.isHearsay() ? null : this.nameResolver.resolve(entry.getSource());
   }

   private static boolean isBetterCandidate(KnowledgeEntry candidate, KnowledgeEntry existing) {
      if (candidate.getHop() != existing.getHop()) {
         return candidate.getHop() < existing.getHop();
      } else {
         return candidate.getWeight() > existing.getWeight();
      }
   }

   @Nullable
   private static WorldEventType resolveEventType(KnowledgeEntry entry) {
      String rawType = (String)entry.getMetadata().get("event_type");
      if (rawType != null && !rawType.isBlank()) {
         try {
            return WorldEventType.valueOf(rawType);
         } catch (IllegalArgumentException var3) {
            log.info("Skipping episodic entry with unrecognized world event type: {}", rawType);
            return null;
         }
      } else {
         return null;
      }
   }

   @Nullable
   private static UUID parseUuid(@Nullable String raw) {
      if (raw != null && !raw.isBlank()) {
         try {
            return UUID.fromString(raw);
         } catch (IllegalArgumentException e) {
            log.error("Failed to parse UUID: {}", raw, e);
            return null;
         }
      } else {
         return null;
      }
   }

   @Inject
   @Generated
   EpisodicEntryAssembler(VillagerNameResolver nameResolver, InferenceConfig inferenceConfig) {
      this.nameResolver = nameResolver;
      this.inferenceConfig = inferenceConfig;
   }

   private static record ResolvedEntry(KnowledgeEntry entry, WorldEventType eventType) {
   }
}
