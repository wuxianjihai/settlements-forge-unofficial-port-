package dev.breezes.settlements.application.ai.inference.monologue;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.dialogue.RehearsedDialogueConfig;
import dev.breezes.settlements.application.ai.inference.InferenceConfig;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class MonologueRequestAssembler_Factory implements Factory<MonologueRequestAssembler> {
   private final Provider<PersonaBundleAssembler> personaBundleAssemblerProvider;
   private final Provider<SnapshotAssembler> snapshotAssemblerProvider;
   private final Provider<InferenceConfig> inferenceConfigProvider;
   private final Provider<RehearsedDialogueConfig> rehearsedDialogueConfigProvider;
   private final Provider<EpisodicEntryAssembler> episodicEntryAssemblerProvider;

   private MonologueRequestAssembler_Factory(Provider<PersonaBundleAssembler> personaBundleAssemblerProvider, Provider<SnapshotAssembler> snapshotAssemblerProvider, Provider<InferenceConfig> inferenceConfigProvider, Provider<RehearsedDialogueConfig> rehearsedDialogueConfigProvider, Provider<EpisodicEntryAssembler> episodicEntryAssemblerProvider) {
      this.personaBundleAssemblerProvider = personaBundleAssemblerProvider;
      this.snapshotAssemblerProvider = snapshotAssemblerProvider;
      this.inferenceConfigProvider = inferenceConfigProvider;
      this.rehearsedDialogueConfigProvider = rehearsedDialogueConfigProvider;
      this.episodicEntryAssemblerProvider = episodicEntryAssemblerProvider;
   }

   public MonologueRequestAssembler get() {
      return newInstance((PersonaBundleAssembler)this.personaBundleAssemblerProvider.get(), (SnapshotAssembler)this.snapshotAssemblerProvider.get(), (InferenceConfig)this.inferenceConfigProvider.get(), (RehearsedDialogueConfig)this.rehearsedDialogueConfigProvider.get(), (EpisodicEntryAssembler)this.episodicEntryAssemblerProvider.get());
   }

   public static MonologueRequestAssembler_Factory create(Provider<PersonaBundleAssembler> personaBundleAssemblerProvider, Provider<SnapshotAssembler> snapshotAssemblerProvider, Provider<InferenceConfig> inferenceConfigProvider, Provider<RehearsedDialogueConfig> rehearsedDialogueConfigProvider, Provider<EpisodicEntryAssembler> episodicEntryAssemblerProvider) {
      return new MonologueRequestAssembler_Factory(personaBundleAssemblerProvider, snapshotAssemblerProvider, inferenceConfigProvider, rehearsedDialogueConfigProvider, episodicEntryAssemblerProvider);
   }

   public static MonologueRequestAssembler newInstance(PersonaBundleAssembler personaBundleAssembler, SnapshotAssembler snapshotAssembler, InferenceConfig inferenceConfig, RehearsedDialogueConfig rehearsedDialogueConfig, EpisodicEntryAssembler episodicEntryAssembler) {
      return new MonologueRequestAssembler(personaBundleAssembler, snapshotAssembler, inferenceConfig, rehearsedDialogueConfig, episodicEntryAssembler);
   }
}
