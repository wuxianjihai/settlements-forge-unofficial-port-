package dev.breezes.settlements.application.ai.inference.monologue;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import lombok.Generated;

public final class VillagerMonologueRequest {
   private final UUID villagerId;
   private final PersonaBundle persona;
   private final Snapshot snapshot;
   private final List<OccasionBucketSpec> buckets;
   private final List<EpisodicEntryDTO> episodic;

   @Generated
   VillagerMonologueRequest(UUID villagerId, PersonaBundle persona, Snapshot snapshot, List<OccasionBucketSpec> buckets, List<EpisodicEntryDTO> episodic) {
      this.villagerId = villagerId;
      this.persona = persona;
      this.snapshot = snapshot;
      this.buckets = buckets;
      this.episodic = episodic;
   }

   @Generated
   public static VillagerMonologueRequestBuilder builder() {
      return new VillagerMonologueRequestBuilder();
   }

   @Generated
   public UUID getVillagerId() {
      return this.villagerId;
   }

   @Generated
   public PersonaBundle getPersona() {
      return this.persona;
   }

   @Generated
   public Snapshot getSnapshot() {
      return this.snapshot;
   }

   @Generated
   public List<OccasionBucketSpec> getBuckets() {
      return this.buckets;
   }

   @Generated
   public List<EpisodicEntryDTO> getEpisodic() {
      return this.episodic;
   }

   @Generated
   public static class VillagerMonologueRequestBuilder {
      @Generated
      private UUID villagerId;
      @Generated
      private PersonaBundle persona;
      @Generated
      private Snapshot snapshot;
      @Generated
      private ArrayList<OccasionBucketSpec> buckets;
      @Generated
      private ArrayList<EpisodicEntryDTO> episodic;

      @Generated
      VillagerMonologueRequestBuilder() {
      }

      @Generated
      public VillagerMonologueRequestBuilder villagerId(UUID villagerId) {
         this.villagerId = villagerId;
         return this;
      }

      @Generated
      public VillagerMonologueRequestBuilder persona(PersonaBundle persona) {
         this.persona = persona;
         return this;
      }

      @Generated
      public VillagerMonologueRequestBuilder snapshot(Snapshot snapshot) {
         this.snapshot = snapshot;
         return this;
      }

      @Generated
      public VillagerMonologueRequestBuilder bucket(OccasionBucketSpec bucket) {
         if (this.buckets == null) {
            this.buckets = new ArrayList();
         }

         this.buckets.add(bucket);
         return this;
      }

      @Generated
      public VillagerMonologueRequestBuilder buckets(Collection<? extends OccasionBucketSpec> buckets) {
         if (buckets == null) {
            throw new NullPointerException("buckets cannot be null");
         } else {
            if (this.buckets == null) {
               this.buckets = new ArrayList();
            }

            this.buckets.addAll(buckets);
            return this;
         }
      }

      @Generated
      public VillagerMonologueRequestBuilder clearBuckets() {
         if (this.buckets != null) {
            this.buckets.clear();
         }

         return this;
      }

      @Generated
      public VillagerMonologueRequestBuilder episodic(EpisodicEntryDTO episodic) {
         if (this.episodic == null) {
            this.episodic = new ArrayList();
         }

         this.episodic.add(episodic);
         return this;
      }

      @Generated
      public VillagerMonologueRequestBuilder episodic(Collection<? extends EpisodicEntryDTO> episodic) {
         if (episodic == null) {
            throw new NullPointerException("episodic cannot be null");
         } else {
            if (this.episodic == null) {
               this.episodic = new ArrayList();
            }

            this.episodic.addAll(episodic);
            return this;
         }
      }

      @Generated
      public VillagerMonologueRequestBuilder clearEpisodic() {
         if (this.episodic != null) {
            this.episodic.clear();
         }

         return this;
      }

      @Generated
      public VillagerMonologueRequest build() {
         List<OccasionBucketSpec> buckets;
         switch (this.buckets == null ? 0 : this.buckets.size()) {
            case 0 -> buckets = Collections.emptyList();
            case 1 -> buckets = Collections.singletonList((OccasionBucketSpec)this.buckets.get(0));
            default -> buckets = Collections.unmodifiableList(new ArrayList(this.buckets));
         }

         List<EpisodicEntryDTO> episodic;
         switch (this.episodic == null ? 0 : this.episodic.size()) {
            case 0 -> episodic = Collections.emptyList();
            case 1 -> episodic = Collections.singletonList((EpisodicEntryDTO)this.episodic.get(0));
            default -> episodic = Collections.unmodifiableList(new ArrayList(this.episodic));
         }

         return new VillagerMonologueRequest(this.villagerId, this.persona, this.snapshot, buckets, episodic);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.villagerId);
         return "VillagerMonologueRequest.VillagerMonologueRequestBuilder(villagerId=" + var10000 + ", persona=" + String.valueOf(this.persona) + ", snapshot=" + String.valueOf(this.snapshot) + ", buckets=" + String.valueOf(this.buckets) + ", episodic=" + String.valueOf(this.episodic) + ")";
      }
   }
}
