package dev.breezes.settlements.application.ai.inference.monologue;

import dev.breezes.settlements.application.ai.dialogue.DialogueFacet;
import dev.breezes.settlements.domain.genetics.GeneSignal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import lombok.Generated;

public final class PersonaBundle {
   private final String name;
   private final String profession;
   private final List<GeneSignal> geneSignals;
   private final String speechStyle;
   private final String characterSketch;
   private final List<DialogueFacet> facets;
   private final Anchors anchors;

   @Generated
   PersonaBundle(String name, String profession, List<GeneSignal> geneSignals, String speechStyle, String characterSketch, List<DialogueFacet> facets, Anchors anchors) {
      this.name = name;
      this.profession = profession;
      this.geneSignals = geneSignals;
      this.speechStyle = speechStyle;
      this.characterSketch = characterSketch;
      this.facets = facets;
      this.anchors = anchors;
   }

   @Generated
   public static PersonaBundleBuilder builder() {
      return new PersonaBundleBuilder();
   }

   @Generated
   public String getName() {
      return this.name;
   }

   @Generated
   public String getProfession() {
      return this.profession;
   }

   @Generated
   public List<GeneSignal> getGeneSignals() {
      return this.geneSignals;
   }

   @Generated
   public String getSpeechStyle() {
      return this.speechStyle;
   }

   @Generated
   public String getCharacterSketch() {
      return this.characterSketch;
   }

   @Generated
   public List<DialogueFacet> getFacets() {
      return this.facets;
   }

   @Generated
   public Anchors getAnchors() {
      return this.anchors;
   }

   @Generated
   public static class PersonaBundleBuilder {
      @Generated
      private String name;
      @Generated
      private String profession;
      @Generated
      private ArrayList<GeneSignal> geneSignals;
      @Generated
      private String speechStyle;
      @Generated
      private String characterSketch;
      @Generated
      private ArrayList<DialogueFacet> facets;
      @Generated
      private Anchors anchors;

      @Generated
      PersonaBundleBuilder() {
      }

      @Generated
      public PersonaBundleBuilder name(String name) {
         this.name = name;
         return this;
      }

      @Generated
      public PersonaBundleBuilder profession(String profession) {
         this.profession = profession;
         return this;
      }

      @Generated
      public PersonaBundleBuilder geneSignal(GeneSignal geneSignal) {
         if (this.geneSignals == null) {
            this.geneSignals = new ArrayList();
         }

         this.geneSignals.add(geneSignal);
         return this;
      }

      @Generated
      public PersonaBundleBuilder geneSignals(Collection<? extends GeneSignal> geneSignals) {
         if (geneSignals == null) {
            throw new NullPointerException("geneSignals cannot be null");
         } else {
            if (this.geneSignals == null) {
               this.geneSignals = new ArrayList();
            }

            this.geneSignals.addAll(geneSignals);
            return this;
         }
      }

      @Generated
      public PersonaBundleBuilder clearGeneSignals() {
         if (this.geneSignals != null) {
            this.geneSignals.clear();
         }

         return this;
      }

      @Generated
      public PersonaBundleBuilder speechStyle(String speechStyle) {
         this.speechStyle = speechStyle;
         return this;
      }

      @Generated
      public PersonaBundleBuilder characterSketch(String characterSketch) {
         this.characterSketch = characterSketch;
         return this;
      }

      @Generated
      public PersonaBundleBuilder facet(DialogueFacet facet) {
         if (this.facets == null) {
            this.facets = new ArrayList();
         }

         this.facets.add(facet);
         return this;
      }

      @Generated
      public PersonaBundleBuilder facets(Collection<? extends DialogueFacet> facets) {
         if (facets == null) {
            throw new NullPointerException("facets cannot be null");
         } else {
            if (this.facets == null) {
               this.facets = new ArrayList();
            }

            this.facets.addAll(facets);
            return this;
         }
      }

      @Generated
      public PersonaBundleBuilder clearFacets() {
         if (this.facets != null) {
            this.facets.clear();
         }

         return this;
      }

      @Generated
      public PersonaBundleBuilder anchors(Anchors anchors) {
         this.anchors = anchors;
         return this;
      }

      @Generated
      public PersonaBundle build() {
         List<GeneSignal> geneSignals;
         switch (this.geneSignals == null ? 0 : this.geneSignals.size()) {
            case 0 -> geneSignals = Collections.emptyList();
            case 1 -> geneSignals = Collections.singletonList((GeneSignal)this.geneSignals.get(0));
            default -> geneSignals = Collections.unmodifiableList(new ArrayList(this.geneSignals));
         }

         List<DialogueFacet> facets;
         switch (this.facets == null ? 0 : this.facets.size()) {
            case 0 -> facets = Collections.emptyList();
            case 1 -> facets = Collections.singletonList((DialogueFacet)this.facets.get(0));
            default -> facets = Collections.unmodifiableList(new ArrayList(this.facets));
         }

         return new PersonaBundle(this.name, this.profession, geneSignals, this.speechStyle, this.characterSketch, facets, this.anchors);
      }

      @Generated
      public String toString() {
         String var10000 = this.name;
         return "PersonaBundle.PersonaBundleBuilder(name=" + var10000 + ", profession=" + this.profession + ", geneSignals=" + String.valueOf(this.geneSignals) + ", speechStyle=" + this.speechStyle + ", characterSketch=" + this.characterSketch + ", facets=" + String.valueOf(this.facets) + ", anchors=" + String.valueOf(this.anchors) + ")";
      }
   }
}
