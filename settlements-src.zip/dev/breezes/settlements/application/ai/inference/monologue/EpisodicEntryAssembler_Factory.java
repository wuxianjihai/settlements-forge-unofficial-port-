package dev.breezes.settlements.application.ai.inference.monologue;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.inference.InferenceConfig;
import dev.breezes.settlements.application.ai.naming.VillagerNameResolver;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class EpisodicEntryAssembler_Factory implements Factory<EpisodicEntryAssembler> {
   private final Provider<VillagerNameResolver> nameResolverProvider;
   private final Provider<InferenceConfig> inferenceConfigProvider;

   private EpisodicEntryAssembler_Factory(Provider<VillagerNameResolver> nameResolverProvider, Provider<InferenceConfig> inferenceConfigProvider) {
      this.nameResolverProvider = nameResolverProvider;
      this.inferenceConfigProvider = inferenceConfigProvider;
   }

   public EpisodicEntryAssembler get() {
      return newInstance((VillagerNameResolver)this.nameResolverProvider.get(), (InferenceConfig)this.inferenceConfigProvider.get());
   }

   public static EpisodicEntryAssembler_Factory create(Provider<VillagerNameResolver> nameResolverProvider, Provider<InferenceConfig> inferenceConfigProvider) {
      return new EpisodicEntryAssembler_Factory(nameResolverProvider, inferenceConfigProvider);
   }

   public static EpisodicEntryAssembler newInstance(VillagerNameResolver nameResolver, InferenceConfig inferenceConfig) {
      return new EpisodicEntryAssembler(nameResolver, inferenceConfig);
   }
}
