package dev.breezes.settlements.application.ai.inference.monologue;

import dev.breezes.settlements.application.ai.dialogue.DialogueFacet;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.infrastructure.minecraft.attachments.VillagerWasCuredAttachment;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nonnull;
import lombok.Generated;

@ServerScope
public final class VillagerFacetDeriver {
   public List<DialogueFacet> derive(@Nonnull BaseVillager villager) {
      List<DialogueFacet> facets = new ArrayList();
      if (VillagerWasCuredAttachment.wasCured(villager)) {
         facets.add(DialogueFacet.WAS_CURED);
      }

      return facets;
   }

   @Inject
   @Generated
   VillagerFacetDeriver() {
   }
}
