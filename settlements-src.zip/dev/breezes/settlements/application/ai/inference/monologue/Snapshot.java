package dev.breezes.settlements.application.ai.inference.monologue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.Generated;

public final class Snapshot {
   private final Map<String, List<int[]>> sites;

   @Generated
   Snapshot(Map<String, List<int[]>> sites) {
      this.sites = sites;
   }

   @Generated
   public static SnapshotBuilder builder() {
      return new SnapshotBuilder();
   }

   @Generated
   public Map<String, List<int[]>> getSites() {
      return this.sites;
   }

   @Generated
   public static class SnapshotBuilder {
      @Generated
      private ArrayList<String> sites$key;
      @Generated
      private ArrayList<List<int[]>> sites$value;

      @Generated
      SnapshotBuilder() {
      }

      @Generated
      public SnapshotBuilder site(String siteKey, List<int[]> siteValue) {
         if (this.sites$key == null) {
            this.sites$key = new ArrayList();
            this.sites$value = new ArrayList();
         }

         this.sites$key.add(siteKey);
         this.sites$value.add(siteValue);
         return this;
      }

      @Generated
      public SnapshotBuilder sites(Map<? extends String, ? extends List<int[]>> sites) {
         if (sites == null) {
            throw new NullPointerException("sites cannot be null");
         } else {
            if (this.sites$key == null) {
               this.sites$key = new ArrayList();
               this.sites$value = new ArrayList();
            }

            for(Map.Entry<? extends String, ? extends List<int[]>> $lombokEntry : sites.entrySet()) {
               this.sites$key.add((String)$lombokEntry.getKey());
               this.sites$value.add((List)$lombokEntry.getValue());
            }

            return this;
         }
      }

      @Generated
      public SnapshotBuilder clearSites() {
         if (this.sites$key != null) {
            this.sites$key.clear();
            this.sites$value.clear();
         }

         return this;
      }

      @Generated
      public Snapshot build() {
         Map<String, List<int[]>> sites;
         switch (this.sites$key == null ? 0 : this.sites$key.size()) {
            case 0:
               sites = Collections.emptyMap();
               break;
            case 1:
               sites = Collections.singletonMap((String)this.sites$key.get(0), (List)this.sites$value.get(0));
               break;
            default:
               sites = new LinkedHashMap(this.sites$key.size() < 1073741824 ? 1 + this.sites$key.size() + (this.sites$key.size() - 3) / 3 : Integer.MAX_VALUE);

               for(int $i = 0; $i < this.sites$key.size(); ++$i) {
                  sites.put((String)this.sites$key.get($i), (List)this.sites$value.get($i));
               }

               sites = Collections.unmodifiableMap(sites);
         }

         return new Snapshot(sites);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.sites$key);
         return "Snapshot.SnapshotBuilder(sites$key=" + var10000 + ", sites$value=" + String.valueOf(this.sites$value) + ")";
      }
   }
}
