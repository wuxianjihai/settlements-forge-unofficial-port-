package dev.breezes.settlements.application.ai.inference.monologue;

import java.util.Arrays;
import javax.annotation.Nullable;
import lombok.Generated;

public final class Anchors {
   private final int[] body;
   @Nullable
   private final int[] jobSite;
   @Nullable
   private final int[] home;

   @Generated
   Anchors(int[] body, @Nullable int[] jobSite, @Nullable int[] home) {
      this.body = body;
      this.jobSite = jobSite;
      this.home = home;
   }

   @Generated
   public static AnchorsBuilder builder() {
      return new AnchorsBuilder();
   }

   @Generated
   public int[] getBody() {
      return this.body;
   }

   @Nullable
   @Generated
   public int[] getJobSite() {
      return this.jobSite;
   }

   @Nullable
   @Generated
   public int[] getHome() {
      return this.home;
   }

   @Generated
   public static class AnchorsBuilder {
      @Generated
      private int[] body;
      @Generated
      private int[] jobSite;
      @Generated
      private int[] home;

      @Generated
      AnchorsBuilder() {
      }

      @Generated
      public AnchorsBuilder body(int[] body) {
         this.body = body;
         return this;
      }

      @Generated
      public AnchorsBuilder jobSite(@Nullable int[] jobSite) {
         this.jobSite = jobSite;
         return this;
      }

      @Generated
      public AnchorsBuilder home(@Nullable int[] home) {
         this.home = home;
         return this;
      }

      @Generated
      public Anchors build() {
         return new Anchors(this.body, this.jobSite, this.home);
      }

      @Generated
      public String toString() {
         String var10000 = Arrays.toString(this.body);
         return "Anchors.AnchorsBuilder(body=" + var10000 + ", jobSite=" + Arrays.toString(this.jobSite) + ", home=" + Arrays.toString(this.home) + ")";
      }
   }
}
