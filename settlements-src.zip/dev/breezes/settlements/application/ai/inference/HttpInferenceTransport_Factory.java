package dev.breezes.settlements.application.ai.inference;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class HttpInferenceTransport_Factory implements Factory<HttpInferenceTransport> {
   private final Provider<InferenceConfig> configProvider;

   private HttpInferenceTransport_Factory(Provider<InferenceConfig> configProvider) {
      this.configProvider = configProvider;
   }

   public HttpInferenceTransport get() {
      return newInstance((InferenceConfig)this.configProvider.get());
   }

   public static HttpInferenceTransport_Factory create(Provider<InferenceConfig> configProvider) {
      return new HttpInferenceTransport_Factory(configProvider);
   }

   public static HttpInferenceTransport newInstance(InferenceConfig config) {
      return new HttpInferenceTransport(config);
   }
}
