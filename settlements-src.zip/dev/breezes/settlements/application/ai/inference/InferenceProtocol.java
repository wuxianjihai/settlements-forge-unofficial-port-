package dev.breezes.settlements.application.ai.inference;

import lombok.Generated;

public final class InferenceProtocol {
   public static final int VERSION = 1;

   @Generated
   private InferenceProtocol() {
   }
}
