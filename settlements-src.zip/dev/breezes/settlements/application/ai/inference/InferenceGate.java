package dev.breezes.settlements.application.ai.inference;

import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.Generated;

@Singleton
public final class InferenceGate {
   private final InferenceConfig config;

   public boolean isEnabled() {
      return this.config.enabled() && this.config.hasEndpoint();
   }

   public boolean isMisconfigured() {
      return this.config.enabled() && !this.config.hasEndpoint();
   }

   @Inject
   @Generated
   InferenceGate(InferenceConfig config) {
      this.config = config;
   }
}
