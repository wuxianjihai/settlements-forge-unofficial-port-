package dev.breezes.settlements.application.ai.inference.persona;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.domain.genetics.GeneSignal;
import dev.breezes.settlements.infrastructure.minecraft.attachments.VillagerOriginAttachment;
import dev.breezes.settlements.infrastructure.minecraft.attachments.VillagerPersonaLineageAttachment;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import javax.annotation.Nonnull;
import lombok.Generated;

@ServerScope
public final class PersonaRequestAssembler {
   public PersonaVillagerRequest assemble(@Nonnull BaseVillager villager) {
      PersonaLineage lineage = PersonaLineageMapper.toWire(VillagerPersonaLineageAttachment.read(villager));
      return PersonaVillagerRequest.builder().villagerId(villager.m_20148_()).spawnType(VillagerOriginAttachment.read(villager)).isNitwit(VillagerProfessionKey.NITWIT.equals(villager.getProfession())).geneSignals(GeneSignal.allFrom(villager.getGenetics())).lineage(lineage).build();
   }

   @Inject
   @Generated
   PersonaRequestAssembler() {
   }
}
