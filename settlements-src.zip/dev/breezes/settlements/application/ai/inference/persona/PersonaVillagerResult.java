package dev.breezes.settlements.application.ai.inference.persona;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import lombok.Generated;

public final class PersonaVillagerResult {
   private final UUID villagerId;
   private final List<String> adjectives;
   private final String characterSketch;
   @Nullable
   private final String speechStyle;

   @Generated
   PersonaVillagerResult(UUID villagerId, List<String> adjectives, String characterSketch, @Nullable String speechStyle) {
      this.villagerId = villagerId;
      this.adjectives = adjectives;
      this.characterSketch = characterSketch;
      this.speechStyle = speechStyle;
   }

   @Generated
   public static PersonaVillagerResultBuilder builder() {
      return new PersonaVillagerResultBuilder();
   }

   @Generated
   public UUID getVillagerId() {
      return this.villagerId;
   }

   @Generated
   public List<String> getAdjectives() {
      return this.adjectives;
   }

   @Generated
   public String getCharacterSketch() {
      return this.characterSketch;
   }

   @Nullable
   @Generated
   public String getSpeechStyle() {
      return this.speechStyle;
   }

   @Generated
   public static class PersonaVillagerResultBuilder {
      @Generated
      private UUID villagerId;
      @Generated
      private ArrayList<String> adjectives;
      @Generated
      private String characterSketch;
      @Generated
      private String speechStyle;

      @Generated
      PersonaVillagerResultBuilder() {
      }

      @Generated
      public PersonaVillagerResultBuilder villagerId(UUID villagerId) {
         this.villagerId = villagerId;
         return this;
      }

      @Generated
      public PersonaVillagerResultBuilder adjective(String adjective) {
         if (this.adjectives == null) {
            this.adjectives = new ArrayList();
         }

         this.adjectives.add(adjective);
         return this;
      }

      @Generated
      public PersonaVillagerResultBuilder adjectives(Collection<? extends String> adjectives) {
         if (adjectives == null) {
            throw new NullPointerException("adjectives cannot be null");
         } else {
            if (this.adjectives == null) {
               this.adjectives = new ArrayList();
            }

            this.adjectives.addAll(adjectives);
            return this;
         }
      }

      @Generated
      public PersonaVillagerResultBuilder clearAdjectives() {
         if (this.adjectives != null) {
            this.adjectives.clear();
         }

         return this;
      }

      @Generated
      public PersonaVillagerResultBuilder characterSketch(String characterSketch) {
         this.characterSketch = characterSketch;
         return this;
      }

      @Generated
      public PersonaVillagerResultBuilder speechStyle(@Nullable String speechStyle) {
         this.speechStyle = speechStyle;
         return this;
      }

      @Generated
      public PersonaVillagerResult build() {
         List<String> adjectives;
         switch (this.adjectives == null ? 0 : this.adjectives.size()) {
            case 0 -> adjectives = Collections.emptyList();
            case 1 -> adjectives = Collections.singletonList((String)this.adjectives.get(0));
            default -> adjectives = Collections.unmodifiableList(new ArrayList(this.adjectives));
         }

         return new PersonaVillagerResult(this.villagerId, adjectives, this.characterSketch, this.speechStyle);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.villagerId);
         return "PersonaVillagerResult.PersonaVillagerResultBuilder(villagerId=" + var10000 + ", adjectives=" + String.valueOf(this.adjectives) + ", characterSketch=" + this.characterSketch + ", speechStyle=" + this.speechStyle + ")";
      }
   }
}
