package dev.breezes.settlements.application.ai.inference.persona;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.inference.InferenceTransport;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
public final class HttpPersonaGateway_Factory implements Factory<HttpPersonaGateway> {
   private final Provider<InferenceTransport> transportProvider;

   private HttpPersonaGateway_Factory(Provider<InferenceTransport> transportProvider) {
      this.transportProvider = transportProvider;
   }

   public HttpPersonaGateway get() {
      return newInstance((InferenceTransport)this.transportProvider.get());
   }

   public static HttpPersonaGateway_Factory create(Provider<InferenceTransport> transportProvider) {
      return new HttpPersonaGateway_Factory(transportProvider);
   }

   public static HttpPersonaGateway newInstance(InferenceTransport transport) {
      return new HttpPersonaGateway(transport);
   }
}
