package dev.breezes.settlements.application.ai.inference.persona;

import dev.breezes.settlements.domain.genetics.GeneSignal;
import dev.breezes.settlements.domain.personality.OriginType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import lombok.Generated;

public final class PersonaVillagerRequest {
   private final UUID villagerId;
   private final OriginType spawnType;
   private final boolean isNitwit;
   private final List<GeneSignal> geneSignals;
   @Nullable
   private final PersonaLineage lineage;

   @Generated
   PersonaVillagerRequest(UUID villagerId, OriginType spawnType, boolean isNitwit, List<GeneSignal> geneSignals, @Nullable PersonaLineage lineage) {
      this.villagerId = villagerId;
      this.spawnType = spawnType;
      this.isNitwit = isNitwit;
      this.geneSignals = geneSignals;
      this.lineage = lineage;
   }

   @Generated
   public static PersonaVillagerRequestBuilder builder() {
      return new PersonaVillagerRequestBuilder();
   }

   @Generated
   public UUID getVillagerId() {
      return this.villagerId;
   }

   @Generated
   public OriginType getSpawnType() {
      return this.spawnType;
   }

   @Generated
   public boolean isNitwit() {
      return this.isNitwit;
   }

   @Generated
   public List<GeneSignal> getGeneSignals() {
      return this.geneSignals;
   }

   @Nullable
   @Generated
   public PersonaLineage getLineage() {
      return this.lineage;
   }

   @Generated
   public static class PersonaVillagerRequestBuilder {
      @Generated
      private UUID villagerId;
      @Generated
      private OriginType spawnType;
      @Generated
      private boolean isNitwit;
      @Generated
      private ArrayList<GeneSignal> geneSignals;
      @Generated
      private PersonaLineage lineage;

      @Generated
      PersonaVillagerRequestBuilder() {
      }

      @Generated
      public PersonaVillagerRequestBuilder villagerId(UUID villagerId) {
         this.villagerId = villagerId;
         return this;
      }

      @Generated
      public PersonaVillagerRequestBuilder spawnType(OriginType spawnType) {
         this.spawnType = spawnType;
         return this;
      }

      @Generated
      public PersonaVillagerRequestBuilder isNitwit(boolean isNitwit) {
         this.isNitwit = isNitwit;
         return this;
      }

      @Generated
      public PersonaVillagerRequestBuilder geneSignal(GeneSignal geneSignal) {
         if (this.geneSignals == null) {
            this.geneSignals = new ArrayList();
         }

         this.geneSignals.add(geneSignal);
         return this;
      }

      @Generated
      public PersonaVillagerRequestBuilder geneSignals(Collection<? extends GeneSignal> geneSignals) {
         if (geneSignals == null) {
            throw new NullPointerException("geneSignals cannot be null");
         } else {
            if (this.geneSignals == null) {
               this.geneSignals = new ArrayList();
            }

            this.geneSignals.addAll(geneSignals);
            return this;
         }
      }

      @Generated
      public PersonaVillagerRequestBuilder clearGeneSignals() {
         if (this.geneSignals != null) {
            this.geneSignals.clear();
         }

         return this;
      }

      @Generated
      public PersonaVillagerRequestBuilder lineage(@Nullable PersonaLineage lineage) {
         this.lineage = lineage;
         return this;
      }

      @Generated
      public PersonaVillagerRequest build() {
         List<GeneSignal> geneSignals;
         switch (this.geneSignals == null ? 0 : this.geneSignals.size()) {
            case 0 -> geneSignals = Collections.emptyList();
            case 1 -> geneSignals = Collections.singletonList((GeneSignal)this.geneSignals.get(0));
            default -> geneSignals = Collections.unmodifiableList(new ArrayList(this.geneSignals));
         }

         return new PersonaVillagerRequest(this.villagerId, this.spawnType, this.isNitwit, geneSignals, this.lineage);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.villagerId);
         return "PersonaVillagerRequest.PersonaVillagerRequestBuilder(villagerId=" + var10000 + ", spawnType=" + String.valueOf(this.spawnType) + ", isNitwit=" + this.isNitwit + ", geneSignals=" + String.valueOf(this.geneSignals) + ", lineage=" + String.valueOf(this.lineage) + ")";
      }
   }
}
