package dev.breezes.settlements.application.ai.inference.persona;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import lombok.Generated;

public final class PersonaBatchRequest {
   private final List<PersonaVillagerRequest> villagers;

   @Generated
   PersonaBatchRequest(List<PersonaVillagerRequest> villagers) {
      this.villagers = villagers;
   }

   @Generated
   public static PersonaBatchRequestBuilder builder() {
      return new PersonaBatchRequestBuilder();
   }

   @Generated
   public List<PersonaVillagerRequest> getVillagers() {
      return this.villagers;
   }

   @Generated
   public static class PersonaBatchRequestBuilder {
      @Generated
      private ArrayList<PersonaVillagerRequest> villagers;

      @Generated
      PersonaBatchRequestBuilder() {
      }

      @Generated
      public PersonaBatchRequestBuilder villager(PersonaVillagerRequest villager) {
         if (this.villagers == null) {
            this.villagers = new ArrayList();
         }

         this.villagers.add(villager);
         return this;
      }

      @Generated
      public PersonaBatchRequestBuilder villagers(Collection<? extends PersonaVillagerRequest> villagers) {
         if (villagers == null) {
            throw new NullPointerException("villagers cannot be null");
         } else {
            if (this.villagers == null) {
               this.villagers = new ArrayList();
            }

            this.villagers.addAll(villagers);
            return this;
         }
      }

      @Generated
      public PersonaBatchRequestBuilder clearVillagers() {
         if (this.villagers != null) {
            this.villagers.clear();
         }

         return this;
      }

      @Generated
      public PersonaBatchRequest build() {
         List<PersonaVillagerRequest> villagers;
         switch (this.villagers == null ? 0 : this.villagers.size()) {
            case 0 -> villagers = Collections.emptyList();
            case 1 -> villagers = Collections.singletonList((PersonaVillagerRequest)this.villagers.get(0));
            default -> villagers = Collections.unmodifiableList(new ArrayList(this.villagers));
         }

         return new PersonaBatchRequest(villagers);
      }

      @Generated
      public String toString() {
         return "PersonaBatchRequest.PersonaBatchRequestBuilder(villagers=" + String.valueOf(this.villagers) + ")";
      }
   }
}
