package dev.breezes.settlements.application.ai.inference.persona;

import com.google.gson.Gson;
import dev.breezes.settlements.application.ai.inference.InferenceCapability;
import dev.breezes.settlements.application.ai.inference.InferenceStreamHandle;
import dev.breezes.settlements.application.ai.inference.InferenceTransport;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.time.Duration;
import java.util.function.Consumer;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class HttpPersonaGateway implements PersonaGateway {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(HttpPersonaGateway.class.getName());
   private static final Gson GSON = new Gson();
   private final InferenceTransport transport;

   public InferenceStreamHandle generate(@Nonnull PersonaBatchRequest request, @Nonnull Duration deadline, @Nonnull Consumer<PersonaVillagerResult> onVillager) {
      return this.transport.postStreaming(InferenceCapability.PERSONA, request, deadline, (line) -> this.parseLine(line, onVillager));
   }

   private void parseLine(String line, Consumer<PersonaVillagerResult> onVillager) {
      String trimmed = line.strip();
      if (!trimmed.isEmpty()) {
         try {
            PersonaVillagerResult result = (PersonaVillagerResult)GSON.fromJson(trimmed, PersonaVillagerResult.class);
            if (result != null && result.getVillagerId() != null) {
               onVillager.accept(result);
            }
         } catch (RuntimeException e) {
            log.error("PERSONA response line parse failed: {}", e.getMessage());
         }

      }
   }

   @Inject
   @Generated
   HttpPersonaGateway(InferenceTransport transport) {
      this.transport = transport;
   }
}
