package dev.breezes.settlements.application.ai.inference.persona;

import dev.breezes.settlements.domain.personality.ParentPersona;
import dev.breezes.settlements.domain.personality.PersonaLineageSnapshot;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public final class PersonaLineageMapper {
   private static final int MAX_DIGEST_LENGTH = 300;

   @Nullable
   public static PersonaLineage toWire(@Nonnull PersonaLineageSnapshot snapshot) {
      return !snapshot.hasAnySignal() ? null : PersonaLineage.builder().parentA(toSide(snapshot.parentA())).parentB(toSide(snapshot.parentB())).build();
   }

   private static PersonaLineageSide toSide(ParentPersona parent) {
      return PersonaLineageSide.builder().adjectives(parent.adjectives()).characterSketchDigest(digest(parent.characterSketch())).build();
   }

   private static String digest(String characterSketch) {
      String trimmed = characterSketch.trim();
      if (trimmed.isBlank()) {
         return "";
      } else if (trimmed.length() <= 300) {
         return trimmed;
      } else {
         String cut = trimmed.substring(0, 300);
         int lastWhitespace = -1;

         for(int i = cut.length() - 1; i >= 0; --i) {
            if (Character.isWhitespace(cut.charAt(i))) {
               lastWhitespace = i;
               break;
            }
         }

         if (lastWhitespace > 0) {
            cut = cut.substring(0, lastWhitespace);
         }

         return cut + "…";
      }
   }

   @Generated
   private PersonaLineageMapper() {
   }
}
