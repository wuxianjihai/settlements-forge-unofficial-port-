package dev.breezes.settlements.application.ai.inference.persona;

import dev.breezes.settlements.application.ai.inference.InferenceStreamHandle;
import java.time.Duration;
import java.util.function.Consumer;

public interface PersonaGateway {
   InferenceStreamHandle generate(PersonaBatchRequest var1, Duration var2, Consumer<PersonaVillagerResult> var3);
}
