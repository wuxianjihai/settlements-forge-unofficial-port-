package dev.breezes.settlements.application.ai.inference.persona;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import lombok.Generated;

public final class PersonaLineageSide {
   private final List<String> adjectives;
   private final String characterSketchDigest;

   @Generated
   PersonaLineageSide(List<String> adjectives, String characterSketchDigest) {
      this.adjectives = adjectives;
      this.characterSketchDigest = characterSketchDigest;
   }

   @Generated
   public static PersonaLineageSideBuilder builder() {
      return new PersonaLineageSideBuilder();
   }

   @Generated
   public List<String> getAdjectives() {
      return this.adjectives;
   }

   @Generated
   public String getCharacterSketchDigest() {
      return this.characterSketchDigest;
   }

   @Generated
   public static class PersonaLineageSideBuilder {
      @Generated
      private ArrayList<String> adjectives;
      @Generated
      private String characterSketchDigest;

      @Generated
      PersonaLineageSideBuilder() {
      }

      @Generated
      public PersonaLineageSideBuilder adjective(String adjective) {
         if (this.adjectives == null) {
            this.adjectives = new ArrayList();
         }

         this.adjectives.add(adjective);
         return this;
      }

      @Generated
      public PersonaLineageSideBuilder adjectives(Collection<? extends String> adjectives) {
         if (adjectives == null) {
            throw new NullPointerException("adjectives cannot be null");
         } else {
            if (this.adjectives == null) {
               this.adjectives = new ArrayList();
            }

            this.adjectives.addAll(adjectives);
            return this;
         }
      }

      @Generated
      public PersonaLineageSideBuilder clearAdjectives() {
         if (this.adjectives != null) {
            this.adjectives.clear();
         }

         return this;
      }

      @Generated
      public PersonaLineageSideBuilder characterSketchDigest(String characterSketchDigest) {
         this.characterSketchDigest = characterSketchDigest;
         return this;
      }

      @Generated
      public PersonaLineageSide build() {
         List<String> adjectives;
         switch (this.adjectives == null ? 0 : this.adjectives.size()) {
            case 0 -> adjectives = Collections.emptyList();
            case 1 -> adjectives = Collections.singletonList((String)this.adjectives.get(0));
            default -> adjectives = Collections.unmodifiableList(new ArrayList(this.adjectives));
         }

         return new PersonaLineageSide(adjectives, this.characterSketchDigest);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.adjectives);
         return "PersonaLineageSide.PersonaLineageSideBuilder(adjectives=" + var10000 + ", characterSketchDigest=" + this.characterSketchDigest + ")";
      }
   }
}
