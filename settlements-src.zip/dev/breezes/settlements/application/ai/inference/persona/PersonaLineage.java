package dev.breezes.settlements.application.ai.inference.persona;

import lombok.Generated;

public final class PersonaLineage {
   private final PersonaLineageSide parentA;
   private final PersonaLineageSide parentB;

   @Generated
   PersonaLineage(PersonaLineageSide parentA, PersonaLineageSide parentB) {
      this.parentA = parentA;
      this.parentB = parentB;
   }

   @Generated
   public static PersonaLineageBuilder builder() {
      return new PersonaLineageBuilder();
   }

   @Generated
   public PersonaLineageSide getParentA() {
      return this.parentA;
   }

   @Generated
   public PersonaLineageSide getParentB() {
      return this.parentB;
   }

   @Generated
   public static class PersonaLineageBuilder {
      @Generated
      private PersonaLineageSide parentA;
      @Generated
      private PersonaLineageSide parentB;

      @Generated
      PersonaLineageBuilder() {
      }

      @Generated
      public PersonaLineageBuilder parentA(PersonaLineageSide parentA) {
         this.parentA = parentA;
         return this;
      }

      @Generated
      public PersonaLineageBuilder parentB(PersonaLineageSide parentB) {
         this.parentB = parentB;
         return this;
      }

      @Generated
      public PersonaLineage build() {
         return new PersonaLineage(this.parentA, this.parentB);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.parentA);
         return "PersonaLineage.PersonaLineageBuilder(parentA=" + var10000 + ", parentB=" + String.valueOf(this.parentB) + ")";
      }
   }
}
