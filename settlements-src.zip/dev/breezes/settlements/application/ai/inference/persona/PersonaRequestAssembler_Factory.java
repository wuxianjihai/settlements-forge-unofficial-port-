package dev.breezes.settlements.application.ai.inference.persona;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class PersonaRequestAssembler_Factory implements Factory<PersonaRequestAssembler> {
   public PersonaRequestAssembler get() {
      return newInstance();
   }

   public static PersonaRequestAssembler_Factory create() {
      return PersonaRequestAssembler_Factory.InstanceHolder.INSTANCE;
   }

   public static PersonaRequestAssembler newInstance() {
      return new PersonaRequestAssembler();
   }

   private static final class InstanceHolder {
      static final PersonaRequestAssembler_Factory INSTANCE = new PersonaRequestAssembler_Factory();
   }
}
