package dev.breezes.settlements.application.ai.inference;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("jakarta.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
public final class InferenceGate_Factory implements Factory<InferenceGate> {
   private final Provider<InferenceConfig> configProvider;

   private InferenceGate_Factory(Provider<InferenceConfig> configProvider) {
      this.configProvider = configProvider;
   }

   public InferenceGate get() {
      return newInstance((InferenceConfig)this.configProvider.get());
   }

   public static InferenceGate_Factory create(Provider<InferenceConfig> configProvider) {
      return new InferenceGate_Factory(configProvider);
   }

   public static InferenceGate newInstance(InferenceConfig config) {
      return new InferenceGate(config);
   }
}
