package dev.breezes.settlements.application.ai.inference;

import com.google.gson.Gson;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Version;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.net.http.HttpResponse.BodySubscribers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Flow;
import java.util.function.Consumer;
import java.util.function.Function;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class HttpInferenceTransport implements InferenceTransport {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(HttpInferenceTransport.class.getName());
   private static final String CONTENT_TYPE_JSON = "application/json";
   private static final Gson GSON = new Gson();
   private final InferenceConfig config;
   private final HttpClient httpClient;

   @Inject
   public HttpInferenceTransport(@Nonnull InferenceConfig config) {
      this.config = config;
      this.httpClient = HttpClient.newBuilder().version(Version.HTTP_1_1).connectTimeout(Duration.ofSeconds(10L)).build();
   }

   public CompletableFuture<InferenceTransportResponse> post(@Nonnull InferenceCapability capability, @Nonnull Object payload, @Nonnull Duration deadline) {
      if (!this.config.hasEndpoint()) {
         return CompletableFuture.completedFuture(InferenceTransportResponse.miss());
      } else {
         String body = this.renderEnvelope(capability, payload, deadline);
         HttpRequest.Builder var10000 = HttpRequest.newBuilder();
         String var10001 = this.config.normalizedBaseUrl();
         HttpRequest.Builder requestBuilder = var10000.uri(URI.create(var10001 + capability.getPath())).header("Content-Type", "application/json").header("X-Settlements-Inference-Protocol", Integer.toString(1)).timeout(deadline).POST(BodyPublishers.ofString(body));
         if (this.config.hasApiKey()) {
            requestBuilder.header("Authorization", "Bearer " + this.config.apiKey());
         }

         return this.httpClient.sendAsync(requestBuilder.build(), BodyHandlers.ofString()).thenApply((response) -> {
            if (response.statusCode() >= 200 && response.statusCode() < 300) {
               return InferenceTransportResponse.success((String)response.body(), response.statusCode());
            } else {
               log.error("Inference backend returned HTTP {} for {}: {}", response.statusCode(), capability, response.body());
               return InferenceTransportResponse.miss();
            }
         }).exceptionally((throwable) -> {
            log.error("Inference request for {} missed", capability, throwable);
            return InferenceTransportResponse.miss();
         });
      }
   }

   public InferenceStreamHandle postStreaming(@Nonnull InferenceCapability capability, @Nonnull Object payload, @Nonnull Duration deadline, @Nonnull Consumer<String> onLine) {
      if (!this.config.hasEndpoint()) {
         return InferenceStreamHandle.noOp();
      } else {
         String body = this.renderEnvelope(capability, payload, deadline);
         HttpRequest.Builder var10000 = HttpRequest.newBuilder();
         String var10001 = this.config.normalizedBaseUrl();
         HttpRequest.Builder requestBuilder = var10000.uri(URI.create(var10001 + capability.getPath())).header("Content-Type", "application/json").header("X-Settlements-Inference-Protocol", Integer.toString(1)).timeout(deadline).POST(BodyPublishers.ofString(body));
         if (this.config.hasApiKey()) {
            requestBuilder.header("Authorization", "Bearer " + this.config.apiKey());
         }

         HttpResponse.BodyHandler<Void> bodyHandler = (responseInfo) -> {
            if (responseInfo.statusCode() >= 200 && responseInfo.statusCode() < 300) {
               return buildLineBodySubscriber(onLine);
            } else {
               log.error("Inference streaming backend returned HTTP {} for {}", responseInfo.statusCode(), capability);
               return BodySubscribers.replacing((Object)null);
            }
         };
         final CompletableFuture<HttpResponse<Void>> sourceFuture = this.httpClient.sendAsync(requestBuilder.build(), bodyHandler);
         final CompletableFuture<Void> completion = sourceFuture.handle((response, throwable) -> {
            if (throwable != null) {
               log.error("Inference streaming request for {} ended with error", capability, throwable);
            }

            return null;
         });
         return new InferenceStreamHandle() {
            public void cancel() {
               sourceFuture.cancel(true);
            }

            public CompletableFuture<Void> completion() {
               return completion;
            }
         };
      }
   }

   private static HttpResponse.BodySubscriber<Void> buildLineBodySubscriber(final Consumer<String> onLine) {
      Flow.Subscriber<String> lineSubscriber = new Flow.Subscriber<String>() {
         public void onSubscribe(Flow.Subscription subscription) {
            subscription.request(Long.MAX_VALUE);
         }

         public void onNext(String line) {
            if (!line.isBlank()) {
               onLine.accept(line);
            }

         }

         public void onError(Throwable throwable) {
         }

         public void onComplete() {
         }
      };
      Function<Flow.Subscriber<String>, Void> finisher = (ignored) -> null;
      return BodySubscribers.fromLineSubscriber(lineSubscriber, finisher, StandardCharsets.UTF_8, "\n");
   }

   public String renderEnvelope(@Nonnull InferenceCapability capability, @Nonnull Object payload, @Nonnull Duration deadline) {
      InferenceRequestEnvelope envelope = InferenceRequestEnvelope.builder().protocolVersion(1).requestId(UUID.randomUUID()).capability(capability).deadlineMillis(deadline.toMillis()).payload(payload).build();
      return GSON.toJson(envelope);
   }

   public void close() {
   }
}
