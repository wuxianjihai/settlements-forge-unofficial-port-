package dev.breezes.settlements.application.ai.inference;

import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

public interface InferenceTransport extends AutoCloseable {
   CompletableFuture<InferenceTransportResponse> post(InferenceCapability var1, Object var2, Duration var3);

   InferenceStreamHandle postStreaming(InferenceCapability var1, Object var2, Duration var3, Consumer<String> var4);

   String renderEnvelope(InferenceCapability var1, Object var2, Duration var3);

   void close();
}
