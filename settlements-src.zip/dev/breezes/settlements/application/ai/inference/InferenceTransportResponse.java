package dev.breezes.settlements.application.ai.inference;

import java.util.Optional;
import lombok.Generated;

public final class InferenceTransportResponse {
   private final String body;
   private final int statusCode;

   public static InferenceTransportResponse success(String body, int statusCode) {
      return new InferenceTransportResponse(body, statusCode);
   }

   public static InferenceTransportResponse miss() {
      return new InferenceTransportResponse((String)null, 0);
   }

   public Optional<String> body() {
      return Optional.ofNullable(this.body).filter((value) -> !value.isBlank());
   }

   @Generated
   public String getBody() {
      return this.body;
   }

   @Generated
   public int getStatusCode() {
      return this.statusCode;
   }

   @Generated
   private InferenceTransportResponse(String body, int statusCode) {
      this.body = body;
      this.statusCode = statusCode;
   }
}
