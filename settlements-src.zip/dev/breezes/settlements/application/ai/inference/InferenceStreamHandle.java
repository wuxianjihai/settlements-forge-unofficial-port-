package dev.breezes.settlements.application.ai.inference;

import java.util.concurrent.CompletableFuture;

public interface InferenceStreamHandle {
   InferenceStreamHandle NO_OP = new InferenceStreamHandle() {
      public void cancel() {
      }

      public CompletableFuture<Void> completion() {
         return CompletableFuture.completedFuture((Object)null);
      }
   };

   void cancel();

   CompletableFuture<Void> completion();

   static InferenceStreamHandle noOp() {
      return NO_OP;
   }
}
