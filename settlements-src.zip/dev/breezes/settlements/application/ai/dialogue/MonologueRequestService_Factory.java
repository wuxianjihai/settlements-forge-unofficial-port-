package dev.breezes.settlements.application.ai.dialogue;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.inference.monologue.MonologueGateway;
import dev.breezes.settlements.application.ai.inference.monologue.MonologueRequestAssembler;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class MonologueRequestService_Factory implements Factory<MonologueRequestService> {
   private final Provider<MonologueRequestAssembler> assemblerProvider;
   private final Provider<MonologueGateway> gatewayProvider;
   private final Provider<OccasionSetResolver> occasionSetResolverProvider;
   private final Provider<DialogueConfig> configProvider;
   private final Provider<RehearsedDialogueConfig> rehearsedDialogueConfigProvider;

   private MonologueRequestService_Factory(Provider<MonologueRequestAssembler> assemblerProvider, Provider<MonologueGateway> gatewayProvider, Provider<OccasionSetResolver> occasionSetResolverProvider, Provider<DialogueConfig> configProvider, Provider<RehearsedDialogueConfig> rehearsedDialogueConfigProvider) {
      this.assemblerProvider = assemblerProvider;
      this.gatewayProvider = gatewayProvider;
      this.occasionSetResolverProvider = occasionSetResolverProvider;
      this.configProvider = configProvider;
      this.rehearsedDialogueConfigProvider = rehearsedDialogueConfigProvider;
   }

   public MonologueRequestService get() {
      return newInstance((MonologueRequestAssembler)this.assemblerProvider.get(), (MonologueGateway)this.gatewayProvider.get(), (OccasionSetResolver)this.occasionSetResolverProvider.get(), (DialogueConfig)this.configProvider.get(), (RehearsedDialogueConfig)this.rehearsedDialogueConfigProvider.get());
   }

   public static MonologueRequestService_Factory create(Provider<MonologueRequestAssembler> assemblerProvider, Provider<MonologueGateway> gatewayProvider, Provider<OccasionSetResolver> occasionSetResolverProvider, Provider<DialogueConfig> configProvider, Provider<RehearsedDialogueConfig> rehearsedDialogueConfigProvider) {
      return new MonologueRequestService_Factory(assemblerProvider, gatewayProvider, occasionSetResolverProvider, configProvider, rehearsedDialogueConfigProvider);
   }

   public static MonologueRequestService newInstance(MonologueRequestAssembler assembler, MonologueGateway gateway, OccasionSetResolver occasionSetResolver, DialogueConfig config, RehearsedDialogueConfig rehearsedDialogueConfig) {
      return new MonologueRequestService(assembler, gateway, occasionSetResolver, config, rehearsedDialogueConfig);
   }
}
