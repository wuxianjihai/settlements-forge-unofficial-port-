package dev.breezes.settlements.application.ai.dialogue;

import dev.breezes.settlements.application.ai.inference.InferenceStreamHandle;
import dev.breezes.settlements.application.ai.inference.monologue.MonologueBatchRequest;
import dev.breezes.settlements.application.ai.inference.monologue.MonologueGateway;
import dev.breezes.settlements.application.ai.inference.monologue.MonologueRequestAssembler;
import dev.breezes.settlements.application.ai.inference.monologue.VillagerMonologueResult;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import lombok.Generated;

@ServerScope
public final class MonologueRequestService {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(MonologueRequestService.class.getName());
   private final MonologueRequestAssembler assembler;
   private final MonologueGateway gateway;
   private final OccasionSetResolver occasionSetResolver;
   private final DialogueConfig config;
   private final RehearsedDialogueConfig rehearsedDialogueConfig;

   public InferenceStreamHandle requestPacksStreaming(Collection<BaseVillager> villagers, Consumer<VillagerPack> onPack) {
      log.debug("Requesting monologue packs (streaming) for {} villagers", villagers.size());
      Map<BaseVillager, Collection<Occasion>> villagersWithOccasions = new HashMap();

      for(BaseVillager villager : villagers) {
         villagersWithOccasions.put(villager, this.occasionSetResolver.resolve(villager.getProfession()));
      }

      if (villagersWithOccasions.isEmpty()) {
         return InferenceStreamHandle.noOp();
      } else {
         MonologueBatchRequest batch = this.assembler.assembleForVillagers(villagersWithOccasions);
         Duration deadline = Duration.ofSeconds((long)this.rehearsedDialogueConfig.packSweepDeadlineSeconds());
         return this.gateway.generate(batch, deadline, (result) -> this.toPack(result).ifPresent(onPack));
      }
   }

   Optional<VillagerPack> toPack(VillagerMonologueResult villagerResult) {
      VillagerPack.VillagerPackBuilder packBuilder = VillagerPack.builder().villagerId(villagerResult.getVillagerId());
      int bubbleCharCap = this.config.bubbleCharCap();
      boolean hasAnyLines = false;

      for(Map.Entry<Occasion, List<String>> entry : villagerResult.getBuckets().entrySet()) {
         Occasion occasion = (Occasion)entry.getKey();
         List<String> sanitized = new ArrayList();

         for(String line : (List)entry.getValue()) {
            Optional var10000 = DialogueResponseSanitizer.sanitize(line, bubbleCharCap);
            Objects.requireNonNull(sanitized);
            var10000.ifPresent(sanitized::add);
         }

         if (!sanitized.isEmpty()) {
            packBuilder.linesByOccasion(occasion, sanitized);
            hasAnyLines = true;
         }
      }

      if (!hasAnyLines) {
         return Optional.empty();
      } else {
         return Optional.of(packBuilder.build());
      }
   }

   @Inject
   @Generated
   MonologueRequestService(MonologueRequestAssembler assembler, MonologueGateway gateway, OccasionSetResolver occasionSetResolver, DialogueConfig config, RehearsedDialogueConfig rehearsedDialogueConfig) {
      this.assembler = assembler;
      this.gateway = gateway;
      this.occasionSetResolver = occasionSetResolver;
      this.config = config;
      this.rehearsedDialogueConfig = rehearsedDialogueConfig;
   }
}
