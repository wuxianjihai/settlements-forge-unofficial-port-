package dev.breezes.settlements.application.ai.dialogue;

import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import lombok.Generated;

public final class DialogueContext {
   private final VillagerProfessionKey profession;
   private final Occasion occasion;
   private final Set<DialogueFacet> facets;

   @Generated
   private static VillagerProfessionKey $default$profession() {
      return VillagerProfessionKey.NONE;
   }

   @Generated
   private static Occasion $default$occasion() {
      return Occasion.IDLE;
   }

   @Generated
   DialogueContext(VillagerProfessionKey profession, Occasion occasion, Set<DialogueFacet> facets) {
      this.profession = profession;
      this.occasion = occasion;
      this.facets = facets;
   }

   @Generated
   public static DialogueContextBuilder builder() {
      return new DialogueContextBuilder();
   }

   @Generated
   public VillagerProfessionKey getProfession() {
      return this.profession;
   }

   @Generated
   public Occasion getOccasion() {
      return this.occasion;
   }

   @Generated
   public Set<DialogueFacet> getFacets() {
      return this.facets;
   }

   @Generated
   public static class DialogueContextBuilder {
      @Generated
      private boolean profession$set;
      @Generated
      private VillagerProfessionKey profession$value;
      @Generated
      private boolean occasion$set;
      @Generated
      private Occasion occasion$value;
      @Generated
      private ArrayList<DialogueFacet> facets;

      @Generated
      DialogueContextBuilder() {
      }

      @Generated
      public DialogueContextBuilder profession(VillagerProfessionKey profession) {
         this.profession$value = profession;
         this.profession$set = true;
         return this;
      }

      @Generated
      public DialogueContextBuilder occasion(Occasion occasion) {
         this.occasion$value = occasion;
         this.occasion$set = true;
         return this;
      }

      @Generated
      public DialogueContextBuilder facet(DialogueFacet facet) {
         if (this.facets == null) {
            this.facets = new ArrayList();
         }

         this.facets.add(facet);
         return this;
      }

      @Generated
      public DialogueContextBuilder facets(Collection<? extends DialogueFacet> facets) {
         if (facets == null) {
            throw new NullPointerException("facets cannot be null");
         } else {
            if (this.facets == null) {
               this.facets = new ArrayList();
            }

            this.facets.addAll(facets);
            return this;
         }
      }

      @Generated
      public DialogueContextBuilder clearFacets() {
         if (this.facets != null) {
            this.facets.clear();
         }

         return this;
      }

      @Generated
      public DialogueContext build() {
         Set<DialogueFacet> facets;
         switch (this.facets == null ? 0 : this.facets.size()) {
            case 0:
               facets = Collections.emptySet();
               break;
            case 1:
               facets = Collections.singleton((DialogueFacet)this.facets.get(0));
               break;
            default:
               facets = new LinkedHashSet(this.facets.size() < 1073741824 ? 1 + this.facets.size() + (this.facets.size() - 3) / 3 : Integer.MAX_VALUE);
               facets.addAll(this.facets);
               facets = Collections.unmodifiableSet(facets);
         }

         VillagerProfessionKey profession$value = this.profession$value;
         if (!this.profession$set) {
            profession$value = DialogueContext.$default$profession();
         }

         Occasion occasion$value = this.occasion$value;
         if (!this.occasion$set) {
            occasion$value = DialogueContext.$default$occasion();
         }

         return new DialogueContext(profession$value, occasion$value, facets);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.profession$value);
         return "DialogueContext.DialogueContextBuilder(profession$value=" + var10000 + ", occasion$value=" + String.valueOf(this.occasion$value) + ", facets=" + String.valueOf(this.facets) + ")";
      }
   }
}
