package dev.breezes.settlements.application.ai.dialogue;

import java.util.Optional;
import lombok.Generated;

public final class DialogueResponseSanitizer {
   private static final char CHAT_FORMATTING_CHAR = '§';

   public static Optional<String> sanitize(String raw, int bubbleCharCap) {
      if (raw != null && !raw.isBlank()) {
         String text = raw.trim();
         text = stripMinecraftFormattingCodes(text);
         text = text.trim();
         if (text.isBlank()) {
            return Optional.empty();
         } else {
            if (text.length() > bubbleCharCap) {
               text = text.substring(0, bubbleCharCap).trim();
            }

            return text.isBlank() ? Optional.empty() : Optional.of(text);
         }
      } else {
         return Optional.empty();
      }
   }

   private static String stripMinecraftFormattingCodes(String text) {
      StringBuilder result = new StringBuilder(text.length());
      int i = 0;

      while(i < text.length()) {
         char c = text.charAt(i);
         if (c == 167 && i + 1 < text.length()) {
            i += 2;
         } else {
            result.append(c);
            ++i;
         }
      }

      return result.toString();
   }

   @Generated
   private DialogueResponseSanitizer() {
   }
}
