package dev.breezes.settlements.application.ai.dialogue;

public enum DialogueMode {
   SCRIPTED,
   REHEARSED;

   // $FF: synthetic method
   private static DialogueMode[] $values() {
      return new DialogueMode[]{SCRIPTED, REHEARSED};
   }
}
