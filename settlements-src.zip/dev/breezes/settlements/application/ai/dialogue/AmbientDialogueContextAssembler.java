package dev.breezes.settlements.application.ai.dialogue;

import dev.breezes.settlements.application.ai.inference.monologue.VillagerFacetDeriver;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Objects;
import javax.annotation.Nonnull;
import lombok.Generated;

@ServerScope
public final class AmbientDialogueContextAssembler {
   private final VillagerFacetDeriver facetDeriver;

   public DialogueContext assemble(@Nonnull BaseVillager villager) {
      return this.assemble(villager, villager.getCurrentOccasion());
   }

   public DialogueContext assemble(@Nonnull BaseVillager villager, @Nonnull Occasion occasion) {
      DialogueContext.DialogueContextBuilder builder = DialogueContext.builder().profession(villager.getProfession()).occasion(occasion);
      List var10000 = this.facetDeriver.derive(villager);
      Objects.requireNonNull(builder);
      var10000.forEach(builder::facet);
      return builder.build();
   }

   @Inject
   @Generated
   AmbientDialogueContextAssembler(VillagerFacetDeriver facetDeriver) {
      this.facetDeriver = facetDeriver;
   }
}
