package dev.breezes.settlements.application.ai.dialogue;

import java.util.List;
import javax.annotation.Nonnull;

public sealed interface DialogueLine {
   static DialogueLine literal(@Nonnull String text) {
      return new Literal(text);
   }

   static DialogueLine translatable(@Nonnull String key) {
      return new Translatable(key, List.of());
   }

   static DialogueLine translatable(@Nonnull String key, @Nonnull List<String> args) {
      return new Translatable(key, args);
   }

   public static record Literal(@Nonnull String text) implements DialogueLine {
      public Literal {
         if (text.isBlank()) {
            throw new IllegalArgumentException("text must not be blank");
         }
      }
   }

   public static record Translatable(@Nonnull String key, @Nonnull List<String> args) implements DialogueLine {
      public Translatable(@Nonnull String key, @Nonnull List<String> args) {
         if (key.isBlank()) {
            throw new IllegalArgumentException("key must not be blank");
         } else {
            args = List.copyOf(args);
            this.key = key;
            this.args = args;
         }
      }
   }
}
