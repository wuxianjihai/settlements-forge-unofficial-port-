package dev.breezes.settlements.application.ai.dialogue;

import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import java.util.Collection;
import java.util.Optional;
import java.util.UUID;

public interface DialogueProvider {
   Optional<DialogueLine> sampleAmbientLine(UUID var1, DialogueContext var2);

   void runEveningPackSweep(Collection<BaseVillager> var1);

   default void cancelInflightSweep() {
   }

   boolean isEnabled();

   default void evict(UUID villagerUuid) {
   }

   default boolean supportsRehearsedDialogSweep() {
      return false;
   }
}
