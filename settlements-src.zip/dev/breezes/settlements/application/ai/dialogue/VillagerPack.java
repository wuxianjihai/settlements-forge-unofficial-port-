package dev.breezes.settlements.application.ai.dialogue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import lombok.Generated;

public final class VillagerPack {
   private final UUID villagerId;
   private final Map<Occasion, List<String>> linesByOccasion;

   @Generated
   VillagerPack(UUID villagerId, Map<Occasion, List<String>> linesByOccasion) {
      this.villagerId = villagerId;
      this.linesByOccasion = linesByOccasion;
   }

   @Generated
   public static VillagerPackBuilder builder() {
      return new VillagerPackBuilder();
   }

   @Generated
   public UUID getVillagerId() {
      return this.villagerId;
   }

   @Generated
   public Map<Occasion, List<String>> getLinesByOccasion() {
      return this.linesByOccasion;
   }

   @Generated
   public static class VillagerPackBuilder {
      @Generated
      private UUID villagerId;
      @Generated
      private ArrayList<Occasion> linesByOccasion$key;
      @Generated
      private ArrayList<List<String>> linesByOccasion$value;

      @Generated
      VillagerPackBuilder() {
      }

      @Generated
      public VillagerPackBuilder villagerId(UUID villagerId) {
         this.villagerId = villagerId;
         return this;
      }

      @Generated
      public VillagerPackBuilder linesByOccasion(Occasion linesByOccasionKey, List<String> linesByOccasionValue) {
         if (this.linesByOccasion$key == null) {
            this.linesByOccasion$key = new ArrayList();
            this.linesByOccasion$value = new ArrayList();
         }

         this.linesByOccasion$key.add(linesByOccasionKey);
         this.linesByOccasion$value.add(linesByOccasionValue);
         return this;
      }

      @Generated
      public VillagerPackBuilder linesByOccasion(Map<? extends Occasion, ? extends List<String>> linesByOccasion) {
         if (linesByOccasion == null) {
            throw new NullPointerException("linesByOccasion cannot be null");
         } else {
            if (this.linesByOccasion$key == null) {
               this.linesByOccasion$key = new ArrayList();
               this.linesByOccasion$value = new ArrayList();
            }

            for(Map.Entry<? extends Occasion, ? extends List<String>> $lombokEntry : linesByOccasion.entrySet()) {
               this.linesByOccasion$key.add((Occasion)$lombokEntry.getKey());
               this.linesByOccasion$value.add((List)$lombokEntry.getValue());
            }

            return this;
         }
      }

      @Generated
      public VillagerPackBuilder clearLinesByOccasion() {
         if (this.linesByOccasion$key != null) {
            this.linesByOccasion$key.clear();
            this.linesByOccasion$value.clear();
         }

         return this;
      }

      @Generated
      public VillagerPack build() {
         Map<Occasion, List<String>> linesByOccasion;
         switch (this.linesByOccasion$key == null ? 0 : this.linesByOccasion$key.size()) {
            case 0:
               linesByOccasion = Collections.emptyMap();
               break;
            case 1:
               linesByOccasion = Collections.singletonMap((Occasion)this.linesByOccasion$key.get(0), (List)this.linesByOccasion$value.get(0));
               break;
            default:
               linesByOccasion = new LinkedHashMap(this.linesByOccasion$key.size() < 1073741824 ? 1 + this.linesByOccasion$key.size() + (this.linesByOccasion$key.size() - 3) / 3 : Integer.MAX_VALUE);

               for(int $i = 0; $i < this.linesByOccasion$key.size(); ++$i) {
                  linesByOccasion.put((Occasion)this.linesByOccasion$key.get($i), (List)this.linesByOccasion$value.get($i));
               }

               linesByOccasion = Collections.unmodifiableMap(linesByOccasion);
         }

         return new VillagerPack(this.villagerId, linesByOccasion);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.villagerId);
         return "VillagerPack.VillagerPackBuilder(villagerId=" + var10000 + ", linesByOccasion$key=" + String.valueOf(this.linesByOccasion$key) + ", linesByOccasion$value=" + String.valueOf(this.linesByOccasion$value) + ")";
      }
   }
}
