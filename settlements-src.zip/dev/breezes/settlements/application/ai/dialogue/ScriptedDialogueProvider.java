package dev.breezes.settlements.application.ai.dialogue;

import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class ScriptedDialogueProvider implements DialogueProvider {
   private final DialogueLineIndex lineIndex;
   private final DialogueConfig config;

   public Optional<DialogueLine> sampleAmbientLine(@Nonnull UUID villagerUuid, @Nonnull DialogueContext context) {
      return !this.config.scriptedChatter() ? Optional.empty() : this.lineIndex.resolveKeys(context.getProfession(), context.getOccasion(), context.getFacets()).map(ScriptedDialogueProvider::chooseKey).map(DialogueLine::translatable);
   }

   public void runEveningPackSweep(Collection<BaseVillager> villagers) {
   }

   public boolean isEnabled() {
      return this.config.scriptedChatter();
   }

   private static String chooseKey(List<String> keys) {
      return (String)RandomUtil.choice(keys).orElse("dialogue.settlements.generic.idle.1");
   }

   @Generated
   ScriptedDialogueProvider(DialogueLineIndex lineIndex, DialogueConfig config) {
      this.lineIndex = lineIndex;
      this.config = config;
   }
}
