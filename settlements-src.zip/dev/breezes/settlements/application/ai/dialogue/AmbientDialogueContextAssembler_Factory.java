package dev.breezes.settlements.application.ai.dialogue;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.ai.inference.monologue.VillagerFacetDeriver;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class AmbientDialogueContextAssembler_Factory implements Factory<AmbientDialogueContextAssembler> {
   private final Provider<VillagerFacetDeriver> facetDeriverProvider;

   private AmbientDialogueContextAssembler_Factory(Provider<VillagerFacetDeriver> facetDeriverProvider) {
      this.facetDeriverProvider = facetDeriverProvider;
   }

   public AmbientDialogueContextAssembler get() {
      return newInstance((VillagerFacetDeriver)this.facetDeriverProvider.get());
   }

   public static AmbientDialogueContextAssembler_Factory create(Provider<VillagerFacetDeriver> facetDeriverProvider) {
      return new AmbientDialogueContextAssembler_Factory(facetDeriverProvider);
   }

   public static AmbientDialogueContextAssembler newInstance(VillagerFacetDeriver facetDeriver) {
      return new AmbientDialogueContextAssembler(facetDeriver);
   }
}
