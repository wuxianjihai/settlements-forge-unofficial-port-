package dev.breezes.settlements.application.ai.dialogue;

public enum Occasion {
   IDLE,
   WORK,
   MEET,
   REST,
   PANIC,
   PRE_RAID,
   RAID,
   HIDE,
   MORNING,
   EVENING,
   REST_DAY,
   ZOMBIE_SIGHTED;

   // $FF: synthetic method
   private static Occasion[] $values() {
      return new Occasion[]{IDLE, WORK, MEET, REST, PANIC, PRE_RAID, RAID, HIDE, MORNING, EVENING, REST_DAY, ZOMBIE_SIGHTED};
   }
}
