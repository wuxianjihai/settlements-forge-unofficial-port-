package dev.breezes.settlements.application.ai.dialogue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Random;

public final class UtterancePack {
   private final List<String> remaining;
   private final Random random;

   public UtterancePack(List<String> lines, Random random) {
      this.remaining = new ArrayList(lines);
      this.random = random;
   }

   public Optional<String> drawLine() {
      if (this.remaining.isEmpty()) {
         return Optional.empty();
      } else {
         int index = this.random.nextInt(this.remaining.size());
         int lastIndex = this.remaining.size() - 1;
         Collections.swap(this.remaining, index, lastIndex);
         return Optional.of((String)this.remaining.remove(lastIndex));
      }
   }

   public boolean isEmpty() {
      return this.remaining.isEmpty();
   }

   public int size() {
      return this.remaining.size();
   }
}
