package dev.breezes.settlements.application.ai.dialogue;

import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import java.util.Set;

public final class OccasionSetResolver {
   private static final Set<Occasion> CORE_OCCASIONS;
   private static final Set<Occasion> NITWIT_OCCASIONS;

   public Set<Occasion> resolve(VillagerProfessionKey profession) {
      return VillagerProfessionKey.NITWIT.equals(profession) ? NITWIT_OCCASIONS : CORE_OCCASIONS;
   }

   static {
      CORE_OCCASIONS = Set.of(Occasion.IDLE, Occasion.WORK, Occasion.MEET, Occasion.REST_DAY);
      NITWIT_OCCASIONS = Set.of(Occasion.IDLE, Occasion.MEET, Occasion.REST_DAY);
   }
}
