package dev.breezes.settlements.application.ai.dialogue;

import dev.breezes.settlements.application.ai.inference.InferenceStreamHandle;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class RehearsedDialogueProvider implements DialogueProvider {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(RehearsedDialogueProvider.class.getName());
   private final DialogueProvider fallback;
   private final MonologueRequestService monologueRequestService;
   private final ConcurrentHashMap<UUID, Map<Occasion, UtterancePack>> packs;
   private final AtomicLong sweepEpoch;
   private final AtomicReference<InferenceStreamHandle> inflightHandle;

   RehearsedDialogueProvider(DialogueProvider fallback, MonologueRequestService monologueRequestService) {
      this.fallback = fallback;
      this.monologueRequestService = monologueRequestService;
      this.packs = new ConcurrentHashMap();
      this.sweepEpoch = new AtomicLong(0L);
      this.inflightHandle = new AtomicReference(InferenceStreamHandle.noOp());
   }

   public Optional<DialogueLine> sampleAmbientLine(@Nonnull UUID villagerUuid, @Nonnull DialogueContext context) {
      Map<Occasion, UtterancePack> villagerPacks = (Map)this.packs.get(villagerUuid);
      if (villagerPacks == null) {
         return this.fallback.sampleAmbientLine(villagerUuid, context);
      } else {
         UtterancePack pack = (UtterancePack)villagerPacks.get(context.getOccasion());
         return pack != null && !pack.isEmpty() ? pack.drawLine().map(DialogueLine::literal).or(() -> this.fallback.sampleAmbientLine(villagerUuid, context)) : this.fallback.sampleAmbientLine(villagerUuid, context);
      }
   }

   public void runEveningPackSweep(Collection<BaseVillager> villagers) {
      List<BaseVillager> due = villagers.stream().filter((v) -> this.needsRefresh(v.m_20148_())).toList();
      if (due.isEmpty()) {
         log.debug("Evening sweep: all {} villager(s) already have full packs, skipping backend call", villagers.size());
      } else {
         long epoch = this.rotateSweepHandle(InferenceStreamHandle.noOp());
         log.debug("Evening sweep: requesting packs for {} villager(s) (epoch {})", due.size(), epoch);
         InferenceStreamHandle handle = this.monologueRequestService.requestPacksStreaming(due, (pack) -> this.installOnePack(epoch, pack));
         this.inflightHandle.set(handle);
         handle.completion().thenRun(() -> {
            this.inflightHandle.compareAndSet(handle, InferenceStreamHandle.noOp());
            log.debug("Evening sweep epoch {} completed", epoch);
         });
      }
   }

   void installOnePack(long epoch, VillagerPack pack) {
      if (epoch == this.sweepEpoch.get()) {
         Map<Occasion, UtterancePack> occasionPacks = new HashMap();

         for(Map.Entry<Occasion, List<String>> entry : pack.getLinesByOccasion().entrySet()) {
            if (!((List)entry.getValue()).isEmpty()) {
               occasionPacks.put((Occasion)entry.getKey(), new UtterancePack((List)entry.getValue(), RandomUtil.RANDOM));
            }
         }

         if (!occasionPacks.isEmpty()) {
            this.packs.put(pack.getVillagerId(), occasionPacks);
         }

      }
   }

   public void cancelInflightSweep() {
      this.rotateSweepHandle(InferenceStreamHandle.noOp());
   }

   public void evict(@Nonnull UUID villagerUuid) {
      this.packs.remove(villagerUuid);
      this.fallback.evict(villagerUuid);
   }

   boolean needsRefresh(UUID villagerUuid) {
      Map<Occasion, UtterancePack> villagerPacks = (Map)this.packs.get(villagerUuid);
      if (villagerPacks == null) {
         return true;
      } else {
         for(UtterancePack pack : villagerPacks.values()) {
            if (pack.isEmpty()) {
               return true;
            }
         }

         return false;
      }
   }

   long rotateSweepHandle(InferenceStreamHandle newHandle) {
      long epoch = this.sweepEpoch.incrementAndGet();
      InferenceStreamHandle previous = (InferenceStreamHandle)this.inflightHandle.getAndSet(newHandle);
      previous.cancel();
      return epoch;
   }

   public boolean isEnabled() {
      return this.fallback.isEnabled() || !this.packs.isEmpty();
   }

   public boolean supportsRehearsedDialogSweep() {
      return true;
   }
}
