package dev.breezes.settlements.application.ai.dialogue;

import lombok.Generated;

public enum DialogueFacet {
   WAS_CURED("cured");

   private final String keySegment;

   @Generated
   private DialogueFacet(String keySegment) {
      this.keySegment = keySegment;
   }

   @Generated
   public String getKeySegment() {
      return this.keySegment;
   }

   // $FF: synthetic method
   private static DialogueFacet[] $values() {
      return new DialogueFacet[]{WAS_CURED};
   }
}
