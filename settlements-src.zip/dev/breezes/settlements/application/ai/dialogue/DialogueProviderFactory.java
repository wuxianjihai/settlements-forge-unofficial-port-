package dev.breezes.settlements.application.ai.dialogue;

import dagger.Lazy;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class DialogueProviderFactory {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(DialogueProviderFactory.class.getName());

   public static DialogueProvider create(@Nonnull DialogueConfig config, @Nonnull RehearsedDialogueConfig rehearsedDialogueConfig, @Nonnull DialogueLineIndex lineIndex, @Nonnull Lazy<MonologueRequestService> monologueRequestService, boolean inferenceEnabled) {
      DialogueProvider scriptedProvider = new ScriptedDialogueProvider(lineIndex, config);
      if (!inferenceEnabled) {
         log.info("DialogueProvider: SCRIPTED — Settlements Inference Service is off, dialogue mode forced regardless of configured value");
         return scriptedProvider;
      } else {
         Object var10000;
         switch (rehearsedDialogueConfig.resolvedMode()) {
            case SCRIPTED:
               log.info("DialogueProvider: SCRIPTED — localized built-in dialogue floor");
               var10000 = scriptedProvider;
               break;
            case REHEARSED:
               log.info("DialogueProvider: REHEARSED — dynamically generate monologue with SCRIPTED as fallback");
               var10000 = new RehearsedDialogueProvider(scriptedProvider, (MonologueRequestService)monologueRequestService.get());
               break;
            default:
               throw new IncompatibleClassChangeError();
         }

         return (DialogueProvider)var10000;
      }
   }

   @Generated
   private DialogueProviderFactory() {
   }
}
