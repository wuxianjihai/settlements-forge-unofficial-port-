package dev.breezes.settlements.application.ai.naming;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public final class VillagerNameTable {
   private final Map<UUID, String> names = new HashMap();
   private boolean dirty;

   @Nullable
   public String resolve(@Nullable UUID id) {
      return id == null ? null : (String)this.names.get(id);
   }

   public void upsert(@Nonnull UUID id, @Nonnull String name) {
      this.names.put(id, name);
      this.dirty = true;
   }

   public boolean remove(@Nullable UUID id) {
      if (id == null) {
         return false;
      } else {
         boolean removed = this.names.remove(id) != null;
         this.dirty |= removed;
         return removed;
      }
   }

   public boolean isDirty() {
      return this.dirty;
   }

   @Nonnull
   public Map<UUID, String> snapshot() {
      return Map.copyOf(this.names);
   }

   public void loadAll(@Nonnull Map<UUID, String> loaded) {
      this.names.putAll(loaded);
      this.dirty = false;
   }
}
