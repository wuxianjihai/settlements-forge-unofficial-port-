package dev.breezes.settlements.application.ai.naming;

import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.infrastructure.minecraft.persistence.VillagerNameSavedData;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;

public final class VillagerNameDirectory {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(VillagerNameDirectory.class.getName());
   private static final VillagerNameTable TABLE = new VillagerNameTable();
   private static boolean loadedFromDisk;

   private VillagerNameDirectory() {
   }

   @Nonnull
   public static VillagerNameTable sharedTable() {
      return TABLE;
   }

   public static void assignNameIfAbsent(@Nonnull BaseVillager villager) {
      if (!villager.m_9236_().m_5776_() && villager.m_7770_() == null) {
         String name = VillagerNameResolver.resolveName(villager.m_20148_());
         villager.m_6593_(Component.m_237113_(name));
         log.info("[villager-name] assigned \"{}\" to villager #{}", name, villager.m_19879_());
      }
   }

   public static void upsert(@Nonnull ServerLevel level, @Nonnull UUID id, @Nonnull String name) {
      ensureLoaded(level);
      TABLE.upsert(id, name);
      VillagerNameSavedData.get(level.m_7654_()).markDirty();
   }

   public static void remove(@Nonnull ServerLevel level, @Nullable UUID id) {
      ensureLoaded(level);
      if (TABLE.remove(id)) {
         VillagerNameSavedData.get(level.m_7654_()).markDirty();
      }

   }

   @Nonnull
   public static String resolve(@Nonnull ServerLevel level, @Nonnull UUID id) {
      ensureLoaded(level);
      String fromTable = TABLE.resolve(id);
      return fromTable != null ? fromTable : VillagerNameResolver.resolveName(id);
   }

   private static void ensureLoaded(@Nonnull ServerLevel level) {
      if (!loadedFromDisk) {
         loadedFromDisk = true;
         VillagerNameSavedData.get(level.m_7654_());
         log.info("[villager-name] directory loaded ({} entries)", TABLE.snapshot().size());
      }
   }
}
