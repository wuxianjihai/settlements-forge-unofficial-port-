package dev.breezes.settlements.application.ai.naming;

import dev.breezes.settlements.di.ServerScope;
import jakarta.inject.Inject;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import lombok.Generated;

@ServerScope
public final class VillagerNameResolver {
   static final List<String> NAME_POOL = List.of("Aldric", "Alma", "Ansel", "Aric", "Arna", "Arvid", "Astrid", "Audra", "Baldric", "Beatrix", "Beren", "Bertha", "Bjorn", "Bram", "Brenna", "Britta", "Calder", "Calla", "Cora", "Corvin", "Cyra", "Dagna", "Dagny", "Daric", "Delia", "Dirk", "Doran", "Draven", "Edda", "Edric", "Egil", "Elda", "Elric", "Elspeth", "Embla", "Erling", "Erwin", "Eska", "Fara", "Faye", "Ferris", "Finn", "Finna", "Freya", "Frieda", "Gareth", "Gerda", "Gilda", "Gorm", "Gregor", "Greta", "Gudrun", "Gunnar", "Hagen", "Haldis", "Halfdan", "Halla", "Halvar", "Hedda", "Helgi", "Herta", "Hildur", "Hjord", "Holger", "Ida", "Idris", "Idunn", "Inga", "Ingrid", "Ivar", "Jarl", "Jarvik", "Jorid", "Karin", "Keld", "Ketil", "Kjeld", "Klara", "Knud", "Kolr", "Lena", "Leif", "Lifa", "Lilja", "Lind", "Lotte", "Ludvik", "Lund", "Maren", "Marit", "Marta", "Mattis", "Mira", "Mjoll", "Moira", "Nadia", "Nanna", "Niall", "Njord", "Odda", "Oddvar", "Olaf", "Olga", "Olvir", "Orm", "Oskar", "Palva", "Petra", "Phelda", "Ragnar", "Ragnhild", "Ralf", "Randi", "Ranveig", "Rasa", "Reva", "Rolf", "Runa", "Runolf", "Saga", "Sigge", "Sigrid", "Sigrun", "Sigurd", "Signe", "Sigvard", "Silda", "Siri", "Sisse", "Skald", "Skara", "Skeld", "Solveig", "Steinar", "Stine", "Sturla", "Svala", "Svein", "Sven", "Tala", "Tilda", "Torvald", "Toste", "Tove", "Trude", "Trygg", "Ulf", "Ulva", "Unna", "Unn", "Vala", "Valdis", "Valka", "Vigdis", "Vigil", "Vilja", "Vilma", "Wilda", "Wulff", "Ylva", "Ymir", "Zara", "Zelda");

   public String resolve(@Nullable UUID uuid) {
      return resolveName(uuid);
   }

   public static String resolveName(@Nullable UUID uuid) {
      if (uuid == null) {
         return "Someone";
      } else {
         long mixed = uuid.getMostSignificantBits() ^ uuid.getLeastSignificantBits();
         int index = Math.floorMod(mixed, NAME_POOL.size());
         return (String)NAME_POOL.get(index);
      }
   }
}
