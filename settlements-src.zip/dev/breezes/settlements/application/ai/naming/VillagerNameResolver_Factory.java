package dev.breezes.settlements.application.ai.naming;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class VillagerNameResolver_Factory implements Factory<VillagerNameResolver> {
   public VillagerNameResolver get() {
      return newInstance();
   }

   public static VillagerNameResolver_Factory create() {
      return VillagerNameResolver_Factory.InstanceHolder.INSTANCE;
   }

   public static VillagerNameResolver newInstance() {
      return new VillagerNameResolver();
   }

   private static final class InstanceHolder {
      static final VillagerNameResolver_Factory INSTANCE = new VillagerNameResolver_Factory();
   }
}
