package dev.breezes.settlements.application.ai.courtship;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class CourtshipSessionRegistry_Factory implements Factory<CourtshipSessionRegistry> {
   public CourtshipSessionRegistry get() {
      return newInstance();
   }

   public static CourtshipSessionRegistry_Factory create() {
      return CourtshipSessionRegistry_Factory.InstanceHolder.INSTANCE;
   }

   public static CourtshipSessionRegistry newInstance() {
      return new CourtshipSessionRegistry();
   }

   private static final class InstanceHolder {
      static final CourtshipSessionRegistry_Factory INSTANCE = new CourtshipSessionRegistry_Factory();
   }
}
