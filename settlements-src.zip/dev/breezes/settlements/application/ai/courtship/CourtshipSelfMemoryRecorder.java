package dev.breezes.settlements.application.ai.courtship;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.knowledge.KnowledgeEntry;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

@ServerScope
public final class CourtshipSelfMemoryRecorder {
   public void recordPrivateFailure(@Nonnull BaseVillager self, @Nullable UUID partnerId, @Nonnull String reason) {
      long currentTick = self.m_9236_().m_46467_();
      UUID originObservationId = UUID.randomUUID();
      KnowledgeEntry entry = CourtshipSelfMemoryEntryBuilder.build(self.m_20148_(), partnerId, currentTick, reason, originObservationId);
      self.getKnowledgeStore().admit(entry);
   }

   @Inject
   @Generated
   CourtshipSelfMemoryRecorder() {
   }
}
