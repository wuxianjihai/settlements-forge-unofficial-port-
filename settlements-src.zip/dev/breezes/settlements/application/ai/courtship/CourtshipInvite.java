package dev.breezes.settlements.application.ai.courtship;

import java.util.UUID;
import javax.annotation.Nonnull;

public record CourtshipInvite(@Nonnull UUID sessionId, @Nonnull UUID presenterId, @Nonnull UUID receiverId, long createdGameTime, long expireGameTime) {
}
