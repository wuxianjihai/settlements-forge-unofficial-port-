package dev.breezes.settlements.application.ai.courtship;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class BedReservationService_Factory implements Factory<BedReservationService> {
   public BedReservationService get() {
      return newInstance();
   }

   public static BedReservationService_Factory create() {
      return BedReservationService_Factory.InstanceHolder.INSTANCE;
   }

   public static BedReservationService newInstance() {
      return new BedReservationService();
   }

   private static final class InstanceHolder {
      static final BedReservationService_Factory INSTANCE = new BedReservationService_Factory();
   }
}
