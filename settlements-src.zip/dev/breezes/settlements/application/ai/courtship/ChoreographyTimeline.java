package dev.breezes.settlements.application.ai.courtship;

public interface ChoreographyTimeline {
   int beatCount();

   long beatStartTick(int var1, long var2);

   long totalDurationTicks();

   CourtshipBeat beatAt(int var1);
}
