package dev.breezes.settlements.application.ai.courtship;

import dev.breezes.settlements.domain.ai.knowledge.KnowledgeEntry;
import dev.breezes.settlements.domain.ai.observation.ObservationType;
import dev.breezes.settlements.domain.ai.worldevent.EventOutcome;
import dev.breezes.settlements.domain.ai.worldevent.WorldEventType;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public final class CourtshipSelfMemoryEntryBuilder {
   public static final float SELF_FAILURE_WEIGHT = 2.5F;

   public static KnowledgeEntry build(@Nonnull UUID actorId, @Nullable UUID partnerId, long currentTick, @Nonnull String reason, @Nonnull UUID originObservationId) {
      Map<String, String> metadata = buildMetadata(actorId, reason);
      return KnowledgeEntry.fromDirectObservation(originObservationId, ObservationType.SOCIAL, currentTick, currentTick, partnerId, metadata, 2.5F, (Long)null);
   }

   public static Map<String, String> buildMetadata(@Nonnull UUID actorId, @Nonnull String reason) {
      Map<String, String> metadata = new HashMap(4);
      metadata.put("event_type", WorldEventType.COURTSHIP_DATE_COMPLETED.name());
      metadata.put("actor_id", actorId.toString());
      metadata.put("outcome", EventOutcome.FAILURE.name());
      metadata.put("reason", reason);
      return Map.copyOf(metadata);
   }

   @Generated
   private CourtshipSelfMemoryEntryBuilder() {
   }
}
