package dev.breezes.settlements.application.ai.courtship;

public enum CourtshipPhase {
   INVITE_SENT,
   ACCEPTED,
   APPROACH,
   COURTSHIP,
   BIRTH,
   COMPLETED,
   ABORTED;

   // $FF: synthetic method
   private static CourtshipPhase[] $values() {
      return new CourtshipPhase[]{INVITE_SENT, ACCEPTED, APPROACH, COURTSHIP, BIRTH, COMPLETED, ABORTED};
   }
}
