package dev.breezes.settlements.application.ai.courtship;

import java.util.UUID;
import javax.annotation.Nonnull;

public enum CourtshipRole {
   PRESENTER,
   RECEIVER;

   public static CourtshipRole of(@Nonnull UUID self, @Nonnull UUID partner) {
      return self.compareTo(partner) < 0 ? PRESENTER : RECEIVER;
   }

   // $FF: synthetic method
   private static CourtshipRole[] $values() {
      return new CourtshipRole[]{PRESENTER, RECEIVER};
   }
}
