package dev.breezes.settlements.application.ai.courtship;

public final class CourtshipConstants {
   public static final double CLOSE_ENOUGH_DISTANCE = (double)1.0F;
   public static final double DRIFT_DISTANCE = (double)2.0F;
   public static final long RECEIVER_REACTION_DELAY_TICKS = 8L;
}
