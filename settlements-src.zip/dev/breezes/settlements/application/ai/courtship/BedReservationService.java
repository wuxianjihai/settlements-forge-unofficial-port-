package dev.breezes.settlements.application.ai.courtship;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.village.poi.PoiType;
import net.minecraft.world.entity.ai.village.poi.PoiTypes;
import net.minecraft.world.level.pathfinder.Path;

@ServerScope
public final class BedReservationService {
   private static final int BED_SCAN_RANGE = 48;

   public Optional<BlockPos> tryClaimVacantHome(@Nonnull ServerLevel level, @Nonnull BaseVillager villager) {
      return level.m_8904_().m_217946_((holder) -> holder.m_203565_(PoiTypes.f_218060_), (holder, pos) -> this.isReachable(villager, pos, ((PoiType)holder.m_203334_()).f_27328_()), villager.m_20183_(), 48);
   }

   public void assignHome(@Nonnull BaseVillager child, @Nonnull ServerLevel level, @Nonnull BlockPos bed) {
      child.m_6274_().m_21879_(MemoryModuleType.f_26359_, GlobalPos.m_122643_(level.m_46472_(), bed));
   }

   private boolean isReachable(@Nonnull BaseVillager villager, @Nonnull BlockPos pos, int validRange) {
      Path path = villager.m_21573_().m_7864_(pos, validRange);
      return path != null && path.m_77403_();
   }
}
