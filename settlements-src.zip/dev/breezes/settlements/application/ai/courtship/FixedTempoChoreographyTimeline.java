package dev.breezes.settlements.application.ai.courtship;

import dev.breezes.settlements.infrastructure.compat.CompatMath;
import java.util.List;
import lombok.Generated;

public final class FixedTempoChoreographyTimeline implements ChoreographyTimeline {
   private final List<CourtshipBeat> beats;
   private final int ticksPerBeat;

   public int beatCount() {
      return this.beats.size();
   }

   public long beatStartTick(int beatIndex, long courtshipStartGameTime) {
      return courtshipStartGameTime + (long)beatIndex * (long)this.ticksPerBeat;
   }

   public long totalDurationTicks() {
      return (long)this.beats.size() * (long)this.ticksPerBeat;
   }

   public CourtshipBeat beatAt(int beatIndex) {
      int clamped = CompatMath.clamp(beatIndex, 0, this.beats.size() - 1);
      return (CourtshipBeat)this.beats.get(clamped);
   }

   @Generated
   public static FixedTempoChoreographyTimelineBuilder builder() {
      return new FixedTempoChoreographyTimelineBuilder();
   }

   @Generated
   public FixedTempoChoreographyTimeline(List<CourtshipBeat> beats, int ticksPerBeat) {
      this.beats = beats;
      this.ticksPerBeat = ticksPerBeat;
   }

   @Generated
   public static class FixedTempoChoreographyTimelineBuilder {
      @Generated
      private List<CourtshipBeat> beats;
      @Generated
      private int ticksPerBeat;

      @Generated
      FixedTempoChoreographyTimelineBuilder() {
      }

      @Generated
      public FixedTempoChoreographyTimelineBuilder beats(List<CourtshipBeat> beats) {
         this.beats = beats;
         return this;
      }

      @Generated
      public FixedTempoChoreographyTimelineBuilder ticksPerBeat(int ticksPerBeat) {
         this.ticksPerBeat = ticksPerBeat;
         return this;
      }

      @Generated
      public FixedTempoChoreographyTimeline build() {
         return new FixedTempoChoreographyTimeline(this.beats, this.ticksPerBeat);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.beats);
         return "FixedTempoChoreographyTimeline.FixedTempoChoreographyTimelineBuilder(beats=" + var10000 + ", ticksPerBeat=" + this.ticksPerBeat + ")";
      }
   }
}
