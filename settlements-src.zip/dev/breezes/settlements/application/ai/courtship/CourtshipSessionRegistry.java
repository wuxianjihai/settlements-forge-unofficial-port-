package dev.breezes.settlements.application.ai.courtship;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.Nonnull;
import lombok.Generated;

@ServerScope
public final class CourtshipSessionRegistry {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(CourtshipSessionRegistry.class.getName());
   private static final int DEADLINE_SLACK_TICKS = ClockTicks.seconds((double)2.0F).getTicksAsInt();
   public static final int INVITE_TIMEOUT_SECONDS = 15;
   private final Map<UUID, CourtshipSession> activeSessionsByParticipant = new ConcurrentHashMap();
   private final Map<UUID, SessionParticipants> sessionParticipantsBySessionId = new ConcurrentHashMap();
   private final Map<UUID, CourtshipInvite> invitesByReceiver = new ConcurrentHashMap();

   public CourtshipSession sendInvite(@Nonnull BaseVillager presenter, @Nonnull BaseVillager receiver, int courtshipDurationTicks, long currentGameTime) {
      UUID sessionId = UUID.randomUUID();
      CourtshipSession session = CourtshipSession.builder().sessionId(sessionId).presenterId(presenter.m_20148_()).receiverId(receiver.m_20148_()).courtshipDurationTicks(courtshipDurationTicks).phase(CourtshipPhase.INVITE_SENT).phaseEnteredGameTime(currentGameTime).build();
      long expireGameTime = currentGameTime + ClockTicks.seconds((double)15.0F).getTicks();
      CourtshipInvite invite = new CourtshipInvite(sessionId, presenter.m_20148_(), receiver.m_20148_(), currentGameTime, expireGameTime);
      this.putSession(session);
      this.invitesByReceiver.put(receiver.m_20148_(), invite);
      log.info("Created courtship invite: sessionId={}, presenter={}, receiver={}", sessionId, presenter.m_20148_(), receiver.m_20148_());
      return session;
   }

   public boolean hasInviteFor(@Nonnull UUID receiverId) {
      return this.invitesByReceiver.containsKey(receiverId);
   }

   public Optional<CourtshipInvite> getInvite(@Nonnull UUID receiverId) {
      return Optional.ofNullable((CourtshipInvite)this.invitesByReceiver.get(receiverId));
   }

   public CourtshipSession acceptInvite(@Nonnull UUID receiverId, long currentGameTime) {
      Optional.ofNullable((CourtshipInvite)this.invitesByReceiver.remove(receiverId)).orElseThrow(() -> new IllegalArgumentException("No pending courtship invite for receiverId=" + String.valueOf(receiverId)));
      CourtshipSession session = (CourtshipSession)Optional.ofNullable((CourtshipSession)this.activeSessionsByParticipant.get(receiverId)).orElseThrow(() -> new IllegalStateException("Pending courtship invite had no matching active session"));
      session.transitionTo(CourtshipPhase.ACCEPTED, currentGameTime);
      log.info("Accepted courtship invite: sessionId={}, receiverId={}", session.getSessionId(), receiverId);
      return session;
   }

   public Optional<CourtshipSession> getActiveSession(@Nonnull UUID villagerId) {
      return Optional.ofNullable((CourtshipSession)this.activeSessionsByParticipant.get(villagerId));
   }

   public void closeSession(@Nonnull UUID sessionId, @Nonnull CourtshipCloseReason reason) {
      SessionParticipants participants = (SessionParticipants)this.sessionParticipantsBySessionId.remove(sessionId);
      if (participants != null) {
         CourtshipSession session = (CourtshipSession)this.activeSessionsByParticipant.remove(participants.firstParticipantId());
         this.activeSessionsByParticipant.remove(participants.secondParticipantId());
         this.invitesByReceiver.remove(participants.firstParticipantId());
         this.invitesByReceiver.remove(participants.secondParticipantId());
         if (session != null) {
            CourtshipPhase terminalPhase = reason == CourtshipCloseReason.COMPLETED ? CourtshipPhase.COMPLETED : CourtshipPhase.ABORTED;
            session.transitionTo(terminalPhase, session.getPhaseEnteredGameTime());
            log.info("Closed courtship session: sessionId={}, reason={}, terminalPhase={}", sessionId, reason, terminalPhase);
         }
      }
   }

   public void tickTimeouts(long currentGameTime) {
      this.invitesByReceiver.entrySet().removeIf((entry) -> ((CourtshipInvite)entry.getValue()).expireGameTime() < currentGameTime);
      Set<UUID> seenSessionIds = new HashSet();

      for(CourtshipSession session : this.activeSessionsByParticipant.values()) {
         if (seenSessionIds.add(session.getSessionId())) {
            long maxDurationTicks = this.maxDurationTicks(session);
            if (maxDurationTicks >= 0L && currentGameTime - session.getPhaseEnteredGameTime() > maxDurationTicks) {
               log.info("Courtship session timed out: sessionId={}, phase={}", session.getSessionId(), session.getPhase());
               this.closeSession(session.getSessionId(), CourtshipCloseReason.TIMEOUT);
            }
         }
      }

   }

   private long maxDurationTicks(@Nonnull CourtshipSession session) {
      long var10000;
      switch (session.getPhase()) {
         case INVITE_SENT:
            var10000 = ClockTicks.seconds((double)15.0F).getTicks();
            break;
         case ACCEPTED:
            var10000 = ClockTicks.seconds((double)2.0F).getTicks();
            break;
         case APPROACH:
            var10000 = ClockTicks.seconds((double)15.0F).getTicks() + (long)DEADLINE_SLACK_TICKS;
            break;
         case COURTSHIP:
            var10000 = (long)session.getCourtshipDurationTicks() * 2L + (long)DEADLINE_SLACK_TICKS;
            break;
         case BIRTH:
            var10000 = ClockTicks.seconds((double)5.0F).getTicks() + (long)DEADLINE_SLACK_TICKS;
            break;
         case COMPLETED:
         case ABORTED:
            var10000 = -1L;
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   private void putSession(@Nonnull CourtshipSession session) {
      SessionParticipants participants = new SessionParticipants(session.getPresenterId(), session.getReceiverId());
      this.activeSessionsByParticipant.put(participants.firstParticipantId(), session);
      this.activeSessionsByParticipant.put(participants.secondParticipantId(), session);
      this.sessionParticipantsBySessionId.put(session.getSessionId(), participants);
   }

   private static record SessionParticipants(@Nonnull UUID firstParticipantId, @Nonnull UUID secondParticipantId) {
   }
}
