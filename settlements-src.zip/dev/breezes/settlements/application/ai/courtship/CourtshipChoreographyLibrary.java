package dev.breezes.settlements.application.ai.courtship;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.animation.AnimationArchetype;
import dev.breezes.settlements.infrastructure.compat.CompatMath;
import jakarta.inject.Inject;
import java.util.List;
import javax.annotation.Nonnull;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;

@ServerScope
public final class CourtshipChoreographyLibrary {
   private static final int TICKS_PER_BEAT = 50;
   private final List<ChoreographyTimeline> routines;

   @Inject
   public CourtshipChoreographyLibrary() {
      this.routines = List.of(FixedTempoChoreographyTimeline.builder().beats(List.of(new CourtshipBeat(AnimationArchetype.INTERACT, AnimationArchetype.IDLE, (SoundEvent)null), new CourtshipBeat(AnimationArchetype.POINT, AnimationArchetype.POINT, SoundEvents.f_12509_), new CourtshipBeat(AnimationArchetype.INTERACT, AnimationArchetype.EAT, (SoundEvent)null), new CourtshipBeat(AnimationArchetype.IDLE, AnimationArchetype.INTERACT, (SoundEvent)null), new CourtshipBeat(AnimationArchetype.POINT, AnimationArchetype.IDLE, SoundEvents.f_12509_), new CourtshipBeat(AnimationArchetype.INTERACT, AnimationArchetype.INTERACT, (SoundEvent)null))).ticksPerBeat(50).build(), FixedTempoChoreographyTimeline.builder().beats(List.of(new CourtshipBeat(AnimationArchetype.EAT, AnimationArchetype.EAT, (SoundEvent)null), new CourtshipBeat(AnimationArchetype.IDLE, AnimationArchetype.POINT, (SoundEvent)null), new CourtshipBeat(AnimationArchetype.EAT, AnimationArchetype.EAT, SoundEvents.f_12509_), new CourtshipBeat(AnimationArchetype.POINT, AnimationArchetype.IDLE, (SoundEvent)null), new CourtshipBeat(AnimationArchetype.EAT, AnimationArchetype.EAT, (SoundEvent)null))).ticksPerBeat(50).build(), FixedTempoChoreographyTimeline.builder().beats(List.of(new CourtshipBeat(AnimationArchetype.POINT, AnimationArchetype.IDLE, (SoundEvent)null), new CourtshipBeat(AnimationArchetype.IDLE, AnimationArchetype.POINT, SoundEvents.f_12509_), new CourtshipBeat(AnimationArchetype.INTERACT, AnimationArchetype.IDLE, (SoundEvent)null), new CourtshipBeat(AnimationArchetype.IDLE, AnimationArchetype.INTERACT, (SoundEvent)null), new CourtshipBeat(AnimationArchetype.POINT, AnimationArchetype.POINT, SoundEvents.f_12509_), new CourtshipBeat(AnimationArchetype.IDLE, AnimationArchetype.IDLE, (SoundEvent)null))).ticksPerBeat(50).build(), FixedTempoChoreographyTimeline.builder().beats(List.of(new CourtshipBeat(AnimationArchetype.INTERACT, AnimationArchetype.POINT, (SoundEvent)null), new CourtshipBeat(AnimationArchetype.IDLE, AnimationArchetype.INTERACT, (SoundEvent)null), new CourtshipBeat(AnimationArchetype.POINT, AnimationArchetype.EAT, SoundEvents.f_12509_), new CourtshipBeat(AnimationArchetype.INTERACT, AnimationArchetype.IDLE, (SoundEvent)null), new CourtshipBeat(AnimationArchetype.IDLE, AnimationArchetype.POINT, (SoundEvent)null))).ticksPerBeat(50).build());
   }

   public int size() {
      return this.routines.size();
   }

   public ChoreographyTimeline get(int id) {
      int safeId = CompatMath.clamp(id, 0, this.routines.size() - 1);
      return (ChoreographyTimeline)this.routines.get(safeId);
   }

   public int selectRandom(@Nonnull RandomSource random) {
      return random.m_188503_(this.routines.size());
   }
}
