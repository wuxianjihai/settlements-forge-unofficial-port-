package dev.breezes.settlements.application.ai.courtship;

import dev.breezes.settlements.domain.animation.AnimationArchetype;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.sounds.SoundEvent;

public record CourtshipBeat(@Nonnull AnimationArchetype presenterMotion, @Nonnull AnimationArchetype receiverMotion, @Nullable SoundEvent sound) {
   public AnimationArchetype motionFor(@Nonnull CourtshipRole role) {
      return role == CourtshipRole.PRESENTER ? this.presenterMotion : this.receiverMotion;
   }
}
