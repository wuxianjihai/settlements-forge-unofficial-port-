package dev.breezes.settlements.application.ai.courtship;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class CourtshipSelfMemoryRecorder_Factory implements Factory<CourtshipSelfMemoryRecorder> {
   public CourtshipSelfMemoryRecorder get() {
      return newInstance();
   }

   public static CourtshipSelfMemoryRecorder_Factory create() {
      return CourtshipSelfMemoryRecorder_Factory.InstanceHolder.INSTANCE;
   }

   public static CourtshipSelfMemoryRecorder newInstance() {
      return new CourtshipSelfMemoryRecorder();
   }

   private static final class InstanceHolder {
      static final CourtshipSelfMemoryRecorder_Factory INSTANCE = new CourtshipSelfMemoryRecorder_Factory();
   }
}
