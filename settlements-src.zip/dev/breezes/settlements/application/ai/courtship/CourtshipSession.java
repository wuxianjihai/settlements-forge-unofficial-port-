package dev.breezes.settlements.application.ai.courtship;

import java.util.UUID;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class CourtshipSession {
   private final UUID sessionId;
   private final UUID presenterId;
   private final UUID receiverId;
   private int courtshipDurationTicks;
   private CourtshipPhase phase;
   private long phaseEnteredGameTime;
   private long courtshipStartGameTime;
   private int currentBeatIndex;
   private int choreographyId;
   private boolean resolved;

   public void transitionTo(@Nonnull CourtshipPhase next, long now) {
      this.phase = next;
      this.phaseEnteredGameTime = now;
   }

   public void beginCourtship(long now, int actualDurationTicks) {
      this.courtshipStartGameTime = now;
      this.courtshipDurationTicks = actualDurationTicks;
      this.phase = CourtshipPhase.COURTSHIP;
      this.phaseEnteredGameTime = now;
   }

   public void advanceBeat(int beatIndex) {
      this.currentBeatIndex = beatIndex;
   }

   public void markResolved() {
      this.resolved = true;
   }

   public UUID partnerOf(@Nonnull UUID villagerId) {
      return villagerId.equals(this.presenterId) ? this.receiverId : this.presenterId;
   }

   @Generated
   private static long $default$courtshipStartGameTime() {
      return -1L;
   }

   @Generated
   private static int $default$currentBeatIndex() {
      return 0;
   }

   @Generated
   private static int $default$choreographyId() {
      return 0;
   }

   @Generated
   CourtshipSession(UUID sessionId, UUID presenterId, UUID receiverId, int courtshipDurationTicks, CourtshipPhase phase, long phaseEnteredGameTime, long courtshipStartGameTime, int currentBeatIndex, int choreographyId, boolean resolved) {
      this.sessionId = sessionId;
      this.presenterId = presenterId;
      this.receiverId = receiverId;
      this.courtshipDurationTicks = courtshipDurationTicks;
      this.phase = phase;
      this.phaseEnteredGameTime = phaseEnteredGameTime;
      this.courtshipStartGameTime = courtshipStartGameTime;
      this.currentBeatIndex = currentBeatIndex;
      this.choreographyId = choreographyId;
      this.resolved = resolved;
   }

   @Generated
   public static CourtshipSessionBuilder builder() {
      return new CourtshipSessionBuilder();
   }

   @Generated
   public UUID getSessionId() {
      return this.sessionId;
   }

   @Generated
   public UUID getPresenterId() {
      return this.presenterId;
   }

   @Generated
   public UUID getReceiverId() {
      return this.receiverId;
   }

   @Generated
   public int getCourtshipDurationTicks() {
      return this.courtshipDurationTicks;
   }

   @Generated
   public CourtshipPhase getPhase() {
      return this.phase;
   }

   @Generated
   public long getPhaseEnteredGameTime() {
      return this.phaseEnteredGameTime;
   }

   @Generated
   public long getCourtshipStartGameTime() {
      return this.courtshipStartGameTime;
   }

   @Generated
   public int getCurrentBeatIndex() {
      return this.currentBeatIndex;
   }

   @Generated
   public int getChoreographyId() {
      return this.choreographyId;
   }

   @Generated
   public boolean isResolved() {
      return this.resolved;
   }

   @Generated
   public void setChoreographyId(int choreographyId) {
      this.choreographyId = choreographyId;
   }

   @Generated
   public static class CourtshipSessionBuilder {
      @Generated
      private UUID sessionId;
      @Generated
      private UUID presenterId;
      @Generated
      private UUID receiverId;
      @Generated
      private int courtshipDurationTicks;
      @Generated
      private CourtshipPhase phase;
      @Generated
      private long phaseEnteredGameTime;
      @Generated
      private boolean courtshipStartGameTime$set;
      @Generated
      private long courtshipStartGameTime$value;
      @Generated
      private boolean currentBeatIndex$set;
      @Generated
      private int currentBeatIndex$value;
      @Generated
      private boolean choreographyId$set;
      @Generated
      private int choreographyId$value;
      @Generated
      private boolean resolved;

      @Generated
      CourtshipSessionBuilder() {
      }

      @Generated
      public CourtshipSessionBuilder sessionId(UUID sessionId) {
         this.sessionId = sessionId;
         return this;
      }

      @Generated
      public CourtshipSessionBuilder presenterId(UUID presenterId) {
         this.presenterId = presenterId;
         return this;
      }

      @Generated
      public CourtshipSessionBuilder receiverId(UUID receiverId) {
         this.receiverId = receiverId;
         return this;
      }

      @Generated
      public CourtshipSessionBuilder courtshipDurationTicks(int courtshipDurationTicks) {
         this.courtshipDurationTicks = courtshipDurationTicks;
         return this;
      }

      @Generated
      public CourtshipSessionBuilder phase(CourtshipPhase phase) {
         this.phase = phase;
         return this;
      }

      @Generated
      public CourtshipSessionBuilder phaseEnteredGameTime(long phaseEnteredGameTime) {
         this.phaseEnteredGameTime = phaseEnteredGameTime;
         return this;
      }

      @Generated
      public CourtshipSessionBuilder courtshipStartGameTime(long courtshipStartGameTime) {
         this.courtshipStartGameTime$value = courtshipStartGameTime;
         this.courtshipStartGameTime$set = true;
         return this;
      }

      @Generated
      public CourtshipSessionBuilder currentBeatIndex(int currentBeatIndex) {
         this.currentBeatIndex$value = currentBeatIndex;
         this.currentBeatIndex$set = true;
         return this;
      }

      @Generated
      public CourtshipSessionBuilder choreographyId(int choreographyId) {
         this.choreographyId$value = choreographyId;
         this.choreographyId$set = true;
         return this;
      }

      @Generated
      public CourtshipSessionBuilder resolved(boolean resolved) {
         this.resolved = resolved;
         return this;
      }

      @Generated
      public CourtshipSession build() {
         long courtshipStartGameTime$value = this.courtshipStartGameTime$value;
         if (!this.courtshipStartGameTime$set) {
            courtshipStartGameTime$value = CourtshipSession.$default$courtshipStartGameTime();
         }

         int currentBeatIndex$value = this.currentBeatIndex$value;
         if (!this.currentBeatIndex$set) {
            currentBeatIndex$value = CourtshipSession.$default$currentBeatIndex();
         }

         int choreographyId$value = this.choreographyId$value;
         if (!this.choreographyId$set) {
            choreographyId$value = CourtshipSession.$default$choreographyId();
         }

         return new CourtshipSession(this.sessionId, this.presenterId, this.receiverId, this.courtshipDurationTicks, this.phase, this.phaseEnteredGameTime, courtshipStartGameTime$value, currentBeatIndex$value, choreographyId$value, this.resolved);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.sessionId);
         return "CourtshipSession.CourtshipSessionBuilder(sessionId=" + var10000 + ", presenterId=" + String.valueOf(this.presenterId) + ", receiverId=" + String.valueOf(this.receiverId) + ", courtshipDurationTicks=" + this.courtshipDurationTicks + ", phase=" + String.valueOf(this.phase) + ", phaseEnteredGameTime=" + this.phaseEnteredGameTime + ", courtshipStartGameTime$value=" + this.courtshipStartGameTime$value + ", currentBeatIndex$value=" + this.currentBeatIndex$value + ", choreographyId$value=" + this.choreographyId$value + ", resolved=" + this.resolved + ")";
      }
   }
}
