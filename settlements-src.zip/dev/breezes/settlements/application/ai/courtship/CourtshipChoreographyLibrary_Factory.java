package dev.breezes.settlements.application.ai.courtship;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class CourtshipChoreographyLibrary_Factory implements Factory<CourtshipChoreographyLibrary> {
   public CourtshipChoreographyLibrary get() {
      return newInstance();
   }

   public static CourtshipChoreographyLibrary_Factory create() {
      return CourtshipChoreographyLibrary_Factory.InstanceHolder.INSTANCE;
   }

   public static CourtshipChoreographyLibrary newInstance() {
      return new CourtshipChoreographyLibrary();
   }

   private static final class InstanceHolder {
      static final CourtshipChoreographyLibrary_Factory INSTANCE = new CourtshipChoreographyLibrary_Factory();
   }
}
