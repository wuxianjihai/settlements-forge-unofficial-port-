package dev.breezes.settlements.application.ai.trading;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.world.item.Item;

@ServerScope
public final class TradeSessionRegistry {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(TradeSessionRegistry.class.getName());
   private static final int DEADLINE_SLACK_TICKS = ClockTicks.seconds((double)2.0F).getTicksAsInt();
   private final TradingConfig tradingConfig;
   private final Map<UUID, TradeSession> activeSessionsByParticipant = new ConcurrentHashMap();
   private final Map<UUID, SessionParticipants> sessionParticipantsBySessionId = new ConcurrentHashMap();
   private final Map<UUID, TradeInvite> invitesByTarget = new ConcurrentHashMap();

   @Inject
   public TradeSessionRegistry(@Nonnull TradingConfig tradingConfig) {
      this.tradingConfig = tradingConfig;
   }

   public TradeSession sendInvite(@Nonnull BaseVillager initiator, @Nonnull BaseVillager target, @Nonnull UUID buyerId, @Nonnull UUID sellerId, @Nonnull Item matchedItem, int bundleSize, int priceJitter, int buyerOffer, int sellerAsk, int negotiationRoundsRemaining, long currentGameTime) {
      UUID sessionId = UUID.randomUUID();
      TradeSession session = TradeSession.builder().sessionId(sessionId).initiatorId(initiator.m_20148_()).responderId(target.m_20148_()).buyerId(buyerId).sellerId(sellerId).matchedItem(matchedItem).bundleSize(bundleSize).priceJitter(priceJitter).buyerOffer(buyerOffer).sellerAsk(sellerAsk).negotiationRoundsRemaining(negotiationRoundsRemaining).phase(TradeSessionPhase.SYN_SENT).phaseEnteredGameTime(currentGameTime).build();
      long inviteExpireGameTime = currentGameTime + ClockTicks.seconds((double)this.tradingConfig.inviteTimeoutSeconds()).getTicks();
      TradeInvite invite = new TradeInvite(sessionId, initiator.m_20148_(), target.m_20148_(), currentGameTime, inviteExpireGameTime);
      this.putSession(session);
      this.invitesByTarget.put(target.m_20148_(), invite);
      log.info("Created trade invite: sessionId={}, initiator={}, responder={}, buyer={}, seller={}, item={}, bundleSize={}, priceJitter={}, buyerOffer={}, sellerAsk={}", sessionId, initiator.m_20148_(), target.m_20148_(), buyerId, sellerId, matchedItem, bundleSize, priceJitter, buyerOffer, sellerAsk);
      return session;
   }

   public boolean hasInviteFor(@Nonnull UUID targetId) {
      return this.invitesByTarget.containsKey(targetId);
   }

   public Optional<TradeInvite> getInvite(@Nonnull UUID targetId) {
      return Optional.ofNullable((TradeInvite)this.invitesByTarget.get(targetId));
   }

   public TradeSession acceptInvite(@Nonnull UUID targetId, long currentGameTime) {
      TradeInvite var10000 = (TradeInvite)Optional.ofNullable((TradeInvite)this.invitesByTarget.remove(targetId)).orElseThrow(() -> new IllegalArgumentException("No pending trade invite exists for targetId=" + String.valueOf(targetId)));
      TradeSession session = (TradeSession)Optional.ofNullable((TradeSession)this.activeSessionsByParticipant.get(targetId)).orElseThrow(() -> new IllegalStateException("Pending trade invite had no matching active session"));
      session.transitionTo(TradeSessionPhase.ESTABLISHED, currentGameTime);
      log.info("Accepted trade invite: sessionId={}, targetId={}, phase={}", session.getSessionId(), targetId, session.getPhase());
      return session;
   }

   public Optional<TradeSession> getActiveSession(@Nonnull UUID villagerId) {
      return Optional.ofNullable((TradeSession)this.activeSessionsByParticipant.get(villagerId));
   }

   public void closeSession(@Nonnull UUID sessionId, @Nonnull CloseReason reason) {
      SessionParticipants participants = (SessionParticipants)this.sessionParticipantsBySessionId.remove(sessionId);
      if (participants != null) {
         TradeSession session = (TradeSession)this.activeSessionsByParticipant.remove(participants.firstParticipantId());
         this.activeSessionsByParticipant.remove(participants.secondParticipantId());
         this.invitesByTarget.remove(participants.secondParticipantId());
         this.invitesByTarget.remove(participants.firstParticipantId());
         if (session != null) {
            TradeSessionPhase var10000;
            switch (reason) {
               case DEAL -> var10000 = TradeSessionPhase.DEAL;
               case WALK_AWAY -> var10000 = TradeSessionPhase.WALK_AWAY;
               case EXTERNAL_CANCEL -> var10000 = TradeSessionPhase.EXTERNAL_CANCEL;
               case TIMEOUT -> var10000 = TradeSessionPhase.CLOSED;
               default -> throw new IncompatibleClassChangeError();
            }

            TradeSessionPhase terminalPhase = var10000;
            session.transitionTo(terminalPhase, session.getPhaseEnteredGameTime());
            log.info("Closed trade session: sessionId={}, reason={}, terminalPhase={}", sessionId, reason, terminalPhase);
         }
      }
   }

   public void tickTimeouts(long currentGameTime) {
      this.invitesByTarget.entrySet().removeIf((entry) -> ((TradeInvite)entry.getValue()).expireGameTime() < currentGameTime);
      Set<UUID> seenSessionIds = new HashSet();

      for(TradeSession session : this.activeSessionsByParticipant.values()) {
         if (seenSessionIds.add(session.getSessionId())) {
            long maxDurationTicks = this.maxDurationTicks(session.getPhase());
            if (maxDurationTicks >= 0L && currentGameTime - session.getPhaseEnteredGameTime() > maxDurationTicks) {
               log.info("Trade session timed out: sessionId={}, phase={}, phaseEnteredGameTime={}, currentGameTime={}", session.getSessionId(), session.getPhase(), session.getPhaseEnteredGameTime(), currentGameTime);
               this.closeSession(session.getSessionId(), CloseReason.TIMEOUT);
            }
         }
      }

   }

   private long maxDurationTicks(@Nonnull TradeSessionPhase phase) {
      long var10000;
      switch (phase) {
         case SYN_SENT:
            var10000 = ClockTicks.seconds((double)this.tradingConfig.inviteTimeoutSeconds()).getTicks();
            break;
         case ESTABLISHED:
            var10000 = ClockTicks.seconds((double)2.0F).getTicks();
            break;
         case APPROACH:
            var10000 = ClockTicks.seconds((double)10.0F).getTicks() + (long)DEADLINE_SLACK_TICKS;
            break;
         case OPENING_OFFER:
            var10000 = this.tradingConfig.openingOfferDuration().getTicks() * 2L + (long)DEADLINE_SLACK_TICKS;
            break;
         case NEGOTIATING:
            var10000 = this.tradingConfig.negotiationRoundDuration().getTicks() * 2L * (long)this.tradingConfig.maxNegotiationRounds() + (long)DEADLINE_SLACK_TICKS;
            break;
         case DEAL:
            var10000 = this.tradingConfig.dealDuration().getTicks() + (long)DEADLINE_SLACK_TICKS;
            break;
         case WALK_AWAY:
            var10000 = this.tradingConfig.walkawayDuration().getTicks() + (long)DEADLINE_SLACK_TICKS;
            break;
         case EXTERNAL_CANCEL:
         case CLOSED:
            var10000 = -1L;
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   private void putSession(@Nonnull TradeSession session) {
      SessionParticipants participants = new SessionParticipants(session.getInitiatorId(), session.getResponderId());
      this.activeSessionsByParticipant.put(participants.firstParticipantId(), session);
      this.activeSessionsByParticipant.put(participants.secondParticipantId(), session);
      this.sessionParticipantsBySessionId.put(session.getSessionId(), participants);
   }

   private static record SessionParticipants(@Nonnull UUID firstParticipantId, @Nonnull UUID secondParticipantId) {
   }
}
