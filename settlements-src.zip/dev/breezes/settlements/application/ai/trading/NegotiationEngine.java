package dev.breezes.settlements.application.ai.trading;

import dev.breezes.settlements.infrastructure.compat.CompatMath;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import dev.breezes.settlements.shared.util.RandomUtil;
import lombok.Generated;

public final class NegotiationEngine {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(NegotiationEngine.class.getName());

   public NegotiationRoundResult advanceRound(int buyerOffer, int sellerAsk, int priceJitter) {
      if (buyerOffer > 0 && sellerAsk > 0) {
         if (priceJitter < 0) {
            throw new IllegalArgumentException("Negotiation priceJitter must be non-negative");
         } else if (buyerOffer >= sellerAsk) {
            throw new IllegalArgumentException("Negotiation advance requires a positive spread");
         } else {
            log.info("Negotiation round start: buyerOffer={}, sellerAsk={}, priceJitter={}", buyerOffer, sellerAsk, priceJitter);
            int spread = sellerAsk - buyerOffer;
            int buyerConcession = this.randomConcessionAmount(spread);
            int sellerConcession = this.randomConcessionAmount(spread);
            int nextBuyerOffer = Math.min(buyerOffer + buyerConcession, sellerAsk);
            int nextSellerAsk = Math.max(nextBuyerOffer, sellerAsk - sellerConcession);
            log.info("Negotiation round result: nextBuyerOffer={}, nextSellerAsk={}, buyerConcession={}, sellerConcession={}", nextBuyerOffer, nextSellerAsk, buyerConcession, sellerConcession);
            return new NegotiationRoundResult(nextBuyerOffer, nextSellerAsk);
         }
      } else {
         throw new IllegalArgumentException("Negotiation prices must be positive");
      }
   }

   private int randomConcessionAmount(int spread) {
      int minimumConcession;
      int maximumConcession;
      if (spread >= 20) {
         minimumConcession = Math.max(1, (int)Math.ceil((double)spread * 0.05));
         maximumConcession = Math.max(minimumConcession, (int)Math.floor((double)spread * 0.2));
      } else if (spread >= 10) {
         minimumConcession = Math.max(2, (int)Math.ceil((double)spread * 0.1));
         maximumConcession = Math.max(minimumConcession, (int)Math.floor((double)spread * (double)0.25F));
      } else {
         minimumConcession = CompatMath.clamp((int)Math.ceil((double)spread * 0.2), 2, spread);
         maximumConcession = Math.max(minimumConcession, (int)Math.floor((double)spread * 0.4));
      }

      maximumConcession = Math.min(spread, maximumConcession);
      return RandomUtil.randomInt(minimumConcession, maximumConcession, true);
   }

   public static enum ConcedingSide {
      BUYER,
      SELLER;

      // $FF: synthetic method
      private static ConcedingSide[] $values() {
         return new ConcedingSide[]{BUYER, SELLER};
      }
   }

   public static record NegotiationRoundResult(int buyerOffer, int sellerAsk) {
   }
}
