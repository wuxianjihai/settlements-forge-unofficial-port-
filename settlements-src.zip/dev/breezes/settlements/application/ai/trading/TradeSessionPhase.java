package dev.breezes.settlements.application.ai.trading;

public enum TradeSessionPhase {
   SYN_SENT,
   ESTABLISHED,
   APPROACH,
   OPENING_OFFER,
   NEGOTIATING,
   DEAL,
   WALK_AWAY,
   EXTERNAL_CANCEL,
   CLOSED;

   // $FF: synthetic method
   private static TradeSessionPhase[] $values() {
      return new TradeSessionPhase[]{SYN_SENT, ESTABLISHED, APPROACH, OPENING_OFFER, NEGOTIATING, DEAL, WALK_AWAY, EXTERNAL_CANCEL, CLOSED};
   }
}
