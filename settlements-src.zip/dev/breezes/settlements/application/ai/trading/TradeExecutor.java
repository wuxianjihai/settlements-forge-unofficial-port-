package dev.breezes.settlements.application.ai.trading;

import dev.breezes.settlements.application.economy.VillagerWallet;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.inventory.VillagerInventory;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import dev.breezes.settlements.shared.logging.ILogger;
import dev.breezes.settlements.shared.logging.LoggerFactory;
import jakarta.inject.Inject;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.world.item.ItemStack;

@ServerScope
public final class TradeExecutor {
   @Generated
   private static final ILogger log = LoggerFactory.getLogger(TradeExecutor.class.getName());
   private final VillagerWallet villagerWallet;

   public void execute(@Nonnull TradeSession session, @Nonnull BaseVillager buyer, @Nonnull BaseVillager seller) {
      VillagerInventory buyerInventory = buyer.getSettlementsInventory();
      VillagerInventory sellerInventory = seller.getSettlementsInventory();
      this.validateTrade(session, buyer, seller, sellerInventory);
      log.info("Executing trade session {}: buyer={}, seller={}, item={}, bundleSize={}, price={}", session.getSessionId(), buyer.m_20148_(), seller.m_20148_(), session.getMatchedItem(), session.getBundleSize(), session.getBuyerOffer());
      this.villagerWallet.transfer(buyer, seller, session.getBuyerOffer());
      int removed = sellerInventory.consume(session.getMatchedItem(), session.getBundleSize());
      if (removed != session.getBundleSize()) {
         throw new IllegalStateException("Validated seller inventory drifted before trade commit");
      } else {
         buyerInventory.add(new ItemStack(session.getMatchedItem(), session.getBundleSize()));
      }
   }

   private void validateTrade(@Nonnull TradeSession session, @Nonnull BaseVillager buyer, @Nonnull BaseVillager seller, @Nonnull VillagerInventory sellerInventory) {
      if (!buyer.m_20148_().equals(session.getBuyerId())) {
         throw new IllegalArgumentException("Trade buyer does not match session buyerId");
      } else if (!seller.m_20148_().equals(session.getSellerId())) {
         throw new IllegalArgumentException("Trade seller does not match session sellerId");
      } else if (!this.villagerWallet.canAfford(buyer, session.getBuyerOffer())) {
         throw new IllegalArgumentException("Trade buyer cannot afford the agreed price");
      } else if (sellerInventory.count(session.getMatchedItem()) < session.getBundleSize()) {
         throw new IllegalArgumentException("Trade seller does not have enough matching items");
      }
   }

   @Inject
   @Generated
   TradeExecutor(VillagerWallet villagerWallet) {
      this.villagerWallet = villagerWallet;
   }
}
