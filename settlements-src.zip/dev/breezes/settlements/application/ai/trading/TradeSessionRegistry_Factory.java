package dev.breezes.settlements.application.ai.trading;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class TradeSessionRegistry_Factory implements Factory<TradeSessionRegistry> {
   private final Provider<TradingConfig> tradingConfigProvider;

   private TradeSessionRegistry_Factory(Provider<TradingConfig> tradingConfigProvider) {
      this.tradingConfigProvider = tradingConfigProvider;
   }

   public TradeSessionRegistry get() {
      return newInstance((TradingConfig)this.tradingConfigProvider.get());
   }

   public static TradeSessionRegistry_Factory create(Provider<TradingConfig> tradingConfigProvider) {
      return new TradeSessionRegistry_Factory(tradingConfigProvider);
   }

   public static TradeSessionRegistry newInstance(TradingConfig tradingConfig) {
      return new TradeSessionRegistry(tradingConfig);
   }
}
