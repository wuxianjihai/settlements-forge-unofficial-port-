package dev.breezes.settlements.application.ai.trading;

import java.util.UUID;
import javax.annotation.Nonnull;
import lombok.Generated;

public record TradeInvite(@Nonnull UUID sessionId, @Nonnull UUID initiatorId, @Nonnull UUID targetId, long createdGameTime, long expireGameTime) {
   @Generated
   public static TradeInviteBuilder builder() {
      return new TradeInviteBuilder();
   }

   @Generated
   public static class TradeInviteBuilder {
      @Generated
      private UUID sessionId;
      @Generated
      private UUID initiatorId;
      @Generated
      private UUID targetId;
      @Generated
      private long createdGameTime;
      @Generated
      private long expireGameTime;

      @Generated
      TradeInviteBuilder() {
      }

      @Generated
      public TradeInviteBuilder sessionId(@Nonnull UUID sessionId) {
         if (sessionId == null) {
            throw new NullPointerException("sessionId is marked non-null but is null");
         } else {
            this.sessionId = sessionId;
            return this;
         }
      }

      @Generated
      public TradeInviteBuilder initiatorId(@Nonnull UUID initiatorId) {
         if (initiatorId == null) {
            throw new NullPointerException("initiatorId is marked non-null but is null");
         } else {
            this.initiatorId = initiatorId;
            return this;
         }
      }

      @Generated
      public TradeInviteBuilder targetId(@Nonnull UUID targetId) {
         if (targetId == null) {
            throw new NullPointerException("targetId is marked non-null but is null");
         } else {
            this.targetId = targetId;
            return this;
         }
      }

      @Generated
      public TradeInviteBuilder createdGameTime(long createdGameTime) {
         this.createdGameTime = createdGameTime;
         return this;
      }

      @Generated
      public TradeInviteBuilder expireGameTime(long expireGameTime) {
         this.expireGameTime = expireGameTime;
         return this;
      }

      @Generated
      public TradeInvite build() {
         return new TradeInvite(this.sessionId, this.initiatorId, this.targetId, this.createdGameTime, this.expireGameTime);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.sessionId);
         return "TradeInvite.TradeInviteBuilder(sessionId=" + var10000 + ", initiatorId=" + String.valueOf(this.initiatorId) + ", targetId=" + String.valueOf(this.targetId) + ", createdGameTime=" + this.createdGameTime + ", expireGameTime=" + this.expireGameTime + ")";
      }
   }
}
