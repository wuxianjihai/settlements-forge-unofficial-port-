package dev.breezes.settlements.application.ai.trading;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.application.economy.VillagerWallet;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class TradeExecutor_Factory implements Factory<TradeExecutor> {
   private final Provider<VillagerWallet> villagerWalletProvider;

   private TradeExecutor_Factory(Provider<VillagerWallet> villagerWalletProvider) {
      this.villagerWalletProvider = villagerWalletProvider;
   }

   public TradeExecutor get() {
      return newInstance((VillagerWallet)this.villagerWalletProvider.get());
   }

   public static TradeExecutor_Factory create(Provider<VillagerWallet> villagerWalletProvider) {
      return new TradeExecutor_Factory(villagerWalletProvider);
   }

   public static TradeExecutor newInstance(VillagerWallet villagerWallet) {
      return new TradeExecutor(villagerWallet);
   }
}
