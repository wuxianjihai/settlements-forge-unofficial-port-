package dev.breezes.settlements.application.ai.trading;

public enum CloseReason {
   DEAL,
   WALK_AWAY,
   EXTERNAL_CANCEL,
   TIMEOUT;

   // $FF: synthetic method
   private static CloseReason[] $values() {
      return new CloseReason[]{DEAL, WALK_AWAY, EXTERNAL_CANCEL, TIMEOUT};
   }
}
