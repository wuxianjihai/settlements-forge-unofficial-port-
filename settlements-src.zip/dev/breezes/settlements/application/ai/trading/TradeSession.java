package dev.breezes.settlements.application.ai.trading;

import java.util.UUID;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.world.item.Item;

public final class TradeSession {
   private final UUID sessionId;
   private final UUID initiatorId;
   private final UUID responderId;
   private final UUID buyerId;
   private final UUID sellerId;
   private final Item matchedItem;
   private final int bundleSize;
   private final int priceJitter;
   private int buyerOffer;
   private int sellerAsk;
   private int negotiationRoundsRemaining;
   private TradeSessionPhase phase;
   private long phaseEnteredGameTime;

   public TradeSession(@Nonnull UUID sessionId, @Nonnull UUID initiatorId, @Nonnull UUID responderId, @Nonnull UUID buyerId, @Nonnull UUID sellerId, @Nonnull Item matchedItem, int bundleSize, int priceJitter, int buyerOffer, int sellerAsk, int negotiationRoundsRemaining, @Nonnull TradeSessionPhase phase, long phaseEnteredGameTime) {
      if (bundleSize <= 0) {
         throw new IllegalArgumentException("Trade session bundleSize must be positive");
      } else if (priceJitter < 0) {
         throw new IllegalArgumentException("Trade session priceJitter must be non-negative");
      } else if (buyerOffer <= 0) {
         throw new IllegalArgumentException("Trade session buyerOffer must be positive");
      } else if (sellerAsk <= 0) {
         throw new IllegalArgumentException("Trade session sellerAsk must be positive");
      } else if (negotiationRoundsRemaining < 0) {
         throw new IllegalArgumentException("Trade session negotiationRoundsRemaining must be non-negative");
      } else {
         this.sessionId = sessionId;
         this.initiatorId = initiatorId;
         this.responderId = responderId;
         this.buyerId = buyerId;
         this.sellerId = sellerId;
         this.matchedItem = matchedItem;
         this.bundleSize = bundleSize;
         this.priceJitter = priceJitter;
         this.buyerOffer = buyerOffer;
         this.sellerAsk = sellerAsk;
         this.negotiationRoundsRemaining = negotiationRoundsRemaining;
         this.phase = phase;
         this.phaseEnteredGameTime = phaseEnteredGameTime;
      }
   }

   public void setBuyerOffer(int buyerOffer) {
      if (buyerOffer <= 0) {
         throw new IllegalArgumentException("Trade session buyerOffer must be positive");
      } else {
         this.buyerOffer = buyerOffer;
      }
   }

   public void setSellerAsk(int sellerAsk) {
      if (sellerAsk <= 0) {
         throw new IllegalArgumentException("Trade session sellerAsk must be positive");
      } else {
         this.sellerAsk = sellerAsk;
      }
   }

   public void setNegotiationRoundsRemaining(int negotiationRoundsRemaining) {
      if (negotiationRoundsRemaining < 0) {
         throw new IllegalArgumentException("Trade session negotiationRoundsRemaining must be non-negative");
      } else {
         this.negotiationRoundsRemaining = negotiationRoundsRemaining;
      }
   }

   public void transitionTo(@Nonnull TradeSessionPhase nextPhase, long currentGameTime) {
      this.phase = nextPhase;
      this.phaseEnteredGameTime = currentGameTime;
   }

   @Generated
   public static TradeSessionBuilder builder() {
      return new TradeSessionBuilder();
   }

   @Generated
   public UUID getSessionId() {
      return this.sessionId;
   }

   @Generated
   public UUID getInitiatorId() {
      return this.initiatorId;
   }

   @Generated
   public UUID getResponderId() {
      return this.responderId;
   }

   @Generated
   public UUID getBuyerId() {
      return this.buyerId;
   }

   @Generated
   public UUID getSellerId() {
      return this.sellerId;
   }

   @Generated
   public Item getMatchedItem() {
      return this.matchedItem;
   }

   @Generated
   public int getBundleSize() {
      return this.bundleSize;
   }

   @Generated
   public int getPriceJitter() {
      return this.priceJitter;
   }

   @Generated
   public int getBuyerOffer() {
      return this.buyerOffer;
   }

   @Generated
   public int getSellerAsk() {
      return this.sellerAsk;
   }

   @Generated
   public int getNegotiationRoundsRemaining() {
      return this.negotiationRoundsRemaining;
   }

   @Generated
   public TradeSessionPhase getPhase() {
      return this.phase;
   }

   @Generated
   public long getPhaseEnteredGameTime() {
      return this.phaseEnteredGameTime;
   }

   @Generated
   public static class TradeSessionBuilder {
      @Generated
      private UUID sessionId;
      @Generated
      private UUID initiatorId;
      @Generated
      private UUID responderId;
      @Generated
      private UUID buyerId;
      @Generated
      private UUID sellerId;
      @Generated
      private Item matchedItem;
      @Generated
      private int bundleSize;
      @Generated
      private int priceJitter;
      @Generated
      private int buyerOffer;
      @Generated
      private int sellerAsk;
      @Generated
      private int negotiationRoundsRemaining;
      @Generated
      private TradeSessionPhase phase;
      @Generated
      private long phaseEnteredGameTime;

      @Generated
      TradeSessionBuilder() {
      }

      @Generated
      public TradeSessionBuilder sessionId(@Nonnull UUID sessionId) {
         if (sessionId == null) {
            throw new NullPointerException("sessionId is marked non-null but is null");
         } else {
            this.sessionId = sessionId;
            return this;
         }
      }

      @Generated
      public TradeSessionBuilder initiatorId(@Nonnull UUID initiatorId) {
         if (initiatorId == null) {
            throw new NullPointerException("initiatorId is marked non-null but is null");
         } else {
            this.initiatorId = initiatorId;
            return this;
         }
      }

      @Generated
      public TradeSessionBuilder responderId(@Nonnull UUID responderId) {
         if (responderId == null) {
            throw new NullPointerException("responderId is marked non-null but is null");
         } else {
            this.responderId = responderId;
            return this;
         }
      }

      @Generated
      public TradeSessionBuilder buyerId(@Nonnull UUID buyerId) {
         if (buyerId == null) {
            throw new NullPointerException("buyerId is marked non-null but is null");
         } else {
            this.buyerId = buyerId;
            return this;
         }
      }

      @Generated
      public TradeSessionBuilder sellerId(@Nonnull UUID sellerId) {
         if (sellerId == null) {
            throw new NullPointerException("sellerId is marked non-null but is null");
         } else {
            this.sellerId = sellerId;
            return this;
         }
      }

      @Generated
      public TradeSessionBuilder matchedItem(@Nonnull Item matchedItem) {
         if (matchedItem == null) {
            throw new NullPointerException("matchedItem is marked non-null but is null");
         } else {
            this.matchedItem = matchedItem;
            return this;
         }
      }

      @Generated
      public TradeSessionBuilder bundleSize(int bundleSize) {
         this.bundleSize = bundleSize;
         return this;
      }

      @Generated
      public TradeSessionBuilder priceJitter(int priceJitter) {
         this.priceJitter = priceJitter;
         return this;
      }

      @Generated
      public TradeSessionBuilder buyerOffer(int buyerOffer) {
         this.buyerOffer = buyerOffer;
         return this;
      }

      @Generated
      public TradeSessionBuilder sellerAsk(int sellerAsk) {
         this.sellerAsk = sellerAsk;
         return this;
      }

      @Generated
      public TradeSessionBuilder negotiationRoundsRemaining(int negotiationRoundsRemaining) {
         this.negotiationRoundsRemaining = negotiationRoundsRemaining;
         return this;
      }

      @Generated
      public TradeSessionBuilder phase(@Nonnull TradeSessionPhase phase) {
         if (phase == null) {
            throw new NullPointerException("phase is marked non-null but is null");
         } else {
            this.phase = phase;
            return this;
         }
      }

      @Generated
      public TradeSessionBuilder phaseEnteredGameTime(long phaseEnteredGameTime) {
         this.phaseEnteredGameTime = phaseEnteredGameTime;
         return this;
      }

      @Generated
      public TradeSession build() {
         return new TradeSession(this.sessionId, this.initiatorId, this.responderId, this.buyerId, this.sellerId, this.matchedItem, this.bundleSize, this.priceJitter, this.buyerOffer, this.sellerAsk, this.negotiationRoundsRemaining, this.phase, this.phaseEnteredGameTime);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.sessionId);
         return "TradeSession.TradeSessionBuilder(sessionId=" + var10000 + ", initiatorId=" + String.valueOf(this.initiatorId) + ", responderId=" + String.valueOf(this.responderId) + ", buyerId=" + String.valueOf(this.buyerId) + ", sellerId=" + String.valueOf(this.sellerId) + ", matchedItem=" + String.valueOf(this.matchedItem) + ", bundleSize=" + this.bundleSize + ", priceJitter=" + this.priceJitter + ", buyerOffer=" + this.buyerOffer + ", sellerAsk=" + this.sellerAsk + ", negotiationRoundsRemaining=" + this.negotiationRoundsRemaining + ", phase=" + String.valueOf(this.phase) + ", phaseEnteredGameTime=" + this.phaseEnteredGameTime + ")";
      }
   }
}
