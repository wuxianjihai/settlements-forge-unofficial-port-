package dev.breezes.settlements.application.economy.catalog;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.domain.economy.catalog.TradeCatalogRegistry;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class TradePriceResolver_Factory implements Factory<TradePriceResolver> {
   private final Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider;

   private TradePriceResolver_Factory(Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider) {
      this.tradeCatalogRegistryProvider = tradeCatalogRegistryProvider;
   }

   public TradePriceResolver get() {
      return newInstance((TradeCatalogRegistry)this.tradeCatalogRegistryProvider.get());
   }

   public static TradePriceResolver_Factory create(Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider) {
      return new TradePriceResolver_Factory(tradeCatalogRegistryProvider);
   }

   public static TradePriceResolver newInstance(TradeCatalogRegistry tradeCatalogRegistry) {
      return new TradePriceResolver(tradeCatalogRegistry);
   }
}
