package dev.breezes.settlements.application.economy;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class VillagerWallet_Factory implements Factory<VillagerWallet> {
   public VillagerWallet get() {
      return newInstance();
   }

   public static VillagerWallet_Factory create() {
      return VillagerWallet_Factory.InstanceHolder.INSTANCE;
   }

   public static VillagerWallet newInstance() {
      return new VillagerWallet();
   }

   private static final class InstanceHolder {
      static final VillagerWallet_Factory INSTANCE = new VillagerWallet_Factory();
   }
}
