package dev.breezes.settlements.application.economy.supply;

import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.world.item.ItemStack;

public record ActiveSupply(@Nonnull ItemMatch match, @Nonnull ItemStack representative, int dumpableCount) {
   @Generated
   public static ActiveSupplyBuilder builder() {
      return new ActiveSupplyBuilder();
   }

   @Generated
   public static class ActiveSupplyBuilder {
      @Generated
      private ItemMatch match;
      @Generated
      private ItemStack representative;
      @Generated
      private int dumpableCount;

      @Generated
      ActiveSupplyBuilder() {
      }

      @Generated
      public ActiveSupplyBuilder match(@Nonnull ItemMatch match) {
         if (match == null) {
            throw new NullPointerException("match is marked non-null but is null");
         } else {
            this.match = match;
            return this;
         }
      }

      @Generated
      public ActiveSupplyBuilder representative(@Nonnull ItemStack representative) {
         if (representative == null) {
            throw new NullPointerException("representative is marked non-null but is null");
         } else {
            this.representative = representative;
            return this;
         }
      }

      @Generated
      public ActiveSupplyBuilder dumpableCount(int dumpableCount) {
         this.dumpableCount = dumpableCount;
         return this;
      }

      @Generated
      public ActiveSupply build() {
         return new ActiveSupply(this.match, this.representative, this.dumpableCount);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.match);
         return "ActiveSupply.ActiveSupplyBuilder(match=" + var10000 + ", representative=" + String.valueOf(this.representative) + ", dumpableCount=" + this.dumpableCount + ")";
      }
   }
}
