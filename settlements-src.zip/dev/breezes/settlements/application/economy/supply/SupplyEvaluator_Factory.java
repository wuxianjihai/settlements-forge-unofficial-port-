package dev.breezes.settlements.application.economy.supply;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.domain.economy.catalog.TradeCatalogRegistry;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class SupplyEvaluator_Factory implements Factory<SupplyEvaluator> {
   private final Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider;

   private SupplyEvaluator_Factory(Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider) {
      this.tradeCatalogRegistryProvider = tradeCatalogRegistryProvider;
   }

   public SupplyEvaluator get() {
      return newInstance((TradeCatalogRegistry)this.tradeCatalogRegistryProvider.get());
   }

   public static SupplyEvaluator_Factory create(Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider) {
      return new SupplyEvaluator_Factory(tradeCatalogRegistryProvider);
   }

   public static SupplyEvaluator newInstance(TradeCatalogRegistry tradeCatalogRegistry) {
      return new SupplyEvaluator(tradeCatalogRegistry);
   }
}
