package dev.breezes.settlements.application.economy.demand;

import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import javax.annotation.Nonnull;
import lombok.Generated;

public record ActiveDemand(@Nonnull ItemMatch match, int desiredCount, int priority, int basePricePerUnit, @Nonnull Origin origin) {
   public ActiveDemand {
      if (desiredCount <= 0) {
         throw new IllegalArgumentException("ActiveDemand desiredCount must be positive");
      } else if (priority < 0) {
         throw new IllegalArgumentException("ActiveDemand priority must be non-negative");
      } else if (basePricePerUnit <= 0) {
         throw new IllegalArgumentException("ActiveDemand basePricePerUnit must be positive");
      }
   }

   @Generated
   public static ActiveDemandBuilder builder() {
      return new ActiveDemandBuilder();
   }

   @Generated
   public static class ActiveDemandBuilder {
      @Generated
      private ItemMatch match;
      @Generated
      private int desiredCount;
      @Generated
      private int priority;
      @Generated
      private int basePricePerUnit;
      @Generated
      private Origin origin;

      @Generated
      ActiveDemandBuilder() {
      }

      @Generated
      public ActiveDemandBuilder match(@Nonnull ItemMatch match) {
         if (match == null) {
            throw new NullPointerException("match is marked non-null but is null");
         } else {
            this.match = match;
            return this;
         }
      }

      @Generated
      public ActiveDemandBuilder desiredCount(int desiredCount) {
         this.desiredCount = desiredCount;
         return this;
      }

      @Generated
      public ActiveDemandBuilder priority(int priority) {
         this.priority = priority;
         return this;
      }

      @Generated
      public ActiveDemandBuilder basePricePerUnit(int basePricePerUnit) {
         this.basePricePerUnit = basePricePerUnit;
         return this;
      }

      @Generated
      public ActiveDemandBuilder origin(@Nonnull Origin origin) {
         if (origin == null) {
            throw new NullPointerException("origin is marked non-null but is null");
         } else {
            this.origin = origin;
            return this;
         }
      }

      @Generated
      public ActiveDemand build() {
         return new ActiveDemand(this.match, this.desiredCount, this.priority, this.basePricePerUnit, this.origin);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.match);
         return "ActiveDemand.ActiveDemandBuilder(match=" + var10000 + ", desiredCount=" + this.desiredCount + ", priority=" + this.priority + ", basePricePerUnit=" + this.basePricePerUnit + ", origin=" + String.valueOf(this.origin) + ")";
      }
   }

   public static enum Origin {
      STATIC_SHORTFALL,
      SIGNAL,
      STATIC_BOOSTED_BY_SIGNAL;

      // $FF: synthetic method
      private static Origin[] $values() {
         return new Origin[]{STATIC_SHORTFALL, SIGNAL, STATIC_BOOSTED_BY_SIGNAL};
      }
   }
}
