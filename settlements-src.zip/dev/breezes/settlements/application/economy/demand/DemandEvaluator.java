package dev.breezes.settlements.application.economy.demand;

import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.economy.catalog.DemandEntry;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.economy.catalog.TradeCatalogRegistry;
import dev.breezes.settlements.domain.entities.VillagerProfessionKey;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import lombok.Generated;

@ServerScope
public final class DemandEvaluator {
   public static final int DEFAULT_BASE_PRICE_PER_UNIT = 4;
   private final TradeCatalogRegistry tradeCatalogRegistry;
   private final DemandSignalService demandSignalService;

   public List<ActiveDemand> resolve(@Nonnull BaseVillager villager) {
      return this.resolve(villager, false);
   }

   public List<ActiveDemand> resolveForPickup(@Nonnull BaseVillager villager) {
      return this.resolve(villager, true);
   }

   private List<ActiveDemand> resolve(@Nonnull BaseVillager villager, boolean usePickupThreshold) {
      long currentGameTime = villager.m_9236_().m_46467_();
      VillagerProfessionKey profession = villager.getProfession();
      List<DemandEntry> staticDemands = this.tradeCatalogRegistry.demandsFor(profession);
      Map<ItemMatch, ActiveDemand> activeByMatch = new LinkedHashMap();
      Map<ItemMatch, DemandEntry> staticDemandByMatch = new LinkedHashMap();

      for(DemandEntry demand : staticDemands) {
         staticDemandByMatch.put(demand.match(), demand);
         int threshold = usePickupThreshold ? demand.pickupDesiredMinCount() : demand.desiredMinCount();
         int currentCount = countMatchingInventory(villager, demand.match());
         int shortfall = Math.max(threshold - currentCount, 0);
         if (shortfall != 0) {
            activeByMatch.put(demand.match(), ActiveDemand.builder().match(demand.match()).desiredCount(shortfall).priority(demand.basePriority()).basePricePerUnit(demand.basePricePerUnit()).origin(ActiveDemand.Origin.STATIC_SHORTFALL).build());
         }
      }

      for(DemandSignal signal : this.demandSignalService.getSignals(villager, currentGameTime).entries()) {
         DemandEntry staticDemand = (DemandEntry)staticDemandByMatch.get(signal.match());
         if (staticDemand != null) {
            int threshold = usePickupThreshold ? staticDemand.pickupDesiredMinCount() : staticDemand.desiredMinCount();
            int currentCount = countMatchingInventory(villager, staticDemand.match());
            int shortfall = Math.max(threshold - currentCount, 0);
            int desiredCount = Math.max(shortfall, signal.desiredCount());
            activeByMatch.put(signal.match(), ActiveDemand.builder().match(signal.match()).desiredCount(desiredCount).priority(staticDemand.basePriority() + signal.priorityBoost()).basePricePerUnit(signal.pricePerUnitOverride() != null ? signal.pricePerUnitOverride() : staticDemand.basePricePerUnit()).origin(ActiveDemand.Origin.STATIC_BOOSTED_BY_SIGNAL).build());
         } else {
            activeByMatch.put(signal.match(), ActiveDemand.builder().match(signal.match()).desiredCount(signal.desiredCount()).priority(signal.priorityBoost()).basePricePerUnit(signal.pricePerUnitOverride() != null ? signal.pricePerUnitOverride() : 4).origin(ActiveDemand.Origin.SIGNAL).build());
         }
      }

      return activeByMatch.values().stream().sorted(Comparator.comparingInt(ActiveDemand::priority).reversed()).toList();
   }

   private static int countMatchingInventory(@Nonnull BaseVillager villager, @Nonnull ItemMatch match) {
      return villager.getSettlementsInventory().countMatching(match);
   }

   @Inject
   @Generated
   DemandEvaluator(TradeCatalogRegistry tradeCatalogRegistry, DemandSignalService demandSignalService) {
      this.tradeCatalogRegistry = tradeCatalogRegistry;
      this.demandSignalService = demandSignalService;
   }
}
