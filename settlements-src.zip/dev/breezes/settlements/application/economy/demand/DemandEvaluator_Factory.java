package dev.breezes.settlements.application.economy.demand;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import dev.breezes.settlements.domain.economy.catalog.TradeCatalogRegistry;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class DemandEvaluator_Factory implements Factory<DemandEvaluator> {
   private final Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider;
   private final Provider<DemandSignalService> demandSignalServiceProvider;

   private DemandEvaluator_Factory(Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider, Provider<DemandSignalService> demandSignalServiceProvider) {
      this.tradeCatalogRegistryProvider = tradeCatalogRegistryProvider;
      this.demandSignalServiceProvider = demandSignalServiceProvider;
   }

   public DemandEvaluator get() {
      return newInstance((TradeCatalogRegistry)this.tradeCatalogRegistryProvider.get(), (DemandSignalService)this.demandSignalServiceProvider.get());
   }

   public static DemandEvaluator_Factory create(Provider<TradeCatalogRegistry> tradeCatalogRegistryProvider, Provider<DemandSignalService> demandSignalServiceProvider) {
      return new DemandEvaluator_Factory(tradeCatalogRegistryProvider, demandSignalServiceProvider);
   }

   public static DemandEvaluator newInstance(TradeCatalogRegistry tradeCatalogRegistry, DemandSignalService demandSignalService) {
      return new DemandEvaluator(tradeCatalogRegistry, demandSignalService);
   }
}
