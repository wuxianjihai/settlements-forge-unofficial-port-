package dev.breezes.settlements.application.economy.demand;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class DemandSignalService_Factory implements Factory<DemandSignalService> {
   public DemandSignalService get() {
      return newInstance();
   }

   public static DemandSignalService_Factory create() {
      return DemandSignalService_Factory.InstanceHolder.INSTANCE;
   }

   public static DemandSignalService newInstance() {
      return new DemandSignalService();
   }

   private static final class InstanceHolder {
      static final DemandSignalService_Factory INSTANCE = new DemandSignalService_Factory();
   }
}
