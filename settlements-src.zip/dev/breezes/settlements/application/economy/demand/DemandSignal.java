package dev.breezes.settlements.application.economy.demand;

import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public record DemandSignal(@Nonnull ItemMatch match, int desiredCount, int priorityBoost, @Nullable Integer pricePerUnitOverride, @Nonnull String source, long createdGameTime, long lastTouchedGameTime) {
   public DemandSignal {
      if (desiredCount <= 0) {
         throw new IllegalArgumentException("DemandSignal desiredCount must be positive");
      } else if (priorityBoost < 0) {
         throw new IllegalArgumentException("DemandSignal priorityBoost must be non-negative");
      } else if (pricePerUnitOverride != null && pricePerUnitOverride <= 0) {
         throw new IllegalArgumentException("DemandSignal pricePerUnitOverride must be positive when present");
      } else if (source.isBlank()) {
         throw new IllegalArgumentException("DemandSignal source must not be blank");
      }
   }

   @Generated
   public static DemandSignalBuilder builder() {
      return new DemandSignalBuilder();
   }

   @Generated
   public static class DemandSignalBuilder {
      @Generated
      private ItemMatch match;
      @Generated
      private int desiredCount;
      @Generated
      private int priorityBoost;
      @Generated
      private Integer pricePerUnitOverride;
      @Generated
      private String source;
      @Generated
      private long createdGameTime;
      @Generated
      private long lastTouchedGameTime;

      @Generated
      DemandSignalBuilder() {
      }

      @Generated
      public DemandSignalBuilder match(@Nonnull ItemMatch match) {
         if (match == null) {
            throw new NullPointerException("match is marked non-null but is null");
         } else {
            this.match = match;
            return this;
         }
      }

      @Generated
      public DemandSignalBuilder desiredCount(int desiredCount) {
         this.desiredCount = desiredCount;
         return this;
      }

      @Generated
      public DemandSignalBuilder priorityBoost(int priorityBoost) {
         this.priorityBoost = priorityBoost;
         return this;
      }

      @Generated
      public DemandSignalBuilder pricePerUnitOverride(@Nullable Integer pricePerUnitOverride) {
         this.pricePerUnitOverride = pricePerUnitOverride;
         return this;
      }

      @Generated
      public DemandSignalBuilder source(@Nonnull String source) {
         if (source == null) {
            throw new NullPointerException("source is marked non-null but is null");
         } else {
            this.source = source;
            return this;
         }
      }

      @Generated
      public DemandSignalBuilder createdGameTime(long createdGameTime) {
         this.createdGameTime = createdGameTime;
         return this;
      }

      @Generated
      public DemandSignalBuilder lastTouchedGameTime(long lastTouchedGameTime) {
         this.lastTouchedGameTime = lastTouchedGameTime;
         return this;
      }

      @Generated
      public DemandSignal build() {
         return new DemandSignal(this.match, this.desiredCount, this.priorityBoost, this.pricePerUnitOverride, this.source, this.createdGameTime, this.lastTouchedGameTime);
      }

      @Generated
      public String toString() {
         String var10000 = String.valueOf(this.match);
         return "DemandSignal.DemandSignalBuilder(match=" + var10000 + ", desiredCount=" + this.desiredCount + ", priorityBoost=" + this.priorityBoost + ", pricePerUnitOverride=" + this.pricePerUnitOverride + ", source=" + this.source + ", createdGameTime=" + this.createdGameTime + ", lastTouchedGameTime=" + this.lastTouchedGameTime + ")";
      }
   }
}
