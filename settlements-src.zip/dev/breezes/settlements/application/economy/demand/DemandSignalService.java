package dev.breezes.settlements.application.economy.demand;

import dev.breezes.settlements.bootstrap.registry.attachments.AttachmentRegistry;
import dev.breezes.settlements.di.ServerScope;
import dev.breezes.settlements.domain.ai.conditions.ICondition;
import dev.breezes.settlements.domain.economy.catalog.ItemMatch;
import dev.breezes.settlements.domain.time.ClockTicks;
import dev.breezes.settlements.infrastructure.compat.AttachmentDataStore;
import dev.breezes.settlements.infrastructure.config.annotations.GeneralConfig;
import dev.breezes.settlements.infrastructure.minecraft.entities.villager.BaseVillager;
import jakarta.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;
import net.minecraft.world.entity.Entity;

@ServerScope
public final class DemandSignalService {
   private static final ClockTicks STALE_SIGNAL_CUTOFF = ClockTicks.hours((double)72.0F);

   public DemandSignalSet getSignals(@Nonnull BaseVillager villager, long currentGameTime) {
      DemandSignalState currentState = (DemandSignalState)AttachmentDataStore.getData((Entity)villager, AttachmentRegistry.VILLAGER_DEMAND_SIGNALS);
      DemandSignalSet current = currentState.demandSignalSet();
      DemandSignalSet pruned = current.removeStale(currentGameTime, STALE_SIGNAL_CUTOFF.getTicks());
      if (!pruned.equals(current)) {
         AttachmentDataStore.setData((Entity)villager, AttachmentRegistry.VILLAGER_DEMAND_SIGNALS, currentState.withDemandSignalSet(pruned));
      }

      return pruned;
   }

   public void emit(@Nonnull BaseVillager villager, @Nonnull ItemMatch key, int desiredCount, int priorityBoost, @Nullable Integer pricePerUnitOverride, @Nonnull String source, long currentGameTime) {
      DemandSignalState currentState = (DemandSignalState)AttachmentDataStore.getData((Entity)villager, AttachmentRegistry.VILLAGER_DEMAND_SIGNALS);
      DemandSignalSet current = currentState.demandSignalSet();
      long createdGameTime = (Long)current.find(key).map(DemandSignal::createdGameTime).orElse(currentGameTime);
      DemandSignal entry = DemandSignal.builder().match(key).desiredCount(desiredCount).priorityBoost(priorityBoost).pricePerUnitOverride(pricePerUnitOverride).source(source).createdGameTime(createdGameTime).lastTouchedGameTime(currentGameTime).build();
      DemandSignalSet updated = current.upsert(entry);
      if (!updated.equals(current)) {
         AttachmentDataStore.setData((Entity)villager, AttachmentRegistry.VILLAGER_DEMAND_SIGNALS, currentState.withDemandSignalSet(updated));
      }

   }

   public ICondition<BaseVillager> requireItem(@Nonnull ItemMatch match, int quantity, int priorityBoost, @Nonnull String source) {
      if (quantity <= 0) {
         throw new IllegalArgumentException("requireItem quantity must be positive");
      } else {
         String name = "RequireItem:" + match.asDebugString();
         return ICondition.<BaseVillager>named(name, (villager) -> {
            if (villager == null) {
               return false;
            } else if (GeneralConfig.bypassInventoryRequirements) {
               return true;
            } else if (villager.getSettlementsInventory().countMatching(match) >= quantity) {
               this.remove(villager, match);
               return true;
            } else {
               this.emit(villager, match, quantity, priorityBoost, (Integer)null, source, villager.m_9236_().m_46467_());
               return false;
            }
         });
      }
   }

   public ICondition<BaseVillager> requireAny(@Nonnull List<ItemMatch> matches, int quantity, int priorityBoost, @Nonnull String source) {
      if (matches.isEmpty()) {
         throw new IllegalArgumentException("requireAny matches must not be empty");
      } else if (quantity <= 0) {
         throw new IllegalArgumentException("requireAny quantity must be positive");
      } else {
         Stream var10000 = matches.stream().map(ItemMatch::asDebugString);
         String name = "RequireAny:" + (String)var10000.collect(Collectors.joining("|"));
         return ICondition.<BaseVillager>named(name, (villager) -> {
            if (villager == null) {
               return false;
            } else if (GeneralConfig.bypassInventoryRequirements) {
               return true;
            } else {
               for(ItemMatch match : matches) {
                  if (villager.getSettlementsInventory().countMatching(match) >= quantity) {
                     for(ItemMatch m : matches) {
                        this.remove(villager, m);
                     }

                     return true;
                  }
               }

               long now = villager.m_9236_().m_46467_();

               for(ItemMatch match : matches) {
                  this.emit(villager, match, quantity, priorityBoost, (Integer)null, source, now);
               }

               return false;
            }
         });
      }
   }

   public void remove(@Nonnull BaseVillager villager, @Nonnull ItemMatch key) {
      DemandSignalState currentState = (DemandSignalState)AttachmentDataStore.getData((Entity)villager, AttachmentRegistry.VILLAGER_DEMAND_SIGNALS);
      DemandSignalSet current = currentState.demandSignalSet();
      DemandSignalSet updated = current.remove(key);
      if (!updated.equals(current)) {
         AttachmentDataStore.setData((Entity)villager, AttachmentRegistry.VILLAGER_DEMAND_SIGNALS, currentState.withDemandSignalSet(updated));
      }

   }

   public int getVersion(@Nonnull BaseVillager villager) {
      return this.pruneAndGetState(villager, villager.m_9236_().m_46467_()).version();
   }

   private DemandSignalState pruneAndGetState(@Nonnull BaseVillager villager, long currentGameTime) {
      DemandSignalState currentState = (DemandSignalState)AttachmentDataStore.getData((Entity)villager, AttachmentRegistry.VILLAGER_DEMAND_SIGNALS);
      DemandSignalSet current = currentState.demandSignalSet();
      DemandSignalSet pruned = current.removeStale(currentGameTime, STALE_SIGNAL_CUTOFF.getTicks());
      if (pruned.equals(current)) {
         return currentState;
      } else {
         DemandSignalState updatedState = currentState.withDemandSignalSet(pruned);
         AttachmentDataStore.setData((Entity)villager, AttachmentRegistry.VILLAGER_DEMAND_SIGNALS, updatedState);
         return updatedState;
      }
   }

   @Inject
   @Generated
   DemandSignalService() {
   }
}
