package dev.breezes.settlements.application.settlement.persistence;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata("dev.breezes.settlements.di.ServerScope")
@QualifierMetadata
@DaggerGenerated
public final class SettlementMetadataQueueService_Factory implements Factory<SettlementMetadataQueueService> {
   public SettlementMetadataQueueService get() {
      return newInstance();
   }

   public static SettlementMetadataQueueService_Factory create() {
      return SettlementMetadataQueueService_Factory.InstanceHolder.INSTANCE;
   }

   public static SettlementMetadataQueueService newInstance() {
      return new SettlementMetadataQueueService();
   }

   private static final class InstanceHolder {
      static final SettlementMetadataQueueService_Factory INSTANCE = new SettlementMetadataQueueService_Factory();
   }
}
