package dev.breezes.settlements.application.enchanting.engine;

import dev.breezes.settlements.shared.util.RandomUtil;
import lombok.Generated;

public final class PowerBudgetCalculator {
   private static final double INTELLIGENCE_BASE_MULTIPLIER = (double)0.5F;
   private static final int POWER_PER_BOOKSHELF = 10;
   private static final double VARIATION_MIN = 0.8;
   private static final double VARIATION_MAX = 1.2;

   public static int calculate(int basePower, double intelligence, int bookshelfCount) {
      double budgetMultiplier = (double)0.5F + intelligence;
      int bookshelfBonus = bookshelfCount * 10;
      double rawPower = (double)basePower * budgetMultiplier + (double)bookshelfBonus;
      double variation = RandomUtil.randomDouble(0.8, 1.2);
      return Math.max(0, (int)(rawPower * variation));
   }

   @Generated
   private PowerBudgetCalculator() {
   }
}
