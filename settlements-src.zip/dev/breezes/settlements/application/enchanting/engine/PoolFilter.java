package dev.breezes.settlements.application.enchanting.engine;

import dev.breezes.settlements.domain.enchanting.EnchantmentCostData;
import dev.breezes.settlements.domain.entities.Expertise;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nonnull;
import lombok.Generated;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;

public final class PoolFilter {
   public static List<EnchantmentCostData> filter(@Nonnull Collection<EnchantmentCostData> allCosts, @Nonnull ItemStack item, @Nonnull List<Enchantment> appliedThisSession, @Nonnull Expertise villagerTier, int remainingBudget, @Nonnull RegistryAccess registryAccess) {
      return allCosts.stream().filter((cost) -> isItemEligible(cost, item, registryAccess)).filter((cost) -> isSessionCompatible(cost, appliedThisSession, registryAccess)).filter((cost) -> isTierEligible(cost, villagerTier)).filter((cost) -> isAffordable(cost, remainingBudget)).toList();
   }

   private static boolean isItemEligible(@Nonnull EnchantmentCostData cost, @Nonnull ItemStack item, @Nonnull RegistryAccess registryAccess) {
      return !item.m_150930_(Items.f_42517_) && !item.m_150930_(Items.f_42690_) ? (Boolean)resolveEnchantment(cost.enchantmentId(), registryAccess).map((enchantment) -> enchantment.m_6081_(item)).orElse(false) : true;
   }

   private static boolean isSessionCompatible(@Nonnull EnchantmentCostData cost, @Nonnull List<Enchantment> appliedThisSession, @Nonnull RegistryAccess registryAccess) {
      Optional<Enchantment> candidate = resolveEnchantment(cost.enchantmentId(), registryAccess);
      if (candidate.isEmpty()) {
         return false;
      } else {
         Enchantment candidateEnch = (Enchantment)candidate.get();

         for(Enchantment applied : appliedThisSession) {
            if (!candidateEnch.m_44695_(applied)) {
               return false;
            }
         }

         return true;
      }
   }

   private static boolean isTierEligible(@Nonnull EnchantmentCostData cost, @Nonnull Expertise villagerTier) {
      return cost.minTierOrdinal() <= villagerTier.ordinal();
   }

   private static boolean isAffordable(@Nonnull EnchantmentCostData cost, int remainingBudget) {
      return cost.baseCost() <= remainingBudget;
   }

   public static Optional<Enchantment> resolveEnchantment(@Nonnull String enchantmentId, @Nonnull RegistryAccess registryAccess) {
      ResourceLocation location = new ResourceLocation(enchantmentId);
      Enchantment enchantment = (Enchantment)registryAccess.m_175515_(Registries.f_256762_).m_7745_(location);
      return Optional.ofNullable(enchantment);
   }

   @Generated
   private PoolFilter() {
   }
}
