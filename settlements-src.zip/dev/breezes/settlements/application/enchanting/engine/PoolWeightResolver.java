package dev.breezes.settlements.application.enchanting.engine;

import dev.breezes.settlements.domain.enchanting.EnchantmentCostData;
import dev.breezes.settlements.domain.enchanting.SpecializationProfile;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.Generated;

public final class PoolWeightResolver {
   public static Map<EnchantmentCostData, Double> resolve(@Nonnull List<EnchantmentCostData> filteredPool, @Nullable SpecializationProfile profile) {
      Map<EnchantmentCostData, Double> weightedPool = new LinkedHashMap();

      for(EnchantmentCostData entry : filteredPool) {
         double weight = profile != null ? (double)profile.getWeight(entry.enchantmentId()) : (double)1.0F;
         if (weight > (double)0.0F) {
            weightedPool.put(entry, weight);
         }
      }

      return weightedPool;
   }

   @Generated
   private PoolWeightResolver() {
   }
}
