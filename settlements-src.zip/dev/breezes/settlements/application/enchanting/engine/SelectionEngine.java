package dev.breezes.settlements.application.enchanting.engine;

import dev.breezes.settlements.domain.enchanting.EnchantmentCostData;
import dev.breezes.settlements.shared.util.RandomUtil;
import java.util.Map;
import javax.annotation.Nonnull;
import lombok.Generated;

public final class SelectionEngine {
   public static EnchantmentCostData selectWeighted(@Nonnull Map<EnchantmentCostData, Double> weightedPool) {
      return (EnchantmentCostData)RandomUtil.weightedChoice(weightedPool);
   }

   public static int calculateLevel(@Nonnull EnchantmentCostData cost, int remainingBudget) {
      int maxAffordable = findMaxAffordableLevel(cost, remainingBudget);
      int capped = Math.min(maxAffordable, cost.maxLevel());
      if (capped <= 1) {
         return 1;
      } else {
         double roll1 = RandomUtil.randomDouble((double)1.0F, (double)capped);
         double roll2 = RandomUtil.randomDouble((double)1.0F, (double)capped);
         int result = (int)Math.round(Math.max(roll1, roll2));
         return Math.max(1, result);
      }
   }

   private static int findMaxAffordableLevel(@Nonnull EnchantmentCostData cost, int remainingBudget) {
      if (cost.levelMultiplier() == 0) {
         return cost.baseCost() <= remainingBudget ? 1 : 0;
      } else {
         int maxLevel = (remainingBudget - cost.baseCost()) / cost.levelMultiplier() + 1;
         return Math.max(0, maxLevel);
      }
   }

   @Generated
   private SelectionEngine() {
   }
}
